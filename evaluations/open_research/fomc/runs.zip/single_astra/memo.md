# Investment research memo

As of 2023-03-22

**Research question**
As of 22 March 2023, how did the Federal Reserve change its federal funds target range, and how did banking stress affect its policy guidance and the outlook for credit?

## Answer

On 2023-03-22, the Federal Open Market Committee raised its federal funds target range by 25 basis points. The resulting range of four and three-quarters to five percent is an unverified question premise: contemporaneous reporting confirms the size of the U.S. hike but not its endpoints. The Fed tightened that day while leaving the next move open, because more cautious bank lending could do some of the work of another rate increase. [1](https://web.archive.org/web/20230322233926/https://www.reuters.com/markets/rates-bonds/fed-stay-course-with-25-bps-rate-hike-march-22-2023-03-17/#:~:text=Macro%20MatterscategorySouth%20Korea%27s%20Sept%20inflation%20slows%20but%20tightening%20bias,Reserve%20delivered%20a%20rate%20hike%20of%20the%20same%20margin.) [2](https://web.archive.org/web/20230322220016/https://www.federalreserve.gov/monetarypolicy/fomc.htm#:~:text=Guide%20to%20the%20Summary%20of%20Economic%20Projections%20The%20term,gave%20the%20Federal%20Reserve%20responsibility%20for%20setting%20monetary%20policy.)

## Evidence

The guidance change supplied in the question—from “ongoing increases” to “some additional policy firming may be appropriate”—made further tightening conditional; it did not announce a pause or abandon the inflation objective. Before the decision, market pricing had briefly swung from a larger hike to a pause after regional bank failures. Economists polled later mostly expected a quarter-point move but disagreed about where rates would peak. Those views concerned different horizons: agreement about the March move did not imply agreement about the next one. The excerpts document that distinction but do not independently reproduce the statement. [3](https://web.archive.org/web/20230322233926/https://www.reuters.com/markets/rates-bonds/fed-stay-course-with-25-bps-rate-hike-march-22-2023-03-17/#:~:text=BENGALURU%2C%20March%2017%20%28Reuters%29%20-%20The%20U.S.%20Federal%20Reserve,one%20point%20following%20the%20failure%20of%20some%20regional%20banks.) [4](https://en.wikipedia.org/w/index.php?oldid=1146117188)

## Outlook

The base case was tighter credit for households and businesses, not a demonstrated nationwide credit crunch. After the run at Silicon Valley Bank, other banks had reason to conserve cash by applying stricter loan standards. Even with the policy rate unchanged after March, reduced access to loans would tend to restrain spending, hiring and ultimately inflation. The direction was more predictable than the magnitude: the available evidence measures neither how broadly banks would tighten nor for how long, so it cannot translate the shock into an equivalent rate hike. [5](https://en.wikipedia.org/w/index.php?oldid=1146126744) [6](https://web.archive.org/web/20230322220016/https://www.federalreserve.gov/monetarypolicy/fomc.htm#:~:text=The%20Federal%20Reserve%20controls%20the%20three%20tools%20of%20monetary,the%20Committee%27s%20assessment%20of%20the%20economy%20and%20policy%20options.)

## What would change the view

The strongest alternative was that depositor protection would contain the stress and leave lending outside the affected banks largely intact. Stable deposits, little change in reported lending standards and resilient lending alongside persistent inflation would strengthen the case for another hike. Broadly tighter standards and weaker lending, by contrast, would support waiting to see how much demand slowed. Protecting Silicon Valley Bank’s depositors was evidence for containment, not proof that other banks would keep lending on the same terms. [5](https://en.wikipedia.org/w/index.php?oldid=1146126744) [7](https://web.archive.org/web/20230322220016/https://www.federalreserve.gov/monetarypolicy/fomc.htm#:~:text=The%20FOMC%20holds%20eight%20regularly%20scheduled%20meetings%20per%20year.,available%20online.%20Jerome%20H.%20Powell%2C%20Board%20of%20Governors%2C%20Chair)

## Sources

1. [Fed to stay the course with 25 bps rate hike on March 22: Reuters poll | Reuters](https://web.archive.org/web/20230322233926/https://www.reuters.com/markets/rates-bonds/fed-stay-course-with-25-bps-rate-hike-march-22-2023-03-17/#:~:text=Macro%20MatterscategorySouth%20Korea%27s%20Sept%20inflation%20slows%20but%20tightening%20bias,Reserve%20delivered%20a%20rate%20hike%20of%20the%20same%20margin.), available by 2023-03-22.
2. [The Fed - Federal Open Market Committee](https://web.archive.org/web/20230322220016/https://www.federalreserve.gov/monetarypolicy/fomc.htm#:~:text=Guide%20to%20the%20Summary%20of%20Economic%20Projections%20The%20term,gave%20the%20Federal%20Reserve%20responsibility%20for%20setting%20monetary%20policy.), available by 2023-03-22.
3. [Fed to stay the course with 25 bps rate hike on March 22: Reuters poll | Reuters](https://web.archive.org/web/20230322233926/https://www.reuters.com/markets/rates-bonds/fed-stay-course-with-25-bps-rate-hike-march-22-2023-03-17/#:~:text=BENGALURU%2C%20March%2017%20%28Reuters%29%20-%20The%20U.S.%20Federal%20Reserve,one%20point%20following%20the%20failure%20of%20some%20regional%20banks.), available by 2023-03-22.
4. [Federal Reserve](https://en.wikipedia.org/w/index.php?oldid=1146117188), available by 2023-03-22.
5. [Silicon Valley Bank](https://en.wikipedia.org/w/index.php?oldid=1146126744), available by 2023-03-22.
6. [The Fed - Federal Open Market Committee](https://web.archive.org/web/20230322220016/https://www.federalreserve.gov/monetarypolicy/fomc.htm#:~:text=The%20Federal%20Reserve%20controls%20the%20three%20tools%20of%20monetary,the%20Committee%27s%20assessment%20of%20the%20economy%20and%20policy%20options.), available by 2023-03-22.
7. [The Fed - Federal Open Market Committee](https://web.archive.org/web/20230322220016/https://www.federalreserve.gov/monetarypolicy/fomc.htm#:~:text=The%20FOMC%20holds%20eight%20regularly%20scheduled%20meetings%20per%20year.,available%20online.%20Jerome%20H.%20Powell%2C%20Board%20of%20Governors%2C%20Chair), available by 2023-03-22.
