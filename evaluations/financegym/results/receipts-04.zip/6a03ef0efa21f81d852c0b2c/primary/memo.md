# Investment research memo

As of 2025-06-25

**Research question**
What factors drove the significant surge in institutional accumulation of the Invesco Variable Rate Preferred ETF (VRP) during Q4 2024 and Q1 2025, and how does this concentrated positioning reflect professional sentiment regarding interest rate volatility and banking sector credit risk?

## Answer

As of 2025-06-25, a material increase in institutional holdings of VRP during either Q4 2024 or Q1 2025 is an unverified question premise. The filing excerpt names Scion Asset Management as a reporting manager, not as a VRP buyer. The available records give no VRP share counts, so neither the size of either quarter’s change nor the largest buyers’ contribution can be determined. The evidence establishes neither a rate-volatility hedge nor confidence in bank credit. [1](https://web.archive.org/web/20250517133050/https://www.sec.gov/Archives/edgar/data/1649339/000187920225000025/xslForm13F_X02/primary_doc.xml#:~:text=adds%20new%20holdings%20entries.%20Institutional%20Investment%20Manager%20Filing%20this%20Report%3A%20Scion%20Asset%20Management%2C%20LLC) [2](https://web.archive.org/web/20250517133050/https://www.sec.gov/Archives/edgar/data/1649339/000187920225000025/xslForm13F_X02/primary_doc.xml#:~:text=Number%20of%20Other%20Included%20Managers%3A%20Form%2013F%20Information%20Table%20Entry%20Total%3A%20Form%2013F%20Information%20Table%20Value%20Total%3A)

## Evidence

The test is a change in shares, not in reported market value. Compare each manager’s VRP shares at the September, December and March quarter-ends, reconciling amendments and excluding option positions. For each quarter, report the aggregate net change relative to starting shares, then rank managers by shares added. Show the largest buyers’ additions both as a share of gross additions and, if holdings rose, as a share of the net increase. Sales by other managers can make the latter ratio look large even when buying was spread across many firms. [3](https://en.wikipedia.org/w/index.php?oldid=1223018657) [4](https://web.archive.org/web/20250517133050/https://www.sec.gov/Archives/edgar/data/1649339/000187920225000025/xslForm13F_X02/primary_doc.xml#:~:text=Signature%2C%20Place%2C%20and%20Date%20of%20Signing%3A%20Please%20note%20that,13f-1%28c%29%20%5B17%20CFR%20240.13f-1%28c%29%5D%20Report%20Type%20%28Check%20only%20one.%29%3A)

## Outlook

If accumulation is verified, the rate explanation is the better-supported hypothesis to test. Treasury yields rose after the December Fed announcement; by March, more officials expected no cuts that year. Those observations concern different things—a market reaction and a policy outlook—but both gave managers reason to reconsider fixed-rate exposure. A shift into resetting dividends could reduce sensitivity to rising yields while retaining preferred income. That is not the same as a hedge that profits from volatility, and the policy news does not establish a buyer’s motive. [5](https://web.archive.org/web/20250618210758/https://www.cnbc.com/2024/12/18/fed-rate-decision-december-2024-.html#:~:text=%22Today%20was%20a%20closer%20call%20but%20we%20decided%20it,think%20going%20forward%20obviously%20we%27re%20moving%20slower%2C%22%20Powell%20said.) [6](https://web.archive.org/web/20250607182556/https://www.cnbc.com/2025/03/19/fed-rate-decision-march-2025.html#:~:text=The%20group%20downgraded%20its%20collective%20outlook%20for%20economic%20growth,rate%20settles%20in%20at%20a%20longer-run%20level%20around%203%25.) [7](https://en.wikipedia.org/w/index.php?oldid=1255556769)

## What would change the view

The strongest competing interpretation is willingness to take more bank credit risk for income. A dividend reset can change the payout rate without protecting the payout itself. To distinguish the explanations, verify VRP’s bank issuer weights and examine the buyers’ other holdings: sales of fixed-rate preferreds from comparable issuers alongside VRP additions, with total bank exposure little changed, would favor rate management. Broad additions to bank preferreds across coupon types would favor a credit allocation. Even then, concentration among a few managers would describe those managers’ positioning, not professional sentiment generally. [7](https://en.wikipedia.org/w/index.php?oldid=1255556769) [3](https://en.wikipedia.org/w/index.php?oldid=1223018657)

## Sources

1. [SEC FORM 13F-HR](https://web.archive.org/web/20250517133050/https://www.sec.gov/Archives/edgar/data/1649339/000187920225000025/xslForm13F_X02/primary_doc.xml#:~:text=adds%20new%20holdings%20entries.%20Institutional%20Investment%20Manager%20Filing%20this%20Report%3A%20Scion%20Asset%20Management%2C%20LLC), available by 2025-05-17.
2. [SEC FORM 13F-HR](https://web.archive.org/web/20250517133050/https://www.sec.gov/Archives/edgar/data/1649339/000187920225000025/xslForm13F_X02/primary_doc.xml#:~:text=Number%20of%20Other%20Included%20Managers%3A%20Form%2013F%20Information%20Table%20Entry%20Total%3A%20Form%2013F%20Information%20Table%20Value%20Total%3A), available by 2025-05-17.
3. [Form 13F](https://en.wikipedia.org/w/index.php?oldid=1223018657), available by 2024-05-09.
4. [SEC FORM 13F-HR](https://web.archive.org/web/20250517133050/https://www.sec.gov/Archives/edgar/data/1649339/000187920225000025/xslForm13F_X02/primary_doc.xml#:~:text=Signature%2C%20Place%2C%20and%20Date%20of%20Signing%3A%20Please%20note%20that,13f-1%28c%29%20%5B17%20CFR%20240.13f-1%28c%29%5D%20Report%20Type%20%28Check%20only%20one.%29%3A), available by 2025-05-17.
5. [Fed meeting December 2024: Fed cuts rate by a quarter point](https://web.archive.org/web/20250618210758/https://www.cnbc.com/2024/12/18/fed-rate-decision-december-2024-.html#:~:text=%22Today%20was%20a%20closer%20call%20but%20we%20decided%20it,think%20going%20forward%20obviously%20we%27re%20moving%20slower%2C%22%20Powell%20said.), available by 2025-06-18.
6. [Fed rate decision March 2025: Fed holds interest rates steady](https://web.archive.org/web/20250607182556/https://www.cnbc.com/2025/03/19/fed-rate-decision-march-2025.html#:~:text=The%20group%20downgraded%20its%20collective%20outlook%20for%20economic%20growth,rate%20settles%20in%20at%20a%20longer-run%20level%20around%203%25.), available by 2025-06-07.
7. [Preferred stock](https://en.wikipedia.org/w/index.php?oldid=1255556769), available by 2024-11-05.
