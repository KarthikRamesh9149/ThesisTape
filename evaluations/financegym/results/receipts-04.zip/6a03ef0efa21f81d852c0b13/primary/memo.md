# Investment research memo

As of 2025-06-05

**Research question**
Given the divestiture of the French Workwear unit to H.I.G. Capital and divergent institutional flows, how should Rentokil Initial’s (RTO) valuation of 25 times earnings be reconciled with its shifting business mix and JPMorgan’s cautious neutral rating?

Some parts of the question could not be established from eligible evidence.

## Answer

As of 2025-06-05, JPMorgan’s neutral stance is better supported than a premium for Rentokil Initial. The French Workwear sale to H.I.G. Capital and the rating are unverified question premises. Taking the sale as given, Rentokil loses a business that earned £41m in adjusted operating profit at actual exchange rates in 2024. The benefit of a tighter focus on pest control and hygiene is plausible, but the main North American margin opportunity still depends on completing the Terminix integration. [1](https://web.archive.org/web/20250408055523/https://www.rentokil-initial.com/~/media/Files/R/Rentokil/documents/2024-preliminary-results.pdf#:~:text=11%20France%20Workwear%202024%20AER%20%C2%A3m%20AER%20Growth%202024,up%204.6ppt%20to%2082.0%25.%20All%20Regions%20except%20Europe%20improved) [2](https://web.archive.org/web/20250408055523/https://www.rentokil-initial.com/~/media/Files/R/Rentokil/documents/2024-preliminary-results.pdf#:~:text=8%20Three%20years%20post%20the%20acquisition%20announcement%20of%20Terminix%2C,%C2%A3m%20AER%20Growth%202024%20CER%20%C2%A3m%20CER%20Growth%20Organic)

## Evidence

The mix shift is not an automatic growth or margin upgrade. In 2024, French Workwear grew organically by 7.1% at a 17.7% adjusted operating margin. Retained Hygiene & Wellbeing grew organically by only 3.1%; its margin was higher at 18.1%, but fell 30bps. The sale therefore removes a faster-growing contributor than Hygiene, not an obvious margin drag. These segment comparisons do not establish the growth rate or margin of the whole remaining group. [1](https://web.archive.org/web/20250408055523/https://www.rentokil-initial.com/~/media/Files/R/Rentokil/documents/2024-preliminary-results.pdf#:~:text=11%20France%20Workwear%202024%20AER%20%C2%A3m%20AER%20Growth%202024,up%204.6ppt%20to%2082.0%25.%20All%20Regions%20except%20Europe%20improved) [3](https://web.archive.org/web/20250408055523/https://www.rentokil-initial.com/~/media/Files/R/Rentokil/documents/2024-preliminary-results.pdf#:~:text=Growth%202024%20CER%20%C2%A3m%20CER%20Growth%20Organic%20Growth%20Revenue,revenues%20of%20c.%C2%A350m%20in%20the%20year%20prior%20to%20purchase.)

## Outlook

The neutral base case gives Terminix savings credit as they appear in results, not at the sale date. Management expects c.$100m of remaining one-time integration costs through 2026. Its estimate of $100m in lower spending *after* integration is measured against 2024 spending; it is not an immediate net earnings gain. Management also retired the group adjusted margin target of more than 19% by 2026. That matters when group free cash flow had already fallen to £410m from £500m in the preceding year. [2](https://web.archive.org/web/20250408055523/https://www.rentokil-initial.com/~/media/Files/R/Rentokil/documents/2024-preliminary-results.pdf#:~:text=8%20Three%20years%20post%20the%20acquisition%20announcement%20of%20Terminix%2C,%C2%A3m%20AER%20Growth%202024%20CER%20%C2%A3m%20CER%20Growth%20Organic) [4](https://web.archive.org/web/20250408055523/https://www.rentokil-initial.com/~/media/Files/R/Rentokil/documents/2024-preliminary-results.pdf#:~:text=25.1%25%29.%2013%20Net%20debt%20and%20cash%20flow%20%C2%A3m%20at,%283%2C146%29%20%283%2C279%29%20133%20Closing%20net%20debt%20%283%2C208%29%20%283%2C146%29%20%2862%29)

## What would change the view

The strongest premium case is that combining branches makes technicians more productive while organic growth recovers. The observable test is sustained North American organic growth improvement alongside operating margins above 20% from 2027, management’s regional expectation rather than a replacement group target. If that improvement translates into stronger group cash flow, a premium on verified continuing earnings would have support. Divergent institutional flows, another unverified question premise, would not change the call: even confirmed changes in holdings would show who owned the shares, not what the business will earn. [2](https://web.archive.org/web/20250408055523/https://www.rentokil-initial.com/~/media/Files/R/Rentokil/documents/2024-preliminary-results.pdf#:~:text=8%20Three%20years%20post%20the%20acquisition%20announcement%20of%20Terminix%2C,%C2%A3m%20AER%20Growth%202024%20CER%20%C2%A3m%20CER%20Growth%20Organic)

## Sources

1. [Archived PDF](https://web.archive.org/web/20250408055523/https://www.rentokil-initial.com/~/media/Files/R/Rentokil/documents/2024-preliminary-results.pdf#:~:text=11%20France%20Workwear%202024%20AER%20%C2%A3m%20AER%20Growth%202024,up%204.6ppt%20to%2082.0%25.%20All%20Regions%20except%20Europe%20improved), available by 2025-04-08.
2. [Archived PDF](https://web.archive.org/web/20250408055523/https://www.rentokil-initial.com/~/media/Files/R/Rentokil/documents/2024-preliminary-results.pdf#:~:text=8%20Three%20years%20post%20the%20acquisition%20announcement%20of%20Terminix%2C,%C2%A3m%20AER%20Growth%202024%20CER%20%C2%A3m%20CER%20Growth%20Organic), available by 2025-04-08.
3. [Archived PDF](https://web.archive.org/web/20250408055523/https://www.rentokil-initial.com/~/media/Files/R/Rentokil/documents/2024-preliminary-results.pdf#:~:text=Growth%202024%20CER%20%C2%A3m%20CER%20Growth%20Organic%20Growth%20Revenue,revenues%20of%20c.%C2%A350m%20in%20the%20year%20prior%20to%20purchase.), available by 2025-04-08.
4. [Archived PDF](https://web.archive.org/web/20250408055523/https://www.rentokil-initial.com/~/media/Files/R/Rentokil/documents/2024-preliminary-results.pdf#:~:text=25.1%25%29.%2013%20Net%20debt%20and%20cash%20flow%20%C2%A3m%20at,%283%2C146%29%20%283%2C279%29%20133%20Closing%20net%20debt%20%283%2C208%29%20%283%2C146%29%20%2862%29), available by 2025-04-08.
