# Investment research memo

As of 2025-07-16

**Research question**
Despite Microsoft’s Azure reporting 33% revenue growth in FY25 Q3 driven by AI services, why has the options market exhibited persistent bearish sentiment through call sweeps at $400, $440, and $490 strikes? Does this suggest a valuation disconnect or anticipation of rising infrastructure costs?

## Answer

No. As of 2025-07-16, the claim that MSFT options traders executed call sweeps at the named strikes is an unverified premise of the question. A strike is the price at which the holder can buy shares, not a forecast of where Microsoft will trade. The available evidence does not show who initiated the trades, how much exposure changed hands or whether traders repeatedly added bearish positions across sessions. There is therefore no established bearish pattern to explain by either an excessive valuation or rising infrastructure costs. [1](https://web.archive.org/web/20250614215141/https://www.theocc.com/getmedia/a151a9ae-d784-4a15-bdeb-23a029f50b70/riskstoc.pdf#:~:text=7%20EXERCISE%20PRICE%20%E2%80%94%20In%20the%20case%20of%20a,market%20on%20which%20each%20series%20is%20traded%20before%20the) [2](https://en.wikipedia.org/w/index.php?oldid=1282937596)

## Evidence

Even a confirmed seller-initiated sweep would be ambiguous. Selling a previously purchased call removes upside exposure without opening a short position. Selling a call against shares can leave the investor net long, and a call sale paired with another option can have a different payoff from the sale in isolation. The strongest bearish alternative would be repeated sales opening new short-call positions without offsetting legs. [2](https://en.wikipedia.org/w/index.php?oldid=1282937596)

The base case for Microsoft’s cloud business is that new capacity supported growth; its effect on profitability remains open. In the fiscal third quarter, Azure and other cloud services revenue grew 33% as reported and 35% in constant currency, with 16 points of growth from AI services. Microsoft also reported stronger non-AI enterprise growth and said AI capacity came online faster than expected. That explains how investment could lift sales, but revenue growth does not measure the cost of serving them. [3](https://web.archive.org/web/20250702033707/https://www.microsoft.com/en-us/investor/events/fy-2025/earnings-fy-2025-q3#:~:text=Next%2C%20the%20Intelligent%20Cloud%20segment.%20Revenue%20was%20%2426.8%20billion,reflective%20of%20the%20continued%20customer%20shift%20to%20cloud%20offerings.)

## Outlook

Infrastructure margin pressure is the better-grounded risk to monitor, not the better-established trading motive. Microsoft planned to invest $80 billion in AI and data centers in fiscal 2025. That annual investment plan is not a quarterly expense: margins could narrow if depreciation and operating costs rise faster than revenue from new capacity. A declining cloud gross margin that management attributes to those costs would support that case. Stable margins alongside a share-price decline relative to unchanged forward earnings estimates would favor the valuation alternative. The record supplies neither the margin trend nor a contemporaneous earnings multiple. [4](https://en.wikipedia.org/w/index.php?oldid=1298945178) [3](https://web.archive.org/web/20250702033707/https://www.microsoft.com/en-us/investor/events/fy-2025/earnings-fy-2025-q3#:~:text=Next%2C%20the%20Intelligent%20Cloud%20segment.%20Revenue%20was%20%2426.8%20billion,reflective%20of%20the%20continued%20customer%20shift%20to%20cloud%20offerings.)

## What would change the view

To upgrade the flow from ambiguous to bearish, look for dated trades across sessions with contract sizes, expiries and execution prices relative to the bid and ask. Opening-sale records, checked against linked stock and option legs, would show whether traders repeatedly added net downside exposure. Rising open interest alone would not identify which side initiated the trades; even confirmed bearish exposure would not distinguish a valuation thesis from a margin thesis. [2](https://en.wikipedia.org/w/index.php?oldid=1282937596)

## Sources

1. [Archived PDF](https://web.archive.org/web/20250614215141/https://www.theocc.com/getmedia/a151a9ae-d784-4a15-bdeb-23a029f50b70/riskstoc.pdf#:~:text=7%20EXERCISE%20PRICE%20%E2%80%94%20In%20the%20case%20of%20a,market%20on%20which%20each%20series%20is%20traded%20before%20the), available by 2025-06-14.
2. [Option (finance)](https://en.wikipedia.org/w/index.php?oldid=1282937596), available by 2025-03-29.
3. [Microsoft Fiscal Year 2025 Third Quarter Earnings Conference Call](https://web.archive.org/web/20250702033707/https://www.microsoft.com/en-us/investor/events/fy-2025/earnings-fy-2025-q3#:~:text=Next%2C%20the%20Intelligent%20Cloud%20segment.%20Revenue%20was%20%2426.8%20billion,reflective%20of%20the%20continued%20customer%20shift%20to%20cloud%20offerings.), available by 2025-07-02.
4. [Microsoft Azure](https://en.wikipedia.org/w/index.php?oldid=1298945178), available by 2025-07-05.
