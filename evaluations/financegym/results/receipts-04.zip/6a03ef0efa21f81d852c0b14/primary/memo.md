# Investment research memo

As of 2025-06-10

**Research question**
Despite Zebra Technologies beating Q1 EPS estimates and receiving significant capital inflows from Norges Bank and GAMMA Investing, major analysts like Truist and Barclays sharply reduced price targets in June 2025. What underlying debt-to-equity risks and segment growth decelerations justify this bearish shift in valuation?

## Answer

As of 2025-06-10, the supplied record does not verify that Truist or Barclays cut its ZBRA price target between the start of June and the cutoff. Neither the size of either reported cut nor its rationale is established. The passages document a retail product showcase and past acquisitions, not analyst actions. That leaves the June timing unconfirmed, not disproved. [1](https://web.archive.org/web/20250306102900/https://www.nasdaq.com/press-release/zebra-technologies-to-unveil-new-solutions-at-nrf-2024-advancing-the-modern-store#:~:text=Company%20will%20showcase%20solutions%20that%20empower%20retailers%20to%20elevate,providing%20the%20agility%20needed%20to%20adapt%20for%20the%20future.) [2](https://en.wikipedia.org/w/index.php?oldid=1280238497)

## Evidence

Leverage could justify a lower equity valuation if debt obligations left shareholders more exposed to a decline in operating cash flow. But the $3.45 billion Motorola enterprise transaction was an acquisition price, not a current debt balance. The record gives neither current debt nor book equity, so it cannot establish a high or rising debt-to-equity ratio. Interest coverage and cash flow would help distinguish genuine repayment pressure from a ratio elevated by a small equity base. [2](https://en.wikipedia.org/w/index.php?oldid=1280238497)

Slower segment sales growth could warrant lower forward earnings estimates even after a quarterly EPS beat, but product announcements are not sales results. The record lacks comparable segment growth rates across successive quarters. The reported Q1 EPS beat and significant inflows from Norges Bank and GAMMA Investing are unverified question premises. Even confirmed purchases of existing shares would not put cash on Zebra’s balance sheet or reduce its debt. [3](https://web.archive.org/web/20250306102900/https://www.nasdaq.com/press-release/zebra-technologies-to-unveil-new-solutions-at-nrf-2024-advancing-the-modern-store#:~:text=Engage%20Associates%20to%20Drive%20Productivity%20Eight%20in%2010%20retail,cost%20of%20lost%20devices%20and%20driving%20productivity%20for%20retailers.) [4](https://web.archive.org/web/20250306102900/https://www.nasdaq.com/press-release/zebra-technologies-to-unveil-new-solutions-at-nrf-2024-advancing-the-modern-store#:~:text=Launching%20at%20NRF%2C%20the%20new%20AI-powered%20Workcloud%20Modeling%20Studio,visibility%20to%20maximize%20accuracy%20without%20an%20expensive%20infrastructure%20investment.)

## What would change the view

The base case is to make no valuation adjustment on these claims alone. The strongest bearish alternative is that slowing demand reduced expected operating cash flow while debt service remained fixed. Sustained declines in comparable segment growth and weakening interest coverage would support that interpretation; stable growth and improving coverage would weaken it. To settle the separate timing and attribution questions, look for each broker’s dated note, prior and revised targets, and stated reasons: a June recap of an earlier action would not establish a June cut. [1](https://web.archive.org/web/20250306102900/https://www.nasdaq.com/press-release/zebra-technologies-to-unveil-new-solutions-at-nrf-2024-advancing-the-modern-store#:~:text=Company%20will%20showcase%20solutions%20that%20empower%20retailers%20to%20elevate,providing%20the%20agility%20needed%20to%20adapt%20for%20the%20future.) [2](https://en.wikipedia.org/w/index.php?oldid=1280238497)

## Sources

1. [Zebra Technologies to Unveil New Solutions at NRF 2024 Advancing the Modern Store | Nasdaq](https://web.archive.org/web/20250306102900/https://www.nasdaq.com/press-release/zebra-technologies-to-unveil-new-solutions-at-nrf-2024-advancing-the-modern-store#:~:text=Company%20will%20showcase%20solutions%20that%20empower%20retailers%20to%20elevate,providing%20the%20agility%20needed%20to%20adapt%20for%20the%20future.), available by 2025-03-06.
2. [Zebra Technologies](https://en.wikipedia.org/w/index.php?oldid=1280238497), available by 2025-03-13.
3. [Zebra Technologies to Unveil New Solutions at NRF 2024 Advancing the Modern Store | Nasdaq](https://web.archive.org/web/20250306102900/https://www.nasdaq.com/press-release/zebra-technologies-to-unveil-new-solutions-at-nrf-2024-advancing-the-modern-store#:~:text=Engage%20Associates%20to%20Drive%20Productivity%20Eight%20in%2010%20retail,cost%20of%20lost%20devices%20and%20driving%20productivity%20for%20retailers.), available by 2025-03-06.
4. [Zebra Technologies to Unveil New Solutions at NRF 2024 Advancing the Modern Store | Nasdaq](https://web.archive.org/web/20250306102900/https://www.nasdaq.com/press-release/zebra-technologies-to-unveil-new-solutions-at-nrf-2024-advancing-the-modern-store#:~:text=Launching%20at%20NRF%2C%20the%20new%20AI-powered%20Workcloud%20Modeling%20Studio,visibility%20to%20maximize%20accuracy%20without%20an%20expensive%20infrastructure%20investment.), available by 2025-03-06.
