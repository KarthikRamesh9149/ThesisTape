# Investment research memo

As of 2025-03-03

**Research question**
Given INEGI’s data on Mexico’s Q4 2024 GDP contraction and deteriorating business confidence, how will the 25% US tariffs scheduled for March 2025 impact Mexico’s near-term growth outlook and its critical bilateral trade in crude oil and corn?

## Answer

As of 2025-03-03, I would lower Mexico’s near-term growth forecast relative to a baseline that already reflects the weak fourth quarter but assumes no new tariff. The United States is the destination for nearly 80 percent of Mexican exports, so even a temporary duty could weaken orders, especially for manufacturers serving the U.S. market. The 25 percent rate and scheduled start tomorrow are an unverified question premise: the available account documents a campaign threat at that rate, not an implementing order. That supports a directional cut, not a specific GDP downgrade. [1](https://en.wikipedia.org/w/index.php?oldid=1277190848)

## Evidence

The fourth-quarter contraction and deteriorating business confidence described in the question belong in the starting forecast, not in the estimated cost of a duty that had yet to be collected. Confidence may already reflect some anticipation of tariffs. The incremental risk is that U.S. customers now reduce orders or Mexican firms defer investment beyond what that earlier weakness implied. The available INEGI material is a household survey, not the GDP or confidence release, so it cannot verify the size of either decline or isolate an anticipation effect. [2](https://web.archive.org/web/20250303221708/https://www.inegi.org.mx/contenidos/saladeprensa/boletines/2023/ENIGH/ENIGH2022.pdf#:~:text=COMUNICACI%C3%93N%20SOCIAL%20Temas%20sobresalientes%20captados%20por%20la%20ENIGH%20%E2%80%A2,la%20ENIGH%202022%20se%20puede%20consultar%20en%3A%20https%3A%2F%2Fwww.inegi.org.mx%2Fcontenidos%2Fproductos%2Fprod_serv%2Fcontenidos%2Fespanol%2Fbvinegi%2Fproduc%20tos%2Fnueva_estruc%2F889463901204.pdf) [1](https://en.wikipedia.org/w/index.php?oldid=1277190848)

Mexican crude entering the United States is directly exposed under the stated all-goods scenario. The U.S. importer would owe the duty; the cost to Mexico would depend on whether refiners absorb it, negotiate a lower price from Mexican sellers or switch suppliers. Lower export receipts need not mean lower Mexican real output if barrels can be sold elsewhere. The sources establish oil trade, but not a binding crude-specific rate, current shipment volumes or how readily refiners and exporters could redirect purchases and sales. [1](https://en.wikipedia.org/w/index.php?oldid=1277190848) [3](https://en.wikipedia.org/w/index.php?oldid=1257939031)

U.S. corn entering Mexico crosses the border in the opposite direction and would not incur the U.S. import duty. A direct tariff cost for Mexican corn buyers would require a separate Mexican measure covering corn; a signal that Mexico might retaliate is not a product list. Without retaliation, a weaker peso could still make dollar-priced corn dearer. With it, higher feed costs could reach Mexican livestock producers while U.S. growers risk losing sales. Household cereal spending shows why food costs matter, but does not measure U.S. corn imports or predict retail price increases. [1](https://en.wikipedia.org/w/index.php?oldid=1277190848) [4](https://web.archive.org/web/20250303221708/https://www.inegi.org.mx/contenidos/saladeprensa/boletines/2023/ENIGH/ENIGH2022.pdf#:~:text=COMUNICADO%20DE%20PRENSA%20N%C3%9AM.%20420%2F23%2026%20DE%20JULIO%20DE,de%20M%C3%A9xico%20obtuvieron%20el%20mayor%20ingreso%20corriente%20promedio%20trimestral)

## What would change the view

The base case is slower growth, not necessarily another contraction: a broad duty sustained for long enough to affect orders should show up in weaker U.S.-bound manufacturing shipments and either wider discounts on Mexican crude or lower U.S. purchases. The strongest alternative is a delay or broad exemptions that leave trade largely intact. Check U.S. customs coverage and collections first, then orders, shipments and crude prices; a waiver accompanied by stable orders would favor removing the tariff-related cut while retaining the weak starting forecast. Count a corn duty only if Mexico publishes one. [1](https://en.wikipedia.org/w/index.php?oldid=1277190848)

## Sources

1. [Mexico–United States relations](https://en.wikipedia.org/w/index.php?oldid=1277190848), available by 2025-02-23.
2. [Archived PDF](https://web.archive.org/web/20250303221708/https://www.inegi.org.mx/contenidos/saladeprensa/boletines/2023/ENIGH/ENIGH2022.pdf#:~:text=COMUNICACI%C3%93N%20SOCIAL%20Temas%20sobresalientes%20captados%20por%20la%20ENIGH%20%E2%80%A2,la%20ENIGH%202022%20se%20puede%20consultar%20en%3A%20https%3A%2F%2Fwww.inegi.org.mx%2Fcontenidos%2Fproductos%2Fprod_serv%2Fcontenidos%2Fespanol%2Fbvinegi%2Fproduc%20tos%2Fnueva_estruc%2F889463901204.pdf), available by 2025-03-03.
3. [Pemex](https://en.wikipedia.org/w/index.php?oldid=1257939031), available by 2024-11-17.
4. [Archived PDF](https://web.archive.org/web/20250303221708/https://www.inegi.org.mx/contenidos/saladeprensa/boletines/2023/ENIGH/ENIGH2022.pdf#:~:text=COMUNICADO%20DE%20PRENSA%20N%C3%9AM.%20420%2F23%2026%20DE%20JULIO%20DE,de%20M%C3%A9xico%20obtuvieron%20el%20mayor%20ingreso%20corriente%20promedio%20trimestral), available by 2025-03-03.
