# Investment research memo

As of 2025-05-06

**Research question**
Given the significant Q3 and Q4 2024 institutional stake increases by firms like ARGA, Massachusetts Financial Services, and Banco Santander, to what extent is Banco Bradesco’s digital infrastructure pivot—specifically its involvement in the Drex pilot and Pix proximity payments—driving a fundamental institutional re-rating of the bank?

Some parts of the question could not be established from eligible evidence.

## Evidence

Pix adoption is evidence of demand for instant payments, not of a competitive advantage for Bradesco. Pix was already Brazil’s main payment system in 2023, before the reported stake changes, and the central bank operates its settlement infrastructure. Proximity payments could still benefit Bradesco if they help it retain merchants or lower its cost per transaction more than at rivals. The evidence provides no Bradesco-specific measure of either effect, and it neither documents the bank’s Drex pilot role nor identifies earnings from it. [1](https://en.wikipedia.org/w/index.php?oldid=1282596909)

The available book-value comparison concerns the wrong transaction: 1.8 times book value was the price Bradesco agreed to pay for HSBC Brasil, not the multiple investors paid for Bradesco during the quarters in question. The earnings-call excerpt likewise supplies a date and participants but no forecasts. Neither source distinguishes a higher share price in anticipation of recovering earnings from investors paying a higher multiple for those earnings. [2](https://web.archive.org/web/20210811154801/https://www.reuters.com/article/us-hsbc-bank-brasil-m-a-banco-bradesco-idUSKCN0Q806N20150803#:~:text=The%20all-cash%20acquisition%20will%20allow%20Bradesco%20to%20close%20the,depositary%20receipt%20BBD.N%20lost%203.5%20percent%20in%20New%20York.) [3](https://web.archive.org/web/20250209071057/https://seekingalpha.com/article/4756328-banco-bradesco-s-a-bbd-q4-2024-earnings-call-transcript#:~:text=Banco%20Bradesco%20S.A.%20%28NYSE%3ABBD%29%20Q4%202024%20Earnings%20Conference%20Call,Relations%20Joao%20Carlos%20Gomes%20Da%20Silva%20-%20Executive%20Officer)

## What would change the view

The base case is to assign no separate digital premium, not to assume the managers bought for an earnings recovery. First verify each manager’s quarter-end ADR count and portfolio weight: a larger position with an unchanged weight is consistent with portfolio growth. Then track Bradesco’s price-to-book multiple against Itaú and Banco do Brasil alongside contemporaneous forecasts of return on equity. A narrowing discount as profitability forecasts recover would favor the earnings explanation, not establish a premium. The strongest alternative is that digital services improve Bradesco’s economics more than peers’. A persistent premium alongside disclosed incremental Pix savings or Drex income beyond the expected recovery would support it; contemporaneous manager commentary would separately address motive. [2](https://web.archive.org/web/20210811154801/https://www.reuters.com/article/us-hsbc-bank-brasil-m-a-banco-bradesco-idUSKCN0Q806N20150803#:~:text=The%20all-cash%20acquisition%20will%20allow%20Bradesco%20to%20close%20the,depositary%20receipt%20BBD.N%20lost%203.5%20percent%20in%20New%20York.) [1](https://en.wikipedia.org/w/index.php?oldid=1282596909)

## Sources

1. [Pix (payment system)](https://en.wikipedia.org/w/index.php?oldid=1282596909), available by 2025-03-27.
2. [Bradesco to acquire HSBC Brazil unit, biggest-ever buy | Reuters](https://web.archive.org/web/20210811154801/https://www.reuters.com/article/us-hsbc-bank-brasil-m-a-banco-bradesco-idUSKCN0Q806N20150803#:~:text=The%20all-cash%20acquisition%20will%20allow%20Bradesco%20to%20close%20the,depositary%20receipt%20BBD.N%20lost%203.5%20percent%20in%20New%20York.), available by 2021-08-11.
3. [Banco Bradesco S.A. (BBD) Q4 2024 Earnings Call Transcript | Seeking Alpha](https://web.archive.org/web/20250209071057/https://seekingalpha.com/article/4756328-banco-bradesco-s-a-bbd-q4-2024-earnings-call-transcript#:~:text=Banco%20Bradesco%20S.A.%20%28NYSE%3ABBD%29%20Q4%202024%20Earnings%20Conference%20Call,Relations%20Joao%20Carlos%20Gomes%20Da%20Silva%20-%20Executive%20Officer), available by 2025-02-09.
