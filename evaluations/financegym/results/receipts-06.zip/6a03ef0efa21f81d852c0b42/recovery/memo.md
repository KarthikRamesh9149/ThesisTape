# Investment research memo

As of 2025-06-17

**Research question**
Given the pending $14 billion acquisition of Juniper Networks and the launch of 'NVIDIA AI Computing by HPE', how will HPE's pivot toward high-margin AI infrastructure and hybrid cloud solutions impact its valuation multiples and competitive standing against Dell and SMCI through fiscal 2025?

Some parts of the question could not be established from eligible evidence.

## Evidence

The economics of “NVIDIA AI Computing by HPE” remain unverified here. The passages establish HPE’s supercomputing and flash-storage capabilities, but contain no launch release specifying which products were announced, which were generally available, or what customers bought. The question’s high-margin characterization is an unverified financial premise. The record lacks HPE’s reported Server and Hybrid Cloud margins, AI systems orders and backlog, and fiscal 2025 guidance. Orders would show demand; even conversion to revenue would not prove profitability. GPU-heavy shipments could lift sales while diluting Server margin. The offset to look for is incremental hybrid-cloud software and services profit on those deployments. [1](https://en.wikipedia.org/w/index.php?oldid=1295779790) [2](https://en.wikipedia.org/w/index.php?oldid=1291155170)

Dell and Supermicro had evidence of AI-server scale that HPE’s enterprise strategy does not negate. A report described xAI’s plan to source half its servers from Supermicro and half from Dell; Supermicro also offered liquid-cooled servers. The planned split is not a realized shipment count, market share or margin. The latest quarterly results and actual period ends for all three vendors are missing from the record, so a cutoff-date ranking on shipments, backlog or profitability is not supportable. Without Juniper, HPE’s more credible opportunity was to win bids where customers wanted compute, storage and private-cloud management together, rather than to displace either rival on server volume. [2](https://en.wikipedia.org/w/index.php?oldid=1291155170) [1](https://en.wikipedia.org/w/index.php?oldid=1295779790)

## Outlook

Base case: roughly flat forward P/E through October, even if AI shipments lift expected earnings and the share price. If Juniper remains unresolved, expect selective hybrid-cloud wins rather than broad server-share gains. If it closes, HPE could bid with a stronger networking portfolio immediately, but a modest multiple increase would require evidence that combined sales improve durable profit after financing and integration costs. To measure that increase, compare HPE’s price with its contemporaneous next-twelve-month earnings estimate at each date, using the same earnings definition for Dell and Supermicro. Supermicro’s historical market-cap rally is neither a P/E nor a cutoff-date peer benchmark. [3](https://web.archive.org/web/20250531210841/https://www.cnbc.com/2025/01/30/doj-sues-to-block-hpes-14-billion-juniper-deal.html#:~:text=The%20DOJ%20argued%20that%20the%20acquisition%20would%20eliminate%20competition,networking%20offerings%20to%20better%20compete%20with%20global%20incumbent%20players.) [4](https://en.wikipedia.org/w/index.php?oldid=1281899468) [2](https://en.wikipedia.org/w/index.php?oldid=1291155170)

## What would change the view

The strongest upside case is that enterprise buyers repeatedly purchase profitable software and services alongside HPE’s AI hardware. I would raise the multiple if reported AI backlog converted to sales while Server margin stabilized and Hybrid Cloud profit grew; after a Juniper close, disclosed joint customer wins would strengthen that conclusion. The downside is the opposite: Dell and Supermicro win the large deployments while HPE grows hardware revenue at falling margins. Continued litigation would leave Mist outside HPE; an expensive integration after closing could instead absorb the incremental profit. Either outcome favors a lower multiple if earnings quality deteriorates. [2](https://en.wikipedia.org/w/index.php?oldid=1291155170) [5](https://web.archive.org/web/20250531210841/https://www.cnbc.com/2025/01/30/doj-sues-to-block-hpes-14-billion-juniper-deal.html#:~:text=The%20U.S.%20Department%20of%20Justice%20has%20sued%20to%20block,first%20since%20President%20Donald%20Trump%20took%20office%20last%20week.) [4](https://en.wikipedia.org/w/index.php?oldid=1281899468)

## Sources

1. [Hewlett Packard Enterprise](https://en.wikipedia.org/w/index.php?oldid=1295779790), available by 2025-06-15.
2. [Supermicro](https://en.wikipedia.org/w/index.php?oldid=1291155170), available by 2025-05-19.
3. [DOJ sues to block HPE's $14 billion Juniper deal](https://web.archive.org/web/20250531210841/https://www.cnbc.com/2025/01/30/doj-sues-to-block-hpes-14-billion-juniper-deal.html#:~:text=The%20DOJ%20argued%20that%20the%20acquisition%20would%20eliminate%20competition,networking%20offerings%20to%20better%20compete%20with%20global%20incumbent%20players.), available by 2025-05-31.
4. [Juniper Networks](https://en.wikipedia.org/w/index.php?oldid=1281899468), available by 2025-03-23.
5. [DOJ sues to block HPE's $14 billion Juniper deal](https://web.archive.org/web/20250531210841/https://www.cnbc.com/2025/01/30/doj-sues-to-block-hpes-14-billion-juniper-deal.html#:~:text=The%20U.S.%20Department%20of%20Justice%20has%20sued%20to%20block,first%20since%20President%20Donald%20Trump%20took%20office%20last%20week.), available by 2025-05-31.
