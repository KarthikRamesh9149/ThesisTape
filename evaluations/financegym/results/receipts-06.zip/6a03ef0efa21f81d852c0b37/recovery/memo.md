# Investment research memo

As of 2025-06-05

**Research question**
How does StandardAero's aggressive global expansion into LEAP engine MRO services across China, India, and the UAE impact its valuation and long-term outlook, especially when balanced against heavy post-IPO divestment by GIC Private Ltd and the firm's significant $2.25 billion debt load?

Some parts of the question could not be established from eligible evidence.

## Answer

As of 2025-06-05, I would leave StandardAero’s valuation multiple unchanged. By 2024, LEAP had been selected for 75% of Airbus A320neo orders. That indicates a sizable future maintenance market, not StandardAero’s share of it. The available evidence neither verifies enough work in China, India or the UAE to justify a premium nor shows that ramp costs and debt service outweigh the potential cash gains. It also does not establish a GIC Private Ltd sale large enough to warrant a share-price discount. [1](https://en.wikipedia.org/w/index.php?oldid=1293274835) [2](https://web.archive.org/web/20250521121602/https://ir.standardaero.com/news-events/events/detail/20250512-first-quarter-2025-earnings-call#:~:text=First%20Quarter%202025%20Earnings%20Call%20location_cityCompany%20Profile)

## Evidence

In China, the documented decision was COMAC’s selection of LEAP for the C919 in 2009, not a maintenance award to StandardAero. For China, India and the UAE alike, the supplied record verifies neither a named StandardAero customer award and contracted visit volume nor a planned or operating local LEAP shop. A local airline can send engines to an existing shop abroad, generating revenue without adding local capacity. Conversely, a planned shop can require investment well before it is approved, staffed and processing engines. [1](https://en.wikipedia.org/w/index.php?oldid=1293274835) [2](https://web.archive.org/web/20250521121602/https://ir.standardaero.com/news-events/events/detail/20250512-first-quarter-2025-earnings-call#:~:text=First%20Quarter%202025%20Earnings%20Call%20location_cityCompany%20Profile)

Heavy post-IPO divestment by GIC is an unverified question premise. The record provides no IPO-era share count for GIC, dated closing disclosure for a subsequent sale or remaining holding. The size, timing and fraction of its original stake sold therefore cannot be established; proposed offerings and unexercised options should not be counted as sales. A completed secondary sale could increase tradable supply, and a large remaining stake could weigh on sentiment if investors expect further sales. Neither effect reduces shop cash flow: the buyer pays GIC, not StandardAero. [2](https://web.archive.org/web/20250521121602/https://ir.standardaero.com/news-events/events/detail/20250512-first-quarter-2025-earnings-call#:~:text=First%20Quarter%202025%20Earnings%20Call%20location_cityCompany%20Profile)

## Outlook

Base case: keep the multiple flat through the ramp. Orders must become deliveries, engines must accumulate use, and even a signed service contract need not generate revenue until engines arrive and work is performed. Hiring, tooling and stocking parts can absorb cash first. A missing part can lengthen turnaround, tying up both a bay and working capital; CFM’s historical warning concerned engine production, not a measured StandardAero shortage. Over successive overhaul cycles, repeat visits could spread fixed shop costs over more jobs, raising margins and free cash flow. [1](https://en.wikipedia.org/w/index.php?oldid=1293274835) [3](https://web.archive.org/web/20190820014357/https://www.flightglobal.com/news/articles/cfm-quietly-confident-on-leap-production-ramp-up-431474/#:~:text=Ebanga%20says%20that%20CFM%20has%20been%20preparing%20for%20the,expect%20any%20big%20surprises.%E2%80%9D%20CFM%20names%20new%20chief%20executive)

## What would change the view

The strongest upside case is earlier paid work that fills existing bays with little additional capital spending. An early LEAP turbine-disk defect illustrates the distinction between a technical issue and billable work: it was found during assembly, not on a StandardAero overhaul. I would raise the multiple when disclosed contract starts lead to completed visits, higher utilization and sustained free cash flow after tooling and inventory spending, with net leverage falling. Rising visit counts alongside persistent cash burn and approaching debt maturities would instead argue for a discount. [1](https://en.wikipedia.org/w/index.php?oldid=1293274835)

## Sources

1. [CFM International LEAP](https://en.wikipedia.org/w/index.php?oldid=1293274835), available by 2025-05-31.
2. [First Quarter 2025 Earnings Call :: StandardAero, Inc. (SARO)](https://web.archive.org/web/20250521121602/https://ir.standardaero.com/news-events/events/detail/20250512-first-quarter-2025-earnings-call#:~:text=First%20Quarter%202025%20Earnings%20Call%20location_cityCompany%20Profile), available by 2025-05-21.
3. [​CFM quietly confident on Leap production ramp-up](https://web.archive.org/web/20190820014357/https://www.flightglobal.com/news/articles/cfm-quietly-confident-on-leap-production-ramp-up-431474/#:~:text=Ebanga%20says%20that%20CFM%20has%20been%20preparing%20for%20the,expect%20any%20big%20surprises.%E2%80%9D%20CFM%20names%20new%20chief%20executive), available by 2019-08-20.
