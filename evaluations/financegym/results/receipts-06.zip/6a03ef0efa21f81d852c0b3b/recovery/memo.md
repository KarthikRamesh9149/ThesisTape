# Investment research memo

As of 2025-07-21

**Research question**
How does Joseph Feldman’s divergence in sentiment toward Target and Best Buy versus Walmart and Costco reflect a bifurcation in consumer spending? Analyze how his mid-2025 downgrades and EPS cuts for discretionary retailers contrast with his maintained bullishness on staple and value-oriented leaders.

Some parts of the question could not be established from eligible evidence.

## Answer

As of 2025-07-21, a split between discretionary and value-oriented spending is plausible, but the evidence does not show that it drove Joseph Feldman’s calls at Telsey Advisory Group. The claimed Target and Best Buy downgrades and EPS cuts, and his maintained bullishness on Walmart and Costco, are unverified premises of the question. The sources establish a contrast in retail businesses, not the direction or size of Feldman’s revisions. That matters because an earnings cut caused by fewer purchases would say more about consumers than one caused by higher costs. [1](https://en.wikipedia.org/w/index.php?oldid=1301253576) [2](https://web.archive.org/web/20250623070045/https://www.geekseller.com/blog/selling-on-best-buy-a-new-marketplace-for-sellers-in-2025/#:~:text=Selling%20on%20Best%20Buy%3A%20A%20New%20Marketplace%20for%20Sellers,entirely%20new%20categories%20a%20chance%20to%20showcase%20their%20brands.) [3](https://en.wikipedia.org/w/index.php?oldid=1300157982)

## Evidence

For neither Target nor Best Buy do the supplied sources verify a decision date, prior and revised rating, or prior and revised EPS estimate for an identified fiscal year. They describe Target’s merchandise sourcing and Best Buy’s planned marketplace, not a dated Telsey research note or a company earnings release. No EPS figure can therefore be identified as Feldman’s forecast rather than management’s guidance, and no company-specific explanation can be attributed to him. [1](https://en.wikipedia.org/w/index.php?oldid=1301253576) [2](https://web.archive.org/web/20250623070045/https://www.geekseller.com/blog/selling-on-best-buy-a-new-marketplace-for-sellers-in-2025/#:~:text=Selling%20on%20Best%20Buy%3A%20A%20New%20Marketplace%20for%20Sellers,entirely%20new%20categories%20a%20chance%20to%20showcase%20their%20brands.)

For Walmart and Costco, the sources document low-price strategies but do not verify Feldman’s rating on either stock at the cutoff. A maintained bullish rating, even if confirmed, would establish continuity in the recommendation alone: Feldman could still have changed his EPS forecast or price target. Neither change nor its absence is documented for either retailer. [4](https://en.wikipedia.org/w/index.php?oldid=1299843474) [3](https://en.wikipedia.org/w/index.php?oldid=1300157982)

Two distinct shopping decisions could produce the proposed divergence. A household can postpone an electronics replacement at Best Buy or a furniture purchase at Target while continuing to buy groceries at Walmart. It can also buy the same discretionary item more cheaply elsewhere. Walmart’s pricing and Costco’s limited-selection, high-volume model make that second explanation plausible: either retailer could gain sales without an increase in total category demand. The historical Target–Walmart grocery comparison explains why their exposure may differ; it does not measure what shoppers bought during the requested period. [2](https://web.archive.org/web/20250623070045/https://www.geekseller.com/blog/selling-on-best-buy-a-new-marketplace-for-sellers-in-2025/#:~:text=Selling%20on%20Best%20Buy%3A%20A%20New%20Marketplace%20for%20Sellers,entirely%20new%20categories%20a%20chance%20to%20showcase%20their%20brands.) [1](https://en.wikipedia.org/w/index.php?oldid=1301253576) [4](https://en.wikipedia.org/w/index.php?oldid=1299843474) [3](https://en.wikipedia.org/w/index.php?oldid=1300157982)

## Outlook

Conditional base case for the next few quarters: if households tighten budgets, discretionary unit sales should lag grocery units across retailers, not just at Target and Best Buy. There is no contemporaneous category-level demand evidence here to confirm or contradict that prediction. Best Buy’s seller onboarding is evidence of an effort to widen its assortment, not evidence that customers bought more electronics. [1](https://en.wikipedia.org/w/index.php?oldid=1301253576) [2](https://web.archive.org/web/20250623070045/https://www.geekseller.com/blog/selling-on-best-buy-a-new-marketplace-for-sellers-in-2025/#:~:text=Selling%20on%20Best%20Buy%3A%20A%20New%20Marketplace%20for%20Sellers,entirely%20new%20categories%20a%20chance%20to%20showcase%20their%20brands.)

## What would change the view

The strongest alternative is firm-specific margin pressure rather than a broad drop in discretionary demand. Target’s import sourcing, for example, leaves room for higher landed costs to reduce EPS even with steady unit sales; the source establishes the exposure, not a cost increase. Stable discretionary units across peers alongside falling margins concentrated at Target or Best Buy would favor that explanation. To connect either outcome to Feldman’s decisions would still require his dated notes identifying what he changed and why. [1](https://en.wikipedia.org/w/index.php?oldid=1301253576)

## Sources

1. [Target Corporation](https://en.wikipedia.org/w/index.php?oldid=1301253576), available by 2025-07-18.
2. [Selling on Best Buy: A New Marketplace for Sellers in 2025](https://web.archive.org/web/20250623070045/https://www.geekseller.com/blog/selling-on-best-buy-a-new-marketplace-for-sellers-in-2025/#:~:text=Selling%20on%20Best%20Buy%3A%20A%20New%20Marketplace%20for%20Sellers,entirely%20new%20categories%20a%20chance%20to%20showcase%20their%20brands.), available by 2025-06-23.
3. [Costco](https://en.wikipedia.org/w/index.php?oldid=1300157982), available by 2025-07-12.
4. [Walmart](https://en.wikipedia.org/w/index.php?oldid=1299843474), available by 2025-07-10.
