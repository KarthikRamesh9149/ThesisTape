# Investment research memo

As of 2025-06-05

**Research question**
What is driving the divergence between significant institutional accumulation by firms like Corvex and Southeastern and the widespread downward revisions in price targets by analysts at JPMorgan, Barclays, and Benchmark following IAC's reported $2.80 per share quarterly loss?

## Answer

As of 2025-06-05, the evidence does not establish that Corvex or Southeastern increased its IAC share count in the quarter at issue. Neither the size of either change nor the size and timing of the target cuts attributed to JPMorgan, Barclays and Benchmark can be verified. The apparent divergence is therefore unproven. One material reason to question the comparison is that Angi became independent of IAC; a lower target for IAC without Angi need not mean a lower valuation of the remaining businesses. [1](https://web.archive.org/web/20250525070317/https://finance.yahoo.com/quote/ANGI/profile/#:~:text=Chief%20Customer%20Officer%20%26%20Director%20Angi%20Inc.%20connects%20home,UTC%20-%20August%208%2C%202025%20at%2012%3A00%20PM%20UTC) [2](https://en.wikipedia.org/w/index.php?oldid=1291502709)

## Evidence

The holdings test is to compare each manager’s IAC shares at the start and end of the same quarter, not to treat the disclosure date as a purchase date. Neither pair of counts is supplied. For Southeastern, the comparison must also cover the same accounts: a Longleaf fund is only part of the manager’s portfolio. Even a verified net increase would not, by itself, show that the manager bought after the earnings report. [2](https://en.wikipedia.org/w/index.php?oldid=1291502709)

## Outlook

The base case to test is a change in what the targets include, not an earnings-driven markdown. Angi was independent as of March 31, 2025. For each bank, compare its revised IAC target with its prior target after removing any per-share value it previously assigned to Angi. If the targets then broadly match, the cut is consistent with the separation. No analyst valuation breakdown is supplied, and the reported quarterly loss is an unverified question premise, not evidence of why any bank acted. [1](https://web.archive.org/web/20250525070317/https://finance.yahoo.com/quote/ANGI/profile/#:~:text=Chief%20Customer%20Officer%20%26%20Director%20Angi%20Inc.%20connects%20home,UTC%20-%20August%208%2C%202025%20at%2012%3A00%20PM%20UTC)

## What would change the view

The strongest alternative is genuine disagreement about the remaining IAC businesses. The signal would be comparable filings showing net share additions alongside analyst notes that lower earnings forecasts or valuation multiples for those same businesses. A note tying that reduction to the quarterly result would support loss attribution; dated trades or manager commentary would be needed to call the buying a response to it. [1](https://web.archive.org/web/20250525070317/https://finance.yahoo.com/quote/ANGI/profile/#:~:text=Chief%20Customer%20Officer%20%26%20Director%20Angi%20Inc.%20connects%20home,UTC%20-%20August%208%2C%202025%20at%2012%3A00%20PM%20UTC) [2](https://en.wikipedia.org/w/index.php?oldid=1291502709)

## Sources

1. [Angi Inc. (ANGI) Company Profile & Facts - Yahoo Finance](https://web.archive.org/web/20250525070317/https://finance.yahoo.com/quote/ANGI/profile/#:~:text=Chief%20Customer%20Officer%20%26%20Director%20Angi%20Inc.%20connects%20home,UTC%20-%20August%208%2C%202025%20at%2012%3A00%20PM%20UTC), available by 2025-05-25.
2. [Southeastern Asset Management](https://en.wikipedia.org/w/index.php?oldid=1291502709), available by 2025-05-21.
