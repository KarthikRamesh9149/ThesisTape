# Investment research memo

As of 2025-06-05

**Research question**
Given the aggressive international expansion of Omnipod 5 and its expanded compatibility with Abbott and Dexcom sensors, how should investors interpret the divergence between the recent bullish analyst price target revisions (up to $380) and the significant Q2 2025 share liquidations by institutional leaders and corporate insiders?

## Answer

Hold Insulet as of 2025-06-05. The bullish analyst target and significant Q2 2025 sales by leading institutional holders and Insulet insiders are unverified question premises. No analyst, selling manager or insider is identified in the available evidence, and no sale size is documented. Early Omnipod results therefore do not establish that the reported target is justified, but neither is there verified selling to warrant a trim. [1](https://en.wikipedia.org/w/index.php?oldid=1223018657)

## Evidence

A filing published during the quarter need not describe trading during the quarter. The quarter was still open at the cutoff, and Form 13F reports quarter-end positions rather than dated transactions. Comparing a named manager’s share counts across filings could establish a net reduction in its disclosed position, not the timing or motive of a sale. An insider-sale claim needs separate transaction evidence identifying the person, date and amount; none is supplied. That leaves selling unverified, not disproved. [1](https://en.wikipedia.org/w/index.php?oldid=1223018657)

## Outlook

The hold case turns on conversion, not reach. If the international rollout and Abbott and Dexcom compatibility described in the question expand access, the first useful test is whether more eligible patients start using Omnipod; the next is whether they reorder pods at attractive margins. The available material concerns manager exposures, not patient starts, repeat use, margins or the analyst’s valuation assumptions. It cannot show how much profitable adoption the target requires or whether early results are on that path. [1](https://en.wikipedia.org/w/index.php?oldid=1223018657)

## What would change the view

The strongest buy case is that broader sensor choice removes a meaningful barrier to adoption. Sustained gains in starts and repeat orders in newly served markets, with margins holding up, would support a buy if a valuation using those results still offered upside to the market price. Weak repeat use despite wider access would favor a trim. Verified sales would merit scrutiny, but even confirmed reductions in fund holdings would be weaker evidence against the product thesis than disappointing patient retention. [1](https://en.wikipedia.org/w/index.php?oldid=1223018657)

## Sources

1. [Form 13F](https://en.wikipedia.org/w/index.php?oldid=1223018657), available by 2024-05-09.
