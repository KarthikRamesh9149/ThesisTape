# Investment research memo

As of 2025-07-21

**Research question**
Given the significant institutional accumulation of EWZ in late 2024 and early 2025, alongside its low P/E ratio of 9.47X and 17% outperformance of the SPY, what fundamental drivers within the Brazilian equity market and currency dynamics are justifying this concentrated shift in institutional sentiment?

Some parts of the question could not be established from eligible evidence.

## Evidence

Test accumulation by matching each manager’s split-adjusted EWZ share count across the quarter-ends bracketing the claimed buying. Unchanged shares with a higher market value indicate appreciation, not net buying. Sum increases and reductions separately: a few managers accounting for most additions would show concentrated buying, but offsetting sales could still leave aggregate institutional ownership flat. These filings report quarter-end holdings with a lag, not trade dates or managers’ motives. [1](https://en.wikipedia.org/w/index.php?oldid=1223018657)

Neither the date nor the earnings basis of the quoted P/E is documented. A dated EWZ factsheet specifying trailing or forecast earnings, portfolio weighting and treatment of loss-making companies would make the multiple interpretable. Even a confirmed low multiple need not signal improving profits: in June, Brazil’s central bank raised the Selic to 15.00% amid above-band inflation. A higher required return is a competing explanation for a low equity valuation. [2](https://web.archive.org/web/20250710103209/https://www.focus-economics.com/countries/brazil/news/monetary-policy/brazil-central-bank-meeting-18-06-2025-central-bank-hikes-further-in-june/#:~:text=Brazil%3A%20Central%20Bank%20hikes%20further%20in%20June%20Latest%20decision%3A,a%20tight%20labor%20market%20were%20further%20factors%20at%20play.)

The claimed lead has no specified endpoints or paired return series. Compare EWZ and SPY over identical closing dates in dollars, with distributions reinvested and the same market-price or NAV convention. Report both the percentage-point difference in returns and the relative gain in ending wealth; they are not interchangeable. If a lead survives, divide EWZ’s ending dollar wealth per dollar invested by the real’s ending dollar value relative to its starting value. The result is the local-currency wealth factor, which can be checked against a holdings-matched Brazilian equity total return after fees and tracking differences. The available historical exchange-rate observations do not supply the matched endpoints. [3](https://en.wikipedia.org/w/index.php?oldid=1299971111)

## What would change the view

The base case is that a fundamentals-led institutional shift remains unproven. The strongest alternative to an earnings recovery is that currency appreciation lifted dollar returns while investors anticipated lower rates. That is a hypothesis, not an observed attribution: the central bank signaled a hold after tightening, and analysts treated appreciation as something that could bring cuts forward, not as evidence that cuts had occurred. Concentrated net share additions alongside a local equity gain that persists after removing the currency effect and broad upward earnings revisions among EWZ holdings would favor the fundamentals interpretation. Flat share counts and a lead that disappears after currency adjustment would favor appreciation of existing positions. [4](https://web.archive.org/web/20250710103209/https://www.focus-economics.com/countries/brazil/news/monetary-policy/brazil-central-bank-meeting-18-06-2025-central-bank-hikes-further-in-june/#:~:text=BCB%20suggests%20rates%20will%20stay%20on%20hold%3A%20The%20Bank,to%20a%20terminal%20level%20of%20about%209%25%20in%202027%E2%80%9328.%E2%80%9D)

## Sources

1. [Form 13F](https://en.wikipedia.org/w/index.php?oldid=1223018657), available by 2024-05-09.
2. [Brazil Monetary Policy June 2025 - FocusEconomics](https://web.archive.org/web/20250710103209/https://www.focus-economics.com/countries/brazil/news/monetary-policy/brazil-central-bank-meeting-18-06-2025-central-bank-hikes-further-in-june/#:~:text=Brazil%3A%20Central%20Bank%20hikes%20further%20in%20June%20Latest%20decision%3A,a%20tight%20labor%20market%20were%20further%20factors%20at%20play.), available by 2025-07-10.
3. [Brazilian real](https://en.wikipedia.org/w/index.php?oldid=1299971111), available by 2025-07-11.
4. [Brazil Monetary Policy June 2025 - FocusEconomics](https://web.archive.org/web/20250710103209/https://www.focus-economics.com/countries/brazil/news/monetary-policy/brazil-central-bank-meeting-18-06-2025-central-bank-hikes-further-in-june/#:~:text=BCB%20suggests%20rates%20will%20stay%20on%20hold%3A%20The%20Bank,to%20a%20terminal%20level%20of%20about%209%25%20in%202027%E2%80%9328.%E2%80%9D), available by 2025-07-10.
