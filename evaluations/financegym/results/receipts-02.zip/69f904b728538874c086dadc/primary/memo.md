# Investment research memo

As of 2025-05-11

**Research question**
Given Savers Value Village's high concentration of ownership by Ares Management and the divergent insider activity between executive selling (Walsh, Medway) and director buying (Hunsinger), what are the primary risks to SVV’s valuation and liquidity as it manages its high leverage and North American footprint?

## Answer

As of 2025-05-11, I would discount Savers Value Village (SVV) relative to an otherwise comparable, less leveraged retailer if the question’s unverified premises of high leverage and concentrated North American operations hold. I would treat a possible sale by Ares Management as a separate stock-price risk, not a drain on SVV’s cash. Ares’s large stake, the sales by executives Walsh and Medway, and the purchase by director Hunsinger are also unverified question premises. The available accounts describe Ares’s own listing and investments elsewhere; they establish neither the size of its SVV stake nor the scale of SVV’s debt or insider trades. A numerical discount is not defensible. [1](https://en.wikipedia.org/w/index.php?oldid=1288032936)

## Evidence

The operating risk matters through cash coverage. If demand weakens or store costs rise across SVV’s North American markets at the same time, cash earnings could fall while scheduled interest and principal remain due. Debt then magnifies the loss to equity holders. I would compare operating cash flow after working-capital needs and maintenance investment, but before debt service, with cash interest and scheduled principal. Ares’s ability to raise money for a private equity fund is not cash available to SVV. Without SVV’s cash flows and maturity schedule, a refinancing shortfall is a risk, not a finding. [1](https://en.wikipedia.org/w/index.php?oldid=1288032936)

Stock liquidity is the ability to trade shares without materially moving the price. If Ares owns a large block, a small public float could limit market depth, and buyers might demand a concession to absorb a sale large relative to normal trading volume. In a secondary sale the proceeds go to Ares, not to SVV for debt repayment. The strongest alternative is that buyers absorb the block readily and the wider float improves trading liquidity afterward. Ares’s own exchange listing says nothing about SVV’s float, trading depth or the timing of a sale. [1](https://en.wikipedia.org/w/index.php?oldid=1288032936)

I would not change either assessment on the reported insider activity. Walsh and Medway might be reducing personal exposure rather than anticipating weaker earnings; Hunsinger’s purchase might express conviction without being large enough to absorb meaningful supply. Opposite directions do not establish offsetting trades. The available Ares investment disclosures concern other issuers, not these transactions. SVV ownership filings showing dates, trade terms, size relative to prior holdings and any preset sale plans would help distinguish discretionary signals from routine trades. Personal secondary trades would not change SVV’s debt-service cash. [1](https://en.wikipedia.org/w/index.php?oldid=1288032936)

## What would change the view

My conditional base case is a persistent leverage discount but only a contingent Ares overhang. I would narrow the former if SVV’s filings showed that cash left after maintaining its stores consistently covered interest and principal even through regional sales weakness, with net debt falling. I would narrow the latter if a disclosed Ares placement cleared without a lasting price concession and bid–ask spreads subsequently narrowed. Those are distinct tests: even a well-received block sale would not demonstrate deleveraging. The cited transactions document Ares’s activity elsewhere, not either outcome at SVV. [1](https://en.wikipedia.org/w/index.php?oldid=1288032936)

## Sources

1. [Ares Management](https://en.wikipedia.org/w/index.php?oldid=1288032936), available by 2025-04-30.
