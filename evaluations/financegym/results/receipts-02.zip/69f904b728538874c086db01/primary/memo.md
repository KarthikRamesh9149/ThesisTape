# Investment research memo

As of 2025-05-11

**Research question**
Following Novartis’s April 2025 announcement to acquire Regulus Therapeutics for up to $1.7 billion, how does the $7.00 per share cash offer and deal structure reconcile with the recent termination of the Sanofi collaboration and farabursen’s clinical outlook in ADPKD?

Some parts of the question could not be established from eligible evidence.

## Evidence

The reported Sanofi termination is not, by itself, evidence that rights to farabursen changed hands. The historical account describes a fibrosis collaboration, and an older pipeline description identifies an Alport syndrome candidate, not farabursen in ADPKD. Neither is a license or termination notice. The better-supported reading is to treat the collaboration and the acquisition separately: there is no demonstrated loss of farabursen rights, but also no basis here for saying the termination returned those rights to Regulus. [1](https://en.wikipedia.org/w/index.php?oldid=1232628785)

## Outlook

As of 2025-05-11, the evidence supports total kidney volume as a relevant measure in ADPKD, not a conclusion that farabursen preserves kidney function. Cyst growth enlarges the kidneys, but progression varies even within families. A favorable comparison with historical kidney growth would therefore justify further testing, not establish a drug effect. The available passages give no farabursen trial results, concurrent control, follow-up duration or safety findings with which to judge the strength or durability of a signal. [2](https://en.wikipedia.org/w/index.php?oldid=1286558022)

## What would change the view

Base case: value the closing cash separately and do not count the contingent consideration at face value. The strongest upside case is that a kidney-volume signal predicts a durable slowing of renal decline and farabursen earns the contractual payment. A controlled study showing slower loss of kidney function with acceptable safety would strengthen the clinical case; it would not itself establish that payment was due. The decisive financial evidence would be the signed milestone terms and confirmation that the specified event occurred. The decisive rights evidence would be a license schedule or termination notice naming farabursen or its target. [3](https://en.wikipedia.org/w/index.php?oldid=1289861916) [2](https://en.wikipedia.org/w/index.php?oldid=1286558022)

## Sources

1. [Regulus Therapeutics](https://en.wikipedia.org/w/index.php?oldid=1232628785), available by 2024-07-04.
2. [Autosomal dominant polycystic kidney disease](https://en.wikipedia.org/w/index.php?oldid=1286558022), available by 2025-04-20.
3. [Novartis](https://en.wikipedia.org/w/index.php?oldid=1289861916), available by 2025-05-11.
