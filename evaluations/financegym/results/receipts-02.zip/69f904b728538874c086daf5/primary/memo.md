# Investment research memo

As of 2025-03-16

**Research question**
How does the surge in institutional accumulation and insider buying in early 2025 align with the strategic valuation of the Capital One-Discover merger, particularly regarding Discover's proprietary PULSE and Diners Club networks as regulatory scrutiny intensifies?

## Answer

As of 2025-03-16, the claimed surge in institutional holdings and insider purchases in early 2025 is an unverified question premise. The supplied record identifies no buying institution or insider, share count or purchase price for either Capital One or Discover. The documented figure is Capital One’s announced $35.3&nbsp;billion all-stock offer for Discover, not the scale of investor buying or the value of its networks. Give the trading claim no weight in valuing the merger. [1](https://en.wikipedia.org/w/index.php?oldid=1280670982)

## Evidence

Diners Club gives the network thesis a factual basis, but its existing international reach belongs in Discover’s standalone value. The merger benefit would be the additional net fees earned or external routing costs avoided on Capital One transactions. The same test applies to debit traffic potentially routed through PULSE. The record contains no PULSE-specific operating evidence and no estimate for either network of eligible Capital One volume, net margin or migration cost. Diners Club acceptance demonstrates where a card can work, not how often Capital One customers would use it. [2](https://en.wikipedia.org/w/index.php?oldid=1280190630)

The supplied record contains neither institutional holdings filings nor insider transaction reports for Capital One or Discover. To test accumulation, compare the same managers’ share counts in each company across reporting dates, not filing dates: a year-end position disclosed later does not establish buying after year-end, and its market value can rise without a purchase. For insiders, use transaction dates, codes and footnotes to distinguish discretionary purchases from grants and option exercises. Compare purchases with prior periods before calling any increase a surge. Even verified Discover buying could reflect an expectation that the all-stock deal would close and the gap between Discover’s price and the value of the offered Capital One shares would narrow. That interpretation does not require higher earnings from either network. [3](https://en.wikipedia.org/w/index.php?oldid=1272346846) [1](https://en.wikipedia.org/w/index.php?oldid=1280670982)

## Outlook

Base case: treat additional network earnings as conditional upside, not a fixed premium. Greater transaction volume could strengthen Discover as a rival network, while the combined issuer’s size could still raise antitrust concerns: those arguments concern different markets. New York’s investigation and the Virginia consumer suit establish scrutiny, not a ruling or evidence that scrutiny intensified near the cutoff. Value incremental cash flows net of migration costs in each closing scenario, reduce them for delay or conditions, and assign no merger synergy if the deal fails. The record does not support numerical scenario weights. [3](https://en.wikipedia.org/w/index.php?oldid=1272346846) [1](https://en.wikipedia.org/w/index.php?oldid=1280670982)

## What would change the view

The strongest bullish alternative is that approval leaves routing unrestricted and enough Capital One traffic moves to PULSE and Diners Club to generate material net earnings. The decisive evidence would be approval terms and a network-specific migration plan showing eligible volume, timing and net savings, followed by actual routed volume and margins. Matched holdings disclosures and dated insider purchases could separately establish that buying occurred; they would not establish those economics. [1](https://en.wikipedia.org/w/index.php?oldid=1280670982) [2](https://en.wikipedia.org/w/index.php?oldid=1280190630)

## Sources

1. [Capital One](https://en.wikipedia.org/w/index.php?oldid=1280670982), available by 2025-03-15.
2. [Diners Club International](https://en.wikipedia.org/w/index.php?oldid=1280190630), available by 2025-03-13.
3. [Discover Financial](https://en.wikipedia.org/w/index.php?oldid=1272346846), available by 2025-01-28.
