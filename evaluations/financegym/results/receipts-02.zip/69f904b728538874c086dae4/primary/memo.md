# Investment research memo

As of 2025-09-29

**Research question**
Can Tate & Lyle's $1.8bn acquisition of CP Kelco and its strategic pivot to a growth-focused solutions model successfully offset the structural revenue declines and mid-term target concerns that triggered Morgan Stanley’s September 2025 downgrade?

## Answer

As of 2025-09-29, Tate & Lyle’s $1.8 bln CP Kelco deal gives it more ingredients to sell, but does not establish that it can meet its medium-term revenue and earnings targets. Buying an existing sales base lifts reported revenue when those sales are first consolidated. The test of the solutions strategy is whether customers subsequently buy more from the combined business or shift toward more profitable formulations. The available evidence establishes the product fit, not that change in buying behaviour. [1](https://en.wikipedia.org/w/index.php?oldid=1311894528)

## Evidence

Cost savings could support earnings even with flat volume, but they would not arrest a like-for-like sales decline. A recurring saving raises the profit level; once fully reflected in both comparison periods, it no longer delivers incremental growth. Reuters reported planned consideration of $1.15 bln in cash with the balance in shares. For shareholders, the relevant test is therefore earnings per share after integration and financing costs, not gross savings alone. The supplied evidence gives neither realised savings nor a reconciliation to earnings per share. [2](https://web.archive.org/web/20240622013726/https://www.reuters.com/business/retail-consumer/uks-sweetener-maker-tate-lyle-buy-us-based-cp-kelco-18-bln-2024-06-20/#:~:text=Tate%20to%20pay%20%241.15%20bln%20in%20cash%2C%20rest%20in%20shares)

The stated explanation for Morgan Stanley’s September 2025 downgrade remains an unverified question premise. The available broker material contains no Tate & Lyle rating note or contemporaneous account of the analyst’s reasoning. Reuters’ report that Tate shares fell more than 8% concerned the earlier deal announcement, not the alleged downgrade. It verifies neither a structural revenue decline nor analyst concern about medium-term targets. Attribution requires the dated note or reporting that quotes it. [3](https://web.archive.org/web/20240622013726/https://www.reuters.com/business/retail-consumer/uks-sweetener-maker-tate-lyle-buy-us-based-cp-kelco-18-bln-2024-06-20/#:~:text=J.M.%20Huber%20to%20hold%2016%25%20stake%20in%20Tate%20Tate,Editing%20by%20Mrigank%20Dhaniwala%2C%20Mark%20Potter%20and%20David%20Goodman) [1](https://en.wikipedia.org/w/index.php?oldid=1311894528) [4](https://en.wikipedia.org/w/index.php?oldid=1305935056)

## What would change the view

My base case is to treat CP Kelco’s existing sales as acquired revenue and give no credit for faster organic growth until it appears in comparable results. The strongest alternative is that pectin’s gelling, thickening and stabilising functions let Tate & Lyle win formulation work that neither business could win alone. Repeat orders from those wins, accompanied by sustained volume growth and a more profitable mix, would favour that case. To judge target credibility, I would compare those gains against management’s dated target definitions, using a sales reconciliation that separates acquisition effects, currency and pricing, and an earnings reconciliation that isolates net savings. Neither is available here. [5](https://en.wikipedia.org/w/index.php?oldid=1310395408) [1](https://en.wikipedia.org/w/index.php?oldid=1311894528)

## Sources

1. [Tate & Lyle](https://en.wikipedia.org/w/index.php?oldid=1311894528), available by 2025-09-17.
2. [Tate & Lyle bulks up food ingredients with $1.8 bln CP Kelco deal | Reuters](https://web.archive.org/web/20240622013726/https://www.reuters.com/business/retail-consumer/uks-sweetener-maker-tate-lyle-buy-us-based-cp-kelco-18-bln-2024-06-20/#:~:text=Tate%20to%20pay%20%241.15%20bln%20in%20cash%2C%20rest%20in%20shares), available by 2024-06-22.
3. [Tate & Lyle bulks up food ingredients with $1.8 bln CP Kelco deal | Reuters](https://web.archive.org/web/20240622013726/https://www.reuters.com/business/retail-consumer/uks-sweetener-maker-tate-lyle-buy-us-based-cp-kelco-18-bln-2024-06-20/#:~:text=J.M.%20Huber%20to%20hold%2016%25%20stake%20in%20Tate%20Tate,Editing%20by%20Mrigank%20Dhaniwala%2C%20Mark%20Potter%20and%20David%20Goodman), available by 2024-06-22.
4. [Morgan Stanley](https://en.wikipedia.org/w/index.php?oldid=1305935056), available by 2025-08-14.
5. [Pectin](https://en.wikipedia.org/w/index.php?oldid=1310395408), available by 2025-09-09.
