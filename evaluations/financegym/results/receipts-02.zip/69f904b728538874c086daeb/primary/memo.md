# Investment research memo

As of 2025-05-27

**Research question**
Given the divergent performance of XLU constituents—with firms like Constellation Energy (CEG) significantly outperforming the fund while others like AES Corp (AES) lag—how has the shifting weight of high-growth power producers relative to regulated utilities impacted XLU’s price recovery from its February 2025 lows?

## Answer

Neither the size of the merchant generators’ contribution to XLU’s price change nor the sign of the effect of changing their weights can be established from the February 2025 closing low through 2025-05-27. XLU’s recovery, Constellation Energy’s outperformance and AES’s lag are unverified question premises. The sources distinguish Constellation’s generation business from Exelon’s utilities, but provide no daily XLU closes, constituent price returns or portfolio weights. Even if Constellation outperformed XLU over the full period, that would not show that increasing its weight helped: what matters is how the stock performed after its weight changed. [1](https://en.wikipedia.org/w/index.php?oldid=1290066331)

## Evidence

Classify issuers by business model, not by stock performance. Constellation belongs on the generation side of the Exelon split; AES’s alleged lag is not evidence that it belongs in the regulated group. NextEra illustrates why the distinction matters: it owns both rate-regulated Florida Power & Light and a separate generation business. Use a disclosed primary-business rule for the main comparison and show mixed issuers separately as a sensitivity test. A parent company’s stock return does not reveal its divisions’ separate contributions. [1](https://en.wikipedia.org/w/index.php?oldid=1290066331) [2](https://en.wikipedia.org/w/index.php?oldid=1290323257)

## Outlook

Conditional on the question’s premises, the base case to test is that XLU benefited from owning Constellation at the low; no subsequent increase in exposure was needed to participate in its rebound. The strongest alternative is that merchant weights rose before further gains and amplified the recovery. The observable signal would be a larger merchant contribution under actual weights than under fixed weights, alongside a larger overall portfolio return after accounting for the regulated exposure displaced. A higher ending merchant weight alone cannot distinguish those explanations: it could be the result of gains already earned. [1](https://en.wikipedia.org/w/index.php?oldid=1290066331)

## What would change the view

To measure the split, identify XLU’s lowest February close and start with the next trading day’s close-to-close price return. Each day, multiply each stock’s price return, excluding dividends, by its beginning-of-day weight and sum by issuer group. Repeat with the same daily returns but reset each stock’s weight daily to its weight at the low close. For each portfolio, scale daily group contributions by that portfolio’s cumulative value through the prior close relative to its starting value, then sum through 2025-05-27. This gives comparable percentage-point contributions. Report any gap between the actual-weight result and XLU’s market-price return separately rather than assigning it to regulated utilities. The supplied market-pricing evidence concerns electricity, not stock prices or fund holdings. [3](https://en.wikipedia.org/w/index.php?oldid=1273695429)

## Sources

1. [Constellation Energy](https://en.wikipedia.org/w/index.php?oldid=1290066331), available by 2025-05-12.
2. [NextEra Energy](https://en.wikipedia.org/w/index.php?oldid=1290323257), available by 2025-05-14.
3. [PJM Interconnection](https://en.wikipedia.org/w/index.php?oldid=1273695429), available by 2025-02-03.
