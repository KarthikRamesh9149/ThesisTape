# Investment research memo

As of 2025-04-07

**Research question**
Following the collapse of the $8.5 billion Tapestry (TPR) merger due to federal regulatory intervention, what is the standalone strategic outlook for Capri Holdings (CPRI), and to what extent can the Michael Kors brand stabilize group revenues amid declining performance and a negative outlook?

## Answer

As of 2025-04-07, do not underwrite a standalone revenue recovery for Capri Holdings. Tapestry’s $8.5 billion bid is over, so the investment case turns on Capri’s own brands. If Versace and Jimmy Choo continue to lose sales, flat Michael Kors revenue would cushion the percentage decline but would not stop group revenue from falling. Use further contraction as the conditional base case, not as a measured forecast: the brand declines are an unverified question premise. [1](https://en.wikipedia.org/w/index.php?oldid=1258970660)

## Evidence

The court block and the termination were separate events. After Tapestry announced the bid in August 2023, the FTC sued in April 2024 over competition between Coach and Michael Kors in affordable luxury handbags. A federal judge blocked the merger on 24 October 2024. The companies initially committed to appeal, then called it off the following month because of regulatory hurdles. The ruling addressed competitive harm, not the prospects for standalone sales. [1](https://en.wikipedia.org/w/index.php?oldid=1258970660) [2](https://web.archive.org/web/20250114184734/https://www.reuters.com/legal/government/us-court-blocks-tapestrys-85-billion-acquisition-rival-capri-2024-10-24/#:~:text=FTC%20argued%20merger%20would%20eliminate%20competition%2C%20raise%20prices%20Capri,ruling%20Judge%20Rochon%20said%20harm%20to%20competition%20outweighs%20benefits)

## Outlook

Capri has a standalone strategy to draw on, but its old targets are not current guidance. When it completed the Versace acquisition, Capri intended to expand Versace accessories, stores and e-commerce; it also aspired to $8 billion in group revenue. Those plans identify ways to grow outside Kors. They do not establish recent customer demand, achieved returns on expansion or a timetable for recovery. [3](https://web.archive.org/web/20240902142231/https://www.vogue.co.uk/article/michael-kors-holdings-becomes-capri-holdings#:~:text=It%20was%20the%20much-publicised%20merger%20of%202018%2C%20and%2C%20on,Choo%2C%20which%20Kors%20acquired%20in%202017%20for%20%241.2%20billion.) [4](https://web.archive.org/web/20240902142231/https://www.vogue.co.uk/article/michael-kors-holdings-becomes-capri-holdings#:~:text=Read%20more%3A%20Michael%20Kors%20Buys%20Versace%20For%20%242.1%20Billion,goal%20to%20make%20an%20annual%20turnover%20of%20%242%20billion.) [5](https://web.archive.org/web/20240902142231/https://www.vogue.co.uk/article/michael-kors-holdings-becomes-capri-holdings#:~:text=Read%20more%3A%20What%20Does%20Michael%20Kors%E2%80%99s%20Power%20Move%20Mean,truthful.%20Read%20more%3A%20The%20Biggest%20Fashion%20Headlines%20Of%202018)

Treat the negative credit outlook as a separate, unverified question premise. A credit outlook indicates the possible direction of a debt rating; it supplies neither a sales growth rate nor a forecast period. Likewise, the reported fall in Capri’s shares followed the court ruling and cannot isolate a change in brand demand from the loss of the takeover prospect. Neither signal establishes the magnitude of any revenue decline. [2](https://web.archive.org/web/20250114184734/https://www.reuters.com/legal/government/us-court-blocks-tapestrys-85-billion-acquisition-rival-capri-2024-10-24/#:~:text=FTC%20argued%20merger%20would%20eliminate%20competition%2C%20raise%20prices%20Capri,ruling%20Judge%20Rochon%20said%20harm%20to%20competition%20outweighs%20benefits)

## What would change the view

The strongest recovery case is full-price growth at Kors, whose assortment spans handbags, shoes and apparel. Compare the year-over-year dollar gain in Kors sales with the combined dollar losses at Versace and Jimmy Choo over the same period: matching them stabilizes group revenue; exceeding them produces growth. Look for sustained full-price sell-through and stable or improving Kors and group operating margins. A discount-led offset with falling margins would pass the revenue test but fail the underwriting test. The available evidence lacks recent brand sales, markdowns and comparable margins, so it cannot quantify the required Kors growth rate or show that Kors can deliver it profitably. [6](https://en.wikipedia.org/w/index.php?oldid=1283895608) [1](https://en.wikipedia.org/w/index.php?oldid=1258970660)

## Sources

1. [Tapestry, Inc.](https://en.wikipedia.org/w/index.php?oldid=1258970660), available by 2024-11-22.
2. [US court blocks Tapestry's $8.5 billion acquisition of rival Capri | Reuters](https://web.archive.org/web/20250114184734/https://www.reuters.com/legal/government/us-court-blocks-tapestrys-85-billion-acquisition-rival-capri-2024-10-24/#:~:text=FTC%20argued%20merger%20would%20eliminate%20competition%2C%20raise%20prices%20Capri,ruling%20Judge%20Rochon%20said%20harm%20to%20competition%20outweighs%20benefits), available by 2025-01-14.
3. [Michael Kors' Acquisition Of Versace Is Complete | British Vogue | British Vogue](https://web.archive.org/web/20240902142231/https://www.vogue.co.uk/article/michael-kors-holdings-becomes-capri-holdings#:~:text=It%20was%20the%20much-publicised%20merger%20of%202018%2C%20and%2C%20on,Choo%2C%20which%20Kors%20acquired%20in%202017%20for%20%241.2%20billion.), available by 2024-09-02.
4. [Michael Kors' Acquisition Of Versace Is Complete | British Vogue | British Vogue](https://web.archive.org/web/20240902142231/https://www.vogue.co.uk/article/michael-kors-holdings-becomes-capri-holdings#:~:text=Read%20more%3A%20Michael%20Kors%20Buys%20Versace%20For%20%242.1%20Billion,goal%20to%20make%20an%20annual%20turnover%20of%20%242%20billion.), available by 2024-09-02.
5. [Michael Kors' Acquisition Of Versace Is Complete | British Vogue | British Vogue](https://web.archive.org/web/20240902142231/https://www.vogue.co.uk/article/michael-kors-holdings-becomes-capri-holdings#:~:text=Read%20more%3A%20What%20Does%20Michael%20Kors%E2%80%99s%20Power%20Move%20Mean,truthful.%20Read%20more%3A%20The%20Biggest%20Fashion%20Headlines%20Of%202018), available by 2024-09-02.
6. [Capri Holdings](https://en.wikipedia.org/w/index.php?oldid=1283895608), available by 2025-04-04.
