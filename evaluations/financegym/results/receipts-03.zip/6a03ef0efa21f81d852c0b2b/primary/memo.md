# Investment research memo

As of 2025-06-17

**Research question**
How do Copart's $3.34 billion cash position and historical reinvestment efficiency reconcile with significant Q4 2024 institutional divestments by AllianceBernstein and Capital Research, and the recent insider selling activity by directors James E. Meeks and Steven D. Cohan?

Some parts of the question could not be established from eligible evidence.

## Evidence

Copart’s expansion history explains why retaining cash could make sense, but does not establish reinvestment efficiency. The NER acquisition doubled the facility count; national coverage then helped Copart pursue insurer contracts. That gives a new yard a potential benefit beyond its own sales if it helps win volume across the network. Neither the acquisition history nor the cash premise tells us how much additional operating profit Copart earned per dollar invested, or whether comparable opportunities remain. [1](https://en.wikipedia.org/w/index.php?oldid=1288176292)

AllianceBernstein’s firmwide assets under management in April are not a measure of its Copart holdings in the preceding December. Compare consecutive quarter-end holdings disclosures on the same reporting basis for each manager to establish any net reduction; those snapshots would not reveal trade dates or motives. For Meeks and Cohan, check transaction filings for sale dates, amounts, remaining stakes and trading-plan disclosures. Even verified sales transfer holders’ shares, not Copart’s operating cash: portfolio rebalancing or personal diversification could coexist with attractive reinvestment returns. [2](https://en.wikipedia.org/w/index.php?oldid=1288484772)

## What would change the view

The hold case predicts that added capacity will attract insurer volume and lift operating profit as yards mature. The strongest alternative is that the best sites are already in place: cash may accumulate for lack of attractive projects while newer yards earn less. Verify the dated cash balance against Copart’s filings, then compare the sustained increase in after-tax operating profit with the capital committed to successive expansions, allowing similar time for each to mature. Persistently lower returns on mature projects would support a trim even without holder sales; confirmed sales alone would not. [1](https://en.wikipedia.org/w/index.php?oldid=1288176292)

## Sources

1. [Copart](https://en.wikipedia.org/w/index.php?oldid=1288176292), available by 2025-04-30.
2. [AllianceBernstein](https://en.wikipedia.org/w/index.php?oldid=1288484772), available by 2025-05-02.
