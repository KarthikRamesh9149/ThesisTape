# Investment research memo

As of 2025-07-29

**Research question**
How do Teck Resources' recent earnings beats, the $2.4 billion Highland Valley copper mine extension, and the Quebrada Blanca ramp-up reconcile with the simultaneous price target reductions by JP Morgan and RBC, and what does this suggest about the company's valuation as it transitions into a copper-focused producer?

## Answer

As of 2025-07-29, Teck’s future copper production warrants an execution-risk discount relative to a valuation that assumes the mines deliver on schedule, not a premium simply for exiting coal. The transition is material: the coal divestiture valued those operations at US$9 billion and left Teck focused on copper and zinc. If confirmed, the earnings beats and the JP Morgan and RBC target cuts would not conflict: earnings can exceed expectations for a past quarter while the expected value of future mine cash flows falls. That is a valuation judgment, not a finding that Teck’s shares already trade at a discount. [1](https://en.wikipedia.org/w/index.php?oldid=1291896569)

## Evidence

The earnings beats and simultaneous target cuts remain unverified question premises. The available history reports revenue from an earlier period, not recent reported earnings against pre-release consensus on the same accounting basis. It supplies neither bank’s dated note, prior and revised targets, currency or rationale. A lower target alone would not establish a lower valuation multiple: a bank could apply the same multiple to a smaller earnings forecast. There is no basis here for attributing either bank’s decision to mine performance. [1](https://en.wikipedia.org/w/index.php?oldid=1291896569)

The Highland Valley extension and its stated cost are unverified question premises. Teck’s Highland Valley mine produced 119,000 tonnes of copper in 2016, but that history establishes neither the extension budget nor its currency or spending schedule. The extension’s value depends on how much profitable production it would preserve relative to operating the mine without it. Construction could therefore reduce near-term free cash flow even if the added years of production justify the investment. An earnings beat would not settle the funding question: the relevant test is whether operating cash flow covers both sustaining capital and extension spending. [1](https://en.wikipedia.org/w/index.php?oldid=1291896569)

## Outlook

Quebrada Blanca presents a different valuation test: how quickly it can turn capacity into profitable copper sales. The evidence confirms Teck runs the Chilean mine, not the pace or cost of the reported ramp-up. The base case gives partial credit for future production: slower throughput would defer receipts and spread fixed costs over fewer saleable tonnes while Highland Valley spending could draw on the same cash. Without production, unit-cost and capital-spending data, neither the cash shortfall nor the appropriate discount can be quantified. [1](https://en.wikipedia.org/w/index.php?oldid=1291896569)

## What would change the view

The strongest case for a premium is that Quebrada Blanca reaches sustained, profitable output soon enough to help fund Highland Valley, giving shareholders a longer copper production life without a prolonged drain on cash. The observable signal would be successive operating reports showing Quebrada Blanca meeting throughput, recovery and unit-cost guidance, Highland Valley meeting disclosed budget milestones, and positive free cash flow after extension spending at comparable copper prices. That would justify reducing the execution discount; a premium over other copper producers would still require a peer valuation comparison. [1](https://en.wikipedia.org/w/index.php?oldid=1291896569)

## Sources

1. [Teck Resources](https://en.wikipedia.org/w/index.php?oldid=1291896569), available by 2025-05-24.
