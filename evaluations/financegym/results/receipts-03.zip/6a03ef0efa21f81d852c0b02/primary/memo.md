# Investment research memo

As of 2025-06-29

**Research question**
How do Colin Langan's June 2025 rating adjustments and price target revisions for Autoliv, BorgWarner, and Dana reflect a diverging sector outlook between diversified auto suppliers and pure-play electric vehicle manufacturers like Tesla and Rivian?

## Answer

As of 2025-06-29, the evidence does not establish that Wells Fargo’s Colin Langan favored Autoliv, BorgWarner and Dana over Tesla and Rivian in June 2025. That preference is an unverified premise of the question. None of the supplied sources reports Langan’s prior or new rating for any of the companies. Separately, none reports a prior or revised price target. A target increase would not, by itself, constitute a rating upgrade. The distinction matters because a higher valuation need not imply a stronger recommendation. [1](https://web.archive.org/web/20250413011922/https://www.kbb.com/car-news/ev-sales-jumped-10-in-the-first-quarter/#:~:text=Americans%20bought%2010.6%25%20more%20electric%20vehicles%20%28EVs%29%20in%20the,electric%2C%20up%20half%20a%20percent%20from%20last%20year%E2%80%99s%20total.) [2](https://en.wikipedia.org/w/index.php?oldid=1295235410)

## Evidence

The strongest market evidence points to a divergence *within* the US EV market, not between suppliers and EV makers. Kelley Blue Book reports that first-quarter EV purchases rose 10.6% year over year, while sales of Tesla’s Model Y fell 34% on the same basis. That contrast is consistent with a Tesla-specific competitive or product issue rather than a market-wide demand decline. It does not establish Langan’s rationale, show comparable weakness at Rivian or identify a catalyst for Autoliv, BorgWarner or Dana. [1](https://web.archive.org/web/20250413011922/https://www.kbb.com/car-news/ev-sales-jumped-10-in-the-first-quarter/#:~:text=Americans%20bought%2010.6%25%20more%20electric%20vehicles%20%28EVs%29%20in%20the,electric%2C%20up%20half%20a%20percent%20from%20last%20year%E2%80%99s%20total.) [3](https://web.archive.org/web/20250413011922/https://www.kbb.com/car-news/ev-sales-jumped-10-in-the-first-quarter/#:~:text=Stellantis%20launched%20the%20first%20EVs%20under%20the%20Jeep%20and,the%20first%20quarter%20were%20down%2026%25%20from%20that%20peak.)

## What would change the view

The working base case is to assess each company on its own rather than infer a sector call from the sales split. The strongest alternative is that Langan favored diversified suppliers for a shared reason even as EV sales grew. To distinguish those views, compare his dated June notes with the preceding rating and target for each stock. Consistently stronger supplier ratings would establish a preference; a common earnings or valuation assumption explicitly driving the revisions would support a sector explanation. Distinct catalysts would instead support company-specific calls, even if the targets moved together. [4](https://web.archive.org/web/20250413011922/https://www.kbb.com/car-news/ev-sales-jumped-10-in-the-first-quarter/#:~:text=New%20EVs%20Pick%20Up%20Sales%20Pace%20The%20sales%20pace,Cadillac%20Lyriq%2C%20and%20even%20the%20off-road-oriented%20GMC%20Hummer%20EV.) [3](https://web.archive.org/web/20250413011922/https://www.kbb.com/car-news/ev-sales-jumped-10-in-the-first-quarter/#:~:text=Stellantis%20launched%20the%20first%20EVs%20under%20the%20Jeep%20and,the%20first%20quarter%20were%20down%2026%25%20from%20that%20peak.)

## Sources

1. [EV Sales Jumped 10% in the First Quarter - Kelley Blue Book](https://web.archive.org/web/20250413011922/https://www.kbb.com/car-news/ev-sales-jumped-10-in-the-first-quarter/#:~:text=Americans%20bought%2010.6%25%20more%20electric%20vehicles%20%28EVs%29%20in%20the,electric%2C%20up%20half%20a%20percent%20from%20last%20year%E2%80%99s%20total.), available by 2025-04-13.
2. [Rivian](https://en.wikipedia.org/w/index.php?oldid=1295235410), available by 2025-06-12.
3. [EV Sales Jumped 10% in the First Quarter - Kelley Blue Book](https://web.archive.org/web/20250413011922/https://www.kbb.com/car-news/ev-sales-jumped-10-in-the-first-quarter/#:~:text=Stellantis%20launched%20the%20first%20EVs%20under%20the%20Jeep%20and,the%20first%20quarter%20were%20down%2026%25%20from%20that%20peak.), available by 2025-04-13.
4. [EV Sales Jumped 10% in the First Quarter - Kelley Blue Book](https://web.archive.org/web/20250413011922/https://www.kbb.com/car-news/ev-sales-jumped-10-in-the-first-quarter/#:~:text=New%20EVs%20Pick%20Up%20Sales%20Pace%20The%20sales%20pace,Cadillac%20Lyriq%2C%20and%20even%20the%20off-road-oriented%20GMC%20Hummer%20EV.), available by 2025-04-13.
