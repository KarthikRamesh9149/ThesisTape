# Investment research memo

As of 2025-07-21

**Research question**
How do PTTEP’s recent strategic actions—including the divestment of North American assets, the acquisition of Jadestone’s Sinphuhorm stake, and intensified drilling campaigns in Sarawak—impact the feasibility of its 900,000 boe/d production target for 2030 amid ongoing recovery challenges at the Erawan gas field?

Some parts of the question could not be established from eligible evidence.

## Evidence

The North American divestment and the purchase of Jadestone’s Sinphuhorm stake, as described in the question, have opposite effects on attributable volumes only to the extent that the interests carry output. The relevant comparison is the volume PTTEP would have retained from the sold interests in the target year against the volume due to PTTEP from the acquired stake that year—not the gross output of Sinphuhorm. The historical portfolio count establishes neither the transactions’ effective dates nor their net rates. There is no basis to say the purchase replaces the loss; a baseline taken after closing must not count either transaction again. [1](https://en.wikipedia.org/w/index.php?oldid=1301342510)

Erawan recovery would help PTTEP grow from a depressed baseline, but restoring lost flow is not new field capacity. Credit only the sustained increase above the chosen baseline, and none of the recovery already reflected in it. The portfolio profile counts Thai projects but gives no Erawan rate or recovery schedule. It therefore cannot show how much of the gap restoration would close or whether the restored rate could be maintained. [1](https://en.wikipedia.org/w/index.php?oldid=1301342510)

Treat the Sarawak drilling campaign described in the question as exploration upside, not committed supply. Bintulu’s offshore gas history and LNG infrastructure make commercialization plausible in principle; neither demonstrates a commercial PTTEP discovery, a sanctioned development or access to processing capacity. Include a project in the committed case only when its approval, timetable and PTTEP share support an attributable rate deliverable by the target year. [2](https://en.wikipedia.org/w/index.php?oldid=1300423154)

## What would change the view

The investment base case leaves the target unproven. The strongest alternative is that sustained Erawan recovery, Sinphuhorm and timely Sarawak developments together more than offset divested volumes and decline elsewhere. The decisive signal would be a dated PTTEP reconciliation from reported production or sales to a target on the same basis: net volumes sold and acquired, observed Erawan delivery, and sanctioned project start dates with attributable rates after ramp-up. If those rates cover the gap after decline without relying on unsanctioned wells, the target becomes credible. Project counts and regional infrastructure cannot pass that test. [1](https://en.wikipedia.org/w/index.php?oldid=1301342510) [2](https://en.wikipedia.org/w/index.php?oldid=1300423154)

## Sources

1. [PTT Exploration and Production](https://en.wikipedia.org/w/index.php?oldid=1301342510), available by 2025-07-19.
2. [Bintulu](https://en.wikipedia.org/w/index.php?oldid=1300423154), available by 2025-07-14.
