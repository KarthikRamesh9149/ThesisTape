# Investment research memo

As of 2025-05-27

**Research question**
How is the operational divergence between H World Group's Legacy-Huazhu and Legacy-DH segments impacting its long-term margin profile, considering the Q1 2025 earnings miss and the aggressive transition to a 91% manachised business model under CEO Jin Hui's expansion strategy?

Some parts of the question could not be established from eligible evidence.

## Answer

As of 2025-05-27, I would not forecast a sustained increase in H World’s consolidated operating margin above its 2024 level solely on the strength of the expansion attributed to CEO Jin Hui. Legacy-Huazhu can earn fees from additional rooms without directly operating the hotels. But weaker Legacy-Huazhu revenue per available room and a burdensome Legacy-DH cost base are unverified question premises. If both persist, lower fees on existing rooms and costs at DH could offset the profit from new rooms. The available evidence establishes the fee model and the acquisition of Deutsche Hospitality, but gives neither the group’s baseline operating margin nor the segment results needed to quantify the offset. [1](https://web.archive.org/web/20250425054324/https://ir.hworld.com/news-releases/news-release-details/huazhu-group-limited-announces-acquisition-blossom-hill-hotels#:~:text=Huazhu%20Group%20Limited%20is%20a%20leading%20hotel%20operator%20and,For%20more%20information%2C%20please%20visit%20the%20Company%E2%80%99s%20website%3A%20http%3A%2F%2Fir.huazhu.com.) [2](https://en.wikipedia.org/w/index.php?oldid=1265176034) [3](https://web.archive.org/web/20250512054054/https://www.cushmanwakefield.com/en/germany/news/2025/04/hotelinvestmentmarket-germany#:~:text=The%20hotel%20segment%20accounted%20for%206%25%20of%20the%20total,for%20its%20award-winning%20culture.%20For%20additional%20information%2C%20visit%20www.cushmanwakefield.com.)

## Evidence

The Q1 2025 miss was in adjusted EPS and, according to Zacks’s headline, revenue. Adjusted EPS was $0.34 against consensus of $0.42, an actual-minus-consensus difference of -0.08 per share, despite improving from $0.29 a year earlier. The excerpt gives no size for the revenue miss and no operating-profit estimate. It therefore establishes neither an operating-profit miss nor a decline in operating margin. [4](https://web.archive.org/web/20250520155503/https://www.zacks.com/stock/news/2474420/h-world-group-htht-misses-q1-earnings-and-revenue-estimates#:~:text=If%20you%20wish%20to%20go%20to%20ZacksTrade%2C%20click%20OK.,year%20ago.%20These%20figures%20are%20adjusted%20for%20non-recurring%20items.)

## What would change the view

The strongest case for a higher margin is that new fee-paying rooms add more profit per unit of reported revenue than directly operated hotels, even without a RevPAR recovery. The risk is that lower room takings reduce revenue-linked fees across the existing Huazhu network while DH’s costs do not fall with revenue. To distinguish those outcomes, track Huazhu fee revenue per operating fee-paying room alongside comparable-hotel RevPAR, then compare each segment’s operating profit with its revenue. I would raise the base case if fee growth consistently lifted Huazhu’s margin enough to carry the consolidated margin above its baseline after DH costs. More openings alone would not meet that test. [1](https://web.archive.org/web/20250425054324/https://ir.hworld.com/news-releases/news-release-details/huazhu-group-limited-announces-acquisition-blossom-hill-hotels#:~:text=Huazhu%20Group%20Limited%20is%20a%20leading%20hotel%20operator%20and,For%20more%20information%2C%20please%20visit%20the%20Company%E2%80%99s%20website%3A%20http%3A%2F%2Fir.huazhu.com.)

## Checked calculations

- C1. Q1 2025 adjusted EPS: actual minus Zacks consensus (not an operating profit shortfall) (USD per share) — 0.34 − 0.42 = -0.08 [4](https://web.archive.org/web/20250520155503/https://www.zacks.com/stock/news/2474420/h-world-group-htht-misses-q1-earnings-and-revenue-estimates#:~:text=If%20you%20wish%20to%20go%20to%20ZacksTrade%2C%20click%20OK.,year%20ago.%20These%20figures%20are%20adjusted%20for%20non-recurring%20items.)

## Sources

1. [Huazhu Group Limited Announces Acquisition of Blossom Hill Hotels & Resorts | H World Group Limited](https://web.archive.org/web/20250425054324/https://ir.hworld.com/news-releases/news-release-details/huazhu-group-limited-announces-acquisition-blossom-hill-hotels#:~:text=Huazhu%20Group%20Limited%20is%20a%20leading%20hotel%20operator%20and,For%20more%20information%2C%20please%20visit%20the%20Company%E2%80%99s%20website%3A%20http%3A%2F%2Fir.huazhu.com.), available by 2025-04-25.
2. [H World Group Limited](https://en.wikipedia.org/w/index.php?oldid=1265176034), available by 2024-12-25.
3. [Further revival on the German hotel investment market | DE | Cushman & Wakefield](https://web.archive.org/web/20250512054054/https://www.cushmanwakefield.com/en/germany/news/2025/04/hotelinvestmentmarket-germany#:~:text=The%20hotel%20segment%20accounted%20for%206%25%20of%20the%20total,for%20its%20award-winning%20culture.%20For%20additional%20information%2C%20visit%20www.cushmanwakefield.com.), available by 2025-05-12.
4. [H World Group (HTHT) Misses Q1 Earnings and Revenue Estimates - May 20, 2025 - Zacks.com](https://web.archive.org/web/20250520155503/https://www.zacks.com/stock/news/2474420/h-world-group-htht-misses-q1-earnings-and-revenue-estimates#:~:text=If%20you%20wish%20to%20go%20to%20ZacksTrade%2C%20click%20OK.,year%20ago.%20These%20figures%20are%20adjusted%20for%20non-recurring%20items.), available by 2025-05-20.
