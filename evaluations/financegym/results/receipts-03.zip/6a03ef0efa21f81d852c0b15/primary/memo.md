# Investment research memo

As of 2025-09-29

**Research question**
How has the evolving capital structure of Lithium Americas (LAC), specifically its reliance on the $2.3 billion U.S. Department of Energy loan and strategic infusions from Orion Resource Partners, impacted its risk profile and valuation amidst reported project delays in 2025?

## Answer

As of 2025-09-29, the U.S. Department of Energy’s announced $2.26 billion construction loan made a funding shortfall at Lithium Americas’ Thacker Pass project less likely than if LAC had to raise that capital in the market. But the evidence does not show that the benefit outweighed drawdown risk, repayment obligations and dilution for existing shareholders. The announcement establishes the scale of potential funding, not cash received. The strategic infusions attributed to Orion Resource Partners are an unverified question premise; I would not count them as available cash or assign them a dilution cost without their terms. [1](https://en.wikipedia.org/w/index.php?oldid=1294857536)

## Evidence

Timing matters more to shortfall risk than the headline sum. General Motors illustrates the distinction: it announced $650M, but the initial investment documented as completed was $320 million. GM became both a shareholder and an offtake partner; that is evidence of strategic backing, not evidence of an Orion closing. Likewise, the general DOE account describes conditions on loan guarantees, but does not establish the conditions on this particular loan or whether LAC met them. A loan drawn before construction bills fall due can avert a forced equity raise; the same loan drawn afterward cannot avert the interim cash gap. [2](https://en.wikipedia.org/w/index.php?oldid=1310900207) [3](https://en.wikipedia.org/w/index.php?oldid=1311010567)

The reported 2025 delay is not established against a comparable milestone. The earlier account expected production to begin in 2026 and full production in 2027. Neither was due in the reporting year. A construction setback could still threaten those dates, but the evidence gives no revised date for either milestone. A revised first-production forecast should be compared with the earlier start date, not the full-production target. [1](https://en.wikipedia.org/w/index.php?oldid=1294857536)

## Outlook

My base case is improved financing prospects, not a demonstrated increase in value per LAC share. Timely funding raises the chance the mine reaches production, but loan proceeds come with a repayment claim; any new shares would spread the residual value across more holders. A genuine production delay would push receipts further out even if the mine were fully financed. The supplied stock-slide reference concerns 2023, not the reported delay period. There is no contemporaneous price series here to measure a market reaction, and even an observed move would not measure a change in the mine’s discounted cash flows. [1](https://en.wikipedia.org/w/index.php?oldid=1294857536)

## What would change the view

The strongest favorable alternative is that DOE and Orion funding together eliminate the need for a more dilutive emergency raise. The decisive test is a dated cash forecast matching actual draws and documented Orion proceeds to construction payments through first production, followed by a per-share comparison after debt service and any Orion claims. Coverage through ramp-up on better terms than the equity raise avoided would support a valuation uplift. A payment due before the next permitted draw, especially alongside a later first-production forecast, would favor the shortfall case instead. [1](https://en.wikipedia.org/w/index.php?oldid=1294857536) [2](https://en.wikipedia.org/w/index.php?oldid=1310900207)

## Sources

1. [Lithium Americas](https://en.wikipedia.org/w/index.php?oldid=1294857536), available by 2025-06-10.
2. [Thacker Pass lithium mine](https://en.wikipedia.org/w/index.php?oldid=1310900207), available by 2025-09-12.
3. [United States Department of Energy](https://en.wikipedia.org/w/index.php?oldid=1311010567), available by 2025-09-12.
