# Investment research memo

As of 2025-04-28

**Research question**
Given Susan Morris's transition to CEO of Albertsons Companies (ACI) on May 1, 2025, what impact will her operational leadership have on the company's competitive strategy and margin preservation efforts relative to industry peers like Sprouts Farmers Market (SFM)?

## Answer

As of 2025-04-28, do not credit Albertsons with a narrower operating-margin gap versus Sprouts Farmers Market. Albertsons announced on March 3 that Susan Morris would succeed Vivek Sankaran on May 1, 2025. As COO, Morris already oversaw more than 2,200 stores. That experience favors continuity in how Albertsons competes for customers; the appointment was not yet effective and does not establish a margin gain. [1](https://web.archive.org/web/20250408012850/https://idahobusinessreview.com/2025/03/04/albertsons-ceo-retirement-susan-morris-succession/#:~:text=A%20change%20of%20leadership%20is%20set%20to%20take%20place,by%20evaluating%20internal%20and%20external%20candidates%20for%20the%20position.) [2](https://web.archive.org/web/20250408012850/https://idahobusinessreview.com/2025/03/04/albertsons-ceo-retirement-susan-morris-succession/#:~:text=%E2%80%9CThe%20Board%20is%20confident%20that%20Susan%20is%20the%20ideal,boards%20of%20IDACORP%2C%20Inc.%2C%20and%20the%20Food%20Marketing%20Institute.)

## Evidence

The base case is that Morris will execute Customers for Life rather than launch a new pricing strategy. Sankaran expressed confidence that she would improve the customer offering, but Morris described growth plans she had already helped develop. Those statements are consistent: better execution could improve value for shoppers without a change in strategy. Neither statement commits Albertsons to price cuts or identifies savings to pay for them. [3](https://web.archive.org/web/20250408012850/https://idahobusinessreview.com/2025/03/04/albertsons-ceo-retirement-susan-morris-succession/#:~:text=%E2%80%9CI%20have%20worked%20closely%20with%20Vivek%20and%20the%20leadership,he%20prepares%20to%20exit%20in%20the%20next%20two%20months.) [4](https://web.archive.org/web/20250408012850/https://idahobusinessreview.com/2025/03/04/albertsons-ceo-retirement-susan-morris-succession/#:~:text=%E2%80%9CIt%20has%20been%20a%20privilege%20to%20lead%20Albertsons%20Cos.,communities%20where%20we%20operate.%E2%80%9D%20It%E2%80%99s%20an%20outlook%20Morris%20echoed.)

## Outlook

Productivity-funded pricing is the strongest upside case, not a demonstrated outcome. If savings just cover the cost of keeping prices competitive, Albertsons may preserve its operating margin without gaining ground on Sprouts. If savings exceed that cost or lower prices drive enough additional profitable sales, Albertsons could improve its margin. Sprouts has a substantial produce business and its own private-label range, so its margin need not move in step. The starting gap is an unverified question premise: the supplied evidence gives no comparable operating margins or quantified net savings. [3](https://web.archive.org/web/20250408012850/https://idahobusinessreview.com/2025/03/04/albertsons-ceo-retirement-susan-morris-succession/#:~:text=%E2%80%9CI%20have%20worked%20closely%20with%20Vivek%20and%20the%20leadership,he%20prepares%20to%20exit%20in%20the%20next%20two%20months.) [5](https://en.wikipedia.org/w/index.php?oldid=1284819897)

## What would change the view

Give Morris credit for margin preservation when Albertsons can reconcile realized productivity savings with spending on lower prices and implementation costs, while showing that prices became more competitive and operating margin held. For credit versus Sprouts, compare operating income as a share of sales for both retailers on a consistent basis over comparable periods. A smaller gap caused only by a decline at Sprouts would not validate Morris’s execution; management’s promised outlook is a forecast to test, not that test’s result. [3](https://web.archive.org/web/20250408012850/https://idahobusinessreview.com/2025/03/04/albertsons-ceo-retirement-susan-morris-succession/#:~:text=%E2%80%9CI%20have%20worked%20closely%20with%20Vivek%20and%20the%20leadership,he%20prepares%20to%20exit%20in%20the%20next%20two%20months.)

## Sources

1. [Albertsons CEO to retire, Susan Morris named successor](https://web.archive.org/web/20250408012850/https://idahobusinessreview.com/2025/03/04/albertsons-ceo-retirement-susan-morris-succession/#:~:text=A%20change%20of%20leadership%20is%20set%20to%20take%20place,by%20evaluating%20internal%20and%20external%20candidates%20for%20the%20position.), available by 2025-04-08.
2. [Albertsons CEO to retire, Susan Morris named successor](https://web.archive.org/web/20250408012850/https://idahobusinessreview.com/2025/03/04/albertsons-ceo-retirement-susan-morris-succession/#:~:text=%E2%80%9CThe%20Board%20is%20confident%20that%20Susan%20is%20the%20ideal,boards%20of%20IDACORP%2C%20Inc.%2C%20and%20the%20Food%20Marketing%20Institute.), available by 2025-04-08.
3. [Albertsons CEO to retire, Susan Morris named successor](https://web.archive.org/web/20250408012850/https://idahobusinessreview.com/2025/03/04/albertsons-ceo-retirement-susan-morris-succession/#:~:text=%E2%80%9CI%20have%20worked%20closely%20with%20Vivek%20and%20the%20leadership,he%20prepares%20to%20exit%20in%20the%20next%20two%20months.), available by 2025-04-08.
4. [Albertsons CEO to retire, Susan Morris named successor](https://web.archive.org/web/20250408012850/https://idahobusinessreview.com/2025/03/04/albertsons-ceo-retirement-susan-morris-succession/#:~:text=%E2%80%9CIt%20has%20been%20a%20privilege%20to%20lead%20Albertsons%20Cos.,communities%20where%20we%20operate.%E2%80%9D%20It%E2%80%99s%20an%20outlook%20Morris%20echoed.), available by 2025-04-08.
5. [Sprouts Farmers Market](https://en.wikipedia.org/w/index.php?oldid=1284819897), available by 2025-04-09.
