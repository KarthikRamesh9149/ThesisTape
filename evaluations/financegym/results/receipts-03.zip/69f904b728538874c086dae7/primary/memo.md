# Investment research memo

As of 2025-07-29

**Research question**
How has JPMorgan Chase's mid-2025 pivot to accepting Bitcoin ETFs as loan collateral impacted the asset class's institutional credibility and net flow volatility, specifically examining SoSoValue's reported data trends from May through July 2025?

## Answer

As of 2025-07-29, JPMorgan Chase’s acceptance of spot Bitcoin ETF shares as loan collateral is an unverified question premise. The supplied JPMorgan passages document unrelated lending and custody matters, not a rollout. They do not contain the planning report either. The defensible distinction is between a reported intention and a verified lending practice: neither the scale of any lending nor an increase in institutional credibility is established here. [1](https://en.wikipedia.org/w/index.php?oldid=1301555934)

## Evidence

The supplied evidence does not show whether daily net flows into spot Bitcoin ETFs became more or less volatile from May through July 2025, up to the cutoff. The passages cover JPMorgan’s acquisition of Frank and its WorldCom settlement; neither supplies SoSoValue’s daily flow observations. Even if cumulative net inflows rose, the same total could reflect steady daily inflows or large inflows interspersed with outflows. [1](https://en.wikipedia.org/w/index.php?oldid=1301555934)

## What would change the view

The base case is to treat the reported plan, if corroborated, as a signal of lender interest rather than evidence of adoption. The strongest alternative is that JPMorgan had already begun lending against the shares. A dated collateral schedule in force by the cutoff would establish eligibility; a documented loan secured by the shares would establish use. Either would speak to acceptance at JPMorgan, not necessarily across lenders. To test the separate flow claim, compare the dispersion of SoSoValue’s aggregate daily net flows over comparable trading-day windows before and after the report. Even a clear shift would not identify a JPMorgan effect without a credible comparison accounting for broader market moves. [1](https://en.wikipedia.org/w/index.php?oldid=1301555934)

## Sources

1. [JPMorgan Chase](https://en.wikipedia.org/w/index.php?oldid=1301555934), available by 2025-07-20.
