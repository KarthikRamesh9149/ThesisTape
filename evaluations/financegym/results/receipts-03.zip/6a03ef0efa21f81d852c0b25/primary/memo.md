# Investment research memo

As of 2025-06-05

**Research question**
How is the integration of Marathon Oil and the resulting production surge influencing ConocoPhillips' valuation outlook, given the divergence between quantitative value models and the recent wave of sell-side rating downgrades and price target reductions observed in May 2025?

Some parts of the question could not be established from eligible evidence.

## Evidence

The acquisition changes what a production comparison measures: post-close ConocoPhillips includes Marathon barrels that pre-close ConocoPhillips did not. Consolidated output could therefore rise even if neither operator improved well performance. Marathon had already spun off its downstream operations, so the relevant cash-flow test is what the acquired production earns at realized oil and gas prices after operating costs and the capital needed to sustain output. The available evidence supplies neither acquired volumes nor that cash-flow contribution. [1](https://en.wikipedia.org/w/index.php?oldid=1287386462)

Which May cuts also involved rating downgrades? None can be verified from the available evidence; that is not a finding that none occurred. The dated transaction report establishes the closing, not an analyst action. Verification requires each firm’s dated old and new target and recommendation: a lower target with an unchanged recommendation is not a downgrade. Without those notes, the value models’ inputs or a cutoff share price, neither the size of a valuation gap nor its cause can be established. [1](https://en.wikipedia.org/w/index.php?oldid=1287386462)

## Outlook

My base case gives Marathon credit for acquired output but no valuation premium until cash generation per diluted share improves. A value model using normalized commodity prices and a sell-side target using a weaker near-term price forecast could both be internally consistent; those are possible explanations, not documented assumptions. To distinguish a price disagreement from an integration disagreement, compare the valuations at the same commodity prices and horizon, then examine what each assumes about costs, capital spending and share count. [2](https://en.wikipedia.org/w/index.php?oldid=1292266911) [1](https://en.wikipedia.org/w/index.php?oldid=1287386462)

## What would change the view

The strongest bullish alternative is that combining the upstream assets lowers recurring costs enough to lift sustainable free cash flow per diluted share beyond what the market price implies. I would look for a reconciliation from standalone ConocoPhillips to combined cash flow per share at common realized prices, separating acquired cash flow, realized savings, integration spending, sustaining capital and financing effects. A durable gain that supports a value above the cutoff price would justify the discount thesis; more barrels without that gain would favor caution, though not validate a particular target. [1](https://en.wikipedia.org/w/index.php?oldid=1287386462)

## Sources

1. [Marathon Oil](https://en.wikipedia.org/w/index.php?oldid=1287386462), available by 2025-04-25.
2. [ConocoPhillips](https://en.wikipedia.org/w/index.php?oldid=1292266911), available by 2025-05-26.
