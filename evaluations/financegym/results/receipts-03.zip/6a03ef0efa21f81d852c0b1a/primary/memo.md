# Investment research memo

As of 2025-05-27

**Research question**
Given the divergence between significant Q4 2024 institutional inflows from firms like Balyasny and D1 Capital and aggressive insider liquidation by CEO Douglas Yearley and CFO Martin Connor, how should investors assess Toll Brothers' valuation and margin sustainability as it pivots toward lower-priced inventory?

## Answer

Wait rather than buy Toll Brothers at the 2025-05-27 price. The reported significant Q4 2024 purchases by Balyasny and D1 Capital and aggressive insider selling by Douglas Yearley and Martin Connor are unverified question premises. The available evidence identifies Yearley as CEO but gives neither the shares bought by either manager nor the fraction of either insider’s stake sold. Give the reports no weight in the valuation. The cited home prices are not a stock quote; without a verified cutoff share price and a conservative estimate of cash earnings per share, a margin of safety is unproven, not necessarily absent. [1](https://en.wikipedia.org/w/index.php?oldid=1264406239) [2](https://en.wikipedia.org/w/index.php?oldid=1292602434)

## Evidence

Test the apparent divergence against the filings before interpreting it. Compare Toll share counts in consecutive quarter-end holdings filings for each manager: a larger reported stake would establish a net increase in shares held, not the cash spent, entry price or investment thesis. The later report naming Maplebear as D1 Capital’s largest U.S.-listed long position neither confirms nor contradicts an earlier Toll purchase. For Yearley and Connor, check transaction codes, trading-plan footnotes and holdings before and after each transaction. A discretionary sale of a substantial share of an insider’s stake is more informative than shares withheld for taxes, but even a verified sale would not establish that housing margins are deteriorating. None of the relevant filings is supplied. [2](https://en.wikipedia.org/w/index.php?oldid=1292602434) [1](https://en.wikipedia.org/w/index.php?oldid=1264406239)

## Outlook

Treat the pivot to cheaper inventory, faster sales and lower profit per delivery as an unverified question premise. Toll’s 2021 selling prices ranged from $663,700 in the South to $1,376,800 in the Pacific. A lower companywide average could therefore reflect geography rather than discounting; it would not by itself show margin erosion. In the underwriting base case, assume less gross profit per closing and give no credit for faster orders until they become deliveries. To preserve total homebuilding gross profit, the delivery count must rise enough to offset the lost dollars per home, not merely rise. [1](https://en.wikipedia.org/w/index.php?oldid=1264406239)

## What would change the view

The strongest buy case is that cheaper homes tie up less capital for less time: even with fewer gross-profit dollars per delivery, Toll could earn more on its average inventory investment. Look for higher deliveries per community, stable or rising total homebuilding gross profit and improving operating cash flow without deeper incentives, rather than faster orders alone. To move from wait to buy, verify the cutoff price and compare it with a conservative per-share value based on cash earnings after inventory reinvestment, allowing for net debt and a slower-turn downside. The historical price data supply none of those valuation inputs. [1](https://en.wikipedia.org/w/index.php?oldid=1264406239)

## Sources

1. [Toll Brothers](https://en.wikipedia.org/w/index.php?oldid=1264406239), available by 2024-12-21.
2. [D1 Capital Partners](https://en.wikipedia.org/w/index.php?oldid=1292602434), available by 2025-05-27.
