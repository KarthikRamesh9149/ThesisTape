# Investment research memo

As of 2025-06-05

**Research question**
Evaluating MoonLake Immunotherapeutics' (MLTX) strategic position: Does the $500 million non-dilutive financing from Hercules Capital and reported $3 billion acquisition interest from Merck accurately reflect the clinical derisking of sonelokimab, considering shifting institutional sentiment and the engagement of Goldman Sachs and Morgan Stanley?

## Answer

As of 2025-06-05, keep the estimated probability of sonelokimab’s pivotal trial success unchanged. Treat the Hercules Capital facility for MoonLake Immunotherapeutics, described as non-dilutive and in the hundreds of millions of dollars, and Merck’s reported multibillion-dollar acquisition interest as unverified question premises. If accurate, the facility could help MoonLake reach a readout and the interest could improve its sale prospects. Neither establishes that patients are more likely to benefit. The documented Merck transactions concern other assets, not sonelokimab. [1](https://en.wikipedia.org/w/index.php?oldid=1293714226)

## Evidence

For financing risk, the relevant amount is the cash MoonLake can draw before the readout, not the facility ceiling. Without the Hercules agreement, draw conditions, repayment terms and MoonLake’s cash needs, the evidence cannot establish how much runway the facility buys or verify the non-dilutive label. Merck’s Afferent acquisition illustrates the narrower point that a headline can include contingent payments; it is not evidence of Hercules’s terms. [1](https://en.wikipedia.org/w/index.php?oldid=1293714226)

Keep takeover evidence separate from investor sentiment. Merck & Co.’s purchase of Immune Design shows a willingness to buy immunotherapy programs, not a bid for MoonLake. The Goldman Sachs reference concerns a historical Merck buyback, not a MoonLake mandate; the record does not confirm a Morgan Stanley engagement either. Even verified adviser appointments would indicate deal preparation rather than clinical validation. Without dated, comparable holdings or investor statements, neither the direction of institutional sentiment nor a clinical reason for a shift is established. [1](https://en.wikipedia.org/w/index.php?oldid=1293714226)

## What would change the view

The strongest alternative is that lender and buyer diligence uncovered favorable clinical evidence not yet public. A signed bid would strengthen the takeover case, and confirmation of funds drawable before results would strengthen the financing case. To raise the clinical estimate, look instead for disclosed sonelokimab data showing a clinically meaningful benefit versus control on the prespecified pivotal endpoint, with acceptable safety. The evidence contains no such comparison. Merck’s separate molnupiravir history illustrates the distinction: a purchase commitment conditional on approval and a reported patient outcome were different events. [1](https://en.wikipedia.org/w/index.php?oldid=1293714226)

## Sources

1. [Merck & Co.](https://en.wikipedia.org/w/index.php?oldid=1293714226), available by 2025-06-03.
