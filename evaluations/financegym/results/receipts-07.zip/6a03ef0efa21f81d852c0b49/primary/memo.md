# Investment research memo

As of 2025-04-23

**Research question**
How did the sharp valuation contraction and oversold technical profile of the VanEck Oil Services ETF (OIH) in early 2025 drive the divergent institutional positioning between major U.S. asset managers like Citadel and JPMorgan versus international pension and insurance funds?

## Answer

As of 2025-04-23, the available evidence does not show that Citadel and JPMorgan changed their OIH holdings in the opposite direction from international pension and insurance funds in early 2025. The materials describe what managers disclose but contain no manager-specific OIH positions. Neither the direction nor the size of a change is established for either group, so there is no documented divergence to attribute to the selloff. [1](https://en.wikipedia.org/w/index.php?oldid=1223018657)

## Evidence

The sharp valuation contraction and oversold reading are unverified premises of the question. The relative strength index measures recent price momentum, not valuation; the materials supply neither a dated OIH reading nor a valuation multiple before and after the decline. Even a confirmed oversold reading would identify a possible reason to buy, not which managers acted on it. [2](https://en.wikipedia.org/w/index.php?oldid=1284209177)

The holdings date, not the filing date, determines whether a position could reflect the selloff. A filing published during the decline could describe a December quarter-end position that predates it. March quarter-end filings were not yet due at the cutoff, and no early filing is supplied. Even a March snapshot would not distinguish a trade before the price break from one after it within the same quarter. [1](https://en.wikipedia.org/w/index.php?oldid=1223018657)

## What would change the view

The base case is to leave any selloff response unattributed. The strongest alternative is that an opposite-direction pattern was already underway: test it by comparing changes in OIH share counts across successive pre-selloff quarter ends for Citadel, JPMorgan and a named, consistent set of international funds. Use shares rather than market value, which can fall without a sale. A split already visible before the break would favor a pre-existing divergence; a new split in trades dated after the break would favor a response. Manager commentary tying those trades to valuation or momentum would strengthen the case for motive. [1](https://en.wikipedia.org/w/index.php?oldid=1223018657)

## Sources

1. [Form 13F](https://en.wikipedia.org/w/index.php?oldid=1223018657), available by 2024-05-09.
2. [Relative strength index](https://en.wikipedia.org/w/index.php?oldid=1284209177), available by 2025-04-06.
