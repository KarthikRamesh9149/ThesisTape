# Investment research memo

As of 2025-01-27

**Research question**
Following the 2023 safety crisis and leadership overhaul, how do Cruise’s operational restarts in Texas and Arizona, combined with General Motors’ $1 billion budget reduction, impact the unit’s long-term commercialization timeline and competitive standing against Waymo and Tesla?

Some parts of the question could not be established from eligible evidence.

## Answer

As of 2025-01-27, GM’s December funding decision ended Cruise’s funded plan for paid driverless service rather than postponing its launch. Even taking the question’s account of supervised restarts in Texas and Arizona as given, those tests did not establish a commercial launch date. GM redirected Cruise’s work to driver assistance for personal vehicles. Its mid-2025 target was for completing the restructuring, not for carrying paying passengers. By contrast, Waymo was already providing 150,000 paid rides per week in October. [1](https://en.wikipedia.org/w/index.php?oldid=1263362819) [2](https://en.wikipedia.org/w/index.php?oldid=1271601084)

## Evidence

The strongest case for an eventual relaunch was that supervised testing after the leadership overhaul could help Cruise rebuild its safety record. Cruise had previously secured permission to charge for driverless rides in San Francisco. But after the pedestrian collision, California suspended its permits, and Cruise itself extended the pause nationwide. Returning cars to roads in Arizona and Texas with supervision was therefore distinct from restoring fare-paying service without a driver. The available evidence establishes neither the scope of the restarted tests nor a new commercial authorization. [3](https://en.wikipedia.org/w/index.php?oldid=1271340250) [1](https://en.wikipedia.org/w/index.php?oldid=1263362819)

On deployed service, Waymo led both peers: it operated commercial robotaxis in Phoenix, San Francisco and Los Angeles, logging over 1 million miles weekly in October 2024. Tesla’s Cybercab and Robovan were concepts for a future network, not evidence of public paid driverless rides. Cruise’s exit removed a former commercial operator from the contest; it did not establish Tesla as a deployed substitute or prove Waymo’s service was profitable. [2](https://en.wikipedia.org/w/index.php?oldid=1271601084) [4](https://en.wikipedia.org/w/index.php?oldid=1271798791) [1](https://en.wikipedia.org/w/index.php?oldid=1263362819)

## What would change the view

The investment base case excludes Cruise robotaxi fares rather than pushing them into a later forecast year. Its earlier revenue targets predated both the suspension and the funding decision. The strongest alternative is that GM or a partner finances a new service using the retained technology. A committed fleet budget and a dated, authorized plan to carry paying riders without a safety driver would justify reinstating a launch assumption; further supervised miles alone would not. [3](https://en.wikipedia.org/w/index.php?oldid=1271340250) [1](https://en.wikipedia.org/w/index.php?oldid=1263362819)

## Sources

1. [Cruise (autonomous vehicle)](https://en.wikipedia.org/w/index.php?oldid=1263362819), available by 2024-12-16.
2. [Waymo](https://en.wikipedia.org/w/index.php?oldid=1271601084), available by 2025-01-24.
3. [General Motors](https://en.wikipedia.org/w/index.php?oldid=1271340250), available by 2025-01-23.
4. [Tesla, Inc.](https://en.wikipedia.org/w/index.php?oldid=1271798791), available by 2025-01-25.
