# Investment research memo

As of 2025-07-09

**Research question**
Considering the significant divestments by Avalon Ventures and insider Andrew Hollman Meyer alongside aggressive accumulation by RA Capital Management and top-tier analyst buy ratings, how should investors value Janux Therapeutics' TRACTr-based pipeline (JANX007/008) in the context of its 2025 buyout potential?

## Answer

As of 2025-07-09, pay no premium for a possible 2025 Janux acquisition. Standalone equity value is not estimable from the supplied evidence; that is not a judgment that the pipeline is worthless. The reported selling by Avalon Ventures and Andrew Hollman Meyer, buying by RA Capital Management and bullish analyst ratings are unverified question premises: neither their scale nor their timing is documented here. The relevant documented transaction is Merck’s announced $680 million Harpoon acquisition in January 2024. It shows strategic interest in T-cell engagers, not an offer for Janux. [1](https://en.wikipedia.org/w/index.php?oldid=1299005656)

## Evidence

Even if verified, the trades would not necessarily conflict. Avalon and Meyer could be reducing concentration while RA sees favorable clinical odds at its entry price. The stronger bearish reading is that the sellers expect disappointing data; a bullish analyst rating could reflect standalone upside without anticipating a sale. Dated filings showing trades relative to each holder’s stake, and analyst models separating pipeline value from takeover assumptions, would distinguish these interpretations better than the direction of a trade. The Harpoon precedent documents a buyer’s decision about a different company, not any of these actors’ motives. [1](https://en.wikipedia.org/w/index.php?oldid=1299005656)

Value each TRACTr candidate separately: discount its potential commercial cash flows, weight them by the probability of reaching market, and deduct remaining costs weighted by the probability of incurring them. Add net cash and subtract shared overhead once to reach equity value; use diluted shares for a per-share estimate. The record supplies no Janux efficacy, durability or safety results to anchor success probabilities, nor commercial forecasts, development budgets, net cash or a share count. Harpoon is a useful technology comparison because it also pursued tumor-dependent activation, but its whole-company price cannot substitute for either candidate’s cash flows. [1](https://en.wikipedia.org/w/index.php?oldid=1299005656)

## What would change the view

The base case is continued independent development. Durable responses at tolerable doses in larger cohorts would raise the affected candidate’s standalone value even without a buyer; failure to reproduce activity would lower it. The strongest alternative is a strategic buyer moving before those results mature to secure the platform. Merck’s $2.75 billion VelosBio announcement shows willingness to buy clinical-stage oncology assets, but that program was an antibody-drug conjugate, not a TRACTr engager. A disclosed Janux sale process or credible offer would warrant modeling a separate, probability-weighted deal premium over standalone value; another sector transaction would not. [1](https://en.wikipedia.org/w/index.php?oldid=1299005656)

## Sources

1. [Merck & Co.](https://en.wikipedia.org/w/index.php?oldid=1299005656), available by 2025-07-06.
