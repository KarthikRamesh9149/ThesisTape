# Investment research memo

As of 2025-07-21

**Research question**
How will PGIM's consolidation of its fixed income and private credit units into a $1 trillion platform under CEO Jacques Chappuis, combined with its strategic capital partnerships with Affirm and SoFi, drive AUM growth and influence Prudential Financial's broader asset management profitability through late 2025?

## Answer

As of 2025-07-21, keep both late-2025 forecasts unchanged: PGIM’s fee-earning AUM and its adjusted operating income contribution to Prudential Financial. The consolidation under Jacques Chappuis, the claimed trillion-dollar size of the combined credit platform and the capital partnerships with Affirm and SoFi are unverified premises of the question. The documented figure of more than $1 trillion covered all of PGIM as of December 2019, not the proposed credit platform. Even if the initiatives proceed as described, regrouping existing mandates adds no AUM, and access to loans does not establish that clients have deployed new fee-paying capital or that PGIM will earn enough in fees to cover its additional costs. [1](https://en.wikipedia.org/w/index.php?oldid=1301125242) [2](https://en.wikipedia.org/w/index.php?oldid=1299425876) [3](https://en.wikipedia.org/w/index.php?oldid=1294406411)

## Evidence

The historical figures establish the scale of the businesses being regrouped, not a new inflow. PGIM Fixed Income reported $968 billion and PGIM Private Capital managed $101 billion at December 31, 2020. Neither figure measures current fee-earning assets or establishes which mandates fall inside the proposed platform. Likewise, the historical reference naming David Hunt as CEO does not establish who leads PGIM at the cutoff. [1](https://en.wikipedia.org/w/index.php?oldid=1301125242)

## Outlook

The strongest upside case is that a combined public and private credit team wins fresh client mandates because it can source Affirm point-of-sale loans and draw on SoFi’s lending business. Loan purchases alone would not confirm that case: buying loans with cash already in a PGIM mandate changes the portfolio, not its AUM. For the base case, exclude undeployed commitments and count only incremental deployed balances that earn PGIM fees and remain outstanding after repayments or sales. [2](https://en.wikipedia.org/w/index.php?oldid=1299425876) [3](https://en.wikipedia.org/w/index.php?oldid=1294406411)

## What would change the view

Raise the AUM forecast on disclosure of funded net new client balances attributable to the partnerships, reconciled to fee-earning AUM and separated from internal transfers. Raise the income forecast only when fees on average deployed balances, plus demonstrable operating savings, exceed incremental underwriting and integration costs during the forecast period. A late deployment could lift closing AUM with little in-period profit. Affirm’s merchant commissions and borrower interest are not PGIM management fees; the available evidence supplies no PGIM fee rate, deployment schedule or net expense benefit. [2](https://en.wikipedia.org/w/index.php?oldid=1299425876) [1](https://en.wikipedia.org/w/index.php?oldid=1301125242)

## Sources

1. [PGIM](https://en.wikipedia.org/w/index.php?oldid=1301125242), available by 2025-07-18.
2. [Affirm Holdings](https://en.wikipedia.org/w/index.php?oldid=1299425876), available by 2025-07-08.
3. [SoFi](https://en.wikipedia.org/w/index.php?oldid=1294406411), available by 2025-06-07.
