# Investment research memo

As of 2025-07-09

**Research question**
How should investors reconcile the aggressive institutional positioning by Vanguard and Wellington in Tractor Supply Co. (TSCO) with the concurrent pattern of insider selling by CEO Harry Lawton III and recent price target reductions by Citigroup and Mizuho following the April earnings miss?

## Answer

Hold TSCO pending evidence of a sales recovery as of 2025-07-09. The April earnings miss, aggressive Vanguard and Wellington positioning, sales by CEO Harry Lawton III, and subsequent Citigroup and Mizuho target cuts are unverified question premises. The available material establishes neither the size of the trades or target changes nor the size of the miss. It offers no basis to add on institutional buying or to trim on the assumption that the miss reduced full-year earning power. [1](https://en.wikipedia.org/w/index.php?oldid=1277210912) [2](https://en.wikipedia.org/w/index.php?oldid=1295208050)

## Evidence

Give the reported ownership changes no directional weight. Vanguard offers both index and active strategies, and Wellington manages money for diverse clients. A manager-wide increase in TSCO shares would not distinguish a discretionary overweight from subscriptions or index rebalancing. Likewise, Lawton’s role makes his trading relevant, but does not establish that a sale reflected his view of demand. Look for a fund-level increase in weight relative to benchmark after accounting for flows, or a material reduction in Lawton’s retained stake outside a pre-existing plan. The passages document neither. [2](https://en.wikipedia.org/w/index.php?oldid=1295208050) [3](https://en.wikipedia.org/w/index.php?oldid=1287097379) [1](https://en.wikipedia.org/w/index.php?oldid=1277210912)

## What would change the view

The base case for holding is that a quarterly shortfall need not persist. Even if the reported target cuts are accurate, a lower target can reflect a lower valuation multiple rather than lower expected earnings; the analyst notes and estimate revisions are missing. Add if improving comparable-store sales are supported by more customer transactions, stable margins and maintained earnings guidance at an attractive valuation. The strongest alternative is sustained demand weakness: falling transactions coupled with margin pressure and a guidance cut would favor trimming. Tractor Supply’s exposure to gardening and livestock customers identifies demand worth tracking, not evidence that it has recovered. [1](https://en.wikipedia.org/w/index.php?oldid=1277210912)

## Sources

1. [Tractor Supply Company](https://en.wikipedia.org/w/index.php?oldid=1277210912), available by 2025-02-23.
2. [The Vanguard Group](https://en.wikipedia.org/w/index.php?oldid=1295208050), available by 2025-06-12.
3. [Wellington Management Company](https://en.wikipedia.org/w/index.php?oldid=1287097379), available by 2025-04-24.
