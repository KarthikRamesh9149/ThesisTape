# Investment research memo

As of 2025-10-28

**Research question**
How will the abrupt reversal in China's trade policy regarding U.S. soybeans impact global price stability and inventory liquidation strategies for exporters, given the divergent planting intentions and inventory surpluses reported by Stats Canada earlier in 2025?

Some parts of the question could not be established from eligible evidence.

## Answer

As of 2025-10-28, Canadian soybean exporters should sell the bulk of uncommitted inventory against firm nearby bids and carry only lots for which a forward sale pays the cost of waiting. The reported switch away from U.S. soybeans reached Argentina, Uruguay and Brazil; a switch back could lift U.S. futures while eroding the premium a competing exporter can earn. The evidence does not establish the tonnage of any return to U.S. buying or justify a precise liquidation share. [1](https://en.wikipedia.org/w/index.php?oldid=1319148033) [2](https://web.archive.org/web/20251027113811/https://www.reuters.com/world/china/us-china-seek-avoid-trade-war-escalation-salvage-trump-xi-meeting-malaysia-talks-2025-10-25/#:~:text=Our%20Standards%3A%20The%20Thomson%20Reuters%20Trust%20Principles.%2C%20opens%20new,earths%2C%20tariff%20pause%20for%20Trump%20and%20Xi%20to%20consider)

## Evidence

A Chinese policy announcement would change expectations; a confirmed U.S. booking naming China would establish contracted demand for a delivery period. The October reporting describes a tariff pause under consideration, not a soybean-specific decision. USDA did confirm 198,000 metric tons of U.S. soybean sales, but the destination was unknown and the sale was for the 2024/2025 marketing year. It cannot confirm an October booking by China. [2](https://web.archive.org/web/20251027113811/https://www.reuters.com/world/china/us-china-seek-avoid-trade-war-escalation-salvage-trump-xi-meeting-malaysia-talks-2025-10-25/#:~:text=Our%20Standards%3A%20The%20Thomson%20Reuters%20Trust%20Principles.%2C%20opens%20new,earths%2C%20tariff%20pause%20for%20Trump%20and%20Xi%20to%20consider) [3](https://web.archive.org/web/20250426054416/https://www.fas.usda.gov/newsroom/export-sales-unknown-destinations-1000#:~:text=Export%20Sales%20to%20Unknown%20Destinations%20Private%20exporters%20reported%20sales,contact%20the%20Export%20Sales%20Reporting%20Staff%20at%20%28202%29%20720-9209.)

## Outlook

The base case is a shift in sourcing rather than an increase in world consumption: earlier Chinese orders moved toward South America when U.S. buying stopped. News of renewed U.S. access could therefore produce a sharp futures rally that reverses if orders disappoint. Repeated U.S. bookings would reduce uncertainty about the trade route and support U.S. export bids, but not necessarily raise prices everywhere. The test is whether competing origins lose orders and their cash bids weaken relative to futures as U.S. sales rise. [1](https://en.wikipedia.org/w/index.php?oldid=1319148033) [4](https://web.archive.org/web/20251027113811/https://www.reuters.com/world/china/us-china-seek-avoid-trade-war-escalation-salvage-trump-xi-meeting-malaysia-talks-2025-10-25/#:~:text=SustainabilitycategoryChina%27s%20securities%20regulator%20streamlines%20scheme%20for%20foreign%20investors11%3A12%20AM,in%20Japan%2C%20China%20trade%20truce%20hopes%20rise11%3A11%20AM%20UTC)

## What would change the view

The strongest case for carrying more is that Chinese purchases are additional, not diverted. Look for sustained China-named U.S. sales followed by shipments, without an offsetting fall in purchases from South America. That would support a broader price rise. Increase carry only if buyers also lift the executable local forward bid enough to clear carrying costs; a higher futures quote alone is not a higher return on the inventory. [3](https://web.archive.org/web/20250426054416/https://www.fas.usda.gov/newsroom/export-sales-unknown-destinations-1000#:~:text=Export%20Sales%20to%20Unknown%20Destinations%20Private%20exporters%20reported%20sales,contact%20the%20Export%20Sales%20Reporting%20Staff%20at%20%28202%29%20720-9209.) [1](https://en.wikipedia.org/w/index.php?oldid=1319148033)

## Sources

1. [China–United States trade war](https://en.wikipedia.org/w/index.php?oldid=1319148033), available by 2025-10-28.
2. [US, China seek to avoid trade war escalation, salvage Trump-Xi meeting in Malaysia talks | Reuters](https://web.archive.org/web/20251027113811/https://www.reuters.com/world/china/us-china-seek-avoid-trade-war-escalation-salvage-trump-xi-meeting-malaysia-talks-2025-10-25/#:~:text=Our%20Standards%3A%20The%20Thomson%20Reuters%20Trust%20Principles.%2C%20opens%20new,earths%2C%20tariff%20pause%20for%20Trump%20and%20Xi%20to%20consider), available by 2025-10-27.
3. [Export Sales to Unknown Destinations | USDA Foreign Agricultural Service](https://web.archive.org/web/20250426054416/https://www.fas.usda.gov/newsroom/export-sales-unknown-destinations-1000#:~:text=Export%20Sales%20to%20Unknown%20Destinations%20Private%20exporters%20reported%20sales,contact%20the%20Export%20Sales%20Reporting%20Staff%20at%20%28202%29%20720-9209.), available by 2025-04-26.
4. [US, China seek to avoid trade war escalation, salvage Trump-Xi meeting in Malaysia talks | Reuters](https://web.archive.org/web/20251027113811/https://www.reuters.com/world/china/us-china-seek-avoid-trade-war-escalation-salvage-trump-xi-meeting-malaysia-talks-2025-10-25/#:~:text=SustainabilitycategoryChina%27s%20securities%20regulator%20streamlines%20scheme%20for%20foreign%20investors11%3A12%20AM,in%20Japan%2C%20China%20trade%20truce%20hopes%20rise11%3A11%20AM%20UTC), available by 2025-10-27.
