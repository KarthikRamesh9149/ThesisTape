# Investment research memo

As of 2025-03-03

**Research question**
Does the recurring insider selling by CFO Melissa N. Schaeffer, specifically the February 2025 disposal of 3,233 shares, signal a valuation ceiling for Air Products and Chemicals (APD) despite Citigroup’s recent price target hike to $365 and maintained Buy rating?

Some parts of the question could not be established from eligible evidence.

## Evidence

Discretion is the missing fact. The supplied material explains insider reporting but does not include Schaeffer’s ownership filing. Check the transaction code and footnotes for an open-market sale versus shares withheld for taxes, and check whether a pre-existing trading plan governed the timing. Then compare prior filings and her remaining stake. Repeated withholding or scheduled sales would explain recurrence without implying that the CFO repeatedly judged APD expensive. [1](https://en.wikipedia.org/w/index.php?oldid=1277747326)

## Outlook

The base case is to leave the valuation assessment unchanged by the reported disposal, not to adopt Citi’s target. No dated Citi research note is supplied to verify the target, rating or assumptions. A better test of the bullish case is whether Air Products delivers its backlog on schedule and within budget, and whether the resulting earnings and cash generation justify the capital spent. A shortfall on those measures would weaken the case regardless of Schaeffer’s motive. [2](https://web.archive.org/web/20250217183305/https://www.airproducts.com/company/news-center/2025/02/0206-air-products-fiscal-2025-first-quarter-earnings#:~:text=Cautionary%20Note%20Regarding%20Forward-Looking%20Statements%20This%20release%20contains%20%E2%80%9Cforward-looking,new%20projects%3B%20tariffs%2C%20economic%20sanctions%20and%20regulatory%20activities%20in) [3](https://web.archive.org/web/20250217183305/https://www.airproducts.com/company/news-center/2025/02/0206-air-products-fiscal-2025-first-quarter-earnings#:~:text=%2AManagement%20is%20unable%20to%20reconcile%2C%20without%20unreasonable%20efforts%2C%20the,website.%20View%20entire%20earnings%20release%20with%20all%20financial%20tables.)

## What would change the view

The strongest bearish alternative is that Schaeffer repeatedly chose to cut a material portion of her stake as project economics weakened. Filings showing discretionary sales and a substantial decline in her holdings, coupled with disclosed cost overruns or customer cancellations, would warrant revisiting the valuation. The filings alone would make the selling more informative; they still would not identify a price ceiling. [1](https://en.wikipedia.org/w/index.php?oldid=1277747326) [2](https://web.archive.org/web/20250217183305/https://www.airproducts.com/company/news-center/2025/02/0206-air-products-fiscal-2025-first-quarter-earnings#:~:text=Cautionary%20Note%20Regarding%20Forward-Looking%20Statements%20This%20release%20contains%20%E2%80%9Cforward-looking,new%20projects%3B%20tariffs%2C%20economic%20sanctions%20and%20regulatory%20activities%20in)

## Sources

1. [Insider trading](https://en.wikipedia.org/w/index.php?oldid=1277747326), available by 2025-02-26.
2. [Air Products Fiscal 2025 First Quarter Financial Results | News Release](https://web.archive.org/web/20250217183305/https://www.airproducts.com/company/news-center/2025/02/0206-air-products-fiscal-2025-first-quarter-earnings#:~:text=Cautionary%20Note%20Regarding%20Forward-Looking%20Statements%20This%20release%20contains%20%E2%80%9Cforward-looking,new%20projects%3B%20tariffs%2C%20economic%20sanctions%20and%20regulatory%20activities%20in), available by 2025-02-17.
3. [Air Products Fiscal 2025 First Quarter Financial Results | News Release](https://web.archive.org/web/20250217183305/https://www.airproducts.com/company/news-center/2025/02/0206-air-products-fiscal-2025-first-quarter-earnings#:~:text=%2AManagement%20is%20unable%20to%20reconcile%2C%20without%20unreasonable%20efforts%2C%20the,website.%20View%20entire%20earnings%20release%20with%20all%20financial%20tables.), available by 2025-02-17.
