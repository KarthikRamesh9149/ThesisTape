# Investment research memo

As of 2025-07-29

**Research question**
How does the 5.9% year-over-year revenue growth in the Experiences segment mitigate the capital losses and margin pressure from the theatrical underperformance of high-budget releases like the 'Snow White' live-action remake in the 2025 fiscal year?

Some parts of the question could not be established from eligible evidence.

## Answer

As of 2025-07-29, treat Disney’s Experiences business as a plausible earnings cushion, not a demonstrated earnings or cash-flow offset. Disney reported strength in domestic parks, cruises and consumer products in its second fiscal quarter of 2025. The scale to test is incremental Experiences operating income against an illustrative 55 million-dollar lifetime shortfall on Snow White. The quarterly report excerpt does not quantify that segment profit increase, and the film estimate is not a loss Disney booked in the quarter. [1](https://web.archive.org/web/20250614073027/https://www.wdwinfo.com/news-stories/disney/the-walt-disney-company-reports-second-quarter-earnings-for-2025/#:~:text=The%20Walt%20Disney%20Company%20reported%20its%20second%20quarter%20earnings,15%25%20to%20%244.4%20billion.%20Message%20from%20CEO%20Bob%20Iger%3A) [2](https://en.wikipedia.org/w/index.php?oldid=1302953125) [3](https://web.archive.org/web/20250720143229/https://www.forbes.com/sites/timlammers/2025/06/07/disneys-snow-white-ends-theater-run-how-much-money-did-it-lose/#:~:text=To%20begin%20with%2C%20the%20production%20needs%20to%20split%20its,streaming%20and%20TV%20revenues%2C%20and%20%242%20million%20from%20merchandise.%E2%80%9D)

## Evidence

Subtracting Deadline’s forecast of $295 million in lifetime receipts from the cited $350 million production and marketing investment gives the illustrative shortfall. This is more informative than subtracting ticket sales from the budget: theaters keep part of the gross, and the forecast already counts home entertainment, streaming, TV and merchandise. But the forecast assumed $225 million of worldwide ticket sales; the final gross was $205,545,435. That weakens the rental assumption without establishing final ancillary receipts, residual costs or the fiscal-year loss on this film, much less the whole slate. [2](https://en.wikipedia.org/w/index.php?oldid=1302953125) [3](https://web.archive.org/web/20250720143229/https://www.forbes.com/sites/timlammers/2025/06/07/disneys-snow-white-ends-theater-run-how-much-money-did-it-lose/#:~:text=To%20begin%20with%2C%20the%20production%20needs%20to%20split%20its,streaming%20and%20TV%20revenues%2C%20and%20%242%20million%20from%20merchandise.%E2%80%9D) [4](https://web.archive.org/web/20250720143229/https://www.forbes.com/sites/timlammers/2025/06/07/disneys-snow-white-ends-theater-run-how-much-money-did-it-lose/#:~:text=According%20to%20the%20box%20office%20tracker%2C%20the%20film%20earned,prints%20and%20advertising%20costs.%20Rachel%20Zegler%20in%20%22Snow%20White.%22)

## Outlook

For the full fiscal year, the base case is a partial earnings cushion if the reported domestic strength persists and generates additional segment profit. The strongest alternative is that sales rise but costs absorb the gain, or that profits rise while park and cruise investment absorbs the cash. Disney’s multiyear expansion plan makes the latter a material possibility, not a measure of this year’s spending. Test earnings coverage by comparing the full-year change in Experiences operating income with theatrical losses recognized in that same period. Test free-cash-flow coverage separately using incremental operating cash after capital spending against the film slate’s net cash outflow. Neither test is settled by the results available at the cutoff. [1](https://web.archive.org/web/20250614073027/https://www.wdwinfo.com/news-stories/disney/the-walt-disney-company-reports-second-quarter-earnings-for-2025/#:~:text=The%20Walt%20Disney%20Company%20reported%20its%20second%20quarter%20earnings,15%25%20to%20%244.4%20billion.%20Message%20from%20CEO%20Bob%20Iger%3A) [5](https://en.wikipedia.org/w/index.php?oldid=1302135838)

## Checked calculations

- C1. Snow White lifetime shortfall on cited production/marketing costs and forecast receipts; not a booked FY2025 loss (USD millions) — 350 − 295 = 55 [3](https://web.archive.org/web/20250720143229/https://www.forbes.com/sites/timlammers/2025/06/07/disneys-snow-white-ends-theater-run-how-much-money-did-it-lose/#:~:text=To%20begin%20with%2C%20the%20production%20needs%20to%20split%20its,streaming%20and%20TV%20revenues%2C%20and%20%242%20million%20from%20merchandise.%E2%80%9D) [2](https://en.wikipedia.org/w/index.php?oldid=1302953125)

## Sources

1. [The Walt Disney Company Reports Second Quarter Earnings for 2025](https://web.archive.org/web/20250614073027/https://www.wdwinfo.com/news-stories/disney/the-walt-disney-company-reports-second-quarter-earnings-for-2025/#:~:text=The%20Walt%20Disney%20Company%20reported%20its%20second%20quarter%20earnings,15%25%20to%20%244.4%20billion.%20Message%20from%20CEO%20Bob%20Iger%3A), available by 2025-06-14.
2. [Snow White (2025 film)](https://en.wikipedia.org/w/index.php?oldid=1302953125), available by 2025-07-28.
3. [Disney’s ‘Snow White’ Ends Theater Run. How Much Money Did It Lose?](https://web.archive.org/web/20250720143229/https://www.forbes.com/sites/timlammers/2025/06/07/disneys-snow-white-ends-theater-run-how-much-money-did-it-lose/#:~:text=To%20begin%20with%2C%20the%20production%20needs%20to%20split%20its,streaming%20and%20TV%20revenues%2C%20and%20%242%20million%20from%20merchandise.%E2%80%9D), available by 2025-07-20.
4. [Disney’s ‘Snow White’ Ends Theater Run. How Much Money Did It Lose?](https://web.archive.org/web/20250720143229/https://www.forbes.com/sites/timlammers/2025/06/07/disneys-snow-white-ends-theater-run-how-much-money-did-it-lose/#:~:text=According%20to%20the%20box%20office%20tracker%2C%20the%20film%20earned,prints%20and%20advertising%20costs.%20Rachel%20Zegler%20in%20%22Snow%20White.%22), available by 2025-07-20.
5. [Disney Experiences](https://en.wikipedia.org/w/index.php?oldid=1302135838), available by 2025-07-23.
