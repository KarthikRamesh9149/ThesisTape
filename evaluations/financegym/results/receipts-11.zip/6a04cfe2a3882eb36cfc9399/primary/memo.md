# Investment research memo

As of 2025-09-02

**Research question**
How has Cleveland Fed President Beth Hammack’s pivot from projecting potential mid-2025 rate cuts to highlighting stagflation and tariff-driven inflation risks reshaped market expectations for the Federal Reserve’s restrictive policy duration and the long-term terminal rate through late 2025?

## Answer

As of 2025-09-02, neither a longer hold through December nor a higher eventual policy rate can be established as a market reaction to Cleveland Fed President Beth Hammack. Take the FOMC’s late-July decision to hold its target range unchanged as the stipulated policy baseline, an unverified question premise. That decision sets the starting point for the analysis; it does not show that Hammack withdrew a conditional midyear cut scenario or that investors changed the expected timing or size of cuts. [1](https://en.wikipedia.org/w/index.php?oldid=1301095973) [2](https://web.archive.org/web/20250401233015/https://www.federalreservehistory.org/people/beth-hammack#:~:text=President%2C%20Federal%20Reserve%20Bank%20of%20Cleveland%2C%202024%E2%80%93%20Beth%20M.,enterprise%20risk%2C%20finance%2C%20and%20global%20inclusion%20and%20diversity%20committees.)

## Evidence

The reported pivot is itself an unverified question premise. If Hammack made a midyear cut conditional on easing inflation, a later warning about tariffs and weak growth could mean she judged that condition less likely to be met, not that she had withdrawn the scenario. The available biographical account establishes her policy role but quotes neither set of remarks. Dated statements specifying the original condition and whether she later rejected it would distinguish a withdrawal from a change in the odds. [2](https://web.archive.org/web/20250401233015/https://www.federalreservehistory.org/people/beth-hammack#:~:text=President%2C%20Federal%20Reserve%20Bank%20of%20Cleveland%2C%202024%E2%80%93%20Beth%20M.,enterprise%20risk%2C%20finance%2C%20and%20global%20inclusion%20and%20diversity%20committees.)

The June reporting supports a narrower conclusion: Fed officials collectively signaled fewer cuts while investors were watching the July tariff deadline. A signal from officials is not a price change, and the report gives neither a December implied rate nor a longer-run forward rate. It therefore cannot establish that markets expected no cuts through December, much less attribute that view to Hammack rather than to broader Fed communication or tariff news. [3](https://web.archive.org/web/20250622012952/https://www.reuters.com/business/fed-treads-carefully-leaving-markets-anxious-about-tariff-risks-2025-06-19/#:~:text=Fed%20holds%20rates%20steady%20but%20officials%20signal%20fewer%20cuts,Market%20sentiment%20fragile%20as%20investors%20eye%20July%20tariff%20deadline)

## What would change the view

The base case to test is delayed easing, not a higher endpoint: tariff uncertainty could give policymakers reason to wait without changing where rates settle. A rise in implied rates at meetings through December immediately around Hammack’s remarks, with distant forward rates little changed, would favor that reading; a rise alone would not imply a full hold. The strongest alternative is that investors marked up both the near-term path and the eventual rate. A persistent rise in distant overnight-indexed swap forwards alongside near-term repricing would support that alternative, though forwards also contain risk premia. Compare those moves with separate windows around FOMC and tariff announcements before assigning them to Hammack. The supplied evidence describes the instruments but provides no such observations. [1](https://en.wikipedia.org/w/index.php?oldid=1301095973) [4](https://en.wikipedia.org/w/index.php?oldid=1285191845)

## Sources

1. [Federal funds rate](https://en.wikipedia.org/w/index.php?oldid=1301095973), available by 2025-07-18.
2. [Beth M. Hammack | Federal Reserve History](https://web.archive.org/web/20250401233015/https://www.federalreservehistory.org/people/beth-hammack#:~:text=President%2C%20Federal%20Reserve%20Bank%20of%20Cleveland%2C%202024%E2%80%93%20Beth%20M.,enterprise%20risk%2C%20finance%2C%20and%20global%20inclusion%20and%20diversity%20committees.), available by 2025-04-01.
3. [Fed treads carefully, leaving markets anxious about tariff risks | Reuters](https://web.archive.org/web/20250622012952/https://www.reuters.com/business/fed-treads-carefully-leaving-markets-anxious-about-tariff-risks-2025-06-19/#:~:text=Fed%20holds%20rates%20steady%20but%20officials%20signal%20fewer%20cuts,Market%20sentiment%20fragile%20as%20investors%20eye%20July%20tariff%20deadline), available by 2025-06-22.
4. [Overnight indexed swap](https://en.wikipedia.org/w/index.php?oldid=1285191845), available by 2025-04-12.
