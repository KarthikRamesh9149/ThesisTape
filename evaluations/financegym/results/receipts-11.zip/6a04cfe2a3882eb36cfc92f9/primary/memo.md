# Investment research memo

As of 2025-08-05

**Research question**
How do Vivek Ramaswamy's consistent share divestments throughout Q2 2025 impact the market valuation and investor sentiment for Roivant Sciences (ROIV) as the company approaches critical late-stage clinical catalysts for its lead asset, the TYK2/JAK1 inhibitor brepocitinib?

## Answer

As of 2025-08-05, do not discount Roivant Sciences (ROIV) or lower brepocitinib’s probability of success on account of sales by Vivek Ramaswamy. The question’s premise of consistent divestments throughout Q2 2025 is unverified: the available record establishes neither a trade nor a cumulative sale size for that quarter. The report of 4 million Roivant shares sold at $7.95 each dates to February 2023. Its later archive date does not make it a new trade. [1](https://web.archive.org/web/20250723072607/https://newrepublic.com/article/170733/vivek-ramaswamy-business-china-roivant#:~:text=SEC%20filings%20from%20last%20March%20show%20Roivant%20has%20subsidiaries,reference%20the%20Chinese-domiciled%20Cytovant%20companies%20listed%20in%20earlier%20filings.) [2](https://en.wikipedia.org/w/index.php?oldid=1302334088)

## Evidence

Even a confirmed founder sale would establish a change in his exposure, not a change in investors’ estimate of clinical success. Ramaswamy had already left both the CEO and chair roles. Moreover, ROIV represents a portfolio, not just Priovant’s rights to brepocitinib. The available evidence includes neither a contemporaneous price-and-volume series nor investor estimates of the dermatomyositis trial’s odds, so it establishes neither selling pressure nor a deterioration in sentiment. [2](https://en.wikipedia.org/w/index.php?oldid=1302334088) [3](https://en.wikipedia.org/w/index.php?oldid=1280731494)

## What would change the view

Keep clinical assumptions unchanged pending the dermatomyositis readout or new trial-specific evidence. First verify any quarter sales against dated transaction disclosures and compare their size with normal ROIV trading volume. Weakness concentrated on sale dates that reverses as volume normalizes would favor temporary supply pressure. The strongest alternative is that investors marked down the trial’s odds: persistent underperformance versus biotech peers after selling ends, accompanied by explicit cuts to brepocitinib success estimates rather than news about other Roivant assets, would support that interpretation. A price decline alone would not. [3](https://en.wikipedia.org/w/index.php?oldid=1280731494)

## Sources

1. [GOP Presidential Candidate Vivek Ramaswamy, Who Used to Do Business With China, Wants to Ban Business With China | The New Republic](https://web.archive.org/web/20250723072607/https://newrepublic.com/article/170733/vivek-ramaswamy-business-china-roivant#:~:text=SEC%20filings%20from%20last%20March%20show%20Roivant%20has%20subsidiaries,reference%20the%20Chinese-domiciled%20Cytovant%20companies%20listed%20in%20earlier%20filings.), available by 2025-07-23.
2. [Vivek Ramaswamy](https://en.wikipedia.org/w/index.php?oldid=1302334088), available by 2025-07-24.
3. [Roivant Sciences](https://en.wikipedia.org/w/index.php?oldid=1280731494), available by 2025-03-16.
