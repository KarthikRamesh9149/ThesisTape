# Investment research memo

As of 2025-09-02

**Research question**
Following the liquidation of its Super Micro Computer stake, how is Philippe Laffont’s Coatue Management reallocating capital across the AI value chain, specifically balancing volatile semiconductor positions like Nvidia and AMD against infrastructure expansion in Broadcom and CoreWeave?

## Answer

As of 2025-09-02, the available holdings evidence does not confirm that Philippe Laffont’s Coatue Management liquidated Super Micro Computer, cut Nvidia and AMD, or added Broadcom and CoreWeave. The liquidation is an unverified question premise. The Coatue holdings excerpt contains column headings but no position rows, so neither the direction nor the dollar scale of the proposed shift is established. What is documented is an earlier infrastructure investment: Coatue led CoreWeave’s $1.1 billion financing in May 2024. That was the size of the round, not Coatue’s disclosed contribution. [1](https://web.archive.org/web/20250218062032/https://13f.info/13f/000091957425001429-coatue-management-llc-q4-2024#:~:text=Sym%20Issuer%20Name%20Cl%20CUSIP%20Value%20%28%24000%29%20%25%20Shares%20Principal%20Option%20Type) [2](https://en.wikipedia.org/w/index.php?oldid=1306487400)

## Evidence

The economic case for the proposed shift is diversification within AI infrastructure, not a clean exit from chips. Broadcom would add exposure to the networks that connect computing clusters: it reported AI revenue growth of 46% year over year to over $4.4 billion, citing networking demand. CoreWeave would add exposure to selling cloud capacity, but that capacity uses Nvidia hardware. Even if Coatue trimmed its direct Nvidia holding, a larger CoreWeave stake would retain exposure to demand for Nvidia-powered computing. This explains what the trades would mean, not whether Coatue made them. [3](https://web.archive.org/web/20250621210245/https://futurumgroup.com/insights/broadcom-q2-fy-2025-sees-record-revenue-solid-ai-and-software-growth/#:~:text=%E2%80%9CBroadcom%20achieved%20record%20Q2%20revenue%20on%20continued%20momentum%20in,2026.%20AI%20Networking%20Momentum%20Driven%20by%20Tomahawk%206%20Launch) [2](https://en.wikipedia.org/w/index.php?oldid=1306487400)

## Outlook

The base case is continuity in Coatue’s CoreWeave exposure rather than a newly funded rotation: Coatue backed the company before it went public on March 28, 2025. A newly visible public holding could therefore reflect an existing private stake. Likewise, a larger portfolio weight need not mean more shares: weight can rise because the stock appreciates or because the rest of the reported portfolio falls in value. [2](https://en.wikipedia.org/w/index.php?oldid=1306487400) [1](https://web.archive.org/web/20250218062032/https://13f.info/13f/000091957425001429-coatue-management-llc-q4-2024#:~:text=Sym%20Issuer%20Name%20Cl%20CUSIP%20Value%20%28%24000%29%20%25%20Shares%20Principal%20Option%20Type)

## What would change the view

The strongest alternative is an active shift toward networking and cloud capacity. Its test is consecutive complete quarter-end holdings tables: a previously reported Super Micro common-stock position disappears, Nvidia and AMD share counts fall, and Broadcom and CoreWeave counts rise after accounting for splits and any private-share conversion. That pattern would establish a reported exit and a directional shift in holdings. It would not show that proceeds from any particular sale funded either addition; that requires transaction and cash records, not quarter-end snapshots. [1](https://web.archive.org/web/20250218062032/https://13f.info/13f/000091957425001429-coatue-management-llc-q4-2024#:~:text=Sym%20Issuer%20Name%20Cl%20CUSIP%20Value%20%28%24000%29%20%25%20Shares%20Principal%20Option%20Type) [2](https://en.wikipedia.org/w/index.php?oldid=1306487400)

## Sources

1. [Coatue Management LLC Q4 2024 13F Top Portfolio Holdings](https://web.archive.org/web/20250218062032/https://13f.info/13f/000091957425001429-coatue-management-llc-q4-2024#:~:text=Sym%20Issuer%20Name%20Cl%20CUSIP%20Value%20%28%24000%29%20%25%20Shares%20Principal%20Option%20Type), available by 2025-02-18.
2. [CoreWeave](https://en.wikipedia.org/w/index.php?oldid=1306487400), available by 2025-08-18.
3. [Broadcom Q2 FY 2025 Sees Record Earnings, Solid AI Growth - The Futurum Group](https://web.archive.org/web/20250621210245/https://futurumgroup.com/insights/broadcom-q2-fy-2025-sees-record-revenue-solid-ai-and-software-growth/#:~:text=%E2%80%9CBroadcom%20achieved%20record%20Q2%20revenue%20on%20continued%20momentum%20in,2026.%20AI%20Networking%20Momentum%20Driven%20by%20Tomahawk%206%20Launch), available by 2025-06-21.
