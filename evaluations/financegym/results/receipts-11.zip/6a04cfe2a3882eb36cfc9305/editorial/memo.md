# Investment research memo

As of 2025-04-07

**Research question**
To what extent does the intensifying generic competition for Xarelto, Bayer's top-selling drug, threaten the group’s free cash flow and balance sheet stability as it continues to navigate multi-billion dollar legal liabilities and debt obligations inherited from the 2018 Monsanto acquisition?

Some parts of the question could not be established from eligible evidence.

## Answer

Monsanto-related litigation is documented. The scale of the legal liabilities and the Monsanto-linked debt obligations are unverified question premises. If substantial payments fall due during the sales decline, Bayer has less room to absorb them without borrowing or drawing down cash. Without Xarelto’s cash contribution, group free cash flow, available liquidity, a debt maturity schedule or a litigation payment timetable, neither a funding gap nor adequate coverage can be established. [1](https://web.archive.org/web/20250306015026/https://www.fiercepharma.com/pharma/bayer-projects-xareltos-sales-decline-pick-steam-2025#:~:text=Steeped%20in%20litigation%20resulting%20from%20Bayer%E2%80%99s%20disastrous%20%2463%20billion,toughest%20year%20for%20our%20turnaround%2C%E2%80%9D%20CEO%20Bill%20Anderson%20said.)

## Evidence

Generic competition can erode both price and branded volume, but exposure varies by market. A European patent extension to January 2026 did not guarantee protection throughout that period: London’s High Court invalidated the patent, and Bayer said it would appeal. In the US, the FDA approved generics specifically for 2.5 mg tablets. That approval is not evidence of generic entry across all strengths or of an equivalent loss for Bayer. [2](https://web.archive.org/web/20250124111810/https://www.pharmavoice.com/news/drug-patent-expirations-xarelto-abilify-victoza/713384/#:~:text=Bayer%E2%80%99s%20court%20strategy%20to%20guard%20Xarelto%20With%20the%20patent,the%20patent.%20Bayer%20said%20it%20will%20appeal%20the%20decision.) [3](https://web.archive.org/web/20250328094805/https://www.fda.gov/news-events/press-announcements/fda-roundup-march-4-2025#:~:text=Today%2C%20the%20U.S.%20Food%20and%20Drug%20Administration%20is%20providing,products%20that%20currently%20do%20not%20contain%20such%20labeling%20information.)

C1. Subtract (EUR billion) — 3.5 − 1 = 2.5 [4](https://web.archive.org/web/20250306015026/https://www.fiercepharma.com/pharma/bayer-projects-xareltos-sales-decline-pick-steam-2025#:~:text=While%20Xarelto%20sales%20fell%2015%25%20from%204.1%20billion%20euros,more%20than%202.5%20billion%20euros%20%28%242.7%20billion%29%20this%20year.)

C2. Subtract (EUR billion) — 3.5 − 1.5 = 2.0 [4](https://web.archive.org/web/20250306015026/https://www.fiercepharma.com/pharma/bayer-projects-xareltos-sales-decline-pick-steam-2025#:~:text=While%20Xarelto%20sales%20fell%2015%25%20from%204.1%20billion%20euros,more%20than%202.5%20billion%20euros%20%28%242.7%20billion%29%20this%20year.)

C3. Ratio percent (%) — 1 ÷ 3.5 × 100 ≈ 28.571429 [4](https://web.archive.org/web/20250306015026/https://www.fiercepharma.com/pharma/bayer-projects-xareltos-sales-decline-pick-steam-2025#:~:text=While%20Xarelto%20sales%20fell%2015%25%20from%204.1%20billion%20euros,more%20than%202.5%20billion%20euros%20%28%242.7%20billion%29%20this%20year.)

C4. Ratio percent (%) — 1.5 ÷ 3.5 × 100 ≈ 42.857143 [4](https://web.archive.org/web/20250306015026/https://www.fiercepharma.com/pharma/bayer-projects-xareltos-sales-decline-pick-steam-2025#:~:text=While%20Xarelto%20sales%20fell%2015%25%20from%204.1%20billion%20euros,more%20than%202.5%20billion%20euros%20%28%242.7%20billion%29%20this%20year.)

## Outlook

Base case: Xarelto reduces Bayer’s capacity to generate cash in 2025. Bayer expects combined Nubeqa and Kerendia sales to rise from 2 billion euros to more than 2.5 billion euros. At the forecast threshold, the 0.5 increase replaces only part of the Xarelto loss. Management expects stable pharma sales through 2026; that suggests other products can sustain revenue, not necessarily the same margin or cash flow. [4](https://web.archive.org/web/20250306015026/https://www.fiercepharma.com/pharma/bayer-projects-xareltos-sales-decline-pick-steam-2025#:~:text=While%20Xarelto%20sales%20fell%2015%25%20from%204.1%20billion%20euros,more%20than%202.5%20billion%20euros%20%28%242.7%20billion%29%20this%20year.) [5](https://web.archive.org/web/20250306015026/https://www.fiercepharma.com/pharma/bayer-projects-xareltos-sales-decline-pick-steam-2025#:~:text=While%20Bayer%E2%80%99s%20consumer%20and%20crop%20science%20divisions%20continued%20to,Stefan%20Oelrich%2C%20said%20during%20the%20company%E2%80%99s%20Q4%20conference%20call.)

## Checked calculations

- C5. Nubeqa and Kerendia sales uplift at forecast threshold (EUR billion) — 2.5 − 2 = 0.5 [4](https://web.archive.org/web/20250306015026/https://www.fiercepharma.com/pharma/bayer-projects-xareltos-sales-decline-pick-steam-2025#:~:text=While%20Xarelto%20sales%20fell%2015%25%20from%204.1%20billion%20euros,more%20than%202.5%20billion%20euros%20%28%242.7%20billion%29%20this%20year.)

## Sources

1. [Bayer sees Xarelto sales falling by between 1 to 1.5B euros](https://web.archive.org/web/20250306015026/https://www.fiercepharma.com/pharma/bayer-projects-xareltos-sales-decline-pick-steam-2025#:~:text=Steeped%20in%20litigation%20resulting%20from%20Bayer%E2%80%99s%20disastrous%20%2463%20billion,toughest%20year%20for%20our%20turnaround%2C%E2%80%9D%20CEO%20Bill%20Anderson%20said.), available by 2025-03-06.
2. [3 patent expirations in 2024 and how companies are pivoting | PharmaVoice](https://web.archive.org/web/20250124111810/https://www.pharmavoice.com/news/drug-patent-expirations-xarelto-abilify-victoza/713384/#:~:text=Bayer%E2%80%99s%20court%20strategy%20to%20guard%20Xarelto%20With%20the%20patent,the%20patent.%20Bayer%20said%20it%20will%20appeal%20the%20decision.), available by 2025-01-24.
3. [FDA Roundup: March 4, 2025 | FDA](https://web.archive.org/web/20250328094805/https://www.fda.gov/news-events/press-announcements/fda-roundup-march-4-2025#:~:text=Today%2C%20the%20U.S.%20Food%20and%20Drug%20Administration%20is%20providing,products%20that%20currently%20do%20not%20contain%20such%20labeling%20information.), available by 2025-03-28.
4. [Bayer sees Xarelto sales falling by between 1 to 1.5B euros](https://web.archive.org/web/20250306015026/https://www.fiercepharma.com/pharma/bayer-projects-xareltos-sales-decline-pick-steam-2025#:~:text=While%20Xarelto%20sales%20fell%2015%25%20from%204.1%20billion%20euros,more%20than%202.5%20billion%20euros%20%28%242.7%20billion%29%20this%20year.), available by 2025-03-06.
5. [Bayer sees Xarelto sales falling by between 1 to 1.5B euros](https://web.archive.org/web/20250306015026/https://www.fiercepharma.com/pharma/bayer-projects-xareltos-sales-decline-pick-steam-2025#:~:text=While%20Bayer%E2%80%99s%20consumer%20and%20crop%20science%20divisions%20continued%20to,Stefan%20Oelrich%2C%20said%20during%20the%20company%E2%80%99s%20Q4%20conference%20call.), available by 2025-03-06.
