# Investment research memo

As of 2025-08-20

**Research question**
How will Coloplast's leadership transition and structural reorganization into Chronic and Acute Care units impact its margin recovery and organic growth targets, considering the recent downward guidance revisions and the DKK 80 million revenue headwind from product recalls in China?

Some parts of the question could not be established from eligible evidence.

## Answer

As of 2025-08-20, lower the near-term organic growth forecast and defer part of the expected EBIT margin recovery if the existing forecast assumes uninterrupted China sales. If it already reflects recall disruption, retain it rather than cutting twice. Coloplast’s voluntary Biatain recalls support a near-term downside case, not a quantified group-wide cut. Give the incoming leadership no forecast credit yet for the proposed Chronic Care and Acute Care split. [1](https://web.archive.org/web/20250714103247/https://www.cqn.com.cn/ms/content/2025-07/14/content_9114507.htm) [2](https://web.archive.org/web/20250701064720/https://www.cqn.com.cn/ms/content/2025-07/01/content_9111986.htm)

## Outlook

The base case is a sales rebound when normal shipments resume, not a higher underlying growth rate. Restocking can lift organic sales temporarily; how much EBIT margin recovers depends on the contribution from those sales and whether testing and remediation costs persist. The leadership transition and split described in the question could yield a separate benefit if unit leaders tailor selling resources to different buying channels and take responsibility for quality costs. Coloplast sells both to institutions and directly to consumers, but that channel diversity does not establish savings. Duplicated support teams could instead delay margin recovery. [3](https://en.wikipedia.org/w/index.php?oldid=1302466299) [2](https://web.archive.org/web/20250701064720/https://www.cqn.com.cn/ms/content/2025-07/01/content_9111986.htm)

## What would change the view

The strongest upside case is that focused management improves customer demand and lowers the cost of serving it even outside the recalled lines. Coloplast’s decision to keep Atos Medical separate shows a precedent for autonomy, not proof of a payoff. First seek a dated company update reconciling old and new guidance and isolating China lost sales from recall expenses. Raise forecasts for the split only if, after restocking ends, unaffected product lines show sustained organic volume growth and EBIT margin improves after accounting for fading recall costs and added unit overhead. A rebound confined to China dressings would support recovery, not a lasting management benefit. [4](https://web.archive.org/web/20230828094819/https://www.reuters.com/article/atos-medical-m-a-coloplast/coloplast-to-acquire-atos-medical-in-2-5-billion-deal-shares-rise-idUSKBN2HT0MX#:~:text=Coloplast%20said%20it%20will%20keep%20the%20name%20and%20brand,that%20connects%20the%20nose%20and%20mouth%20to%20the%20lungs.) [1](https://web.archive.org/web/20250714103247/https://www.cqn.com.cn/ms/content/2025-07/14/content_9114507.htm)

## Sources

1. [康乐保公司 Coloplast A/S对泡沫敷料 Biatain Foam Dressings主动召回-中国质量新闻网](https://web.archive.org/web/20250714103247/https://www.cqn.com.cn/ms/content/2025-07/14/content_9114507.htm), available by 2025-07-14.
2. [康乐保公司 Coloplast A/S对泡沫敷料 Biatain Foam Dressings主动召回-中国质量新闻网](https://web.archive.org/web/20250701064720/https://www.cqn.com.cn/ms/content/2025-07/01/content_9111986.htm), available by 2025-07-01.
3. [Coloplast](https://en.wikipedia.org/w/index.php?oldid=1302466299), available by 2025-07-25.
4. [Coloplast to acquire Atos Medical in $2.5 billion deal, shares rise | Reuters](https://web.archive.org/web/20230828094819/https://www.reuters.com/article/atos-medical-m-a-coloplast/coloplast-to-acquire-atos-medical-in-2-5-billion-deal-shares-rise-idUSKBN2HT0MX#:~:text=Coloplast%20said%20it%20will%20keep%20the%20name%20and%20brand,that%20connects%20the%20nose%20and%20mouth%20to%20the%20lungs.), available by 2023-08-28.
