# Investment research memo

As of 2025-09-29

**Research question**
How does the Qatar Investment Authority's strategic entry at C$12.00 per share, coupled with record operational throughput at Kamoa-Kakula, recalibrate Ivanhoe Mines’ (IVN) valuation framework in light of the significant price target reductions by major sell-side institutions during the first half of 2025?

Some parts of the question could not be established from eligible evidence.

## Evidence

If confirmed, QIA’s price would be a reference for what a strategic buyer paid on the deal terms, not a floor for IVN. The available QIA financing history concerns other companies and does not establish this deal’s size or terms. First distinguish a secondary purchase, which adds neither cash nor shares to IVN, from a primary issue. For a primary issue, add net proceeds to pre-deal equity NAV and divide by the enlarged diluted share count. Ownership dilution need not mean NAV dilution: the test is whether net proceeds per new share exceed or fall short of pre-deal NAV per share, before any change in project value. Neither side of that comparison is documented. [1](https://en.wikipedia.org/w/index.php?oldid=1311493611)

Record milling, even if verified, would establish processing capacity, not payable copper or cash generation. Test tonnes milled against actual feed grade and recovery to derive copper in concentrate; then reconcile shipments, inventory and contract payability to payable metal sold. Compare sales receipts with operating costs, working-capital movements and capital spending before attributing cash to IVN. The historical resource grade is not the period’s feed grade, and an old concentrate start-up schedule is not a sales report. The evidence therefore shows neither successful conversion to cash nor a failure to convert. [2](https://en.wikipedia.org/w/index.php?oldid=1245409207)

## What would change the view

The strongest alternative is to narrow the discount without raising mine NAV: a funded closing could reduce financing risk, and sustained payable sales could reduce execution risk. That can coexist with lower broker targets if the cuts reflected weaker near-term cash flows rather than lower long-run mine value. No dated broker notes identify the institutions, target changes or assumptions, so that reconciliation is a hypothesis. Revisit the discount on verified closing terms and repeated evidence of cash available to IVN after project spending. Revise NAV itself if the updated mine plan changes the timing or amount of attributable cash flows; do not also charge the same shortfall through a wider discount. [2](https://en.wikipedia.org/w/index.php?oldid=1245409207)

## Sources

1. [Qatar Investment Authority](https://en.wikipedia.org/w/index.php?oldid=1311493611), available by 2025-09-15.
2. [Ivanhoe Mines](https://en.wikipedia.org/w/index.php?oldid=1245409207), available by 2024-09-12.
