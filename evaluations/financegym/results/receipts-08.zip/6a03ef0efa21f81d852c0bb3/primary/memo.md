# Investment research memo

As of 2025-04-07

**Research question**
How will Dexcom’s recent regulatory setbacks and the intensifying competition from Abbott’s FreeStyle Libre line impact its 2025 market share and valuation, particularly in light of Robert W. Baird’s January 2025 upgrade and $104 price target?

Some parts of the question could not be established from eligible evidence.

## Evidence

Test the target by holding the earnings multiple fixed initially: apply each scenario’s operating margin to its revenue, deduct interest and taxes, and divide by diluted shares. Lower earnings per share require a higher multiple to reach the same target. That is hardest to justify in the share-loss case, where weaker retention argues for a lower multiple instead. The available product evidence supplies neither Baird’s earnings and multiple assumptions nor a financial baseline or cutoff share price. It cannot establish a numerical fair value, the size of any share loss or the upside to the target. [1](https://en.wikipedia.org/w/index.php?oldid=1283754834) [2](https://en.wikipedia.org/w/index.php?oldid=1283806916)

## Outlook

Use stable Dexcom unit share as the 2025 base case to test, not as an observed trend. If the overall continuous glucose monitoring market grows more slowly, Dexcom sensor volume should still grow roughly in line with the category. With realized prices and sales mix unchanged, revenue growth would slow alongside volume. Operating margin could fall short of plan because fixed costs are spread over fewer sales than budgeted, without any need to assume price cuts to match Libre. Abbott’s clearance predates the forecast period; it is not evidence of a new shift in demand. [2](https://en.wikipedia.org/w/index.php?oldid=1283806916)

The strongest downside alternative is that a Dexcom supply interruption gives Libre an opening and patients keep reordering Libre after Dexcom availability recovers. Even in a growing market, Dexcom volume would then lag the category. The same revenue shortfall as in the slowdown case could carry a lower operating margin if Dexcom also raises spending to win patients back. Persistent losses would warrant a lower earnings multiple than a temporary market slowdown because restoring supply alone would not restore the customer base. Libre’s sensor and reader app make substitution plausible, not proven. [2](https://en.wikipedia.org/w/index.php?oldid=1283806916)

## What would change the view

First verify the regulatory notice: a restriction on shipping an existing sensor puts refills at risk, whereas a delayed launch primarily puts expected new sales at risk. Then compare Dexcom and Libre new starts and refills with total category units in the same channels and geographies. Stable Dexcom share, retention and realized prices through a category slowdown would favor the base case; sustained Dexcom refill losses alongside Libre gains after supply normalizes would favor the downside. I would reconsider a Buy if verified revenue and margin estimates supported upside at the cutoff price without requiring a higher multiple. [1](https://en.wikipedia.org/w/index.php?oldid=1283754834) [2](https://en.wikipedia.org/w/index.php?oldid=1283806916)

## Sources

1. [Dexcom](https://en.wikipedia.org/w/index.php?oldid=1283754834), available by 2025-04-03.
2. [Abbott Laboratories](https://en.wikipedia.org/w/index.php?oldid=1283806916), available by 2025-04-03.
