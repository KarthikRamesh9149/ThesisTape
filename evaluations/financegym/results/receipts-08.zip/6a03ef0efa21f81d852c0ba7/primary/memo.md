# Investment research memo

As of 2025-03-16

**Research question**
How is the volatility induced by President Trump’s tariff announcements on North American partners impacting the S&P 500's technical recovery outlook, specifically evaluating whether the RSI reading of 31.0 serves as a reliable oversold signal or a precursor to further policy-driven declines?

Some parts of the question could not be established from eligible evidence.

## Evidence

To verify a daily reading, first identify the index session it describes rather than assuming it is the latest close before the cutoff. Then use the index’s close-to-close gains and losses, ordinarily with a 14-period lookback and Wilder smoothing, and apply RSI = 100 – 100/(1+RS) to the ratio of average gain to average loss. The supplied material gives no observation date, closing-price series or provider settings. The distinction matters: a simple average can yield a different RSI, and Wilder’s result can depend on where the series starts. [1](https://web.archive.org/web/20250113171716/https://www.investorsunderground.com/technical-indicators/rsi-relative-strength-index/#:~:text=Using%20the%20RSI%20Oscillator%3A%20The%20most%20commonly%20used%20setting,70%2F30%20overbought%2Foversold%20bands%20to%20generate%20a%20more%20robust%20reversion%2Freversal.) [2](https://web.archive.org/web/20250113171716/https://www.investorsunderground.com/technical-indicators/rsi-relative-strength-index/#:~:text=The%20formula%20is%20RSI%20%3D%20100%20%E2%80%93%20100%2F%281%2BRS%29.%20The,or%20picking%20up%20steam%20by%20comparing%20to%20prior%20momentum.) [3](https://en.wikipedia.org/w/index.php?oldid=1244280652)

## Outlook

The base case is a fragile rebound. The tariffs took effect on March 4, 2025; the March 6, 2025 announcement exempted USMCA-compliant products until April 2, 2025, rather than repealing the tariffs across the board. Relief for covered imports could support prices, while a surprise narrowing of that relief could reverse the gain. RSI reflects past closes and cannot anticipate that decision. The policy chronology establishes the risk, but without market observations around the announcements it cannot establish how much volatility the tariffs caused. [4](https://en.wikipedia.org/w/index.php?oldid=1279465489) [3](https://en.wikipedia.org/w/index.php?oldid=1244280652)

## What would change the view

The strongest alternative is that selling pressure is easing and a durable low is forming. A single near-threshold reading cannot distinguish a rebound from below 30 from a slide toward it. On a retest, a lower index low paired with a higher RSI low would be an early sign of waning selling pressure. A subsequent higher price low that holds through adverse tariff news would strengthen the recovery case; a fresh price low accompanied by a lower RSI would favor the fragile-bounce interpretation. [5](https://web.archive.org/web/20250113171716/https://www.investorsunderground.com/technical-indicators/rsi-relative-strength-index/#:~:text=As%20the%20stock%20makes%20new%20highs%2C%20RSI%20should%20also,trendlines%20and%20chart%20patterns%20to%20galvanize%20a%20trading%20system.) [3](https://en.wikipedia.org/w/index.php?oldid=1244280652)

## Sources

1. [Relative Strength Index (RSI) Definition](https://web.archive.org/web/20250113171716/https://www.investorsunderground.com/technical-indicators/rsi-relative-strength-index/#:~:text=Using%20the%20RSI%20Oscillator%3A%20The%20most%20commonly%20used%20setting,70%2F30%20overbought%2Foversold%20bands%20to%20generate%20a%20more%20robust%20reversion%2Freversal.), available by 2025-01-13.
2. [Relative Strength Index (RSI) Definition](https://web.archive.org/web/20250113171716/https://www.investorsunderground.com/technical-indicators/rsi-relative-strength-index/#:~:text=The%20formula%20is%20RSI%20%3D%20100%20%E2%80%93%20100%2F%281%2BRS%29.%20The,or%20picking%20up%20steam%20by%20comparing%20to%20prior%20momentum.), available by 2025-01-13.
3. [Relative strength index](https://en.wikipedia.org/w/index.php?oldid=1244280652), available by 2024-09-06.
4. [United States–Mexico–Canada Agreement](https://en.wikipedia.org/w/index.php?oldid=1279465489), available by 2025-03-08.
5. [Relative Strength Index (RSI) Definition](https://web.archive.org/web/20250113171716/https://www.investorsunderground.com/technical-indicators/rsi-relative-strength-index/#:~:text=As%20the%20stock%20makes%20new%20highs%2C%20RSI%20should%20also,trendlines%20and%20chart%20patterns%20to%20galvanize%20a%20trading%20system.), available by 2025-01-13.
