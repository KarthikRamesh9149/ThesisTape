# Investment research memo

As of 2025-02-10

**Research question**
Following the collapse of merger talks with Honda (HMC) in early February 2025, how does Nissan's (NSANY) shift toward a 'self-rescue' strategy affect its long-term solvency and valuation, given its historical reliance on structural cost-cutting to mitigate recurring quarterly net losses?

## Answer

As of 2025-02-10, value Nissan as a standalone turnaround. The proposed Honda combination aimed to create the world’s third-largest automaker by sales, but neither merger savings nor Honda funding belongs in Nissan’s base case. That puts the burden of restructuring on Nissan’s own liquidity. The available evidence does not show that recurring savings can restore automotive free cash flow before liquidity tightens; it does not establish insolvency either. [1](https://en.wikipedia.org/w/index.php?oldid=1274448614)

## Evidence

The reported breakdown is credible enough to change the valuation assumption, but it is not proof of formal termination. The 23 December 2024 memorandum opened integration talks; 2026 was an aim, not a closing commitment. The subsequent account says Nissan wanted equal status rather than a subsidiary role. Although it describes abandonment as announced, it cites a media report, not a company termination notice. Formal termination was unverified at the cutoff. [2](https://en.wikipedia.org/w/index.php?oldid=1274918395) [1](https://en.wikipedia.org/w/index.php?oldid=1274448614)

## Outlook

Historical reliance on structural cuts to offset recurring quarterly net losses is an unverified question premise. Even if accurate, a smaller net loss is not the solvency test. Nissan can pay severance and closure costs before payroll and plant savings arrive. Model those payments when due, and credit only savings that persist after any lost sales contribution and necessary product investment. Nissan’s reduction of its Mitsubishi stake from 34% to 24% illustrates the distinction: asset-sale proceeds can buy time but cannot support a recurring cash-flow valuation. [1](https://en.wikipedia.org/w/index.php?oldid=1274448614)

## What would change the view

The strongest upside case needs no Honda deal: a permanently lower cost base could let Nissan fund competitive models and meet debt maturities from its own resources. Raise standalone value if automotive operating cash flow covers capital spending across reporting periods without asset sales or a temporary inventory drawdown, and available automotive liquidity stays above operating needs through restructuring payments and maturities. If cash headroom instead shrinks before savings arrive, allow for refinancing costs or equity dilution. The deal and stake-sale accounts provide no automotive cash-flow bridge, savings schedule or maturity profile from which to estimate runway or fair value. [1](https://en.wikipedia.org/w/index.php?oldid=1274448614) [2](https://en.wikipedia.org/w/index.php?oldid=1274918395)

## Sources

1. [Nissan](https://en.wikipedia.org/w/index.php?oldid=1274448614), available by 2025-02-07.
2. [Honda](https://en.wikipedia.org/w/index.php?oldid=1274918395), available by 2025-02-10.
