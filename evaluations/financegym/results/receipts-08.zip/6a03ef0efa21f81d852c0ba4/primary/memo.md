# Investment research memo

As of 2025-10-28

**Research question**
With Pfizer (PFE) announcing a $4.9 billion acquisition of Metsera (MTSR) to bolster its obesity pipeline, what are the primary execution risks and valuation justifications for this deal, considering MTSR's clinical-stage status and Pfizer's recent internal R&D failures in the weight-loss market?

Some parts of the question could not be established from eligible evidence.

## Evidence

The strongest case for paying upfront is the cost of restarting. Given the internal weight-loss setbacks described in the question, buying candidates already in human trials could let Pfizer reach a decisive clinical result sooner than rebuilding internally. The relevant alternative is not just a restart, however: licensing or co-development might also buy time while putting less capital at risk. Pfizer has previously used collaboration for a late-stage program. Nothing supplied shows how much sooner ownership would deliver a competitive obesity drug than either alternative. [1](https://en.wikipedia.org/w/index.php?oldid=1319145810)

## Outlook

My base case credits Metsera with a head start in testing, not a head start in sales. The first execution risk is clinical: weight loss may not persist, or tolerability may prevent patients from staying on an effective dose. The next is commercial: even an approvable drug may offer too little benefit or convenience over alternatives to win coverage at a profitable price. Pfizer’s experience with injectables makes scale-up plausible, but its history does not establish Metsera-specific manufacturing cost or capacity. Milestones can spare Pfizer some additional consideration on failure; they cannot recover the upfront payment. [1](https://en.wikipedia.org/w/index.php?oldid=1319145810)

## What would change the view

I would favor the stronger bullish interpretation if controlled, longer-duration trials showed competitive weight loss with a meaningful advantage in tolerability or dosing, and Pfizer could supply the drug at a cost compatible with payer access. Those observations would turn time saved into a plausible stream of incremental profit. To justify the price, that profit, discounted for delay and the chance of failure, must cover the upfront value, remaining investment and expected contingent payments relative to the best alternative. The supplied history shows that Pfizer has licensed candidates before; it provides neither the clinical comparisons nor the economics needed to clear that test here. [1](https://en.wikipedia.org/w/index.php?oldid=1319145810)

## Sources

1. [Pfizer](https://en.wikipedia.org/w/index.php?oldid=1319145810), available by 2025-10-28.
