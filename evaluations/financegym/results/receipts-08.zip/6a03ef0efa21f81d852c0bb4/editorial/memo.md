# Investment research memo

As of 2025-06-25

**Research question**
How should an income-focused portfolio manager reconcile NNN REIT’s 40-year history of shareholder rewards and conservative <70% payout ratio with the early 2025 insider selling by the CEO and CFO, alongside a series of price target reductions from analysts at UBS, Barclays, and B. Riley?

Some parts of the question could not be established from eligible evidence.

## Evidence

Separate dividend capacity from share valuation. If the stated payout is measured against sustainable adjusted funds from operations (AFFO), retained cash provides a cushion. A higher required yield can lower a price target without changing the dividend; a cut driven by a lower AFFO forecast is more relevant to income. Check each analyst’s rationale and the payout denominator. NNN’s dated operating snapshot—3,118 properties at December 31, 2019—establishes portfolio scale, not current rent collections or coverage. [1](https://en.wikipedia.org/w/index.php?oldid=1282733754)

## Outlook

Conditional base case: expect a stable dividend through the next reporting cycle if recurring AFFO per share continues to cover the distribution with the stated margin. The strongest alternative is that the target cuts anticipate tenant stress that will erode coverage. Geographic exposure offers a concrete test: Texas properties once supplied 17.6% of revenue. Check current exposures and rent collections rather than assume that historical concentration persists. [1](https://en.wikipedia.org/w/index.php?oldid=1282733754)

## What would change the view

Give the reported insider sales more weight if transaction filings show discretionary disposals of substantial portions of both executives’ holdings, rather than scheduled sales that leave their stakes largely intact. The historical leadership record supplies no transaction terms. Trim if weakening collections push recurring AFFO per share below the dividend without a credible recovery path; that would invalidate the income thesis regardless of the executives’ motives or analysts’ targets. [1](https://en.wikipedia.org/w/index.php?oldid=1282733754)

## Sources

1. [NNN Reit](https://en.wikipedia.org/w/index.php?oldid=1282733754), available by 2025-03-28.
