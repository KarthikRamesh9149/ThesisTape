# Investment research memo

As of 2025-05-27

**Research question**
Given the leadership transition under CEO Rob Lynch and the May 2025 licensing partnership with PENN Entertainment, how is Shake Shack's strategic shift toward asset-light expansion and non-traditional locations likely to impact its operating margins and valuation relative to peers like Wendy's and Brinker International?

## Answer

As of 2025-05-27, I would not pay a premium forward EV/EBITDA multiple for Shake Shack over Wendy’s or Brinker on the strength of Rob Lynch’s licensing strategy alone. Licensing can raise consolidated operating margin, but there is no verified PENN restaurant count or opening schedule here to support a material change in unit mix. Lynch’s appointment is documented; the May 2025 PENN partnership is an unverified question premise in the supplied record. I would assign it no incremental earnings in the base case until its scope is confirmed. [1](https://en.wikipedia.org/w/index.php?oldid=1291370076) [2](https://en.wikipedia.org/w/index.php?oldid=1284156982)

## Evidence

A casino footprint is not a restaurant commitment. PENN’s documented sublicensing agreements concern gaming rights, not Shake Shack, and the cited casino property count belongs to GLPI, a landlord with multiple tenants. Neither establishes even which PENN venues are eligible, much less which must open a Shack. A dated announcement distinguishing committed sites from options would be the starting point for estimating the deal’s scale. [2](https://en.wikipedia.org/w/index.php?oldid=1284156982)

The peer comparison turns on earnings growth and cash investment, not margin rank. Wendy’s has used franchising, so partner-funded growth is not by itself a reason to prefer Shake Shack. Brinker has bought franchised Chili’s restaurants: operating a restaurant can yield more profit dollars than collecting a fee even if recognizing its full sales lowers the reported margin percentage. The record lacks comparable enterprise values as of the cutoff and same-horizon EBITDA forecasts for all three companies. It therefore supports neither a measured trading premium nor a claim that Shake Shack is overvalued overall. [3](https://en.wikipedia.org/w/index.php?oldid=1289609111) [4](https://en.wikipedia.org/w/index.php?oldid=1280282278)

## Outlook

My base case is that non-traditional licenses supplement rather than replace company-operated expansion. Shake Shack had stadium locations before Lynch, and its IPO plan emphasized company-operated stores; neither fact measures today’s mix. If a partner funds a new site and Shake Shack books royalties rather than the restaurant’s gross sales, consolidated operating margin rises only if the fees, net of support costs, earn a higher margin than the existing business. Cash investment can fall relative to building the site itself even when the royalty dollars are too small to move consolidated earnings appreciably. [1](https://en.wikipedia.org/w/index.php?oldid=1291370076)

## What would change the view

The strongest alternative is that PENN proves a repeatable way to reach customers at venues Shake Shack would not profitably build itself. The test is conversion into operating restaurants, not announced potential: Shake Shack’s Mexico history likewise distinguishes a development target from actual openings. I would reconsider a premium if disclosed commitments became sustained licensed net openings, recurring fees grew faster than support costs, and consolidated operating income and free cash flow rose with less capital per opening. The resulting EBITDA growth would then need to justify the observed multiple gap against both peers. [1](https://en.wikipedia.org/w/index.php?oldid=1291370076)

## Sources

1. [Shake Shack](https://en.wikipedia.org/w/index.php?oldid=1291370076), available by 2025-05-20.
2. [Penn Entertainment](https://en.wikipedia.org/w/index.php?oldid=1284156982), available by 2025-04-05.
3. [Wendy's](https://en.wikipedia.org/w/index.php?oldid=1289609111), available by 2025-05-09.
4. [Brinker International](https://en.wikipedia.org/w/index.php?oldid=1280282278), available by 2025-03-13.
