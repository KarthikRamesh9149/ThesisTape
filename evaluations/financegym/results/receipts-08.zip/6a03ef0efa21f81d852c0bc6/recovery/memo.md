# Investment research memo

As of 2025-08-20

**Research question**
Evaluate the valuation impact on Pershing Square’s 13-year long position in Freddie Mac (FMCC) resulting from President Trump’s 2025 proposals to end government conservatorship, initiate a $30 billion share offering, and return the GSE to public markets via a unified listing.

Some parts of the question could not be established from eligible evidence.

## Answer

As of 2025-08-20, the available evidence does not establish that President Trump’s plans increased the market value of Pershing Square’s existing Freddie Mac common shares (FMCC). It supplies neither a pre-announcement FMCC price nor a cutoff price. The documented price decline followed Freddie’s historical delisting, not the proposed offering. Neither the direction nor the size of Pershing’s paper gain can therefore be verified. Even a documented rally would not, by itself, tell us how much reflected better terms for Freddie’s shareholders rather than anticipation of a combined Fannie–Freddie offering. [1](https://en.wikipedia.org/w/index.php?oldid=1305742755)

## Evidence

The policy record establishes that FHFA placed both companies in conservatorship in 2008 and that in 2019 its incoming director committed to work toward ending it. That commitment was not a release decision. No contemporaneous Trump statement or Treasury or FHFA decision in the record verifies the scope of the 2025 proposal. Release changes who controls the companies; an offering sells shares; a listing changes where shares trade. The evidence does not establish that release was required before a sale or listing, or that officials had decided on a sequence. [2](https://en.wikipedia.org/w/index.php?oldid=1280541602)

A unified listing is not a verified merger or an exchange offer for FMCC. Fannie was already publicly traded, and Freddie’s historical NYSE delisting does not tell us what would happen to its outstanding shares in a relisting. The record does not distinguish a merger from a common listed parent over separate companies or coordinated listings. Even a reliable combined equity valuation would not value Pershing’s stake without knowing whether FMCC survives, what holders receive in an exchange, and how much equity they retain after senior claims and new issuance. [3](https://en.wikipedia.org/w/index.php?oldid=1306043351) [1](https://en.wikipedia.org/w/index.php?oldid=1305742755)

## Outlook

Base case: keep the valuation of legacy FMCC unchanged on offering news alone. This is a judgment about the evidence, not a forecast of a flat trading price. In the near term, buyers could bid up FMCC on expectations of release. The strongest bullish alternative is that a recapitalization actually leaves each existing share with a more valuable claim: Freddie meets its capital needs and Treasury accepts terms that leave more of Freddie’s future earnings for common holders. The downside is that senior preferred priority persists, or conversion, warrant exercise and new issuance leave legacy holders with too little of the resulting equity. Freddie’s return to profitability does not resolve that allocation. [1](https://en.wikipedia.org/w/index.php?oldid=1305742755)

## Sources

1. [Freddie Mac](https://en.wikipedia.org/w/index.php?oldid=1305742755), available by 2025-08-13.
2. [Federal Housing Finance Agency](https://en.wikipedia.org/w/index.php?oldid=1280541602), available by 2025-03-15.
3. [Fannie Mae](https://en.wikipedia.org/w/index.php?oldid=1306043351), available by 2025-08-15.
