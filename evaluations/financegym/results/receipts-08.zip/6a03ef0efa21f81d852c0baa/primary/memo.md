# Investment research memo

As of 2025-10-28

**Research question**
How will the fiscal consolidation measures proposed by Rachel Reeves in the November 26 Autumn Budget—specifically the anticipated £30-40bn tax package and National Insurance hikes—impact UK business investment and hiring trends according to Capital Economics' fiscal analysis?

Some parts of the question could not be established from eligible evidence.

## Evidence

The verified £40 billion was the value of all tax rises Reeves announced in the October 2024 Budget, not the yield of employer National Insurance alone. That Budget raised employer National Insurance to 15% on earnings above £5,000 from April 2025. The rise was therefore already part of firms’ cost base before November. Nothing supplied shows that Capital Economics assumed a further hike, or that it ruled one out. [1](https://en.wikipedia.org/w/index.php?oldid=1318455156)

## Outlook

A testable base case, not a Capital Economics forecast, is that tightening which weakens expected sales would lead firms to defer investment and post fewer vacancies than they otherwise would. That need not mean either measure falls outright. The strongest alternative is that the Budget leaves marginal hiring costs unchanged and orders hold up, producing little additional drag beyond April’s rise. Watch the announced employer contribution terms, then compare order books, capital-spending intentions and vacancies: weaker hiring before the Budget would not by itself identify a November effect. [1](https://en.wikipedia.org/w/index.php?oldid=1318455156)

## Sources

1. [Rachel Reeves](https://en.wikipedia.org/w/index.php?oldid=1318455156), available by 2025-10-23.
