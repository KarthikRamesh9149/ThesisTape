# Investment research memo

As of 2025-07-21

**Research question**
Does Arrowstreet Capital's aggressive accumulation of Nutrien Ltd (NTR) shares throughout Q4 2024 and Q1 2025 indicate a contrarian view on management's stated tariff risks, or a strategic bet on global potash demand outstripping potential North American trade friction voiced by Ken Seitz?

## Answer

As of 2025-07-21, Arrowstreet Capital’s “aggressive accumulation” of Nutrien shares in Q4 2024 and Q1 2025 is an unverified question premise. The available material describes Arrowstreet’s stock-selection process but gives no quarter-end NTR share counts. Neither the direction nor the scale of the changes can be verified. Even if the count rose in both quarters, that pattern alone would not favor a global potash demand thesis over a judgment that tariff costs would be limited. [1](https://en.wikipedia.org/w/index.php?oldid=1294414102)

## Evidence

The chronology weakens the claim that Arrowstreet was trading against Ken Seitz. Nutrien’s call took place on February 20, 2025, after the first quarter under review had ended. The excerpts identify Seitz but do not quote the tariff warning attributed to him. Even a verified increase in the following quarter’s closing balance would not show whether Arrowstreet added shares before or after he spoke. [2](https://web.archive.org/web/20250222002429/https://seekingalpha.com/article/4760202-nutrien-ltd-ntr-q4-2024-earnings-call-transcript#:~:text=Nutrien%20Ltd.%20%28NYSE%3ANTR%29%20Q4%202024%20Earnings%20Conference%20Call%20February,SVP%2C%20Retail%20North%20America%20Jason%20Newton%20-%20Head%20Economist) [3](https://web.archive.org/web/20250222002429/https://seekingalpha.com/article/4760202-nutrien-ltd-ntr-q4-2024-earnings-call-transcript#:~:text=Thank%20you%2C%20operator.%20Good%20morning%2C%20and%20welcome%20to%20Nutrien%27s,review%20our%202024%20results%20and%20the%20outlook%20for%20the)

## Outlook

The more defensible operating base case is narrower tariff exposure, not a surge in demand. Effective March 7, 2025, qualifying Canadian potash was exempt from the new U.S. duty; nonqualifying potash faced an additional 10%. If most of Nutrien’s U.S.-bound potash qualified, direct duty costs could be modest even with flat demand. That would reflect a change in policy after the call, not necessarily disagreement with Seitz when he spoke. Nutrien’s qualifying shipment share and actual duty expense would test this case. [4](https://web.archive.org/web/20250714021458/https://www.westernoverseas.com/tariff-updates-usmca-exemptions-and-potash-duties-for-canada-imports/#:~:text=Effective%20March%207%2C%202025%2C%20goods%20entered%20under%20USMCA%20will,classifications%20have%20been%20established%20for%20goods%20qualifying%20for%20USMCA.) [5](https://web.archive.org/web/20250714021458/https://www.westernoverseas.com/tariff-updates-usmca-exemptions-and-potash-duties-for-canada-imports/#:~:text=Potash%3A%20Potash%20from%20Canada%20qualifying%20for%20USMCA%20is%20exempt,reduced%20additional%20duty%20of%2010%25.%20Key%20Exemptions%20and%20Changes)

## What would change the view

The strongest demand argument is that overseas sales could offset a material U.S. cost, not simply that large overseas markets exist. Higher Nutrien sales volumes or realized prices in markets such as Brazil, China and India would support that interpretation if the resulting incremental profit exceeded the tariff costs Nutrien absorbed. To verify the position changes, compare Arrowstreet’s NTR common-share counts in successive holdings filings against the pre-period baseline. Dated trades would resolve timing; contemporaneous investment commentary or model attribution would help distinguish either thesis from routine portfolio rebalancing. [6](https://en.wikipedia.org/w/index.php?oldid=1296099529) [1](https://en.wikipedia.org/w/index.php?oldid=1294414102)

## Sources

1. [Arrowstreet Capital](https://en.wikipedia.org/w/index.php?oldid=1294414102), available by 2025-06-07.
2. [Nutrien Ltd. (NTR) Q4 2024 Earnings Call Transcript | Seeking Alpha](https://web.archive.org/web/20250222002429/https://seekingalpha.com/article/4760202-nutrien-ltd-ntr-q4-2024-earnings-call-transcript#:~:text=Nutrien%20Ltd.%20%28NYSE%3ANTR%29%20Q4%202024%20Earnings%20Conference%20Call%20February,SVP%2C%20Retail%20North%20America%20Jason%20Newton%20-%20Head%20Economist), available by 2025-02-22.
3. [Nutrien Ltd. (NTR) Q4 2024 Earnings Call Transcript | Seeking Alpha](https://web.archive.org/web/20250222002429/https://seekingalpha.com/article/4760202-nutrien-ltd-ntr-q4-2024-earnings-call-transcript#:~:text=Thank%20you%2C%20operator.%20Good%20morning%2C%20and%20welcome%20to%20Nutrien%27s,review%20our%202024%20results%20and%20the%20outlook%20for%20the), available by 2025-02-22.
4. [Tariff Updates: USMCA Exemptions and Potash Duties for Canada Imports | Western Overseas](https://web.archive.org/web/20250714021458/https://www.westernoverseas.com/tariff-updates-usmca-exemptions-and-potash-duties-for-canada-imports/#:~:text=Effective%20March%207%2C%202025%2C%20goods%20entered%20under%20USMCA%20will,classifications%20have%20been%20established%20for%20goods%20qualifying%20for%20USMCA.), available by 2025-07-14.
5. [Tariff Updates: USMCA Exemptions and Potash Duties for Canada Imports | Western Overseas](https://web.archive.org/web/20250714021458/https://www.westernoverseas.com/tariff-updates-usmca-exemptions-and-potash-duties-for-canada-imports/#:~:text=Potash%3A%20Potash%20from%20Canada%20qualifying%20for%20USMCA%20is%20exempt,reduced%20additional%20duty%20of%2010%25.%20Key%20Exemptions%20and%20Changes), available by 2025-07-14.
6. [Potash](https://en.wikipedia.org/w/index.php?oldid=1296099529), available by 2025-06-17.
