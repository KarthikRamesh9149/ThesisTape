# Investment research memo

As of 2025-04-23

**Research question**
To what extent has Charlie Scharf’s progress in resolving legacy regulatory consent orders enabled Wells Fargo to pivot its growth strategy toward investment banking and digital infrastructure, and how does this affect WFC’s competitive positioning relative to other Money Center Banks?

## Answer

As of 2025-04-23, I would treat Charlie Scharf’s consent-order progress at Wells Fargo (WFC) mainly as relief from remediation work, not as evidence of a material competitive gain against JPMorgan Chase, Bank of America or Citigroup. That judgment is conditional: order resolution and a still-binding Fed asset cap are unverified question premises. The available evidence establishes Scharf’s tenure and the peers’ investment banking presence, but neither quantifies compliance savings nor shows that WFC converted them into mandates or digital capacity. [1](https://en.wikipedia.org/w/index.php?oldid=1286935378) [2](https://en.wikipedia.org/w/index.php?oldid=1285217189)

## Evidence

Investment banking offers WFC a selective route to growth under an asset cap. An advisory mandate earns fees without requiring a larger loan book; a mandate that also requires WFC to commit financing competes for scarce balance-sheet capacity. WFC hired investment bankers in 2011, well before Scharf’s appointment in 2019, so the strategic question is whether remediation helped an existing franchise win more business. The available market-share excerpt names the metric but supplies no bank-level results to demonstrate a gain against the peers. [2](https://en.wikipedia.org/w/index.php?oldid=1285217189) [3](https://en.wikipedia.org/w/index.php?oldid=1286935532) [1](https://en.wikipedia.org/w/index.php?oldid=1286935378) [4](https://web.archive.org/web/20240714030950/https://www.statista.com/statistics/244795/leading-global-equity-investment-banks-by-fee/#:~:text=Largest%20banks%20globally%202023%2C%20by%20revenue%20from%20investment%20banking,investment%20banks%202024%20Largest%20IPOs%20worldwide%20as%20of%202023)

Digital investment need not wait for asset growth: WFC could redirect engineers from remediation toward platforms that serve existing customers at lower cost. But capacity to redirect staff is not evidence of a deployment. The footprint data describe branches and ATMs at WFC and Bank of America, not digital transaction volumes, reliability or cost per transaction. They do not establish that WFC scaled its infrastructure faster than any of the three peers. [3](https://en.wikipedia.org/w/index.php?oldid=1286935532) [5](https://en.wikipedia.org/w/index.php?oldid=1285199532)

## What would change the view

The base case is that a smaller remediation workload shows up in compliance costs before it shows up in relative performance. The strongest alternative is that WFC can win fee-based mandates and modernize its platforms even while the cap binds. I would favor that view if documented order closures and staff redeployments were followed by sustained advisory fee-share gains and higher digital volumes at lower unit cost relative to JPMorgan Chase, Bank of America and Citigroup. Formal Fed cap relief would change the balance-sheet outlook; it would not, by itself, demonstrate either competitive gain. [2](https://en.wikipedia.org/w/index.php?oldid=1285217189)

## Sources

1. [Charles Scharf](https://en.wikipedia.org/w/index.php?oldid=1286935378), available by 2025-04-22.
2. [Investment banking](https://en.wikipedia.org/w/index.php?oldid=1285217189), available by 2025-04-12.
3. [Wells Fargo](https://en.wikipedia.org/w/index.php?oldid=1286935532), available by 2025-04-22.
4. [Leading equity investment banks by fees 2023 | Statista](https://web.archive.org/web/20240714030950/https://www.statista.com/statistics/244795/leading-global-equity-investment-banks-by-fee/#:~:text=Largest%20banks%20globally%202023%2C%20by%20revenue%20from%20investment%20banking,investment%20banks%202024%20Largest%20IPOs%20worldwide%20as%20of%202023), available by 2024-07-14.
5. [Bank of America](https://en.wikipedia.org/w/index.php?oldid=1285199532), available by 2025-04-12.
