# Investment research memo

As of 2025-07-29

**Research question**
How will the simultaneous acceleration of Porter Airlines' E195-E2 fleet expansion and the 41% year-over-year delivery growth in the Executive Aviation segment impact Embraer's ability to meet its 2025 guidance and sustain operational margins across its commercial and private jet divisions?

Some parts of the question could not be established from eligible evidence.

## Evidence

Porter did take aircraft: its first handovers were on December 21, 2022. The increase from 50 firm commitments in July 2022 to 75 firm orders the following year measures orders, not deliveries. New routes show that Porter put jets to work, but it could add flights with aircraft already delivered. Establishing acceleration requires dated Porter handover counts over comparable intervals, or actual handover dates earlier than the prior schedule. Neither is supplied. [1](https://en.wikipedia.org/w/index.php?oldid=1302682122)

The executive jet evidence does not identify the quarter or year-to-date period behind the claimed growth, give comparable unit counts, or establish that the percentage applies to Executive Aviation alone rather than a broader delivery total. A historical executive jet milestone is not a period comparison, and Embraer’s cumulative company-wide aircraft count spans businesses. I would not annualize the rate or apply it to executive revenue. [2](https://en.wikipedia.org/w/index.php?oldid=1303121555)

## Outlook

Commercial Aviation’s margin depends on the cost and timing of converting Porter orders into accepted aircraft. More handovers from the same production capacity could spread fixed costs over more jets and support revenue. But moving a handover between quarters of the guidance year would not itself add a full-year delivery. The E-Jet’s reliance on an exclusive engine supplier makes engine availability worth monitoring: expediting parts to protect delivery dates could preserve revenue at the expense of margin. There is no evidence here that such costs were incurred. [2](https://en.wikipedia.org/w/index.php?oldid=1303121555) [3](https://en.wikipedia.org/w/index.php?oldid=1303160053) [1](https://en.wikipedia.org/w/index.php?oldid=1302682122)

Executive Aviation could likewise benefit from spreading fixed costs across more deliveries, but a unit is not a constant amount of revenue or EBIT: the lineup ranges from light Phenom jets to larger Praetors. Even verified unit growth would not establish a sustained margin without the delivered model mix, realized prices and production costs. And gains in either jet division need not lift consolidated adjusted EBIT margin if defense or support activities offset them. [2](https://en.wikipedia.org/w/index.php?oldid=1303121555)

## What would change the view

My base case gives Porter credit for future demand but assumes no incremental full-year handovers or margin gain from either claim. The strongest upside alternative is that Porter takes jets previously scheduled for a later year while executive deliveries rise at stable prices and unit costs. To test it, compare customer handover dates with the prior schedule and reconcile Embraer’s same-period delivery tables by division. Then subtract year-to-date deliveries and revenue from the respective guidance floors and test whether the remaining schedule, at observed segment profitability, supports the consolidated margin target. The record supplies neither the guidance ranges nor the current financial results needed for that test. [1](https://en.wikipedia.org/w/index.php?oldid=1302682122) [2](https://en.wikipedia.org/w/index.php?oldid=1303121555)

## Sources

1. [Porter Airlines](https://en.wikipedia.org/w/index.php?oldid=1302682122), available by 2025-07-26.
2. [Embraer](https://en.wikipedia.org/w/index.php?oldid=1303121555), available by 2025-07-29.
3. [Embraer E-Jet E2 family](https://en.wikipedia.org/w/index.php?oldid=1303160053), available by 2025-07-29.
