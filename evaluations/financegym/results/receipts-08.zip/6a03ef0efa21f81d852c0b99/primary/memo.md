# Investment research memo

As of 2025-07-09

**Research question**
How do the divergent analyst price targets (ranging from $45 to $67) and heavy institutional accumulation in early 2025 reflect the market's assessment of Varonis Systems' (VRNS) SaaS transition and AI-driven growth strategy ahead of Q2 2025 earnings?

Some parts of the question could not be established from eligible evidence.

## Evidence

Different SaaS growth assumptions could explain the target spread, but they are not the only explanation. An analyst expecting mostly conversions of existing contracts could forecast rising SaaS ARR with little change in total ARR; one expecting new customers and larger contracts could forecast faster growth in both. Even identical growth forecasts could yield different targets if analysts apply different valuation multiples. The reported $737-$745 million ARR target concerns company ARR, not a forecast for SaaS ARR alone. Without dated analyst notes, separate ARR forecasts and valuation multiples, neither endpoint can be attributed to a particular assumption. [1](https://en.wikipedia.org/w/index.php?oldid=1283598010) [2](https://web.archive.org/web/20250330091108/https://seekingalpha.com/news/4403348-varonis-accelerates-saas-transition-to-complete-by-2025-targets-737m-745m-arr#:~:text=Earnings%20Call%20Insights%3A%20Varonis%20Systems%20%28NASDAQ%3AVRNS%29%20Q4%202024%20CEO,during%202024%2C%20reaching%20%24340%20million%20and%20representing%2053%25%20of)

Broad net institutional buying is not established. The earnings commentary documents operating progress, not changes in investors’ positions, and the available material contains no institutional holdings filings. To test the claim, compare successive quarter-end share counts across reporting managers, including new and exited positions. Aggregate net shares added would test scale; the distribution of increases and reductions across managers would test breadth. Even a positive result would not establish that AI motivated the purchases. [2](https://web.archive.org/web/20250330091108/https://seekingalpha.com/news/4403348-varonis-accelerates-saas-transition-to-complete-by-2025-targets-737m-745m-arr#:~:text=Earnings%20Call%20Insights%3A%20Varonis%20Systems%20%28NASDAQ%3AVRNS%29%20Q4%202024%20CEO,during%202024%2C%20reaching%20%24340%20million%20and%20representing%2053%25%20of)

## Outlook

The base case is that migration continues and Athena makes the SaaS offering more useful, without a separately demonstrated AI sales uplift. Varonis planned to finish the transition by the end of 2025. Athena can help analysts triage alerts, but customers receive it as standard: a converted customer gains access whether or not Athena influenced the purchase. A rising SaaS share without stronger net additions to total ARR would be consistent with this case. [1](https://en.wikipedia.org/w/index.php?oldid=1283598010) [3](https://web.archive.org/web/20250523150419/https://www.somerfordassociates.com/blog/introducing-athena-ai-for-varonis-saas/#:~:text=It%20can%20be%20used%20as%20an%20assistant%20SOC%20Analyst,is%20Varonis%20SaaS%20blog.%20More%20Resources%20like%20this%20one%3A)

## What would change the view

The strongest upside alternative is that bundled AI wins business without a separate AI fee: faster investigations may persuade buyers to choose Varonis or expand a contract. I would increase exposure if management distinguishes ARR from conversions, new customers and expansion, and quantifies wins or larger contracts in which Athena influenced the decision. Faster SaaS growth or more Athena usage alone would not clear that bar. [4](https://web.archive.org/web/20250523150419/https://www.somerfordassociates.com/blog/introducing-athena-ai-for-varonis-saas/#:~:text=Athena%20AI%20is%20the%20new%20generative%20AI%20layer%20added,to%20find%20information%20and%20more%20efficiently%20pull%20together%20searches.) [3](https://web.archive.org/web/20250523150419/https://www.somerfordassociates.com/blog/introducing-athena-ai-for-varonis-saas/#:~:text=It%20can%20be%20used%20as%20an%20assistant%20SOC%20Analyst,is%20Varonis%20SaaS%20blog.%20More%20Resources%20like%20this%20one%3A)

## Sources

1. [Varonis Systems](https://en.wikipedia.org/w/index.php?oldid=1283598010), available by 2025-04-02.
2. [Varonis accelerates SaaS transition to complete by 2025, targets $737M-$745M ARR (NASDAQ:VRNS) | Seeking Alpha](https://web.archive.org/web/20250330091108/https://seekingalpha.com/news/4403348-varonis-accelerates-saas-transition-to-complete-by-2025-targets-737m-745m-arr#:~:text=Earnings%20Call%20Insights%3A%20Varonis%20Systems%20%28NASDAQ%3AVRNS%29%20Q4%202024%20CEO,during%202024%2C%20reaching%20%24340%20million%20and%20representing%2053%25%20of), available by 2025-03-30.
3. [Introducing Athena AI for Varonis SaaS - Somerford Associates](https://web.archive.org/web/20250523150419/https://www.somerfordassociates.com/blog/introducing-athena-ai-for-varonis-saas/#:~:text=It%20can%20be%20used%20as%20an%20assistant%20SOC%20Analyst,is%20Varonis%20SaaS%20blog.%20More%20Resources%20like%20this%20one%3A), available by 2025-05-23.
4. [Introducing Athena AI for Varonis SaaS - Somerford Associates](https://web.archive.org/web/20250523150419/https://www.somerfordassociates.com/blog/introducing-athena-ai-for-varonis-saas/#:~:text=Athena%20AI%20is%20the%20new%20generative%20AI%20layer%20added,to%20find%20information%20and%20more%20efficiently%20pull%20together%20searches.), available by 2025-05-23.
