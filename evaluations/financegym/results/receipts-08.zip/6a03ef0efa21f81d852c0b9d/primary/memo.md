# Investment research memo

As of 2025-09-29

**Research question**
What are the primary regulatory and political hurdles facing Nexstar’s proposed $6.2 billion acquisition of Tegna, and how might FCC scrutiny regarding ownership caps and potential political quid pro quo impact the deal's timeline and final valuation?

## Answer

As of 2025-09-29, I would not count on Nexstar closing its $6.2 billion acquisition of Tegna on schedule. A longer review with the $22 per-share price intact is a better base case than a price cut: the FCC is considering ownership rules that bear directly on the purchase, but has not granted relief. Shareholder approval is also required. The reported end-of-September milestone is a target for filing FCC and antitrust paperwork, not a clearance date. The available evidence gives no closing deadline against which to forecast a specific slip. [1](https://en.wikipedia.org/w/index.php?oldid=1314114450) [2](https://en.wikipedia.org/w/index.php?oldid=1313850064)

## Evidence

National reach and local competition are separate hurdles. The combined 265 stations would serve 80% of television households, against a national ownership cap reported at 39%. Audience served is not necessarily the reach counted under FCC rules; the figures establish the scale of the issue, not an exact divestiture requirement. Even national cap relief would leave 35 markets with potential duopolies. CEO Perry Sook’s pledge to keep operations autonomous addresses local news independence, but does not remove common ownership or settle antitrust scrutiny. [2](https://en.wikipedia.org/w/index.php?oldid=1313850064) [1](https://en.wikipedia.org/w/index.php?oldid=1314114450)

The political sequence makes pressure plausible, not a quid pro quo proven. FCC Chair Brendan Carr warned ABC over Jimmy Kimmel’s remarks on September 17, 2025, while Nexstar had a merger awaiting review. Nexstar kept the show off its affiliates after most ABC affiliates resumed it, but restored it alongside Sinclair on September 26. The shared response is consistent with pressure on broadcasters generally; the reversal weighs against continued preemption being a merger condition. Neither fact rules out an attempt to curry favor. Evidence of an exchange would require communications or regulatory action explicitly linking carriage to clearance. Without that link, the controversy is a reason to expect scrutiny of the review, not to assume approval or denial. [3](https://en.wikipedia.org/w/index.php?oldid=1313959411) [1](https://en.wikipedia.org/w/index.php?oldid=1314114450)

## Outlook

Delay and divestiture affect different investors differently. A later payment of $22 is worth less today to a Tegna shareholder even if the contract price never changes. Station sales can instead reduce what Nexstar gets: sale proceeds may not replace the earnings and strategic value of the stations surrendered. In the Tribune transaction, Tegna agreed to buy eleven stations from Nexstar for $740 million to address both reach and local conflicts; the FCC approved the sale. That shows a remedy can work, not what this remedy would cost. Only a renegotiation would cut the agreed per-share payment; no amendment or evidence sufficient to price the lost station value is shown. [1](https://en.wikipedia.org/w/index.php?oldid=1314114450)

## What would change the view

The strongest on-time case is prompt, effective cap relief followed by an acceptable plan for the overlap markets. A final FCC decision, identified buyers for any required sales, antitrust clearance and a favorable shareholder vote would support closing at the announced price. A comment period alone does not. If the cap remains binding and regulators demand sales that undermine the rationale for buying Tegna, failure or renegotiation becomes more plausible than mere delay. A revised merger agreement—not a longer review or a station-sale announcement—would be the signal to change the assumed shareholder payment. [1](https://en.wikipedia.org/w/index.php?oldid=1314114450) [2](https://en.wikipedia.org/w/index.php?oldid=1313850064)

## Sources

1. [Tegna Inc.](https://en.wikipedia.org/w/index.php?oldid=1314114450), available by 2025-09-29.
2. [Nexstar Media Group](https://en.wikipedia.org/w/index.php?oldid=1313850064), available by 2025-09-28.
3. [Jimmy Kimmel Live!](https://en.wikipedia.org/w/index.php?oldid=1313959411), available by 2025-09-29.
