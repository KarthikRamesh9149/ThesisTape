# Investment research memo

As of 2025-07-16

**Research question**
Following the completion of Newmont's strategic reshaping under CEO Tom Palmer in May 2025, how did the company’s divestiture program and portfolio rationalization influence its stock performance and valuation premium relative to the S&P 500, given its unique status as the index's sole gold miner?

Some parts of the question could not be established from eligible evidence.

## Evidence

The earlier program met its divestiture target, but the $800 million was consideration for the 50% Kalgoorlie stake; the broader figure of more than $1.4 billion was expected cash proceeds, not a gain for shareholders. The economic test is whether the after-tax proceeds, accounting for how Newmont used them, were worth more than the future cash flows it surrendered. The sale report provides neither that comparison nor a record of how the proceeds were deployed. [1](https://web.archive.org/web/20250705023206/https://www.mining.com/newmont-completes-kcgm-stake-sale-updates-outlook/#:~:text=Newmont%20%28NYSE%3A%20NEM%2C%20TSX%3A%20NGT%29%20announced%20Thursday%20afternoon%20that,cash%20proceeds%20expected%20in%20the%20first%20quarter%20of%202020)

Newmont described itself as the index’s sole gold producer. Scarcity could attract investors seeking gold exposure within the index, but membership is not a measure of what investors paid for earnings. Even a stock-price gain ahead of the index could reflect faster earnings growth with no increase in Newmont’s multiple. A premium requires a same-date comparison, such as Newmont’s forward price-to-earnings ratio versus the index’s on the same earnings horizon. Neither multiple is supplied. [2](https://web.archive.org/web/20250705023203/https://s24.q4cdn.com/382246808/files/doc_downloads/reserves/Newmont-2020-Reserves-Release_Final.pdf#:~:text=reasonable%20basis.%20However%2C%20such%20statements%20are%20subject%20to%20risks%2C,by%20robust%20safety%20standards%2C%20superior%20execution%20and%20technical%20expertise.) [3](https://en.wikipedia.org/w/index.php?oldid=1300807541)

## What would change the view

The base case is to treat gold exposure as the first explanation to test, not to assume it explains the entire return. Higher gold prices can lift a miner’s margins and make more ore economic to extract, so simply subtracting bullion’s percentage gain would not isolate the effect of sales. The strongest alternative is that the disposals improved cash flow per share at a constant gold price. To test it, compare dividend-reinvested Newmont returns around verified deal announcements with returns predicted by its historical sensitivity to gold and by comparable miners. Positive excess returns at those announcements, followed by sustained improvement in cash flow per share at a common gold price, would support a divestiture contribution. The necessary return and cash-flow series are absent. [4](https://web.archive.org/web/20250705023203/https://s24.q4cdn.com/382246808/files/doc_downloads/reserves/Newmont-2020-Reserves-Release_Final.pdf#:~:text=EXPLORATION%20OUTLOOK%20Newmont%E2%80%99s%20total%20exploration%20expenditure%20is%20expected%20to,RESERVES%20AND%20RESOURCES%202020%20RESULTS%20%7C%20NEWS%20RELEASE%205) [1](https://web.archive.org/web/20250705023206/https://www.mining.com/newmont-completes-kcgm-stake-sale-updates-outlook/#:~:text=Newmont%20%28NYSE%3A%20NEM%2C%20TSX%3A%20NGT%29%20announced%20Thursday%20afternoon%20that,cash%20proceeds%20expected%20in%20the%20first%20quarter%20of%202020)

## Sources

1. [Newmont completes KCGM stake sale, updates outlook - MINING.COM](https://web.archive.org/web/20250705023206/https://www.mining.com/newmont-completes-kcgm-stake-sale-updates-outlook/#:~:text=Newmont%20%28NYSE%3A%20NEM%2C%20TSX%3A%20NGT%29%20announced%20Thursday%20afternoon%20that,cash%20proceeds%20expected%20in%20the%20first%20quarter%20of%202020), available by 2025-07-05.
2. [Archived PDF](https://web.archive.org/web/20250705023203/https://s24.q4cdn.com/382246808/files/doc_downloads/reserves/Newmont-2020-Reserves-Release_Final.pdf#:~:text=reasonable%20basis.%20However%2C%20such%20statements%20are%20subject%20to%20risks%2C,by%20robust%20safety%20standards%2C%20superior%20execution%20and%20technical%20expertise.), available by 2025-07-05.
3. [S&P 500](https://en.wikipedia.org/w/index.php?oldid=1300807541), available by 2025-07-16.
4. [Archived PDF](https://web.archive.org/web/20250705023203/https://s24.q4cdn.com/382246808/files/doc_downloads/reserves/Newmont-2020-Reserves-Release_Final.pdf#:~:text=EXPLORATION%20OUTLOOK%20Newmont%E2%80%99s%20total%20exploration%20expenditure%20is%20expected%20to,RESERVES%20AND%20RESOURCES%202020%20RESULTS%20%7C%20NEWS%20RELEASE%205), available by 2025-07-05.
