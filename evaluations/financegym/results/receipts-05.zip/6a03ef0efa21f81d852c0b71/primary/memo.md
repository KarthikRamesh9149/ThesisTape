# Investment research memo

As of 2025-07-21

**Research question**
How do the specific interest rate targets proposed by board member Naoki Tamura in early 2025 contrast with Governor Kazuo Ueda's data-dependent framework, and what does this internal divergence imply for the Bank of Japan's policy normalization trajectory in July 2025?

Some parts of the question could not be established from eligible evidence.

## Evidence

The contrast is between a preferred destination by a deadline and a rule for deciding when to move. Even a member who favors a higher rate by a given date need not favor a hike at every meeting before then. The available passages document Ueda’s earlier decision to end yield curve control, but contain neither Tamura’s early-2025 remarks nor Ueda’s contemporaneous guidance. They therefore do not verify Tamura’s exact target or deadline, a Board commitment to either, or the starting overnight rate, which remains an unverified question premise. [1](https://en.wikipedia.org/w/index.php?oldid=1277878755)

## What would change the view

The hold call rests on a narrow judgment: a single member’s preferred path is weaker evidence for July action than an indication that the Board considers the conditions for a hike met. The strongest alternative is that wage gains are sustaining price increases strongly enough for Ueda’s framework to support a hike now. Broad wage gains accompanied by persistent domestic inflation, and an explicit signal from Ueda that the Board sees that combination, would shift the call toward a hike. The documented wage gains preceded the earlier policy exit; they are not a July reading. [2](https://en.wikipedia.org/w/index.php?oldid=1294716941)

## Sources

1. [Kazuo Ueda](https://en.wikipedia.org/w/index.php?oldid=1277878755), available by 2025-02-27.
2. [Bank of Japan](https://en.wikipedia.org/w/index.php?oldid=1294716941), available by 2025-06-09.
