# Investment research memo

As of 2025-04-23

**Research question**
How does the heavy insider liquidation by President and COO Michael Benkowitz, totaling approximately $72.5 million by April 2025, correlate with United Therapeutics’ legal strategy and the competitive threat posed by Liquidia Corporation’s YUTREPIA launch in the treprostinil market?

Some parts of the question could not be established from eligible evidence.

## Evidence

The available evidence identifies Benkowitz’s office but contains no transaction filings or trading-plan disclosures. To verify the gross proceeds through the cutoff, sum shares sold times the reported sale price for each distinct sale, excluding option exercises from the sales tally. Trade dates show when shares changed hands; a plan’s adoption or amendment date is more relevant to when Benkowitz chose the sale terms. Neither timeline is documented here, so even the claimed overlap cannot be independently dated. [1](https://en.wikipedia.org/w/index.php?oldid=1286706986)

## Outlook

The relevant competitive exposure is Tyvaso, not every treprostinil product equally: Tyvaso is inhaled, whereas Remodulin is injectable. Litigation could protect Tyvaso by delaying rival entry, but a suit is not itself a launch bar. The available material documents the incumbent products, not YUTREPIA’s final FDA status or an operative court order as of the cutoff. It therefore supports identifying the market at risk, not calling launch imminent or legally blocked. [2](https://en.wikipedia.org/w/index.php?oldid=1229042165) [1](https://en.wikipedia.org/w/index.php?oldid=1286706986)

## What would change the view

The investment base case is to assess launch risk from FDA and court records without adjusting it for the reported sales. An unchanged plan adopted before a material legal development would support the interpretation that later trades merely coincided with litigation. The strongest alternative is that Benkowitz reduced exposure in response to a setback that made entry more likely. A new or enlarged discretionary sale following a dated adverse ruling would strengthen that reading, though it would still not prove motive. [1](https://en.wikipedia.org/w/index.php?oldid=1286706986) [2](https://en.wikipedia.org/w/index.php?oldid=1229042165)

## Sources

1. [United Therapeutics](https://en.wikipedia.org/w/index.php?oldid=1286706986), available by 2025-04-21.
2. [Treprostinil](https://en.wikipedia.org/w/index.php?oldid=1229042165), available by 2024-06-14.
