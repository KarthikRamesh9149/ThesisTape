# Investment research memo

As of 2025-04-28

**Research question**
How will the diverging reimbursement landscape for Leqembi across Europe, the UK, and Australia, combined with the entry of Eli Lilly's Kisunla, affect the peak sales outlook and global commercialization strategy for Eisai and Biogen through fiscal year 2026?

## Answer

As of 2025-04-28, Eisai and Biogen should move Leqembi’s expected global sales peak later, provisionally hold its size unchanged, and plan for lower near-term sales rather than count on a broad European rollout through fiscal 2026. Put the largest share of incremental launch spending into US treatment centers that can turn referrals into paid starts. The distinction is economic: a wait for reimbursement delays revenue; a lasting coverage exclusion, lower net price or sustained loss of patients to Kisunla reduces the peak itself. The available evidence does not quantify a defensible change in peak sales or establish a new peak year. [1](https://en.wikipedia.org/w/index.php?oldid=1286654964)

## Evidence

Treat the EU as a series of national funding decisions, not a single commercial launch. Leqembi’s restricted EU marketing authorization permits treatment within its label; it does not set a reimbursed price or pay for diagnosis, infusions and monitoring. Fund national payer submissions and preparation at selected specialist centers first. Release broader launch budgets where a payer decision, an agreed price and staffed sites make paid starts feasible. The European committee’s refusal recommendation concerned Kisunla, not Leqembi: it offers a potential head start, not evidence of funded demand. The supplied European passage does not document country-level Leqembi coverage or prices. [2](https://en.wikipedia.org/w/index.php?oldid=1282823580)

Keep UK spending focused on the reimbursement case, but defer Australian commercial deployment. In Great Britain, a licence permits prescribing; it is not a positive NICE recommendation for routine NHS use in England. Do not budget for NHS-scale volume on the strength of the licence or extrapolate England’s position to every UK payer. The supplied passages do not document a UK funding decision or private patient volumes. Australia faces an earlier barrier: the regulator upheld non-registration on reconsideration. Preserve regulatory options there rather than staffing a launch as though price negotiation were the only remaining step. [1](https://en.wikipedia.org/w/index.php?oldid=1286654964)

## Outlook

In the US, prioritize benefit verification, referral coordination and infusion and MRI scheduling over broad promotion. Eisai estimates that Medicare covers about 85% of eligible Americans with early Alzheimer’s; that describes the patients’ insurer, not the proportion approved for Leqembi or receiving it. Kisunla’s US approval creates a prescribing choice, but does not show that it has displaced Leqembi. Track paid new starts for both drugs at centers offering both: a falling Leqembi share alongside rising Leqembi starts would suggest category expansion, whereas falling starts at centers with spare capacity would warrant investigating displacement. [1](https://en.wikipedia.org/w/index.php?oldid=1286654964) [2](https://en.wikipedia.org/w/index.php?oldid=1282823580)

## What would change the view

The strongest downside case is that what looks like a delay is a permanently smaller paying market. Cut the peak estimate if major payers persistently exclude treatment or require prices well below the forecast, or if funded centers with adequate capacity consistently start fewer patients on Leqembi as Kisunla gains them. Conversely, rising paid starts and sustained treatment after national funding decisions would support keeping the peak and revisiting the delay. The US cost-effectiveness assessment below Leqembi’s US price makes pricing pressure credible, but it is not a European price settlement. Without net prices, treatment duration, paid starts by brand or the original peak model, the size of either revision remains unverified. [1](https://en.wikipedia.org/w/index.php?oldid=1286654964) [2](https://en.wikipedia.org/w/index.php?oldid=1282823580)

## Sources

1. [Lecanemab](https://en.wikipedia.org/w/index.php?oldid=1286654964), available by 2025-04-21.
2. [Donanemab](https://en.wikipedia.org/w/index.php?oldid=1282823580), available by 2025-03-28.
