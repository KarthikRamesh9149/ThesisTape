# Investment research memo

As of 2025-05-27

**Research question**
How does the $1.2 billion refinancing of the FLNG Gimi, managed under CEO Karl Fredrik Staubo, affect Golar LNG's liquidity and leverage ratios as the vessel transitions from commissioning to full operations at the Greater Tortue Ahmeyim project?

Some parts of the question could not be established from eligible evidence.

## Evidence

The liquidity test is how much unrestricted cash reaches Golar, not how much Gimi can borrow. Closing would establish a facility; a draw would establish funding. Only proceeds left after retiring old debt, paying fees and meeting any project reserve requirements could be available for distribution. The cargo report documents an operating event, not a draw, payoff or transfer to Golar. A longer tenor could ease near-term repayment pressure without adding to parent cash. [1](https://web.archive.org/web/20250514141517/https://jpt.spe.org/bp-completes-loading-first-lng-cargo-from-greater-tortue-ahmeyim-phase-1#:~:text=The%20offshore%20Mauritania%20and%20Senegal%20project%E2%80%99s%20initial%20phase%20will,hub%20terminal%20in%20preparation%20for%20the%20second%20cargo%20lifting.)

## Outlook

The base case separates refinancing from earnings growth. Replacing debt with the same principal does not itself reduce gross debt. At unchanged net debt, higher realized EBITDA from full operations would lower net debt to EBITDA, but substituting projected full-operation EBITDA for trailing earnings produces a pro forma ratio, not a reported one. Expected project output of 2.4 mtpa is explicitly conditional on full commissioning; it is neither realized Golar EBITDA nor evidence of a lower reported ratio. No before-and-after ratio can be verified here. [2](https://web.archive.org/web/20250514141517/https://jpt.spe.org/bp-completes-loading-first-lng-cargo-from-greater-tortue-ahmeyim-phase-1#:~:text=Subsea%20wells%20produce%20the%20gas%20through%20large-bore%20wells%20designed,both%20countries%20when%20they%20are%20ready%20to%20receive%20it.) [1](https://web.archive.org/web/20250514141517/https://jpt.spe.org/bp-completes-loading-first-lng-cargo-from-greater-tortue-ahmeyim-phase-1#:~:text=The%20offshore%20Mauritania%20and%20Senegal%20project%E2%80%99s%20initial%20phase%20will,hub%20terminal%20in%20preparation%20for%20the%20second%20cargo%20lifting.)

## What would change the view

The strongest alternative is a cash-out refinancing that both extends maturities and funds a distribution to Golar. To credit that outcome, look for a dated closing and draw disclosure reconciling proceeds to the old loan payoff, restricted balances and cash actually received by the parent. That would establish a liquidity benefit, not necessarily deleveraging: additional borrowing could fund the distribution. A later balance sheet and trailing EBITDA on the same reporting basis would test the leverage claim separately. The start of exports is not a substitute for either test. [3](https://web.archive.org/web/20250514141517/https://jpt.spe.org/bp-completes-loading-first-lng-cargo-from-greater-tortue-ahmeyim-phase-1#:~:text=%E2%80%9CThis%20first%20cargo%20from%20Mauritania%20and%20Senegal%20marks%20a,national%20importance%E2%80%9D%20by%20the%20governments%20of%20Mauritania%20and%20Senegal.)

## Sources

1. [BP Completes Loading First LNG Cargo From Greater Tortue Ahmeyim Phase 1](https://web.archive.org/web/20250514141517/https://jpt.spe.org/bp-completes-loading-first-lng-cargo-from-greater-tortue-ahmeyim-phase-1#:~:text=The%20offshore%20Mauritania%20and%20Senegal%20project%E2%80%99s%20initial%20phase%20will,hub%20terminal%20in%20preparation%20for%20the%20second%20cargo%20lifting.), available by 2025-05-14.
2. [BP Completes Loading First LNG Cargo From Greater Tortue Ahmeyim Phase 1](https://web.archive.org/web/20250514141517/https://jpt.spe.org/bp-completes-loading-first-lng-cargo-from-greater-tortue-ahmeyim-phase-1#:~:text=Subsea%20wells%20produce%20the%20gas%20through%20large-bore%20wells%20designed,both%20countries%20when%20they%20are%20ready%20to%20receive%20it.), available by 2025-05-14.
3. [BP Completes Loading First LNG Cargo From Greater Tortue Ahmeyim Phase 1](https://web.archive.org/web/20250514141517/https://jpt.spe.org/bp-completes-loading-first-lng-cargo-from-greater-tortue-ahmeyim-phase-1#:~:text=%E2%80%9CThis%20first%20cargo%20from%20Mauritania%20and%20Senegal%20marks%20a,national%20importance%E2%80%9D%20by%20the%20governments%20of%20Mauritania%20and%20Senegal.), available by 2025-05-14.
