# Investment research memo

As of 2025-08-12

**Research question**
How has DOF Group’s aggressive accumulation of Petrobras charters, totaling over $1 billion in 2025, altered its valuation and credit profile relative to the offshore vessel sector, and what role does John Fredriksen’s backing play in mitigating Brazilian market concentration risk?

Some parts of the question could not be established from eligible evidence.

## Evidence

Verification requires a charter-by-charter reconciliation of dated DOF and Petrobras notices to DOF’s reported backlog. Match vessels and counterparties, count each firm award once, separate options from commitments, and distinguish the award date from the start of paid work. Neither Weatherford’s intervention contract nor Petrobras’s refinery investment belongs in that tally. Until it reconciles, give the claimed awards no incremental debt-service credit; that is not a finding that DOF won no work. [1](https://en.wikipedia.org/w/index.php?oldid=1305068151)

Fredriksen’s wealth and shipping interests are not creditor protection. Even a confirmed equity stake would give him an incentive, not an obligation, to inject cash. An acquisition could reduce DOF’s Brazilian exposure if it added material cash flow from other customers, but it would not guarantee DOF’s debt and could increase leverage. The biographical evidence establishes neither a DOF holding nor a diversifying transaction nor a signed guarantee; assign no spread benefit to assumed support. [2](https://en.wikipedia.org/w/index.php?oldid=1283549445)

## Outlook

The strongest case for a multiple premium is that firm charters could replace uncertain spot work with profitable vessel days, making DOF’s earnings more predictable through a downturn. The competing risk is that one customer’s payment delay or renewal decision could affect several vessels at once. Tidewater’s international fleet makes it a useful comparator, but fleet geography alone does not measure customer concentration. Test the premium against normalized EBITDA, firm charter coverage and customer exposure on a comparable fleet basis; the evidence supplies no relative multiples. [3](https://en.wikipedia.org/w/index.php?oldid=1290705802)

## What would change the view

The equity and credit decisions need not move together. Verified awards followed by on-time vessel starts and sustained margins relative to peers would support a multiple premium. For a tighter spread, look for charter receipts after operating costs, taxes, working capital and maintenance spending to cover interest and scheduled principal even under a Petrobras payment delay. Compare debt of similar maturity and seniority. A signed, enforceable guarantee covering that debt from a demonstrably solvent Fredriksen entity would separately strengthen creditor recovery; it would not diversify DOF’s operations. [1](https://en.wikipedia.org/w/index.php?oldid=1305068151) [3](https://en.wikipedia.org/w/index.php?oldid=1290705802) [2](https://en.wikipedia.org/w/index.php?oldid=1283549445)

## Sources

1. [Petrobras](https://en.wikipedia.org/w/index.php?oldid=1305068151), available by 2025-08-09.
2. [John Fredriksen](https://en.wikipedia.org/w/index.php?oldid=1283549445), available by 2025-04-02.
3. [Tidewater (marine services)](https://en.wikipedia.org/w/index.php?oldid=1290705802), available by 2025-05-16.
