# Investment research memo

As of 2025-07-21

**Research question**
Considering the significant insider divestments by executives like Michael David Dunn and Todd Krasnow alongside aggressive institutional accumulation by ARK and Vanguard, is Symbotic’s premium valuation sustainable as analysts at UBS and Citigroup lower their price targets ahead of the August 2025 earnings?

## Answer

As of 2025-07-21, I would not underwrite Symbotic’s asserted premium on guidance alone. The premium, large sales by Michael David Dunn and Todd Krasnow, aggressive buying by ARK and Vanguard, and pre-earnings target cuts by UBS and Citigroup are unverified question premises. The record gives neither the cutoff valuation nor management’s revenue and margin guidance, so it cannot establish that a beat is necessary. Citi’s documented $37 target rests on long-term automation demand, not on a forecast that August results will clear the market’s expectations. [1](https://web.archive.org/web/20250115014757/https://www.investing.com/news/analyst-ratings/citi-resumes-symbotic-stock-with-buy-rating-93CH-3808638#:~:text=Kaplowitz%20also%20pointed%20out%20that%20Symbotic%27s%20ongoing%20insourcing%20initiatives,adjusting%20its%20price%20target%20down%20to%20%2445%20from%20%2450.)

## Evidence

The January analyst account describes Citi resuming coverage with a Buy, not cutting its target ahead of August. The explicit reduction in that account was TD Cowen’s, to $45 from $50. Citi’s near-term caution about insourcing is relevant to margins, but its older target is not evidence of a fresh downgrade. Without dated prior and revised targets and rationales for UBS or Citi, neither alleged cut changes the view. [1](https://web.archive.org/web/20250115014757/https://www.investing.com/news/analyst-ratings/citi-resumes-symbotic-stock-with-buy-rating-93CH-3808638#:~:text=Kaplowitz%20also%20pointed%20out%20that%20Symbotic%27s%20ongoing%20insourcing%20initiatives,adjusting%20its%20price%20target%20down%20to%20%2445%20from%20%2450.)

As of 2025-07-21, neither the alleged large sales by Michael David Dunn and Todd Krasnow nor the alleged aggressive buying by ARK and Vanguard changes my valuation view. Both are unverified question premises. For each insider, dated disclosures showing the share of his stake sold, what he retained and whether the sale was prearranged would help distinguish a discretionary exit from routine selling. For ARK and Vanguard, look for dated changes in shares held and in Symbotic’s weight in the specific fund. Vanguard offers indexed and active products, so a purchase to track an index would carry less weight than a discretionary increase backed by an explicit margin thesis. The record identifies neither the fund nor the rationale for either institution’s alleged purchase. [2](https://web.archive.org/web/20211130092622/https://investor.vanguard.com/index-funds/index-vs-active#:~:text=Whatever%20your%20financial%20goals%2C%20you%27ll%20find%20that%20Vanguard%20investments,more%20about%20other%20conditions%20%26%20costs%20that%20may%20apply.%29) [3](https://en.wikipedia.org/w/index.php?oldid=1301237309)

## Outlook

My base case is that adoption supports growth, but growth alone does not establish better margins. Walmart’s deployment demonstrates demand for the system; it does not show what Symbotic earns on the next installation. The strongest bullish alternative is that insourcing gives Symbotic enough control over installation costs to lift margins as deployments grow. That could support a durable premium without a single-quarter revenue beat. [4](https://en.wikipedia.org/w/index.php?oldid=1301530396) [1](https://web.archive.org/web/20250115014757/https://www.investing.com/news/analyst-ratings/citi-resumes-symbotic-stock-with-buy-rating-93CH-3808638#:~:text=Kaplowitz%20also%20pointed%20out%20that%20Symbotic%27s%20ongoing%20insourcing%20initiatives,adjusting%20its%20price%20target%20down%20to%20%2445%20from%20%2450.)

## What would change the view

At August earnings, compare revenue and margins with management’s actual pre-release ranges. A revenue beat with flat margins would leave the central concern intact. In-range revenue with improving margins, lower costs across comparable deployments and a higher forward margin outlook would be stronger evidence for the premium. To decide whether even that improvement is already priced in, compare the cutoff enterprise value with the profit implied by those margins; neither input is established here. [1](https://web.archive.org/web/20250115014757/https://www.investing.com/news/analyst-ratings/citi-resumes-symbotic-stock-with-buy-rating-93CH-3808638#:~:text=Kaplowitz%20also%20pointed%20out%20that%20Symbotic%27s%20ongoing%20insourcing%20initiatives,adjusting%20its%20price%20target%20down%20to%20%2445%20from%20%2450.)

## Sources

1. [Citi resumes Symbotic stock with buy rating By Investing.com](https://web.archive.org/web/20250115014757/https://www.investing.com/news/analyst-ratings/citi-resumes-symbotic-stock-with-buy-rating-93CH-3808638#:~:text=Kaplowitz%20also%20pointed%20out%20that%20Symbotic%27s%20ongoing%20insourcing%20initiatives,adjusting%20its%20price%20target%20down%20to%20%2445%20from%20%2450.), available by 2025-01-15.
2. [Index funds vs. actively managed funds | Vanguard](https://web.archive.org/web/20211130092622/https://investor.vanguard.com/index-funds/index-vs-active#:~:text=Whatever%20your%20financial%20goals%2C%20you%27ll%20find%20that%20Vanguard%20investments,more%20about%20other%20conditions%20%26%20costs%20that%20may%20apply.%29), available by 2021-11-30.
3. [The Vanguard Group](https://en.wikipedia.org/w/index.php?oldid=1301237309), available by 2025-07-18.
4. [Symbotic](https://en.wikipedia.org/w/index.php?oldid=1301530396), available by 2025-07-20.
