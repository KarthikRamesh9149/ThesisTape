# Investment research memo

As of 2025-07-09

**Research question**
How has AppLovin (APP) maintained consistent triple-digit alpha over the Nasdaq index between March and July 2025, and to what extent does this relative outperformance represent a fundamental divergence from high-beta growth peers like Tesla (TSLA) in the tech sector?

## Answer

From March through 2025-07-09, AppLovin’s consistent triple-digit alpha over the Nasdaq Composite is an unverified question premise. The evidence establishes a large absolute gain over a different window: APP had nearly quadrupled over the preceding year even after a selloff left it down for the calendar year. Neither observation measures what a March buyer earned over the index. Nor is there a same-date Tesla return that would establish the size of a peer gap. [1](https://web.archive.org/web/20250520002618/https://www.investopedia.com/applovin-stock-tumbles-after-short-seller-report-alleging-scammy-practices-11704701#:~:text=Shares%20lost%20about%20one-fifth%20of%20their%20value%20Thursday%20to,respond%20to%20a%20request%20for%20comment%20on%20the%20report.)

## Evidence

The choice of start date changes the test. At each trading close from March through the cutoff, a trailing annual spread subtracts the Nasdaq Composite’s return from APP’s return over the preceding year. It can remain large because of gains earned before March. A since-March spread instead holds the March starting close fixed. The cited Nasdaq gain of 28.6% is for calendar 2024, so subtracting it from APP’s reported trailing gain would answer neither question. [2](https://en.wikipedia.org/w/index.php?oldid=1287407801) [1](https://web.archive.org/web/20250520002618/https://www.investopedia.com/applovin-stock-tumbles-after-short-seller-report-alleging-scammy-practices-11704701#:~:text=Shares%20lost%20about%20one-fifth%20of%20their%20value%20Thursday%20to,respond%20to%20a%20request%20for%20comment%20on%20the%20report.)

Subtracting the same index return from APP and TSLA on identical dates leaves their raw return gap unchanged; it does not remove a difference in market sensitivity. To test the high-beta peer premise, use aligned daily returns for both stocks and the Composite, estimate each stock’s beta from pre-March excess returns over the risk-free rate, then compare performance beyond what those betas predict. The Composite is tech-heavy, but that does not establish either stock’s beta. The supplied evidence lacks the matched series for this test or for a daily check of the triple-digit spread. [2](https://en.wikipedia.org/w/index.php?oldid=1287407801)

## Outlook

The base case is that company-specific demand helped distinguish APP from Tesla, but the evidence is stronger for APP. AppLovin reported revenue gains; investors also anticipated future demand for its AI advertising tools. At Tesla, the share of surveyed US buyers who would not consider the brand rose from 27% to 32%. That is a demand warning, not a decline in deliveries or earnings. Without comparable revenue growth and operating margins for the same reporting periods, operating divergence is plausible but cannot be ranked ahead of market exposure or valuation changes. [1](https://web.archive.org/web/20250520002618/https://www.investopedia.com/applovin-stock-tumbles-after-short-seller-report-alleging-scammy-practices-11704701#:~:text=Shares%20lost%20about%20one-fifth%20of%20their%20value%20Thursday%20to,respond%20to%20a%20request%20for%20comment%20on%20the%20report.) [3](https://web.archive.org/web/20250430112359/https://www.axios.com/2025/02/27/tesla-stock-musk-doge-social-presence#:~:text=Republican%20favorability%20of%20Tesla%20hit%20an%20all-time%20high%20this,in%202023%20to%2065%25%20in%202024%2C%20according%20to%20CNN.)

## What would change the view

The strongest alternative is that investors repriced expected growth faster than operating results diverged. APP lost about one-fifth of its value in a session after a short seller challenged its practices; the move shows sensitivity to news, not that the allegations were true. If a matched-date APP lead survives the beta adjustment, compare changes in forward earnings per share with changes in the price paid per dollar of those earnings. Stronger APP revenue and margins followed by relative earnings upgrades at stable multiples would favor fundamentals. Widening multiples without comparable upgrades would favor repricing; a lead that largely disappears after beta adjustment would favor market exposure. [1](https://web.archive.org/web/20250520002618/https://www.investopedia.com/applovin-stock-tumbles-after-short-seller-report-alleging-scammy-practices-11704701#:~:text=Shares%20lost%20about%20one-fifth%20of%20their%20value%20Thursday%20to,respond%20to%20a%20request%20for%20comment%20on%20the%20report.)

## Sources

1. [AppLovin Stock Tumbles After Short-Seller Report Alleging ‘Scammy’ Practices](https://web.archive.org/web/20250520002618/https://www.investopedia.com/applovin-stock-tumbles-after-short-seller-report-alleging-scammy-practices-11704701#:~:text=Shares%20lost%20about%20one-fifth%20of%20their%20value%20Thursday%20to,respond%20to%20a%20request%20for%20comment%20on%20the%20report.), available by 2025-05-20.
2. [Nasdaq Composite](https://en.wikipedia.org/w/index.php?oldid=1287407801), available by 2025-04-26.
3. [Investors question whether Musk's X and DOGE ties are hurting Tesla](https://web.archive.org/web/20250430112359/https://www.axios.com/2025/02/27/tesla-stock-musk-doge-social-presence#:~:text=Republican%20favorability%20of%20Tesla%20hit%20an%20all-time%20high%20this,in%202023%20to%2065%25%20in%202024%2C%20according%20to%20CNN.), available by 2025-04-30.
