# Investment research memo

As of 2025-08-05

**Research question**
Given the potential 39% US tariff hike on Swiss exports and President Karin Keller-Sutter's ongoing negotiations, how should institutional investors assess the risk of the Swiss National Bank returning to negative interest rates to counteract economic slowdown and trade-related currency appreciation?

## Answer

As of 2025-08-05, retain a zero SNB policy rate as the base case for the next policy review, but hedge the portion of floating-rate CHF income that cannot absorb a cut below zero. For that exposure, seek a quote on a short-dated CHF rate floor rather than locking in a negative forward rate across the portfolio. The US duty of 39% on covered Swiss exports makes a slowdown material; President Karin Keller-Sutter’s negotiations could shorten the shock. Neither outcome dictates the SNB’s decision. The current zero policy rate is an unverified question premise in the supplied evidence; the SNB’s willingness to go negative is documented. [1](https://en.wikipedia.org/w/index.php?oldid=1304400190) [2](https://en.wikipedia.org/w/index.php?oldid=1297453699)

## Evidence

Implementation and a negotiated reduction are not mutually exclusive. The announced Swiss rate is a replacement additional duty, not a percentage-point increase of the same size on every export. It is scheduled to apply to covered US entries from August 7, 2025; qualifying goods already in transit by vessel retain the previous treatment if entered before the October 5, 2025 deadline. Model the announced rate first and vary its duration. Talks alone do not amend the order, and the evidence establishes neither a Swiss deal nor a revised rate. [3](https://web.archive.org/web/20250805202335/https://www.whitehouse.gov/presidential-actions/2025/07/further-modifying-the-reciprocal-tariff-rates/#:~:text=After%20considering%20the%20information%20and%20recommendations%20that%20I%20have,issue%20subsequent%20orders%20memorializing%20the%20terms%20of%20those%20agreements.) [4](https://en.wikipedia.org/w/index.php?oldid=1304342931)

There is no basis here to say the market adequately prices either tariff path. No cutoff-date SARON overnight-indexed swap curve or floor premium is supplied. Even a forward rate below zero would not identify the odds of a trade deal: it reflects possible SNB responses under both paths as well as risk premia. Compare executable floor premiums with the CHF income loss under a persistent tariff and a cut, then test the cost if relief arrives and the SNB holds. Size protection against the loss limit, not an inferred negotiation probability. [3](https://web.archive.org/web/20250805202335/https://www.whitehouse.gov/presidential-actions/2025/07/further-modifying-the-reciprocal-tariff-rates/#:~:text=After%20considering%20the%20information%20and%20recommendations%20that%20I%20have,issue%20subsequent%20orders%20memorializing%20the%20terms%20of%20those%20agreements.) [2](https://en.wikipedia.org/w/index.php?oldid=1297453699)

## Outlook

The strongest alternative to a hold is a lasting tariff that depresses Swiss export orders and margins while safe-haven demand lifts the franc and lowers import prices. Together those effects could push projected inflation low enough to justify a cut. April inflation of 0% shows why that risk matters, but it is not an August reading. A stronger franc alone is insufficient: the SNB targets price stability and can buy foreign currency instead. Its 2011 intervention illustrates that choice, not a current exchange-rate trigger. [2](https://en.wikipedia.org/w/index.php?oldid=1297453699) [5](https://en.wikipedia.org/w/index.php?oldid=1303802863)

## What would change the view

Increase protection if the duty remains in force, export orders weaken and the SNB lowers its inflation outlook despite a zero rate. Persistent franc appreciation alongside falling import prices would strengthen that signal; a move against the dollar alone would not. Conversely, a formal US order reducing the Swiss duty, followed by resilient orders and stable inflation expectations, would reinforce the hold case and argue against renewing the hedge. [3](https://web.archive.org/web/20250805202335/https://www.whitehouse.gov/presidential-actions/2025/07/further-modifying-the-reciprocal-tariff-rates/#:~:text=After%20considering%20the%20information%20and%20recommendations%20that%20I%20have,issue%20subsequent%20orders%20memorializing%20the%20terms%20of%20those%20agreements.) [2](https://en.wikipedia.org/w/index.php?oldid=1297453699)

## Sources

1. [Karin Keller-Sutter](https://en.wikipedia.org/w/index.php?oldid=1304400190), available by 2025-08-05.
2. [Swiss National Bank](https://en.wikipedia.org/w/index.php?oldid=1297453699), available by 2025-06-26.
3. [Further Modifying the Reciprocal Tariff Rates – The White House](https://web.archive.org/web/20250805202335/https://www.whitehouse.gov/presidential-actions/2025/07/further-modifying-the-reciprocal-tariff-rates/#:~:text=After%20considering%20the%20information%20and%20recommendations%20that%20I%20have,issue%20subsequent%20orders%20memorializing%20the%20terms%20of%20those%20agreements.), available by 2025-08-05.
4. [Tariffs in the second Trump administration](https://en.wikipedia.org/w/index.php?oldid=1304342931), available by 2025-08-05.
5. [Swiss franc](https://en.wikipedia.org/w/index.php?oldid=1303802863), available by 2025-08-02.
