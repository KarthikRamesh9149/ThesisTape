# Investment research memo

As of 2025-09-02

**Research question**
How will the Phase 3 BRUIN CLL-314 head-to-head trial results impact Eli Lilly’s (LLY) competitive positioning and revenue growth within the CLL market relative to Imbruvica, and what does this imply for Lilly's oncology segment valuation through 2026?

Some parts of the question could not be established from eligible evidence.

## Evidence

Response does not settle how long disease control lasts. Progression-free survival (PFS) was immature and trending toward Jaypirca; Lilly described a more pronounced effect among the 225 treatment-naïve patients, who had the longest follow-up. It supplied no numerical PFS effect estimate in the excerpt. No observed overall-survival detriment is not a survival benefit. Nor does the excerpt give adverse-event or discontinuation rates that would justify forecasting uptake on a tolerability advantage. [1](https://web.archive.org/web/20250811183655/https://investor.lilly.com/news-releases/news-release-details/lillys-jaypirca-pirtobrutinib-first-and-only-approved-non#:~:text=BRUIN%20CLL-314%20is%20the%20first-ever%20head-to-head%20Phase%203%20study,particularly%20pronounced%20PFS%20effect%20size%20in%20favor%20of%20pirtobrutinib.)

An Imbruvica win is not a market-wide win. The trial did not compare Jaypirca with newer BTK inhibitors such as acalabrutinib or zanubrutinib, or with fixed-duration venetoclax regimens. AbbVie had filed for frontline venetoclax–acalabrutinib, an all-oral, fixed-duration alternative. Its PFS evidence was against chemoimmunotherapy, not Jaypirca; the filing signals competition, not approval. Even within the Imbruvica opportunity, its negotiated Medicare price of $9,319 per month effective in 2026 could make payer-preferred displacement harder. That price is not a market-wide net price. [1](https://web.archive.org/web/20250811183655/https://investor.lilly.com/news-releases/news-release-details/lillys-jaypirca-pirtobrutinib-first-and-only-approved-non#:~:text=BRUIN%20CLL-314%20is%20the%20first-ever%20head-to-head%20Phase%203%20study,particularly%20pronounced%20PFS%20effect%20size%20in%20favor%20of%20pirtobrutinib.) [2](https://web.archive.org/web/20250804145945/https://news.abbvie.com/2025-07-31-AbbVie-Reports-Second-Quarter-2025-Financial-Results#:~:text=AbbVie%20announced%20that%20Emrelis%20%28telisotuzumab%20vedotin-tllv%29%20was%20granted%20accelerated,sunirine%20%28PVEK%29%20in%20blastic%20plasmacytoid%20dendritic%20cell%20neoplasm%20%28BPDCN%29.) [3](https://en.wikipedia.org/w/index.php?oldid=1307264281)

## Sources

1. [Lilly's Jaypirca (pirtobrutinib), the first and only approved non-covalent (reversible) BTK inhibitor, met its primary endpoint in a head-to-head Phase 3 trial versus Imbruvica (ibrutinib) in CLL/SLL | Eli Lilly and Company](https://web.archive.org/web/20250811183655/https://investor.lilly.com/news-releases/news-release-details/lillys-jaypirca-pirtobrutinib-first-and-only-approved-non#:~:text=BRUIN%20CLL-314%20is%20the%20first-ever%20head-to-head%20Phase%203%20study,particularly%20pronounced%20PFS%20effect%20size%20in%20favor%20of%20pirtobrutinib.), available by 2025-08-11.
2. [AbbVie Reports Second-Quarter 2025 Financial Results - Jul 31, 2025](https://web.archive.org/web/20250804145945/https://news.abbvie.com/2025-07-31-AbbVie-Reports-Second-Quarter-2025-Financial-Results#:~:text=AbbVie%20announced%20that%20Emrelis%20%28telisotuzumab%20vedotin-tllv%29%20was%20granted%20accelerated,sunirine%20%28PVEK%29%20in%20blastic%20plasmacytoid%20dendritic%20cell%20neoplasm%20%28BPDCN%29.), available by 2025-08-04.
3. [AbbVie](https://en.wikipedia.org/w/index.php?oldid=1307264281), available by 2025-08-22.
