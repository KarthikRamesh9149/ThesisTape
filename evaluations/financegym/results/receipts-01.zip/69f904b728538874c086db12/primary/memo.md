# Investment research memo

As of 2025-06-05

**Research question**
Given the divergence between robust growth in Environmental Services and volatility in the Safety-Kleen Sustainability Services (SKSS) segment, how should the collective downward revisions in price targets by Goldman Sachs, UBS, and Needham, alongside significant insider selling, impact Clean Harbors' (CLH) valuation outlook?

## Answer

As of 2025-06-05, I would cut neither Clean Harbors’ normalized earnings estimate nor its valuation multiple on the supplied evidence. The reported target cuts by Goldman Sachs, UBS and Needham and the characterization of insider selling as significant are unverified question premises. Neither the size of the cuts nor the share of insiders’ holdings sold is documented. The record establishes exposure to both waste disposal and oil re-refining, but not that the stock is fairly priced. [1](https://en.wikipedia.org/w/index.php?oldid=1284634471)

## Evidence

The offset test is about profit dollars, not segment growth rates. Robust Environmental Services growth and SKSS volatility are unverified question premises; the business history confirms distinct operations, not their current profitability. Compare the change in Environmental Services operating profit with the SKSS profit decline over the same period on a comparable basis. If the gain covers the loss, the segments offset at that level; if not, the shortfall matters for near-term earnings but does not by itself establish a lower through-cycle earnings level. [1](https://en.wikipedia.org/w/index.php?oldid=1284634471)

The alleged target cuts and sales do not yet add demonstrable information beyond guidance. The financial announcements supplied are historical, not a current guidance release, analyst notes or transaction filings. Compare each dated note with the guidance available when it was issued: a cut that merely adopts management’s forecast is not independent confirmation of downside, while a lower target on unchanged earnings may reflect a lower multiple. For sales, check filing dates, amounts relative to retained stakes and trading-plan status before interpreting them as discretionary signals. [2](https://web.archive.org/web/20160305080445/http://www.thefreelibrary.com/Clean+Harbors+Files+Form+10-Q+for+the+First+Quarter+2003.-a0102063491#:~:text=Clean%20Harbors%20Files%20Form%2010-Q%20for%20the%20First%20Quarter,Free%20Library.%202003%20Business%20Wire%2005%20Mar.%202016%20http%3A%2F%2Fwww.thefreelibrary.com%2FClean%2BHarbors%2BFiles%2BForm%2B10-Q%2Bfor%2Bthe%2BFirst%2BQuarter%2B2003.-a0102063491) [3](https://web.archive.org/web/20160305080445/http://www.thefreelibrary.com/Clean+Harbors+Files+Form+10-Q+for+the+First+Quarter+2003.-a0102063491#:~:text=Clean%20Harbors%20Announces%20Second%20Quarter%202004%20Financial%20Results.%20Clean,Clean%20Harbors%20Announces%20Fourth-Quarter%20and%20Year-End%202004%20Financial%20Results.)

## What would change the view

The base case to test is a temporary SKSS shortfall that does not impair consolidated earning power. The strongest alternative is a lasting decline in re-refining profitability that Environmental Services cannot absorb. Repeated comparable-period profit shortfalls accompanied by guidance identifying sustained margin pressure would favor cutting normalized earnings first. A lower multiple would require a separate finding: even at the revised earnings level, consolidated cash flows have become persistently less predictable. That distinction avoids charging the same SKSS loss to valuation twice. [1](https://en.wikipedia.org/w/index.php?oldid=1284634471)

## Sources

1. [Clean Harbors](https://en.wikipedia.org/w/index.php?oldid=1284634471), available by 2025-04-08.
2. [Clean Harbors Files Form 10-Q for the First Quarter 2003. - Free Online Library](https://web.archive.org/web/20160305080445/http://www.thefreelibrary.com/Clean+Harbors+Files+Form+10-Q+for+the+First+Quarter+2003.-a0102063491#:~:text=Clean%20Harbors%20Files%20Form%2010-Q%20for%20the%20First%20Quarter,Free%20Library.%202003%20Business%20Wire%2005%20Mar.%202016%20http%3A%2F%2Fwww.thefreelibrary.com%2FClean%2BHarbors%2BFiles%2BForm%2B10-Q%2Bfor%2Bthe%2BFirst%2BQuarter%2B2003.-a0102063491), available by 2016-03-05.
3. [Clean Harbors Files Form 10-Q for the First Quarter 2003. - Free Online Library](https://web.archive.org/web/20160305080445/http://www.thefreelibrary.com/Clean+Harbors+Files+Form+10-Q+for+the+First+Quarter+2003.-a0102063491#:~:text=Clean%20Harbors%20Announces%20Second%20Quarter%202004%20Financial%20Results.%20Clean,Clean%20Harbors%20Announces%20Fourth-Quarter%20and%20Year-End%202004%20Financial%20Results.), available by 2016-03-05.
