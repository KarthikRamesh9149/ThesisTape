# Investment research memo

As of 2025-08-12

**Research question**
How does the diverging timeline for interest rate cuts between Jerome Powell’s Federal Reserve and the Bank of Canada, specifically Powell's Q4 delay versus the BoC’s projected easing, influence USD/CAD interest rate parity and North American cross-border trade financing through year-end 2025?

## Answer

As of 2025-08-12, budget for a Federal Reserve hold until Q4 and earlier Bank of Canada easing as a scenario, not the base case. That sequencing is an unverified question premise. If it keeps US term rates further above Canadian rates through year-end 2025, USD/CAD forward points should be more negative than under a narrower gap. A Canadian importer would lock in fewer Canadian dollars per US dollar payable, but a Canadian borrower financing that payable in US dollars would face higher US interest. The evidence supports the direction of the forward-price difference, not its size or a net financing saving. [1](https://web.archive.org/web/20250803193218/https://www.reuters.com/world/us/weakening-us-jobs-market-hits-center-fed-rate-policy-debate-2025-08-01/#:~:text=Waller%20and%20Bowman%20favored%20a%20rate%20cut%20at%20this,of%20tariffs%20on%20inflation%20have%20kept%20Fed%20on%20sidelines) [2](https://en.wikipedia.org/w/index.php?oldid=1254823135)

## Evidence

The Fed evidence explains a pause, not a commitment by Jerome Powell to wait until the fourth quarter. Tariff-related inflation concerns favored waiting, but Waller and Bowman already favored cutting; the FOMC, not its chair alone, sets the target. The Canadian evidence is weaker on timing: the BoC’s historical guidance identifies the inflation outlook as a decision criterion, not a current projection of an earlier cut. Neither side of the proposed sequence is established. [1](https://web.archive.org/web/20250803193218/https://www.reuters.com/world/us/weakening-us-jobs-market-hits-center-fed-rate-policy-debate-2025-08-01/#:~:text=Waller%20and%20Bowman%20favored%20a%20rate%20cut%20at%20this,of%20tariffs%20on%20inflation%20have%20kept%20Fed%20on%20sidelines) [3](https://en.wikipedia.org/w/index.php?oldid=1305426755) [4](https://en.wikipedia.org/w/index.php?oldid=1303818853)

## Outlook

For USD/CAD quoted in CAD per USD, covered parity gives the year-end forward as spot times the CAD interest accumulation factor divided by the USD factor over the same term. Forward points are forward minus spot. Holding spot fixed, a larger cumulative US yield advantage puts the dollar at a deeper forward discount; a smaller advantage leaves points negative but closer to zero. The relevant rates cover the full period to settlement, not just the policy rates on the last day. The forward is a price available to hedge a payment, not a forecast of year-end spot. [2](https://en.wikipedia.org/w/index.php?oldid=1254823135) [5](https://en.wikipedia.org/w/index.php?oldid=1294051571)

Separate the invoice hedge from the loan. More negative points reduce the CAD cost of a fixed USD invoice but also reduce the CAD proceeds an exporter locks in on a USD receivable. For a Canadian firm borrowing USD, selling the proceeds at spot and buying principal plus interest forward, the CAD repayment per CAD raised is the USD loan accumulation factor times forward divided by spot. At benchmark rates, covered parity makes that equal to the CAD accumulation factor under either path. If the gap narrows solely because US rates fall, cheaper USD interest offsets the smaller forward discount; if it narrows because CAD rates stay higher, benchmark hedged CAD funding is dearer. The gap alone cannot rank all-in costs. [2](https://en.wikipedia.org/w/index.php?oldid=1254823135) [5](https://en.wikipedia.org/w/index.php?oldid=1294051571)

## What would change the view

Use the executable year-end hedge and matched-maturity loan quotes as the budget base. Test the strongest alternative—earlier Fed easing or a later BoC cut—against employment and inflation releases, central-bank guidance and a narrowing US premium on matched overnight-indexed swap curves. At unchanged spot and basis, that repricing should move forward points toward zero; cuts already priced need not move them again. To choose a funding currency, compare direct CAD debt service with the CAD cost of USD debt service hedged at the dealer’s offer, including borrower spreads and fees. Without dated spot, forward, curve and loan quotes, neither year-end points nor an all-in cost difference can be quantified; cross-currency basis can also move independently of policy. [1](https://web.archive.org/web/20250803193218/https://www.reuters.com/world/us/weakening-us-jobs-market-hits-center-fed-rate-policy-debate-2025-08-01/#:~:text=Waller%20and%20Bowman%20favored%20a%20rate%20cut%20at%20this,of%20tariffs%20on%20inflation%20have%20kept%20Fed%20on%20sidelines) [4](https://en.wikipedia.org/w/index.php?oldid=1303818853) [5](https://en.wikipedia.org/w/index.php?oldid=1294051571)

## Sources

1. [Weakening US jobs market hits center of Fed rate policy debate | Reuters](https://web.archive.org/web/20250803193218/https://www.reuters.com/world/us/weakening-us-jobs-market-hits-center-fed-rate-policy-debate-2025-08-01/#:~:text=Waller%20and%20Bowman%20favored%20a%20rate%20cut%20at%20this,of%20tariffs%20on%20inflation%20have%20kept%20Fed%20on%20sidelines), available by 2025-08-03.
2. [Foreign exchange swap](https://en.wikipedia.org/w/index.php?oldid=1254823135), available by 2024-11-01.
3. [Federal Reserve](https://en.wikipedia.org/w/index.php?oldid=1305426755), available by 2025-08-12.
4. [Bank of Canada](https://en.wikipedia.org/w/index.php?oldid=1303818853), available by 2025-08-02.
5. [Interest rate parity](https://en.wikipedia.org/w/index.php?oldid=1294051571), available by 2025-06-05.
