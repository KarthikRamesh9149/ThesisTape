# Investment research memo

As of 2025-06-05

**Research question**
How have recurring multi-billion dollar USD/JPY option expiries at the 143.00 and 145.00 strikes, reported by DTCC, interacted with shifting Federal Reserve policy expectations to influence spot price dynamics and volatility during the second quarter of 2025?

Some parts of the question could not be established from eligible evidence.

## Evidence

Even a verified large expiry would identify a price and a deadline, not the direction of dealer hedging. If dealers are net long gamma near the strike, maintaining their hedge means selling dollars as USD/JPY rises and buying as it falls. That can dampen fluctuations if spot is already nearby; it need not draw spot there from a distance. Dealers net short gamma would hedge in the opposite direction. Gross notional does not distinguish those positions, so a quiet session near a round number would not by itself show that hedging caused it. [1](https://en.wikipedia.org/w/index.php?oldid=1291237244) [2](https://web.archive.org/web/20241114120807/https://www.esma.europa.eu/press-news/esma-news/esma-registers-dtcc-data-repository-ireland-plc-trade-repository-under-emir-and#:~:text=TRs%20are%20commercial%20firms%20that%20centrally%20collect%20and%20maintain,the%20requirements%20of%20both%20Regulations%2C%20including%2C%20most%20importantly%2C%20on%3A)

## Outlook

The base case to test is that relative rate expectations set the direction of USD/JPY, while expiry hedging can temporarily alter how far it moves. With the expected Japanese rate path unchanged, more Fed cuts priced in would narrow the dollar’s expected yield advantage and favor lower USD/JPY; fewer cuts would favor the reverse. A spot move that follows a shift in the futures-implied Fed path and persists beyond the expiry time would favor this account, especially if similar moves occur on non-expiry days. The historical evidence on yield differentials supplies the rationale, not a measure of repricing during the review period. [3](https://en.wikipedia.org/w/index.php?oldid=1293395706) [4](https://en.wikipedia.org/w/index.php?oldid=1285063953)

## What would change the view

The strongest alternative is a recurring, short-lived expiry effect even when the expected Fed path barely changes. Verify each strike’s expiry date, cutoff time and outstanding notional before examining spot. At each strike separately, compare time spent within a prespecified band and realized volatility from intraday returns against earlier equal-length windows and matched non-expiry sessions. Match the time of day, starting distance from the strike and size of any rate repricing. Repeated excess time near the strike alongside lower volatility before the cut, with both differences fading afterward, would favor an expiry effect. Signed dealer exposure or hedge flows would still be needed to attribute it to dealers. [2](https://web.archive.org/web/20241114120807/https://www.esma.europa.eu/press-news/esma-news/esma-registers-dtcc-data-repository-ireland-plc-trade-repository-under-emir-and#:~:text=TRs%20are%20commercial%20firms%20that%20centrally%20collect%20and%20maintain,the%20requirements%20of%20both%20Regulations%2C%20including%2C%20most%20importantly%2C%20on%3A) [1](https://en.wikipedia.org/w/index.php?oldid=1291237244)

## Sources

1. [Foreign exchange option](https://en.wikipedia.org/w/index.php?oldid=1291237244), available by 2025-05-19.
2. [ESMA registers DTCC Data Repository (Ireland) PLC as trade repository under EMIR and SFTR](https://web.archive.org/web/20241114120807/https://www.esma.europa.eu/press-news/esma-news/esma-registers-dtcc-data-repository-ireland-plc-trade-repository-under-emir-and#:~:text=TRs%20are%20commercial%20firms%20that%20centrally%20collect%20and%20maintain,the%20requirements%20of%20both%20Regulations%2C%20including%2C%20most%20importantly%2C%20on%3A), available by 2024-11-14.
3. [Japanese yen](https://en.wikipedia.org/w/index.php?oldid=1293395706), available by 2025-06-01.
4. [Federal Open Market Committee](https://en.wikipedia.org/w/index.php?oldid=1285063953), available by 2025-04-11.
