# Investment research memo

As of 2025-08-05

**Research question**
How did the aggressive institutional accumulation and massive unit inflows into SOXL during H1 2025 correlate with the ETF's price performance and volatility, specifically considering its 3x leveraged exposure to core components Nvidia, Broadcom, and AMD while trading near 52-week lows?

Some parts of the question could not be established from eligible evidence.

## Answer

As of 2025-08-05, the evidence does not establish whether SOXL net creations or institutional position increases coincided with a drawdown, a rebound, or both during H1 2025. “Aggressive” institutional accumulation and “massive” unit inflows are unverified question premises: the record names no SOXL buyer and gives no dated change in holdings or units outstanding. The reported inflow of nearly $4 billion was for Direxion in March 2020, not for SOXL in the period under review. It cannot support a conclusion that institutions bought the dip. [1](https://en.wikipedia.org/w/index.php?oldid=1201614533)

## Evidence

The appropriate volatility benchmark is the leveraged daily index return, not a multiple of Nvidia’s, Broadcom’s or AMD’s half-year return. SOXL’s specific mandate and the stocks’ status as core components are unverified question premises here; the Direxion history supports the daily-reset principle. Compare daily SOXL NAV returns with triple the benchmark’s same-day returns, then compare the volatility of those series. For holding-period performance, compound the leveraged daily returns: reversals can erode gains even when the index finishes near its starting point. Without daily NAV and index data, neither realized volatility nor tracking error can be quantified. [1](https://en.wikipedia.org/w/index.php?oldid=1201614533)

## What would change the view

The base case is that the timing remains unresolved, not that flows and prices were unrelated. The strongest alternative to dip buying is that demand followed a rebound while SOXL was still well below its earlier peak. Compare split-adjusted shares created net of redemptions from peak to trough with those created during the recovery. Positive totals in both intervals would support “both” for fund flows. Attribution is a separate test: compare named managers’ share counts across reporting dates using filings public by the cutoff. A larger quarter-end position narrows the purchase window but does not identify the trade date or show that the manager received newly created units. [1](https://en.wikipedia.org/w/index.php?oldid=1201614533)

## Sources

1. [Direxion](https://en.wikipedia.org/w/index.php?oldid=1201614533), available by 2024-02-01.
