# Investment research memo

As of 2025-09-29

**Research question**
How will Hungary’s persistent reliance on Russian energy via the Druzhba pipeline, coupled with Viktor Orban’s expansionary fiscal policies and price controls, impact the country’s sovereign credit risk and macroeconomic stability amidst increasing pressure from the EU and the U.S. for energy decoupling?

## Answer

As of 2025-09-29, Hungary warrants a higher sovereign risk premium than a comparable borrower with secure oil supplies and more room to absorb a shock. The reason is the mismatch between how quickly Druzhba flows can stop and how slowly MOL can replace them: an earlier assessment put alternative crude at only about 35% of the blend Hungary’s Duna refinery could process. Viktor Orbán’s fiscal expansion and price controls, and intensifying EU and U.S. pressure to decouple, are unverified question premises. If they hold, they increase the risk that a supply interruption becomes a government financing problem. The evidence supports a premium for that risk, not an imminent downgrade or a conclusion that current spreads are too narrow. [1](https://en.wikipedia.org/w/index.php?oldid=1314040128) [2](https://en.wikipedia.org/w/index.php?oldid=1310757678)

## Evidence

Supplier restrictions, physical outages and permanent phaseouts are distinct risks. Ukraine’s July 2024 restriction applied to Lukoil shipments to Hungary and Slovakia, not all Druzhba crude. The reported halts in August 2025 show that physical disruption can be broader, but do not establish a continuing cutoff. Germany’s earlier switch to Kazakh oil on the northern line shows that changing the oil’s origin need not mean abandoning the pipe; it does not establish that Hungary has equivalent replacement volumes. Neither EU nor U.S. pressure should be treated as a binding exit date on this evidence. [1](https://en.wikipedia.org/w/index.php?oldid=1314040128)

## Outlook

The base case is a staged switch with intermittent disruption, not a lasting loss of refinery output. By 2022, MOL had invested more than USD 170 million in Adria logistics. That provides a seaborne alternative, but delivering crude and processing it at normal throughput are separate tests. The estimate of up to $700million for full conversion came from reporting in 2022: it measures the scale of MOL’s investment challenge, not the amount still to spend at the cutoff or a bill already owed by the sovereign. Rising alternative deliveries alongside stable refinery output would support the base case. [2](https://en.wikipedia.org/w/index.php?oldid=1310757678)

Price controls can lower measured inflation promptly without lowering the cost of imported oil. That distinction matters where household consumption accounts for approximately 50% of GDP: holding retail prices down cushions purchasing power, but if replacement fuel costs more, the difference falls on suppliers unless the budget compensates them. Uncompensated suppliers may cut deliveries; compensation instead adds spending unless offset elsewhere. Lifting controls exposes households to a price catch-up. A lower headline reading under controls is therefore not, by itself, evidence of lasting convergence to the central bank’s 3% target. [3](https://en.wikipedia.org/w/index.php?oldid=1311432435)

## What would change the view

The strongest adverse alternative is a prolonged halt or enforced exit before substitutes are ready. Watch for falling refinery throughput despite increased Adria deliveries. Costlier fuel imports and lost production would weaken growth and tax receipts just as pressure for subsidies rose. If fiscal expansion continued without offsets, Hungary could need to issue more debt precisely when renewed inflation or a weaker forint made investors demand higher yields; the interest bill would rise as debt rolled over. Sustained non-Russian refinery runs at normal output, budget offsets and stable auction yields would argue for a smaller premium. Without current refinery tests, deficit outturns, debt maturities or market spreads, neither the refinancing timetable nor the appropriate spread increment can be quantified. [2](https://en.wikipedia.org/w/index.php?oldid=1310757678) [3](https://en.wikipedia.org/w/index.php?oldid=1311432435) [4](https://en.wikipedia.org/w/index.php?oldid=1311451060)

## Sources

1. [Druzhba pipeline](https://en.wikipedia.org/w/index.php?oldid=1314040128), available by 2025-09-29.
2. [MOL (company)](https://en.wikipedia.org/w/index.php?oldid=1310757678), available by 2025-09-11.
3. [Economy of Hungary](https://en.wikipedia.org/w/index.php?oldid=1311432435), available by 2025-09-15.
4. [Hungarian forint](https://en.wikipedia.org/w/index.php?oldid=1311451060), available by 2025-09-15.
