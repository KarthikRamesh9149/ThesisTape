# Investment research memo

As of 2025-05-11

**Research question**
How should investors reconcile Lattice Semiconductor’s (LSCC) aggressive institutional accumulation and high-conviction price targets against the backdrop of persistent insider selling, a recent CFO leadership transition, and the significant revenue contraction reported in its Industrial and Automotive segment for Q1 2025?

## Answer

Wait rather than buy LSCC at its May closing price under review. As of 2025-05-11, the reported Industrial and Automotive revenue contraction in Q1 2025 is an unverified question premise. The sources establish that Lattice sells into both markets, but give neither the size of the decline nor the closing price or current earnings guidance. There is no basis here to conclude that the price compensates investors for a delayed recovery. That is a reason to wait, not a finding that LSCC is overpriced. [1](https://en.wikipedia.org/w/index.php?oldid=1249213394)

## Evidence

Institutional buying and insider selling need not be conflicting forecasts. Both the claimed aggressive accumulation and the persistent sales are unverified question premises: no LSCC manager, insider, position change or sale size is documented here. Institutional reports show quarter-end holdings and arrive with a lag; insider reports cover ownership changes that include option grants and exercises. Comparing holdings across matching quarters and checking insider transaction codes and the fraction of each stake sold would establish what actually changed. Even confirmed trades would not, by themselves, change an earnings estimate. [2](https://en.wikipedia.org/w/index.php?oldid=1223018657) [3](https://en.wikipedia.org/w/index.php?oldid=1272355422)

Give neither the CFO transition nor the bullish analyst targets an independent valuation adjustment. Both are unverified question premises: the record identifies neither the incoming and outgoing executives nor the analysts, target horizons or earnings assumptions. The handoff matters if it affects guidance reliability, cost control or cash generation. A target matters if its earnings forecast and valuation multiple justify the purchase price. In particular, distinguish a forecast driven by computing demand from one that requires an Industrial and Automotive rebound: Lattice serves both, and success in the former would not confirm the latter. [1](https://en.wikipedia.org/w/index.php?oldid=1249213394)

## What would change the view

The base case gives no earnings credit for an Industrial and Automotive recovery until reported revenue in those markets stabilizes and management's margin outlook shows that stabilization can support profits. The strongest case for buying sooner is that computing growth could sustain earnings even if industrial demand stays weak; waiting for industrial confirmation could then miss the opportunity. To test that case, look for an end-market revenue breakdown and margin guidance that support an earnings estimate without an industrial rebound. Buy only if that estimate justifies the prevailing price at a defensible multiple. [1](https://en.wikipedia.org/w/index.php?oldid=1249213394)

## Sources

1. [Lattice Semiconductor](https://en.wikipedia.org/w/index.php?oldid=1249213394), available by 2024-10-03.
2. [Form 13F](https://en.wikipedia.org/w/index.php?oldid=1223018657), available by 2024-05-09.
3. [Form 4](https://en.wikipedia.org/w/index.php?oldid=1272355422), available by 2025-01-28.
