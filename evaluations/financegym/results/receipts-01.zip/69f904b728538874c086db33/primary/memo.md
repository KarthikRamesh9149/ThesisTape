# Investment research memo

As of 2025-07-21

**Research question**
How should institutional investors reconcile Alex Karp’s consistent share disposals throughout July 2025 and frequent SEC insider filings with Palantir’s aggressive AI-driven growth narrative and its deepening integration into critical U.S. government and enterprise data infrastructure?

## Answer

No July sale by Alex Karp can be verified from the supplied record through 2025-07-21. That is not a finding that he sold nothing. Consistent disposals and frequent Karp filings are unverified question premises; neither the number of shares sold nor the fraction of his stake affected is established. Hold the existing Palantir position at the cutoff, provisionally: there is no verified reduction in Karp’s exposure to justify a trim, and the evidence of government use does not establish a return sufficient to justify adding at the prevailing price. [1](https://en.wikipedia.org/w/index.php?oldid=1301180046) [2](https://en.wikipedia.org/w/index.php?oldid=1301474287)

## Evidence

Count executed transactions, not filings. Check Karp’s SEC ownership reports available by the cutoff for transaction dates rather than filing dates; distinguish sales from option exercises and tax withholding, then reconcile direct and indirect holdings and remaining options. A material discretionary sale would carry more weight than an equal sale scheduled before July: both can reduce exposure, but only the former clearly reflects a contemporaneous choice. The general trading-plan rule explains that distinction; it does not establish that Karp had a plan or used one. [1](https://en.wikipedia.org/w/index.php?oldid=1301180046)

Palantir’s historical ICE contract establishes a government customer. Karp’s later argument for government partnership establishes strategic intent, not a subsequent contract expansion. Neither shows how deeply customers depend on the software, how much government work is funded, or whether private enterprises are renewing and expanding paid AI deployments. The government relationship is evidence of adoption in one market, not a proxy for growth in both. [2](https://en.wikipedia.org/w/index.php?oldid=1301474287)

## Outlook

The hold case is that existing government business can persist without adoption necessarily expanding fast enough to reward new capital. The strongest add case is that integration makes the software costly to replace and easier to sell across departments. Test that interpretation with funded government renewals and expansions alongside enterprise pilots converting to paid production and existing customers increasing spend. The sources provide neither those operating measures nor a cutoff price and cash-flow forecast, so they cannot establish the growth rate embedded in the shares. [2](https://en.wikipedia.org/w/index.php?oldid=1301474287)

## What would change the view

Add if repeat orders in both markets translate into cash flow per diluted share that supports the required return at the verified price. Trim if that return requires faster expansion than funded awards and paying customers support. A verified, material discretionary reduction in Karp’s retained stake would strengthen the trim case, but would not substitute for the price test. [1](https://en.wikipedia.org/w/index.php?oldid=1301180046) [2](https://en.wikipedia.org/w/index.php?oldid=1301474287)

## Sources

1. [SEC Rule 10b5-1](https://en.wikipedia.org/w/index.php?oldid=1301180046), available by 2025-07-18.
2. [Alex Karp](https://en.wikipedia.org/w/index.php?oldid=1301474287), available by 2025-07-20.
