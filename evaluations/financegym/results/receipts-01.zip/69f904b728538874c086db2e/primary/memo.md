# Investment research memo

As of 2025-05-27

**Research question**
How does Panasonic's aggressive expansion into North American EV battery production and AI partnerships reconcile with its concurrent 10,000-person workforce reduction and termination of long-standing global sponsorships? What does this restructuring signal about its shifting capital allocation priorities and projected 2026 profitability?

Some parts of the question could not be established from eligible evidence.

## Evidence

North American batteries have the clearest claim on capital. Panasonic Energy targeted a 2025 production start in Kansas and signed a Canadian graphite supply agreement for its US plants. A plant under construction and a signed materials agreement are stronger evidence of commitment than a statement of strategic intent. Neither establishes that production has started or that the plant will earn an adequate return. [1](https://web.archive.org/web/20250517151716/https://news.panasonic.com/global/stories/15805#:~:text=What%20role%20will%20Panasonic%20Energy%E2%80%99s%20Kansas%20plant%20play%3F%20Construction,and%20make%20a%20significant%20contribution%20to%20reducing%20CO2%20emissions.) [2](https://web.archive.org/web/20250517151716/https://news.panasonic.com/global/stories/15805#:~:text=This%20is%20a%20really%20exciting%20collaboration%20and%20a%20great,shorten%20the%20supply%20chain%2C%20significantly%20reducing%20distribution-related%20CO2%20emissions.)

Protected investment in AI is a weaker claim than protected investment in batteries. Panasonic Automotive Systems announced a Qualcomm cockpit-platform collaboration, but the announcement gives no Panasonic spending commitment. The cited Anthropic investments belong to Amazon and Google, not Panasonic. Treating AI partnerships as a material destination for Panasonic’s restructuring savings is therefore an unverified question premise. [3](https://web.archive.org/web/20250212012248/https://automotive.panasonic.com/en/newsroom/2024#:~:text=Panasonic%20Automotive%20Systems%20and%20Qualcomm%20Expand%20Collaboration%20to%20Transform,Elite%20Platform%20Panasonic%20Automotive%20Systems%20Launches%20New%20Management%20Structure) [4](https://en.wikipedia.org/w/index.php?oldid=1290783538)

## Outlook

For the year ending March 2026, do not count a full year of prospective savings as profit. Severance and plant start-up costs could precede payroll savings, while sponsorship savings depend on when payment obligations end. Later years could benefit from a lower recurring cost base even if transition costs depress near-term profit. The battery timetable is a production target, not earnings guidance: without a charge estimate, savings schedule or group profit forecast, neither the size nor the direction of the year’s profit change is established. [1](https://web.archive.org/web/20250517151716/https://news.panasonic.com/global/stories/15805#:~:text=What%20role%20will%20Panasonic%20Energy%E2%80%99s%20Kansas%20plant%20play%3F%20Construction,and%20make%20a%20significant%20contribution%20to%20reducing%20CO2%20emissions.)

## What would change the view

The strongest alternative is broader retrenchment in which Panasonic finishes an already committed plant but cuts the money needed to bring it to scale. A Kansas opening alone would not distinguish the cases. Rising Kansas output alongside falling recurring overhead would support selective reallocation; a sustained delay accompanied by cuts to battery investment would favor broader retreat. A disclosed Panasonic AI budget or contract commitment would make the AI part of the thesis independently testable. [1](https://web.archive.org/web/20250517151716/https://news.panasonic.com/global/stories/15805#:~:text=What%20role%20will%20Panasonic%20Energy%E2%80%99s%20Kansas%20plant%20play%3F%20Construction,and%20make%20a%20significant%20contribution%20to%20reducing%20CO2%20emissions.) [5](https://web.archive.org/web/20250520023242/https://www.ft.com/content/c48044ae-a151-4edc-88a0-b70f061a7eee#:~:text=Tesla%20supplier%20Panasonic%20pressed%20to%20step%20up%20deliveries%20of%20US-made%20batteries%20Only%20undefined%20for%204%20weeks)

## Sources

1. [The Future Created by Panasonic’s Automotive Battery Plant in Kansas, U.S.A.: Contributing to Increasing EV Adoption and CO₂ Reduction | Environment | Sustainability | Feature Story | Panasonic Newsroom Global](https://web.archive.org/web/20250517151716/https://news.panasonic.com/global/stories/15805#:~:text=What%20role%20will%20Panasonic%20Energy%E2%80%99s%20Kansas%20plant%20play%3F%20Construction,and%20make%20a%20significant%20contribution%20to%20reducing%20CO2%20emissions.), available by 2025-05-17.
2. [The Future Created by Panasonic’s Automotive Battery Plant in Kansas, U.S.A.: Contributing to Increasing EV Adoption and CO₂ Reduction | Environment | Sustainability | Feature Story | Panasonic Newsroom Global](https://web.archive.org/web/20250517151716/https://news.panasonic.com/global/stories/15805#:~:text=This%20is%20a%20really%20exciting%20collaboration%20and%20a%20great,shorten%20the%20supply%20chain%2C%20significantly%20reducing%20distribution-related%20CO2%20emissions.), available by 2025-05-17.
3. [2024 Newsroom | Panasonic Automotive Systems Co., Ltd.](https://web.archive.org/web/20250212012248/https://automotive.panasonic.com/en/newsroom/2024#:~:text=Panasonic%20Automotive%20Systems%20and%20Qualcomm%20Expand%20Collaboration%20to%20Transform,Elite%20Platform%20Panasonic%20Automotive%20Systems%20Launches%20New%20Management%20Structure), available by 2025-02-12.
4. [Anthropic](https://en.wikipedia.org/w/index.php?oldid=1290783538), available by 2025-05-17.
5. [Subscribe to read](https://web.archive.org/web/20250520023242/https://www.ft.com/content/c48044ae-a151-4edc-88a0-b70f061a7eee#:~:text=Tesla%20supplier%20Panasonic%20pressed%20to%20step%20up%20deliveries%20of%20US-made%20batteries%20Only%20undefined%20for%204%20weeks), available by 2025-05-20.
