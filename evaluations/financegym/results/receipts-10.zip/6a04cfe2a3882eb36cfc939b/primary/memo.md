# Investment research memo

As of 2025-08-12

**Research question**
Following the sudden resignation of CEO Kristian Villumsen and the downward revision of FY 2024/25 guidance, how effectively can Interim CEO Lars Rasmussen stabilize Coloplast's margins while balancing high-growth acquisitions like Kerecis against performance headwinds from recurring product recalls in the core segments?

## Answer

Do not underwrite interim CEO Lars Rasmussen’s ability to hold Coloplast’s FY 2024/25 EBIT margin before special items at the revised level. As of 2025-08-12, the revised guidance, Kerecis’s high growth and the financial drag from recurring core recalls are unverified question premises. The available group revenue figure is for 2020/2021, not the guidance period. Neither the target margin nor the size of the profit offset is established. This is a decision to withhold underwriting after the leadership change described in the question, not a forecast that Rasmussen will miss. [1](https://en.wikipedia.org/w/index.php?oldid=1302466299)

## Evidence

Kerecis could add operating profit and still dilute the group margin. If the rest of Coloplast earns the target margin before recall costs, the relevant offset is Kerecis EBIT before special items *less* the profit needed on Kerecis sales at that target margin. Only the excess can absorb recall costs included in the metric. The acquisition evidence concerns Comfort Medical and Atos Medical; it gives neither Kerecis sales nor its EBIT contribution. Sales growth alone cannot settle the test. [1](https://en.wikipedia.org/w/index.php?oldid=1302466299)

## Outlook

The underwriting base case gives Rasmussen no credit for an unmeasured offset, but does not assume an unreported recall charge. Coloplast serves institutions, intermediaries and consumers; that describes potential exposure, not which products or channels were affected. No supplied passage documents a recall cost, its fiscal timing, or whether it was booked before special items. A charge already reflected in revised guidance should not be deducted again; further remediation expense or lost sales would need a separate assessment. [1](https://en.wikipedia.org/w/index.php?oldid=1302466299)

## What would change the view

The strongest alternative is that recall losses are contained within the revised plan and Kerecis earns enough above the target margin to cover the remaining core shortfall. To underwrite that case, look for a dated company reconciliation showing the revised target, Kerecis revenue and EBIT before special items, core recall expenses and lost profit on sales, and the resulting full-year group margin. A group margin sustained by savings elsewhere would support stabilization under Rasmussen, but not the claim that Kerecis paid for the recalls. Coloplast’s historical sales mix cannot distinguish those outcomes. [1](https://en.wikipedia.org/w/index.php?oldid=1302466299)

## Sources

1. [Coloplast](https://en.wikipedia.org/w/index.php?oldid=1302466299), available by 2025-07-25.
