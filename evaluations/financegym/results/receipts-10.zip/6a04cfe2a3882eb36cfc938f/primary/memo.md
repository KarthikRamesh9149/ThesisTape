# Investment research memo

As of 2025-06-10

**Research question**
Evaluate the institutional positioning and valuation of the SPDR S&P Bank ETF (KBE) following the March 2025 RSI dip to 26.1. How do the Q4 2024 stake increases by Millennium Management and Mutual Advisors align with the fundamental outlook for underlying holdings like Renasant and Trustmark?

Some parts of the question could not be established from eligible evidence.

## Evidence

To verify the RSI, identify the trading session and reproduce the reading from KBE’s closing-price history using the reported lookback and smoothing convention. The standard setting uses 14 periods, but the starting history affects the result. The available sources explain the method without supplying KBE’s prices or a dated KBE observation. Even a confirmed reading would describe the intensity of recent selling, not the earnings or book value each ETF share represents. [1](https://web.archive.org/web/20250113171716/https://www.investorsunderground.com/technical-indicators/rsi-relative-strength-index/#:~:text=Using%20the%20RSI%20Oscillator%3A%20The%20most%20commonly%20used%20setting,70%2F30%20overbought%2Foversold%20bands%20to%20generate%20a%20more%20robust%20reversion%2Freversal.) [2](https://web.archive.org/web/20190504143936/http://stockcharts.com:80/school/doku.php?id=chart_school:technical_indicators:relative_strength_index_rsi#:~:text=Note%3A%20The%20smoothing%20process%20affects%20RSI%20values.%20RS%20values,than%2014-day%20RSI%20for%20Duke%20Energy%20%28DUK%29%2C%20a%20utility.)

To verify positioning, compare each manager’s KBE share count across the two relevant quarter-end filings; a rise in market value alone would not establish a larger stake. The supplied material concerns RSI, not holdings, and contains neither comparison. Even if both increases are confirmed, they would show greater pre-selloff exposure, not a shared valuation thesis about Renasant or Trustmark. Dated trades would be needed to locate buying during the dip, and timing alone would not establish motive. [3](https://en.wikipedia.org/w/index.php?oldid=1292427879)

## What would change the view

The base case is to treat the selloff as a reason to investigate, not to buy on valuation. The strongest alternative is that bank prices fell while sustainable earnings and tangible book value held up. Test that at Renasant and Trustmark by comparing March price-to-tangible-book multiples with peers and with the banks’ own histories, then checking whether deposit costs, credit losses and returns on tangible equity justify the discounts. No such figures are supplied. Resilient returns at discounted prices would support the value case; extending it to KBE would require similar evidence across its weighted holdings. A price bounce alone would not settle it. [4](https://web.archive.org/web/20190504143936/http://stockcharts.com:80/school/doku.php?id=chart_school:technical_indicators:relative_strength_index_rsi#:~:text=RSI%20is%20considered%20overbought%20when%20above%2070%20and%20oversold,70%20and%20bottomed%20soon%20after%20the%20stock%20reached%2030.)

## Sources

1. [Relative Strength Index (RSI) Definition](https://web.archive.org/web/20250113171716/https://www.investorsunderground.com/technical-indicators/rsi-relative-strength-index/#:~:text=Using%20the%20RSI%20Oscillator%3A%20The%20most%20commonly%20used%20setting,70%2F30%20overbought%2Foversold%20bands%20to%20generate%20a%20more%20robust%20reversion%2Freversal.), available by 2025-01-13.
2. [Relative Strength Index (RSI) ChartSchool](https://web.archive.org/web/20190504143936/http://stockcharts.com:80/school/doku.php?id=chart_school:technical_indicators:relative_strength_index_rsi#:~:text=Note%3A%20The%20smoothing%20process%20affects%20RSI%20values.%20RS%20values,than%2014-day%20RSI%20for%20Duke%20Energy%20%28DUK%29%2C%20a%20utility.), available by 2019-05-04.
3. [Relative strength index](https://en.wikipedia.org/w/index.php?oldid=1292427879), available by 2025-05-26.
4. [Relative Strength Index (RSI) ChartSchool](https://web.archive.org/web/20190504143936/http://stockcharts.com:80/school/doku.php?id=chart_school:technical_indicators:relative_strength_index_rsi#:~:text=RSI%20is%20considered%20overbought%20when%20above%2070%20and%20oversold,70%20and%20bottomed%20soon%20after%20the%20stock%20reached%2030.), available by 2019-05-04.
