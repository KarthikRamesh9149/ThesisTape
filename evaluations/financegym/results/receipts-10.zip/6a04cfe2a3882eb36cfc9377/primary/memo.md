# Investment research memo

As of 2025-07-21

**Research question**
What structural or macroeconomic factors catalyzed the substantial institutional accumulation of the iShares MSCI Brazil ETF (EWZ) by firms like Raymond James and FMR LLC during late 2024, and to what extent did these inflows contribute to EWZ’s 17% outperformance against the SPY in early 2025?

Some parts of the question could not be established from eligible evidence.

## Evidence

Brazilian monetary tightening was relevant during the quarter, but its implications for buyers cut both ways. A June retrospective dates the hiking cycle to the preceding September. A buyer expecting tighter policy to stabilize the real could anticipate stronger dollar returns on Brazilian equities; higher borrowing costs and more attractive local fixed-income yields argue against that trade. The June Selic decision was not information buyers had in December. Without dated valuations, exchange rates or manager commentary, neither a bargain-price thesis nor a currency thesis is an established motive. [1](https://web.archive.org/web/20250720104511/https://g1.globo.com/economia/noticia/2025/06/18/selic-15percent.ghtml#:~:text=A%20maior%20parte%20dos%20analistas%2C%20segundo%20pesquisa%20conduzida%20pelo,e%20o%20presidente%2C%20Gabriel%20Gal%C3%ADpolo%2C%20votaram%20no%20mesmo%20sentido.) [2](https://web.archive.org/web/20250720104511/https://g1.globo.com/economia/noticia/2025/06/18/selic-15percent.ghtml#:~:text=O%20Copom%20%C3%A9%20formado%20pelo%20presidente%20do%20Banco%20Central,juros%20dos%20empr%C3%A9stimos%2C%20dos%20financiamentos%20e%20das%20aplica%C3%A7%C3%B5es%20financeiras.) [3](https://web.archive.org/web/20250720104511/https://g1.globo.com/economia/noticia/2025/06/18/selic-15percent.ghtml#:~:text=Por%20Thiago%20Resende%2C%20TV%20Globo%20%E2%80%94%20Bras%C3%ADlia%2018%2F06%2F2025%2018h33,juros%20e%20elevou%20a%20Selic%20para%2015%25%20ao%20ano.)

The Raymond James figure covers firmwide client assets, not an EWZ position, and there is no comparable FMR holdings record here. For each manager, match the EWZ share count in its September and December quarter-end SEC holdings tables, checking amendments and which affiliates each filing covers. A higher market value alone would not show buying. Even a higher share count would establish a larger reported position, not why it changed: rebalancing client portfolios is an alternative to a discretionary bet on Brazil. [4](https://en.wikipedia.org/w/index.php?oldid=1299686656)

## What would change the view

The base case to test is that any lead reflects the dollar value of EWZ’s underlying portfolio relative to SPY, rather than buying pressure on ETF shares. A manager can buy existing shares from another holder without money entering the fund, and arbitrage normally keeps the ETF close to net asset value. Compare EWZ’s market-price return with its NAV return and separate local equity performance from the real’s movement. The strongest flow-based alternative is that sustained net creations drove demand for the underlying basket. Look for dated net creations preceding abnormal basket gains after accounting for currency and sector returns; a widening ETF premium alone would point instead to pressure on the ETF price. Without those series and a credible comparison for how the basket would have traded absent creations, concurrent inflows and gains would not quantify causation. [5](https://en.wikipedia.org/w/index.php?oldid=1301527501)

## Sources

1. [Banco Central eleva Selic para 15% ao ano, maior patamar desde 2006 | Economia | G1](https://web.archive.org/web/20250720104511/https://g1.globo.com/economia/noticia/2025/06/18/selic-15percent.ghtml#:~:text=A%20maior%20parte%20dos%20analistas%2C%20segundo%20pesquisa%20conduzida%20pelo,e%20o%20presidente%2C%20Gabriel%20Gal%C3%ADpolo%2C%20votaram%20no%20mesmo%20sentido.), available by 2025-07-20.
2. [Banco Central eleva Selic para 15% ao ano, maior patamar desde 2006 | Economia | G1](https://web.archive.org/web/20250720104511/https://g1.globo.com/economia/noticia/2025/06/18/selic-15percent.ghtml#:~:text=O%20Copom%20%C3%A9%20formado%20pelo%20presidente%20do%20Banco%20Central,juros%20dos%20empr%C3%A9stimos%2C%20dos%20financiamentos%20e%20das%20aplica%C3%A7%C3%B5es%20financeiras.), available by 2025-07-20.
3. [Banco Central eleva Selic para 15% ao ano, maior patamar desde 2006 | Economia | G1](https://web.archive.org/web/20250720104511/https://g1.globo.com/economia/noticia/2025/06/18/selic-15percent.ghtml#:~:text=Por%20Thiago%20Resende%2C%20TV%20Globo%20%E2%80%94%20Bras%C3%ADlia%2018%2F06%2F2025%2018h33,juros%20e%20elevou%20a%20Selic%20para%2015%25%20ao%20ano.), available by 2025-07-20.
4. [Raymond James Financial](https://en.wikipedia.org/w/index.php?oldid=1299686656), available by 2025-07-09.
5. [Exchange-traded fund](https://en.wikipedia.org/w/index.php?oldid=1301527501), available by 2025-07-20.
