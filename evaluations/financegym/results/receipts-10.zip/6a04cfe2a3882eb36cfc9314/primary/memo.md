# Investment research memo

As of 2025-05-27

**Research question**
Given Cantor Fitzgerald's May 2025 decision to lower their price objective for PTC Therapeutics after months of bullishness, what is the risk-adjusted outlook for Translarna’s regulatory resubmission and its impact on PTCT’s valuation relative to the previous $113.00 target?

Some parts of the question could not be established from eligible evidence.

## Evidence

The regulatory evidence supports uncertainty, not a change in US approval odds. Translarna’s historical European authorization shows a regulator saw grounds for market access, but it also required a confirmatory trial. A reported false positive in an early assay warrants caution about that assay; it is not a clinical trial result or an FDA judgment. Neither source establishes the status of the US resubmission or how the FDA views its evidence. [1](https://en.wikipedia.org/w/index.php?oldid=1279188920)

## Outlook

The base case is to treat US Translarna sales as contingent on approval and not revise their probability weight solely because of the reported target cut. PTCT’s equity value also reflects assets such as its Huntington’s disease licensing deal. A change in expected milestone proceeds could therefore move the stock target without changing Translarna’s approval odds. That is a competing explanation, not a claim about Cantor’s model. [2](https://en.wikipedia.org/w/index.php?oldid=1261963545)

## What would change the view

The strongest regulatory alternative is that Cantor explicitly lowered its US approval assumption over doubts about confirmatory efficacy. The test is a dated Cantor note giving the revised objective and identifying that assumption as a reason for the cut. That would establish direction; quantifying the share of the cut would require Cantor’s per-share impact or comparable before-and-after model inputs. FDA feedback on the resubmission would inform the investment outlook, but would not by itself establish Cantor’s rationale. [1](https://en.wikipedia.org/w/index.php?oldid=1279188920)

## Sources

1. [Ataluren](https://en.wikipedia.org/w/index.php?oldid=1279188920), available by 2025-03-07.
2. [PTC Therapeutics](https://en.wikipedia.org/w/index.php?oldid=1261963545), available by 2024-12-08.
