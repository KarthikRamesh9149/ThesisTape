# Investment research memo

As of 2025-08-20

**Research question**
Given Scotiabank’s persistent bearish conviction on USD/JPY throughout mid-2025, how does the repeated consolidation around the 147.30 pivot level influence the probability of a range break toward the bank's 142.00 target, and what fundamental drivers justify their divergence from the 146.50–148.50 support-resistance bands?

Some parts of the question could not be established from eligible evidence.

## Answer

As of 2025-08-20, range trading is the better interpretation. Taking the USD/JPY levels and repeated consolidation as unverified question premises, a return to the pivot shows that the pair is still trading inside the proposed band, not that sellers are overcoming its floor. That does not materially strengthen the case for a break toward the lower target attributed to Scotiabank. Reuters reports falling US yields, but its excerpt supplies no USD/JPY price history from which to estimate a change in breakout probability. [1](https://web.archive.org/web/20250813162621/https://www.reuters.com/world/china/global-markets-wrapup-6-graphic-2025-08-12/#:~:text=S%26P%20500%2C%20Nasdaq%20reach%20new%20record%20levels%20Short-term%20Treasury,gilts%20under%20pressure%20as%20wage%20data%20signals%20inflation%20pain)

## Outlook

The strongest bearish alternative is a sustained narrowing of the US yield advantage over Japan. Reuters reports that short-term Treasury yields fell as investors increased bets on Fed cuts; the yield decline was observed, but the cuts were expectations, not policy actions. If US yields keep falling relative to comparable Japanese yields, holding dollars becomes less attractive and the range floor more vulnerable. If Japanese yields fall in step, that mechanism weakens. The evidence establishes neither a current Bank of Japan policy shift nor Scotiabank’s own rationale. [1](https://web.archive.org/web/20250813162621/https://www.reuters.com/world/china/global-markets-wrapup-6-graphic-2025-08-12/#:~:text=S%26P%20500%2C%20Nasdaq%20reach%20new%20record%20levels%20Short-term%20Treasury,gilts%20under%20pressure%20as%20wage%20data%20signals%20inflation%20pain)

## What would change the view

Watch the proposed floor rather than count returns to the pivot. A sustained move below support followed by a failed attempt to regain it would favor the bearish interpretation, especially if the US–Japan yield gap were narrowing at the same time. A quick recovery into the band would instead favor continued range trading. Even a confirmed break would establish direction, not the distance to the target attributed to Scotiabank; verifying that destination and its horizon still requires the bank’s dated forecast. [2](https://web.archive.org/web/20200725091321/https://www.scotiabank.com/ca/en/0,,476,00.html#:~:text=Scotiabank%20Commodity%20Price%20Index%20Scotiabank%27s%20Forecast%20Tables%20Scotiabank%27s%20Global%20Outlook)

## Sources

1. [Stocks hit fresh record high but US dollar weakens as Fed rate cut expectations gain momentum | Reuters](https://web.archive.org/web/20250813162621/https://www.reuters.com/world/china/global-markets-wrapup-6-graphic-2025-08-12/#:~:text=S%26P%20500%2C%20Nasdaq%20reach%20new%20record%20levels%20Short-term%20Treasury,gilts%20under%20pressure%20as%20wage%20data%20signals%20inflation%20pain), available by 2025-08-13.
2. [The Scotiabank Story | Scotiabank](https://web.archive.org/web/20200725091321/https://www.scotiabank.com/ca/en/0,,476,00.html#:~:text=Scotiabank%20Commodity%20Price%20Index%20Scotiabank%27s%20Forecast%20Tables%20Scotiabank%27s%20Global%20Outlook), available by 2020-07-25.
