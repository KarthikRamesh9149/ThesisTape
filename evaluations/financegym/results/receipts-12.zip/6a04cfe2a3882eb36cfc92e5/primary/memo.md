# Investment research memo

As of 2025-04-23

**Research question**
Given the Bank of Canada's April 2025 decision to pause its easing cycle amid an inflation rebound to 2.6% and looming trade-war-induced recession risks, how is the shift from a dovish stance impacting CAD valuation and mid-term monetary policy expectations?

Some parts of the question could not be established from eligible evidence.

## Answer

As of 2025-04-23, the Bank of Canada’s April hold at 2.75% looks more like a delay in easing than a hawkish turn. Forgoing an immediate cut could support CAD if investors had priced one in. But the available evidence does not show that investors reduced expected Canadian cuts relative to Federal Reserve cuts, or establish the size of any currency response. The Bank attributed CAD’s recent appreciation to broad US dollar weakness, not to its rate decision. [1](https://web.archive.org/web/20250423234258/https://www.bankofcanada.ca/2025/04/fad-press-release-2025-04-16/#:~:text=The%20Bank%20of%20Canada%20today%20maintained%20its%20target%20for,of%20the%20shift%20in%20US%20trade%20policy%20are%20unprecedented.) [2](https://web.archive.org/web/20250423234258/https://www.bankofcanada.ca/2025/04/fad-press-release-2025-04-16/#:~:text=Global%20economic%20growth%20was%20solid%20in%20late%202024%20and,hiring.%20Wage%20growth%20continues%20to%20show%20signs%20of%20moderation.)

## Outlook

My base case is delayed cuts, not an end to easing: if hiring and spending continue to weaken while firms pass on little of their tariff costs, the case for resuming cuts strengthens. The strongest alternative is a longer hold even as growth falls. In the Bank’s broad trade-war scenario, recession and inflation above 3% next year coexist. Persistent price increases across goods and rising longer-term inflation expectations would favour that alternative; recession risk alone does not settle the rate outlook. [2](https://web.archive.org/web/20250423234258/https://www.bankofcanada.ca/2025/04/fad-press-release-2025-04-16/#:~:text=Global%20economic%20growth%20was%20solid%20in%20late%202024%20and,hiring.%20Wage%20growth%20continues%20to%20show%20signs%20of%20moderation.) [3](https://web.archive.org/web/20250423234258/https://www.bankofcanada.ca/2025/04/fad-press-release-2025-04-16/#:~:text=Inflation%20was%202.3%25%20in%20March%2C%20lower%20than%20in%20February,economic%20growth%20while%20ensuring%20that%20inflation%20remains%20well%20controlled.) [1](https://web.archive.org/web/20250423234258/https://www.bankofcanada.ca/2025/04/fad-press-release-2025-04-16/#:~:text=The%20Bank%20of%20Canada%20today%20maintained%20its%20target%20for,of%20the%20shift%20in%20US%20trade%20policy%20are%20unprecedented.)

## What would change the view

Compare Canadian and US overnight-indexed swap rates for the same future dates immediately before and after the announcement. If expected Canadian rates rose relative to US rates well beyond the next meeting and CAD also gained against non-US currencies, that would support a lasting policy-driven revaluation. A shift confined to the next meeting would instead indicate a timing change. The available evidence contains neither those rate curves nor announcement-window currency moves, so the Bank’s account of earlier US dollar weakness cannot resolve the event itself. [2](https://web.archive.org/web/20250423234258/https://www.bankofcanada.ca/2025/04/fad-press-release-2025-04-16/#:~:text=Global%20economic%20growth%20was%20solid%20in%20late%202024%20and,hiring.%20Wage%20growth%20continues%20to%20show%20signs%20of%20moderation.)

## Sources

1. [Bank of Canada holds policy rate at 2¾% - Bank of Canada](https://web.archive.org/web/20250423234258/https://www.bankofcanada.ca/2025/04/fad-press-release-2025-04-16/#:~:text=The%20Bank%20of%20Canada%20today%20maintained%20its%20target%20for,of%20the%20shift%20in%20US%20trade%20policy%20are%20unprecedented.), available by 2025-04-23.
2. [Bank of Canada holds policy rate at 2¾% - Bank of Canada](https://web.archive.org/web/20250423234258/https://www.bankofcanada.ca/2025/04/fad-press-release-2025-04-16/#:~:text=Global%20economic%20growth%20was%20solid%20in%20late%202024%20and,hiring.%20Wage%20growth%20continues%20to%20show%20signs%20of%20moderation.), available by 2025-04-23.
3. [Bank of Canada holds policy rate at 2¾% - Bank of Canada](https://web.archive.org/web/20250423234258/https://www.bankofcanada.ca/2025/04/fad-press-release-2025-04-16/#:~:text=Inflation%20was%202.3%25%20in%20March%2C%20lower%20than%20in%20February,economic%20growth%20while%20ensuring%20that%20inflation%20remains%20well%20controlled.), available by 2025-04-23.
