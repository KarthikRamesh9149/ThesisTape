# Investment research memo

As of 2025-08-05

**Research question**
Given the Q2 2025 upward revision of Skyrizi's sales guidance to $17.1 billion and the successful Phase 3 topline results for upadacitinib in alopecia areata, how effectively is AbbVie’s newer immunology portfolio positioning the company to offset Humira's revenue erosion through 2026?

Some parts of the question could not be established from eligible evidence.

## Outlook

Use the last full fiscal year before U.S. biosimilar entry in January 2023 as the common baseline. For each of 2025 and 2026, the offset holds if the increase in combined annual global Skyrizi and Rinvoq net revenue equals or exceeds the decline in annual global Humira net revenue from that same baseline. The quarterly figures support the direction of the base case, but the evidence supplies neither the annual baseline sales nor a complete set of annual product forecasts to measure the surplus or shortfall. [1](https://web.archive.org/web/20250614084558/https://www.truveta.com/blog/research/research-insights/humira-and-biosimilars-2024/#:~:text=Market%20exclusively%20for%20Humira%20ended%20in%20January%202023%2C%20when,approved%20biosimilars%20before%20and%20after%20the%20CVS%20formulary%20change.) [2](https://web.archive.org/web/20250731142530/https://www.prnewswire.com/news-releases/abbvie-reports-second-quarter-2025-financial-results-302518052.html#:~:text=Delivers%20Second-Quarter%20Net%20Revenues%20of%20%2415.423%20Billion%2C%20an%20Increase,Global%20Ubrelvy%20and%20Qulipta%20Net%20Revenues%20Were%20%24605%20Million)

Assume no Rinvoq alopecia areata sales in 2026. The positive pivotal readout supports a possible future indication, not an approval or launch. There is a commercial basis for growth without it: Rinvoq already has approved uses across rheumatology, gastroenterology and dermatology, and Skyrizi is approved for ulcerative colitis. Full replacement is therefore plausible without alopecia sales, but no forecast for Rinvoq excluding that indication establishes that the combined gain clears the threshold. [3](https://web.archive.org/web/20250804145945/https://news.abbvie.com/2025-07-31-AbbVie-Reports-Second-Quarter-2025-Financial-Results#:~:text=Note%3A%20%22Operational%22%20comparisons%20are%20presented%20at%20constant%20currency%20rates,no%20new%20safety%20signals%20were%20identified%20in%20this%20study.) [4](https://en.wikipedia.org/w/index.php?oldid=1292970723)

## Sources

1. [Exploring switching trends from Humira to approved biosimilars](https://web.archive.org/web/20250614084558/https://www.truveta.com/blog/research/research-insights/humira-and-biosimilars-2024/#:~:text=Market%20exclusively%20for%20Humira%20ended%20in%20January%202023%2C%20when,approved%20biosimilars%20before%20and%20after%20the%20CVS%20formulary%20change.), available by 2025-06-14.
2. [AbbVie Reports Second-Quarter 2025 Financial Results](https://web.archive.org/web/20250731142530/https://www.prnewswire.com/news-releases/abbvie-reports-second-quarter-2025-financial-results-302518052.html#:~:text=Delivers%20Second-Quarter%20Net%20Revenues%20of%20%2415.423%20Billion%2C%20an%20Increase,Global%20Ubrelvy%20and%20Qulipta%20Net%20Revenues%20Were%20%24605%20Million), available by 2025-07-31.
3. [AbbVie Reports Second-Quarter 2025 Financial Results - Jul 31, 2025](https://web.archive.org/web/20250804145945/https://news.abbvie.com/2025-07-31-AbbVie-Reports-Second-Quarter-2025-Financial-Results#:~:text=Note%3A%20%22Operational%22%20comparisons%20are%20presented%20at%20constant%20currency%20rates,no%20new%20safety%20signals%20were%20identified%20in%20this%20study.), available by 2025-08-04.
4. [Risankizumab](https://en.wikipedia.org/w/index.php?oldid=1292970723), available by 2025-05-29.
