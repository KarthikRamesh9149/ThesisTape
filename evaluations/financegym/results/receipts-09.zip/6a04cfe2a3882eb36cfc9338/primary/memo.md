# Investment research memo

As of 2025-10-28

**Research question**
Given JD Vance’s repeated criticisms of Jerome Powell’s 'monetary malpractice' and handling of trade policy, how would a transition to Kevin Hassett as Federal Reserve Chair in 2026 likely impact market expectations for interest rate trajectory and central bank independence?

## Answer

As of 2025-10-28, if President Trump nominated Kevin Hassett to succeed Jerome Powell in May 2026 and the Senate confirmed him, my base case would be a modest shift toward earlier cuts after the handover and somewhat greater investor concern about White House influence—not a new near-term cutting cycle or a presumption that the FOMC would follow presidential direction. Hassett was already a public contender. The relevant comparison is with the mix of successors investors expected, not with Powell staying indefinitely. The available evidence does not measure that mix, so the direction is a judgment and the scale is qualitative. [1](https://en.wikipedia.org/w/index.php?oldid=1319091686) [2](https://en.wikipedia.org/w/index.php?oldid=1311720314)

## Evidence

Hassett’s candidacy is better established than the remarks attributed to JD Vance. The earlier report made Hassett’s consideration contingent on Trump winning reelection; the October account says Treasury Secretary Scott Bessent confirmed him as a finalist, not as the nominee or favorite. No supplied passage documents Vance using “monetary malpractice,” repeating that charge, or criticizing Powell’s handling of trade policy. Those are unverified question premises. Even a verified criticism would establish Vance’s position, not Hassett’s preferred rate path. [1](https://en.wikipedia.org/w/index.php?oldid=1319091686)

## Outlook

The case for earlier cuts turns on how Hassett would interpret tariff-related price increases. His defense of Trump’s tariff threats might lead traders to expect him to look through a temporary price rise and favor easing sooner if employment weakened. But defending a trade measure is not a commitment to ease through persistent inflation. Only an unexpected difference between Hassett and the other contenders should move the expected rate path; confirmation should add little if nomination has already settled the succession in investors’ eyes. [1](https://en.wikipedia.org/w/index.php?oldid=1319091686)

Hassett’s White House ties make perceived political influence a more plausible concern than an actual loss of FOMC independence. A chair can steer debate and communicate a consensus, but the rate decision belongs to a committee of governors and regional bank presidents. Hassett’s earlier work as a Fed economist also supports a competing interpretation: he could advocate a cut on economic grounds while resisting pressure to promise one. A lower expected policy rate alone would not distinguish those explanations. [1](https://en.wikipedia.org/w/index.php?oldid=1319091686) [2](https://en.wikipedia.org/w/index.php?oldid=1311720314)

## What would change the view

The strongest alternative is little repricing on either dimension: investors may already expect a successor with similar views. Test the base case around unexpected nomination news or Senate testimony by comparing meeting-dated rate pricing before and after the handover, excluding windows with major economic releases. A decline concentrated in post-handover rates would support the timing call. A pledge to cut regardless of inflation, accompanied by higher longer-term inflation compensation, would strengthen the independence concern. Neither market move alone would prove political control; unchanged pricing after genuinely surprising news would favor the alternative. [1](https://en.wikipedia.org/w/index.php?oldid=1319091686) [3](https://en.wikipedia.org/w/index.php?oldid=1310327202) [2](https://en.wikipedia.org/w/index.php?oldid=1311720314)

## Sources

1. [Kevin Hassett](https://en.wikipedia.org/w/index.php?oldid=1319091686), available by 2025-10-27.
2. [Federal Open Market Committee](https://en.wikipedia.org/w/index.php?oldid=1311720314), available by 2025-09-16.
3. [Chair of the Federal Reserve](https://en.wikipedia.org/w/index.php?oldid=1310327202), available by 2025-09-08.
