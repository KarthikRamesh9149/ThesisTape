# Investment research memo

As of 2025-04-23

**Research question**
Can Oliver Blume’s restructuring and cost-cutting initiatives in Germany sufficiently offset the margin compression caused by Volkswagen Group’s (VWAGY) persistent market share loss and 9.5% sales decline in China, given the intensifying competition from local new energy vehicle (NEV) manufacturers?

## Answer

As of 2025-04-23, I would not count on Oliver Blume’s German restructuring to offset Volkswagen Group’s near-term China earnings pressure. German savings can cushion Group operating margin, but the announced €10 billion cost-cutting plan is not a measure of net German savings already reaching earnings. Nor would German savings restore profit at the equity-accounted Chinese joint ventures. The investment case is for a partial cushion, not a demonstrated full offset. [1](https://en.wikipedia.org/w/index.php?oldid=1284609502) [2](https://en.wikipedia.org/w/index.php?oldid=1285398123)

## Evidence

For **Group operating margin**, the right comparison is German expense reductions actually recognized, less restructuring charges in the same period, against China-related operating losses inside the consolidated business. The cost plan announced in 2023 and plant proposals reported in October 2024 are different in scope and timing; neither establishes completed closures or a schedule of net savings. The reported 64% quarterly profit drop is not a Group operating-margin change or a China-only loss. Without a margin breakdown, it cannot serve as the amount Germany needs to offset. [1](https://en.wikipedia.org/w/index.php?oldid=1284609502)

For **equity-accounted Chinese joint ventures**, VW’s share of earnings sits outside Group operating profit. A venture can defend deliveries with discounts yet earn less per car; domestic new energy vehicle competition therefore threatens earnings even if unit share stabilizes. German savings could counterbalance weaker venture income in Group pretax profit, but cannot repair the ventures’ margins. The evidence identifies the local venture structure and the discounting, not the change in VW’s equity income needed to quantify that comparison. [3](https://en.wikipedia.org/w/index.php?oldid=1285808533) [2](https://en.wikipedia.org/w/index.php?oldid=1285398123)

The percentage decline in Volkswagen’s China sales stated in the question is an **unverified question premise**. The evidence reports lower China sales but does not establish whether the cited rate measures deliveries or revenue, which period it covers, or whether it applies to the Volkswagen brand or the Group. Market share is a separate measure: VW’s China share did fall in 2023, but the 37 percent share reported for 2024 covers all foreign brands. It does not establish that VW’s own share continued to fall through 2025-04-23. Neither figure quantifies the earnings pressure that German savings would need to offset. [1](https://en.wikipedia.org/w/index.php?oldid=1284609502) [2](https://en.wikipedia.org/w/index.php?oldid=1285398123)

## What would change the view

The strongest upside case is that German savings arrive while better local products reduce the need for discounts, shrinking the earnings gap from both sides. VW’s Hefei investment and its aim to shorten development cycles by around 30% give that case a mechanism, not a realized return. I would revise the base case on two distinct signals: a same-period Group operating-profit breakdown showing German savings after charges exceeding consolidated China pressure, and separately reported Chinese venture earnings stabilizing alongside VW-specific share without deeper discounts. [3](https://en.wikipedia.org/w/index.php?oldid=1285808533) [2](https://en.wikipedia.org/w/index.php?oldid=1285398123)

## Sources

1. [Volkswagen Group](https://en.wikipedia.org/w/index.php?oldid=1284609502), available by 2025-04-08.
2. [Automotive industry in China](https://en.wikipedia.org/w/index.php?oldid=1285398123), available by 2025-04-13.
3. [Volkswagen Group China](https://en.wikipedia.org/w/index.php?oldid=1285808533), available by 2025-04-15.
