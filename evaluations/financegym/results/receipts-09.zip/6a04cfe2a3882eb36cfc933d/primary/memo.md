# Investment research memo

As of 2025-05-11

**Research question**
Given Apellis Pharmaceuticals' reported EPS of -$0.74 for Q1 2025 and its sNDA submission for EMPAVELI in rare kidney diseases, how will the company’s capital requirements and path to profitability evolve as it transitions from PNH commercialization to Phase 3 trials in FSGS and DGF?

## Answer

As of 2025-05-11, Apellis has not demonstrated that available cash and commercial receipts will fund its kidney program through operating break-even. I would retain external financing as a contingency, not call it likely: the evidence identifies existing pegcetacoplan indications and a late-stage kidney study, but establishes neither Apellis’s liquidity nor its share of future trial costs. The size and timing of any funding gap are therefore unknown. [1](https://en.wikipedia.org/w/index.php?oldid=1279327704) [2](https://web.archive.org/web/20250417033533/https://www.tga.gov.au/resources/prescription-medicines-registrations/syfovre-apellis-australia-pty-ltd#:~:text=SYFOVRE%20is%20indicated%20for%20the%20treatment%20of%20adult%20patients,cultures%2C%20and%20to%20all%20Elders%20both%20past%20and%20present.)

## Evidence

The renal indications supported by VALIANT are C3 glomerulopathy and primary immune complex–mediated membranoproliferative glomerulonephritis. That identifies the diseases studied, not the exact indications, patient population or status of the EMPAVELI sNDA described in the question. Verifying the submission requires a dated company or FDA filing notice; VALIANT is not evidence of a filing for FSGS or DGF. [1](https://en.wikipedia.org/w/index.php?oldid=1279327704)

Neither focal segmental glomerulosclerosis (FSGS) nor delayed graft function (DGF) can be treated as a confirmed new Apellis trial expense. VALIANT is the documented Phase 3 study; NOBLE studied recurrent disease in transplant recipients, not DGF. The passages do not verify whether the proposed FSGS or DGF trials have begun, who sponsors them or who ultimately pays. Assigning Apellis either the full cost or no cost would be speculative. [1](https://en.wikipedia.org/w/index.php?oldid=1279327704) [3](https://web.archive.org/web/20250203224513/https://pubmed.ncbi.nlm.nih.gov/39810766/#:~:text=Create%20a%20file%20for%20external%20citation%20management%20software%20Introduction%3A,by%20subcutaneous%20infusion%20plus%20standard-of-care%20%28SOC%29%20or%20SOC%20only.)

Apellis’s Q1 2025 EPS figure is an unverified question premise: the supplied evidence contains no quarterly income statement against which to check it. Even if confirmed, a loss per share would not measure operating cash use or establish how long Apellis can fund kidney development. A forecast based on PNH alone would also omit SYFOVRE’s geographic atrophy indication. The indication records identify both markets but do not quantify cash collected from either. [1](https://en.wikipedia.org/w/index.php?oldid=1279327704) [2](https://web.archive.org/web/20250417033533/https://www.tga.gov.au/resources/prescription-medicines-registrations/syfovre-apellis-australia-pty-ltd#:~:text=SYFOVRE%20is%20indicated%20for%20the%20treatment%20of%20adult%20patients,cultures%2C%20and%20to%20all%20Elders%20both%20past%20and%20present.)

## What would change the view

The financing test is whether unrestricted cash covers the largest cumulative cash shortfall before sustained operating break-even, while leaving enough liquidity to operate. Start with collections from existing products, give no base-case credit for renal sales before approval, and vary the unreimbursed trial spend rather than assuming it. Self-funding becomes credible if quarterly filings show the cash deficit narrowing fast enough and collaboration terms limit Apellis’s outlay. The strongest contrary case is that Apellis must pay substantial trial costs before commercial margins cover them. Dated trial records and cost-sharing terms, together with quarterly cash flow, debt payments and product margins, would distinguish those outcomes; clinical efficacy alone cannot. [1](https://en.wikipedia.org/w/index.php?oldid=1279327704) [2](https://web.archive.org/web/20250417033533/https://www.tga.gov.au/resources/prescription-medicines-registrations/syfovre-apellis-australia-pty-ltd#:~:text=SYFOVRE%20is%20indicated%20for%20the%20treatment%20of%20adult%20patients,cultures%2C%20and%20to%20all%20Elders%20both%20past%20and%20present.)

## Sources

1. [Pegcetacoplan](https://en.wikipedia.org/w/index.php?oldid=1279327704), available by 2025-03-07.
2. [SYFOVRE (Apellis Australia Pty Ltd) | Therapeutic Goods Administration (TGA)](https://web.archive.org/web/20250417033533/https://www.tga.gov.au/resources/prescription-medicines-registrations/syfovre-apellis-australia-pty-ltd#:~:text=SYFOVRE%20is%20indicated%20for%20the%20treatment%20of%20adult%20patients,cultures%2C%20and%20to%20all%20Elders%20both%20past%20and%20present.), available by 2025-04-17.
3. [Efficacy and Safety of Pegcetacoplan in Kidney Transplant Recipients With Recurrent Complement 3 Glomerulopathy or Primary Immune Complex Membranoproliferative Glomerulonephritis - PubMed](https://web.archive.org/web/20250203224513/https://pubmed.ncbi.nlm.nih.gov/39810766/#:~:text=Create%20a%20file%20for%20external%20citation%20management%20software%20Introduction%3A,by%20subcutaneous%20infusion%20plus%20standard-of-care%20%28SOC%29%20or%20SOC%20only.), available by 2025-02-03.
