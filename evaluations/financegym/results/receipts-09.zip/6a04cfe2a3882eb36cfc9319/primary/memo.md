# Investment research memo

As of 2025-07-09

**Research question**
Given Nabors Industries' (NBR) rising debt-to-equity ratio of 5.95 and successive earnings misses, how does the strategic acquisition of Parker Wellbore and the SANAD joint venture with Saudi Aramco impact the company's ability to de-lever and reverse its underperformance relative to Transocean and Patterson-UTI?

## Answer

As of 2025-07-09, neither Parker Wellbore nor SANAD has demonstrated enough cash available to Nabors to support a forecast of net debt reduction. Nabors bought Parker with 4.8 million shares of its own stock in March 2025; SANAD, its venture with Saudi Aramco, has operated since December 1, 2017. The acquisition preserved cash relative to a cash purchase, and the venture could distribute cash, but neither fact establishes debt repayment. Nor is there a verified shareholder-return gap versus Transocean or Patterson-UTI to close. [1](https://en.wikipedia.org/w/index.php?oldid=1299538419)

## Evidence

Parker gives Nabors a US downhole tubular rental business. The debt case depends on rental collections and realized cost savings exceeding fleet investment, working-capital needs and integration costs. The relevant measure is incremental free cash flow after those uses, not acquired revenue. The closing account supplies neither that cash flow nor an opening balance of acquired debt and cash against which to judge subsequent deleveraging. [1](https://en.wikipedia.org/w/index.php?oldid=1299538419)

SANAD is an existing source of potential cash, not a new catalyst simply because Aramco is large. For incremental parent debt capacity, count distributions Nabors receives above its prior run rate, net of new contributions. Cash retained to fund rigs or payable to the partner is not available to retire Nabors parent debt. The venture history does not disclose ownership economics, capital commitments or remittances; Aramco’s field count cannot substitute for them. [1](https://en.wikipedia.org/w/index.php?oldid=1299538419) [2](https://en.wikipedia.org/w/index.php?oldid=1298556005)

Successive earnings misses and peer-relative underperformance are separate unverified question premises. Test the former quarter by quarter against consensus recorded before each release, matching adjusted EPS to adjusted EPS or reported EPS to reported EPS. Test the latter with split-adjusted, dividend-reinvested returns for Nabors and each peer over identical start and end dates. Neither series is supplied. Even verified misses would not prove relative losses, and differences in offshore drilling and pressure-pumping exposure would complicate attributing any return gap to Nabors’ financing decisions. [3](https://en.wikipedia.org/w/index.php?oldid=1292087155) [4](https://en.wikipedia.org/w/index.php?oldid=1284457550)

Nabors’ debt-to-equity figure is an unverified premise from the question; the claim that it rose is also unverified. Recalculate the ratio at the last year-end before Parker closed and at the quarter-end following the March 2025 close, using current and long-term borrowings divided by book equity and stating whether equity includes noncontrolling interests. Neither dated balance sheet is supplied. Issuing 4.8 million shares to Parker owners diluted existing holders’ ownership and could lower the ratio by increasing equity without repaying debt. Conversely, losses could raise it without new borrowing. To test for actual deleveraging, compare borrowings less unrestricted cash on the same reporting basis, separating debt and cash acquired with Parker from subsequent borrowing, repayment and cash generation. [1](https://en.wikipedia.org/w/index.php?oldid=1299538419)

## What would change the view

The base case gives neither business credit for incremental debt paydown until cash is visible. The strongest upside case is that Parker converts rental earnings into cash while SANAD raises distributions without requiring offsetting capital. Look for recurring post-close free cash flow and net remittances that exceed other parent cash needs, followed by a sustained decline in net debt from the post-close balance sheet without fresh equity funding. That would support deleveraging; only a narrowing of a measured total-return deficit against each peer would support a shareholder turnaround. [1](https://en.wikipedia.org/w/index.php?oldid=1299538419)

## Sources

1. [Nabors Industries](https://en.wikipedia.org/w/index.php?oldid=1299538419), available by 2025-07-09.
2. [Saudi Aramco](https://en.wikipedia.org/w/index.php?oldid=1298556005), available by 2025-07-03.
3. [Transocean](https://en.wikipedia.org/w/index.php?oldid=1292087155), available by 2025-05-25.
4. [Patterson-UTI](https://en.wikipedia.org/w/index.php?oldid=1284457550), available by 2025-04-07.
