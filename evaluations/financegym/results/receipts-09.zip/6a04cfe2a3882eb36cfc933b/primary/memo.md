# Investment research memo

As of 2025-05-06

**Research question**
How should institutional portfolios balance traditional hedges like Gold against emerging digital assets like a Strategic Bitcoin Reserve, given the Federal Reserve's persistent difficulty in anchoring inflation at 2% and the projected fiscal pressures from the Trump administration's economic policies?

## Answer

As of 2025-05-06, the investment committee should retain gold as the core hedge and transfer none of its risk budget to Bitcoin. Gold’s long monetary history is a reason to keep it, not a promise that it will preserve purchasing power in every inflation shock. Bitcoin has not shown that it can replace gold when the rest of the portfolio is losing money. If the institution wants exposure to Bitcoin adoption, fund it separately as a speculative position, not as insurance. [1](https://en.wikipedia.org/w/index.php?oldid=1285183546) [2](https://en.wikipedia.org/w/index.php?oldid=1289006503)

## Evidence

The Federal Reserve pursues price stability and maximum employment; the investor needs assets it can sell to meet liabilities during a drawdown. A Treasury strategic reserve is a government holding, not a Fed monetary-policy instrument or an institutional allocation benchmark. Powell’s description of Bitcoin as a competitor for gold identifies a rival for investor demand, not an endorsement of equivalent downside protection. The available evidence does not establish that government holdings would put a floor under Bitcoin’s price. [2](https://en.wikipedia.org/w/index.php?oldid=1289006503) [3](https://web.archive.org/web/20250502112626/https://time.com/7275021/federal-reserve-chief-says-trump-tariffs-likely-to-raise-inflation/#:~:text=Federal%20Reserve%20Chief%20Says%20Trump%20Tariffs%20Likely%20to%20Raise,U.S.%20economy%2C%20Federal%20Reserve%20Chair%20Jerome%20Powell%20said%20Friday.)

The strongest case for a capped Bitcoin allocation is that a volatile asset can still diversify a portfolio if it holds up when other assets fall. A 2018 study found high volatility; a 2022 analysis found Bitcoin less volatile than some conventional assets during and after the 2020 crash. Those findings are compatible: one stress window can differ from a broader sample. Neither volatility ranking tells the committee how much cash a Bitcoin position would have preserved on the dates its own portfolio needed liquidity. [2](https://en.wikipedia.org/w/index.php?oldid=1289006503)

## Outlook

The base case is near-term price pressure and weaker growth, not a permanent rise in the inflation rate. The 10% import tariff effective April 5, 2025 gives Powell’s warning a concrete basis. If firms pass through a higher import cost once, prices can remain higher even after inflation subsides. Persistent failure to anchor inflation at target is an unverified question premise: the evidence supplies neither an inflation series nor a measure of expectations. Repeated, broad increases in core prices alongside rising longer-term expectations would favor persistent inflation over a temporary shock. [4](https://en.wikipedia.org/w/index.php?oldid=1289178317) [3](https://web.archive.org/web/20250502112626/https://time.com/7275021/federal-reserve-chief-says-trump-tariffs-likely-to-raise-inflation/#:~:text=Federal%20Reserve%20Chief%20Says%20Trump%20Tariffs%20Likely%20to%20Raise,U.S.%20economy%2C%20Federal%20Reserve%20Chair%20Jerome%20Powell%20said%20Friday.)

Wider federal budget deficits are also an unverified question premise. The tariff order addresses the goods trade deficit—imports exceeding exports—not federal spending exceeding receipts. Economists warned of larger deficits from the administration’s broader agenda, but that warning is not a budget estimate for the enacted tariffs. Customs receipts could narrow the fiscal gap; weaker income-tax collections or higher outlays could outweigh them. Compare total receipts and outlays with a pre-policy budget baseline before treating fiscal deterioration as a reason to change the hedge. [5](https://web.archive.org/web/20250506232932/https://www.whitehouse.gov/presidential-actions/2025/04/regulating-imports-with-a-reciprocal-tariff-to-rectify-trade-practices-that-contribute-to-large-and-persistent-annual-united-states-goods-trade-deficits/#:~:text=By%20the%20authority%20vested%20in%20me%20as%20President%20by,chains%3B%20and%20rendered%20our%20defense-industrial%20base%20dependent%20on%20foreign) [4](https://en.wikipedia.org/w/index.php?oldid=1289178317)

## What would change the view

Authorize a partial shift only if a portfolio with some Bitcoin in place of gold, tested at the same risk budget after custody and trading costs, repeatedly suffers smaller losses in both inflation surprises and equity selloffs while meeting the same cash calls. Until then, cap any separate, unlevered Bitcoin position at the amount the institution can lose in full without impairing those payments. A price rally alone would not pass the test. Without portfolio holdings, liability dates or joint return histories, a precise allocation cap would be false precision. [2](https://en.wikipedia.org/w/index.php?oldid=1289006503) [1](https://en.wikipedia.org/w/index.php?oldid=1285183546)

## Sources

1. [Gold as an investment](https://en.wikipedia.org/w/index.php?oldid=1285183546), available by 2025-04-12.
2. [Bitcoin](https://en.wikipedia.org/w/index.php?oldid=1289006503), available by 2025-05-05.
3. [Federal Reserve Chief Says Trump Tariffs May Raise Inflation | TIME](https://web.archive.org/web/20250502112626/https://time.com/7275021/federal-reserve-chief-says-trump-tariffs-likely-to-raise-inflation/#:~:text=Federal%20Reserve%20Chief%20Says%20Trump%20Tariffs%20Likely%20to%20Raise,U.S.%20economy%2C%20Federal%20Reserve%20Chair%20Jerome%20Powell%20said%20Friday.), available by 2025-05-02.
4. [Tariffs in the second Trump administration](https://en.wikipedia.org/w/index.php?oldid=1289178317), available by 2025-05-06.
5. [Regulating Imports with a Reciprocal Tariff to Rectify Trade Practices that Contribute to Large and Persistent Annual United States Goods Trade Deficits – The White House](https://web.archive.org/web/20250506232932/https://www.whitehouse.gov/presidential-actions/2025/04/regulating-imports-with-a-reciprocal-tariff-to-rectify-trade-practices-that-contribute-to-large-and-persistent-annual-united-states-goods-trade-deficits/#:~:text=By%20the%20authority%20vested%20in%20me%20as%20President%20by,chains%3B%20and%20rendered%20our%20defense-industrial%20base%20dependent%20on%20foreign), available by 2025-05-06.
