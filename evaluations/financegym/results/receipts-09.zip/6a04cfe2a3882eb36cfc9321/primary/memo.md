# Investment research memo

As of 2025-03-16

**Research question**
Given Robert Mionis's sale of over 568,000 Celestica shares totaling approximately $71 million between late 2024 and February 2025, how does this insider activity align with the accelerating revenue concentration and growth performance within the company's Connectivity & Cloud Solutions (CCS) segment?

Some parts of the question could not be established from eligible evidence.

## Evidence

Verification requires Mionis’s insider filings: reconcile distinct sale dates, quantities, execution prices and currencies to the reported proceeds, separating sales from award vesting or tax withholding. Then compare the shares sold with his pre-sale holdings and check for a prearranged plan. His appointment is documented, but tenure alone tells us neither how much of his stake he retained nor whether the trades were discretionary. [1](https://en.wikipedia.org/w/index.php?oldid=1267105391)

A rising CCS share of Celestica revenue would make company results more sensitive to CCS performance; it would not, by itself, demonstrate accelerating CCS growth or dependence on an individual customer. CCS can gain share merely because the rest of Celestica slows. Test acceleration by comparing CCS year-over-year revenue growth across successive quarters, test mix by dividing CCS revenue by consolidated revenue in each quarter, and assess buyer dependence separately from major-customer disclosures. The available corporate history supplies none of those operating data, so the claimed acceleration remains an unverified question premise. [1](https://en.wikipedia.org/w/index.php?oldid=1267105391)

## What would change the view

The base case is to leave the CCS outlook unchanged on the sale report alone. A documented sale plan, substantial retained exposure and sustained CCS growth would favor routine monetization. The strongest bearish alternative would be an unusually large discretionary reduction in Mionis’s stake followed by an order cut at a major CCS customer and a slowdown in segment revenue. That combination would challenge the operating case without proving what Mionis knew when he sold. The leadership record establishes his role, not any of those signals. [1](https://en.wikipedia.org/w/index.php?oldid=1267105391)

## Sources

1. [Celestica](https://en.wikipedia.org/w/index.php?oldid=1267105391), available by 2025-01-03.
