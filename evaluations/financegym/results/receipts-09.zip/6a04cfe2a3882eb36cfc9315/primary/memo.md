# Investment research memo

As of 2025-04-23

**Research question**
Given Fitch Ratings' repeated downward revisions to 2025 U.S. GDP growth forecasts and Olu Sonola's analysis of tariff-driven volatility, how should institutional fixed-income investors assess the sustainability of the U.S. AA+ sovereign credit rating and the potential for a negative outlook shift in late 2025?

## Answer

As of 2025-04-23, institutional fixed-income investors should retain U.S. sovereign exposure at its current weight and monitor for a possible Fitch negative outlook in late 2025. The Fed cut its growth forecast from 2.1% to 1.7%, but a weaker growth forecast does not establish that debt will rise materially faster or that interest will consume materially more revenue. A negative outlook would flag greater risk of a future downgrade; it would not itself lower the rating. [1](https://en.wikipedia.org/w/index.php?oldid=1287066496)

## Evidence

Fitch’s AA+ baseline, its repeated forecast cuts and Olu Sonola’s interpretation of tariff volatility are unverified question premises. The available March forecasts support the direction of the growth concern, not its size relative to Fitch’s baseline: the OECD still projected 2.2% growth in 2025, with its weaker 1.6% projection applying to 2026. Neither forecast is Fitch’s, and the evidence contains no Sonola statement or Fitch fiscal projection against which to measure the shock. [1](https://en.wikipedia.org/w/index.php?oldid=1287066496)

The auto tariffs illustrate why gross customs receipts and net fiscal gains can differ. After an initial delay for qualifying vehicles, the 25% imported-car tariff took effect on April 3. The White House projected higher tax revenue, while Stellantis announced temporary closures and layoffs affecting 900 American employees. These are not contradictory: customs collections can rise while lost wages and profits erode other tax receipts. A company announcement shows a channel for losses, not their economy-wide scale. [1](https://en.wikipedia.org/w/index.php?oldid=1287066496)

## Outlook

The base case is that the rating holds through late 2025: weaker real growth need not cause a lasting deterioration in debt affordability. The dollar’s reserve role supports demand for dollar assets, but does not cap Treasury refinancing costs. The strongest alternative is persistent weakness in tax receipts alongside costly refinancing. The Fed raised its inflation expectations even as it cut its growth forecast, so investors should not assume slower growth will bring enough interest relief to offset lost revenue. [2](https://en.wikipedia.org/w/index.php?oldid=1287028422) [1](https://en.wikipedia.org/w/index.php?oldid=1287066496)

## What would change the view

Obtain Fitch’s fiscal baseline and compare successive fiscal releases and projections on the same government coverage and horizon. Track the primary deficit after actual customs receipts, debt relative to nominal GDP, and interest expense relative to revenue as debt rolls over. Reduce exposure if a persistent primary shortfall puts debt on a materially steeper path than Fitch assumed and refinancing pushes the interest share above baseline without a credible fiscal offset. That combination would strengthen the case for a negative outlook before a downgrade. Until then, a gross tariff-revenue projection is no substitute for collections, and the available evidence cannot establish the size of a fiscal gap or the timing of Fitch action. [1](https://en.wikipedia.org/w/index.php?oldid=1287066496)

## Sources

1. [Tariffs in the second Trump administration](https://en.wikipedia.org/w/index.php?oldid=1287066496), available by 2025-04-23.
2. [United States dollar](https://en.wikipedia.org/w/index.php?oldid=1287028422), available by 2025-04-23.
