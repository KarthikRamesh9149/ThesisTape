# Investment research memo

As of 2025-06-05

**Research question**
Given MSCI's sustained 52-week underperformance relative to the S&P 500 and XLF, how should investors interpret the divergence between heavy institutional selling by firms like BlackRock and Capital Research versus the aggressive insider buying and strategic expansion into private assets via the Intapp and Moody's partnerships?

Some parts of the question could not be established from eligible evidence.

## Evidence

The relative-return check is inconclusive. XLF’s quoted gain is measured from a low on 7 Dec 2023, not over the trailing period ending 2025-06-05. The S&P 500 figure is a long-run compound return including dividends, and no comparable MSCI stock return is supplied. Compare dividend-reinvested returns for MSCI, the broad index and XLF over identical dates. Even a verified end-to-end shortfall would not show it was sustained without checking the intervening relative performance. [1](https://web.archive.org/web/20241204095631/https://www.intelligentinvestor.com.au/shares/nyse-xlf/financial-select-sector-spdr-fund#:~:text=Financial%20Select%20Sector%20SPDR%20Fund%27s%20%28XLF%29%2052-week%20high%20is,average%20trading%20volume%20of%209%2C864%2C252%20XLF%20shares%20per%20day.) [2](https://en.wikipedia.org/w/index.php?oldid=1293815072)

A decline in reported holdings is not a discretionary sell call. BlackRock reports for operating subsidiaries and disclaims discretion at the parent. The filing excerpt identifies a holdings table but gives no MSCI share counts, and no comparable Capital Research positions are supplied. Compare shares, not market values, across quarter ends for the same reporting entities. Even a confirmed reduction could reflect client redemptions or index rebalancing; attributing it to a bearish view requires evidence from the manager. [3](https://web.archive.org/web/20241208193934/https://www.sec.gov/Archives/edgar/data/1364742/000108636424008417/xslForm13F_X02/primary_doc.xml#:~:text=Signature%2C%20Place%2C%20and%20Date%20of%20Signing%3A%20BlackRock%2C%20Inc.%20is,of%20all%20such%20subsidiaries.%20Report%20Type%20%28Check%20only%20one.%29%3A) [4](https://web.archive.org/web/20250325183323/https://www.sec.gov/Archives/edgar/data/1067983/000095012324011775/0000950123-24-011775-index.htm#:~:text=Seq%20Description%20Document%20Type%20Size%20INFORMATION%20TABLE%20FOR%20FORM%2013F%20Complete%20submission%20text%20file) [5](https://en.wikipedia.org/w/index.php?oldid=1223018657)

Insider buying would carry more weight than an institutional holdings change as evidence of personal conviction if insiders voluntarily put material new cash at risk. No insider transaction records here identify buyers, dates, prices or size relative to prior stakes. Check those records for open-market purchases rather than grants or option exercises before treating the two groups as taking opposite views. Even a verified purchase would not establish what the buyer expects from private assets. [5](https://en.wikipedia.org/w/index.php?oldid=1223018657)

## What would change the view

The base case gives MSCI credit for owning Burgiss data but assumes no incremental partnership revenue in the buy decision. The strongest bullish alternative is that Intapp and Moody’s could bring that data to paying clients faster than MSCI could alone. The supplied record establishes the acquisition, not either partnership’s terms, paid adoption or economics. Reconsider an entry if MSCI discloses partner-sourced paid contracts converting into recurring private-assets revenue, distinguishes that growth from acquired Burgiss sales, and the contribution supports the share price. Announcements or a rebound against the benchmarks would not meet that test. [6](https://en.wikipedia.org/w/index.php?oldid=1284092066)

## Sources

1. [Financial Select Sector SPDR Fund (NYSE:XLF) - Shares, Dividends & News - Intelligent Investor](https://web.archive.org/web/20241204095631/https://www.intelligentinvestor.com.au/shares/nyse-xlf/financial-select-sector-spdr-fund#:~:text=Financial%20Select%20Sector%20SPDR%20Fund%27s%20%28XLF%29%2052-week%20high%20is,average%20trading%20volume%20of%209%2C864%2C252%20XLF%20shares%20per%20day.), available by 2024-12-04.
2. [S&P 500](https://en.wikipedia.org/w/index.php?oldid=1293815072), available by 2025-06-03.
3. [SEC FORM 13F-HR](https://web.archive.org/web/20241208193934/https://www.sec.gov/Archives/edgar/data/1364742/000108636424008417/xslForm13F_X02/primary_doc.xml#:~:text=Signature%2C%20Place%2C%20and%20Date%20of%20Signing%3A%20BlackRock%2C%20Inc.%20is,of%20all%20such%20subsidiaries.%20Report%20Type%20%28Check%20only%20one.%29%3A), available by 2024-12-08.
4. [EDGAR Filing Documents for 0000950123-24-011775](https://web.archive.org/web/20250325183323/https://www.sec.gov/Archives/edgar/data/1067983/000095012324011775/0000950123-24-011775-index.htm#:~:text=Seq%20Description%20Document%20Type%20Size%20INFORMATION%20TABLE%20FOR%20FORM%2013F%20Complete%20submission%20text%20file), available by 2025-03-25.
5. [Form 13F](https://en.wikipedia.org/w/index.php?oldid=1223018657), available by 2024-05-09.
6. [MSCI](https://en.wikipedia.org/w/index.php?oldid=1284092066), available by 2025-04-05.
