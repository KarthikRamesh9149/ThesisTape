# Investment research memo

As of 2025-07-21

**Research question**
How do recent shifts in BARDA funding priorities and lobbying efforts, specifically the termination of Moderna's $590 million bird flu award and Emergent BioSolutions' aggressive FY2025/2026 funding advocacy, impact the long-term revenue stability and pipeline risk for U.S. medical countermeasure contractors?

Some parts of the question could not be established from eligible evidence.

## Evidence

For Moderna, the unknown is how much of the announced award would still have funded future work. The available passages do not document the termination terms, amounts paid, or amounts earned but still payable. They therefore establish neither the unpaid funding lost nor a dollar-for-dollar revenue cut. Without replacement financing, lower the probability of bird flu development milestones and eventual procurement. Do not carry that adjustment into the sales forecast for Moderna’s separately approved RSV vaccine. [1](https://web.archive.org/web/20250420042639/https://www.fda.gov/news-events/press-announcements/fda-roundup-may-31-2024#:~:text=Today%2C%20the%20U.S.%20Food%20and%20Drug%20Administration%20is%20providing,devices%20to%20the%20Federal%20Food%2C%20Drug%20and%20Cosmetics%20Act.)

For Emergent, stockpile replenishment has a purchasing history, but renewal is not assured. The $911 million BioThrax contract was reported as of December 2016; it is not evidence of current backlog. Emergent’s filing lists a BioThrax contract modification effective December 13, 2024, but the excerpt gives no incremental order value. Forecast funded deliveries on their own terms and keep prospective renewals separate. Advocacy may support demand, but even an enacted appropriation would not establish Emergent’s share without an order. [2](https://en.wikipedia.org/w/index.php?oldid=1292958171) [3](https://web.archive.org/web/20250406211938/https://www.sec.gov/Archives/edgar/data/1367644/000136764425000021/ebs-20241231.htm#:~:text=Modification%20No.%203%2C%20effective%20December%2013%2C%202024%2C%20to%20the,Report%20on%20Form%2010-Q%20filed%20on%20November%205%2C%202021%29)

## What would change the view

The base case is selective reprioritization: bird flu development faces a financing gap while established stockpile programs continue to receive orders. Test that view against Moderna’s closeout and replacement-funding disclosures and Emergent’s next funded delivery orders. The strongest alternative is a broad BARDA retrenchment, with lobbying a response to threatened renewals rather than a sign of future growth. Broaden the downgrade if enacted funding cuts are followed by smaller orders or repeated nonrenewals across unrelated countermeasures such as anthrax vaccines and botulism antitoxin. The historical contracts establish that comparison, not the outcome. [3](https://web.archive.org/web/20250406211938/https://www.sec.gov/Archives/edgar/data/1367644/000136764425000021/ebs-20241231.htm#:~:text=Modification%20No.%203%2C%20effective%20December%2013%2C%202024%2C%20to%20the,Report%20on%20Form%2010-Q%20filed%20on%20November%205%2C%202021%29) [2](https://en.wikipedia.org/w/index.php?oldid=1292958171)

## Sources

1. [FDA Roundup: May 31, 2024 | FDA](https://web.archive.org/web/20250420042639/https://www.fda.gov/news-events/press-announcements/fda-roundup-may-31-2024#:~:text=Today%2C%20the%20U.S.%20Food%20and%20Drug%20Administration%20is%20providing,devices%20to%20the%20Federal%20Food%2C%20Drug%20and%20Cosmetics%20Act.), available by 2025-04-20.
2. [Emergent BioSolutions](https://en.wikipedia.org/w/index.php?oldid=1292958171), available by 2025-05-29.
3. [ebs-20241231](https://web.archive.org/web/20250406211938/https://www.sec.gov/Archives/edgar/data/1367644/000136764425000021/ebs-20241231.htm#:~:text=Modification%20No.%203%2C%20effective%20December%2013%2C%202024%2C%20to%20the,Report%20on%20Form%2010-Q%20filed%20on%20November%205%2C%202021%29), available by 2025-04-06.
