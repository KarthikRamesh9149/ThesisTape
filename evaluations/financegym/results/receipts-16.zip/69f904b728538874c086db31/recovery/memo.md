# Investment research memo

As of 2025-07-09

**Research question**
How did the S&P 500 and leading technology components like NVIDIA and Microsoft maintain their upward trajectory to record highs in mid-2025 despite significant headwinds from early-year tariff-related volatility and the late-2024 market downturn?

Some parts of the question could not be established from eligible evidence.

## Evidence

NVIDIA’s results help explain why investors could remain optimistic after the tariff rebound. In the quarter ended April 27, 2025, revenue rose 69% year over year to $44.1 billion; Data Center revenue rose 73% to $39.1 billion, evidence of spending on AI infrastructure. Separate export licensing requirements for China still hurt earnings: NVIDIA recorded a $4.5 billion charge and could not ship an additional $2.5 billion of chip revenue. The tariff pause did not undo that constraint. [1](https://web.archive.org/web/20250528210548/https://nvidianews.nvidia.com/_gallery/download_pdf/6837703d3d63320fddb3a9ee/#:~:text=NVIDIA%20Announces%20Financial%20Results%20for%20First%20Quarter%20Fiscal%202026,in%20millions%2C%20except%20earnings%20per%20share%29%20Q1%20FY26%20Q4) [2](https://web.archive.org/web/20250707211320/https://nvidianews.nvidia.com/news/nvidia-announces-financial-results-for-first-quarter-fiscal-2026#:~:text=NVIDIA%20%28NASDAQ%3A%20NVDA%29%20today%20reported%20revenue%20for%20the%20first,first%20quarter%20non-GAAP%20gross%20margin%20would%20have%20been%2071.3%25.)

## Sources

1. [Archived PDF](https://web.archive.org/web/20250528210548/https://nvidianews.nvidia.com/_gallery/download_pdf/6837703d3d63320fddb3a9ee/#:~:text=NVIDIA%20Announces%20Financial%20Results%20for%20First%20Quarter%20Fiscal%202026,in%20millions%2C%20except%20earnings%20per%20share%29%20Q1%20FY26%20Q4), available by 2025-05-28.
2. [NVIDIA Announces Financial Results for First Quarter Fiscal 2026 | NVIDIA Newsroom](https://web.archive.org/web/20250707211320/https://nvidianews.nvidia.com/news/nvidia-announces-financial-results-for-first-quarter-fiscal-2026#:~:text=NVIDIA%20%28NASDAQ%3A%20NVDA%29%20today%20reported%20revenue%20for%20the%20first,first%20quarter%20non-GAAP%20gross%20margin%20would%20have%20been%2071.3%25.), available by 2025-07-07.
