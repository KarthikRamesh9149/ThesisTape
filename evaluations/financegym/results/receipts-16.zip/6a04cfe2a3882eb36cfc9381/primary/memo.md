# Investment research memo

As of 2025-03-16

**Research question**
Given CEO Corie Barry’s March 2025 warnings regarding Best Buy’s 75% product exposure to China and Mexico, to what extent will the company’s new U.S. marketplace and influencer strategies successfully offset the projected one-point drag on comparable sales caused by incoming tariffs?

Some parts of the question could not be established from eligible evidence.

## Outlook

The base case gives neither initiative a quantified comparable-sales offset. That is not a prediction of no benefit: the planned marketplace could attract purchases Best Buy would otherwise miss, while advertising could improve profit without a corresponding lift in comparable sales. In a hypothetical tariff scenario, count only marketplace fees or commissions recognized in comparable sales when Best Buy acts as agent, not sellers’ gross transaction value. Count influencer-driven revenue only to the extent it qualifies for comparable sales and would not otherwise have occurred. Subtract displaced Best Buy sales and count an influencer-referred marketplace order only once. [1](https://web.archive.org/web/20250209121744/https://www.retaildive.com/news/best-buy-third-party-marketplace-launch/737793/#:~:text=%E2%80%9CWe%E2%80%99re%20incredibly%20excited%20to%20roll%20out%20Best%20Buy%20Marketplace,figures%20from%20the%20U.S.%20Department%20of%20Commerce%E2%80%99s%20Census%20Bureau.) [2](https://web.archive.org/web/20250311132259/https://www.forbes.com/sites/kirimasters/2025/03/11/best-buys-marketplace-bet-is-really-about-ad-revenue/#:~:text=The%20Marketplace-Advertising%20Connection%20While%20expanding%20product%20selection%20is%20certainly,marketplace%2C%20continues%20to%20grow%2C%20so%20will%20our%20advertising%20business.%E2%80%9D)

## What would change the view

The strongest upside case is that new brands and creator referrals bring in shoppers who would otherwise buy elsewhere. The test is not marketplace volume or referral clicks: it is disclosed marketplace revenue included in comparable sales, plus a measured lift in eligible purchases among shoppers reached by creators versus a comparable group not reached. The available evidence offers an assortment rationale, but neither that accounting reconciliation nor a measured influencer lift. Until then, any claimed percentage offset is a scenario, not guidance. [1](https://web.archive.org/web/20250209121744/https://www.retaildive.com/news/best-buy-third-party-marketplace-launch/737793/#:~:text=%E2%80%9CWe%E2%80%99re%20incredibly%20excited%20to%20roll%20out%20Best%20Buy%20Marketplace,figures%20from%20the%20U.S.%20Department%20of%20Commerce%E2%80%99s%20Census%20Bureau.) [2](https://web.archive.org/web/20250311132259/https://www.forbes.com/sites/kirimasters/2025/03/11/best-buys-marketplace-bet-is-really-about-ad-revenue/#:~:text=The%20Marketplace-Advertising%20Connection%20While%20expanding%20product%20selection%20is%20certainly,marketplace%2C%20continues%20to%20grow%2C%20so%20will%20our%20advertising%20business.%E2%80%9D)

## Sources

1. [Best Buy to launch third-party marketplace this summer | Retail Dive](https://web.archive.org/web/20250209121744/https://www.retaildive.com/news/best-buy-third-party-marketplace-launch/737793/#:~:text=%E2%80%9CWe%E2%80%99re%20incredibly%20excited%20to%20roll%20out%20Best%20Buy%20Marketplace,figures%20from%20the%20U.S.%20Department%20of%20Commerce%E2%80%99s%20Census%20Bureau.), available by 2025-02-09.
2. [Best Buy's Marketplace Bet Is Really About Ad Revenue](https://web.archive.org/web/20250311132259/https://www.forbes.com/sites/kirimasters/2025/03/11/best-buys-marketplace-bet-is-really-about-ad-revenue/#:~:text=The%20Marketplace-Advertising%20Connection%20While%20expanding%20product%20selection%20is%20certainly,marketplace%2C%20continues%20to%20grow%2C%20so%20will%20our%20advertising%20business.%E2%80%9D), available by 2025-03-11.
