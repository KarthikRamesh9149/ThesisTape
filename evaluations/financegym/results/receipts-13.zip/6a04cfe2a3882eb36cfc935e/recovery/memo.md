# Investment research memo

As of 2025-07-21

**Research question**
How did the simultaneous ascent of the S&P 500 and Gold to all-time highs in the first half of 2025 redefine cross-asset correlation models, and what role did concentration in Nvidia and the technology sector play in driving this dual-peak phenomenon?

Some parts of the question could not be established from eligible evidence.

## Answer

As of 2025-07-21, the evidence supports overlapping strength in equities and gold during the first half of 2025, not a verified pair of all-time highs. The S&P 500 rose 0.5% to a record close on June 27, 2025. The June gold report describes a near two-month high, not an all-time high. A first-half gold record remains an unverified premise of the question; the sources establish neither a shared record date nor a reason to revise stock–gold correlation assumptions. [1](https://web.archive.org/web/20250629101700/https://www.barrons.com/livecoverage/stock-market-news-today-062725#:~:text=Stock%20Market%20News%20From%20June%2027%2C%202025%3A%20S%26P%20500,latest%20PCE%20report%20and%20weighed%20updates%20in%20tariff%20negotiations.) [2](https://web.archive.org/web/20250708115532/https://www.wsj.com/livecoverage/stock-market-today-inflation-data-06-27-2025#:~:text=The%20S%26P%20500%20and%20Nasdaq%20Composite%20closed%20at%20record,said%20Jay%20Hatfield%2C%20chief%20executive%20at%20Infrastructure%20Capital%20Advisors.) [3](https://en.wikipedia.org/w/index.php?oldid=1300962958)

## Evidence

The base case is that the assets rose in the same half-year for different reasons. The equity record-day account emphasized optimism over trade and the budget. The gold account linked its June high to safe-haven buying amid Israel–Iran tensions, and the World Gold Council attributed part of gold’s first-half performance to trade risk. Trade uncertainty could therefore support gold at one point and its easing support equities later, without the assets gaining on the same days. [4](https://web.archive.org/web/20250708115532/https://www.wsj.com/livecoverage/stock-market-today-inflation-data-06-27-2025#:~:text=June%2027%2C%202025%20at%207%3A00%20PM%20ET%20Markets%20hit,in%20the%20afternoon%20driven%20by%20renewed%20tensions%20with%20Canada.) [3](https://en.wikipedia.org/w/index.php?oldid=1300962958) [5](https://web.archive.org/web/20250720011001/https://www.gold.org/goldhub/research/gold-mid-year-outlook-2025#:~:text=A%20full%20resolution%20of%20risk%20does%20not%20seem%20as,central%20bank%20demand%20if%20US%20Treasuries%20are%20again%20favoured.)

## What would change the view

The strongest alternative is a lasting rise in daily stock–gold correlation, which distinct accounts of the June moves do not rule out. Test it with daily percentage returns measured at comparable times on common trading days, not with price levels or record counts. A rolling correlation that stays above its pre-half historical range well beyond June would favor a model change; a return to that range would favor temporary overlap. The available equity-session return and gold price milestone are not a paired series, and by 2025-07-21 the post-June window was still short. Neither persistence nor reversion has been demonstrated. [2](https://web.archive.org/web/20250708115532/https://www.wsj.com/livecoverage/stock-market-today-inflation-data-06-27-2025#:~:text=The%20S%26P%20500%20and%20Nasdaq%20Composite%20closed%20at%20record,said%20Jay%20Hatfield%2C%20chief%20executive%20at%20Infrastructure%20Capital%20Advisors.) [3](https://en.wikipedia.org/w/index.php?oldid=1300962958)

Technology concentration could change the measured stock–gold correlation by changing the equity index’s daily returns, even if it had no effect on gold. Compare the cap-weighted index with an equal-weighted version and a version that excludes technology stocks, using the same gold returns and trading days. If a sustained correlation shift appeared only in the cap-weighted index, that would point to index composition rather than a broad change in how stocks and gold move together. It still would not show that Nvidia or other technology stocks drove gold’s rise; the June gold account points instead to safe-haven demand. [6](https://en.wikipedia.org/w/index.php?oldid=1300807541) [3](https://en.wikipedia.org/w/index.php?oldid=1300962958)

## Sources

1. [Stock Market News From June 27, 2025: S&P 500, Nasdaq Close at Record Highs; Dow Gains; Trump Ends Talks With Canada; Tariffs China Deal; PCE Inflation Report; Nike, Nvidia, Palantir, More Movers](https://web.archive.org/web/20250629101700/https://www.barrons.com/livecoverage/stock-market-news-today-062725#:~:text=Stock%20Market%20News%20From%20June%2027%2C%202025%3A%20S%26P%20500,latest%20PCE%20report%20and%20weighed%20updates%20in%20tariff%20negotiations.), available by 2025-06-29.
2. [Stock Market News, June 27, 2025: Nasdaq, S&P Hit Records](https://web.archive.org/web/20250708115532/https://www.wsj.com/livecoverage/stock-market-today-inflation-data-06-27-2025#:~:text=The%20S%26P%20500%20and%20Nasdaq%20Composite%20closed%20at%20record,said%20Jay%20Hatfield%2C%20chief%20executive%20at%20Infrastructure%20Capital%20Advisors.), available by 2025-07-08.
3. [Gold as an investment](https://en.wikipedia.org/w/index.php?oldid=1300962958), available by 2025-07-17.
4. [Stock Market News, June 27, 2025: Nasdaq, S&P Hit Records](https://web.archive.org/web/20250708115532/https://www.wsj.com/livecoverage/stock-market-today-inflation-data-06-27-2025#:~:text=June%2027%2C%202025%20at%207%3A00%20PM%20ET%20Markets%20hit,in%20the%20afternoon%20driven%20by%20renewed%20tensions%20with%20Canada.), available by 2025-07-08.
5. [Gold Mid-Year Outlook 2025 | World Gold Council](https://web.archive.org/web/20250720011001/https://www.gold.org/goldhub/research/gold-mid-year-outlook-2025#:~:text=A%20full%20resolution%20of%20risk%20does%20not%20seem%20as,central%20bank%20demand%20if%20US%20Treasuries%20are%20again%20favoured.), available by 2025-07-20.
6. [S&P 500](https://en.wikipedia.org/w/index.php?oldid=1300807541), available by 2025-07-16.
