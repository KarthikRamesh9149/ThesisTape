# Investment research memo

As of 2025-02-19

**Research question**
How will Lear Corporation's aggressive workforce reduction of 15,000 employees and its strategic pivot toward automation impact the long-term margin profile of its Seating segment, following its recent quarterly sales beat of $4.19 billion?

Some parts of the question could not be established from eligible evidence.

## Evidence

Lear has a credible route to recurring Seating savings: its acquisition of InTouch Automation in 2022 gave it access to automated seat-testing equipment. If that equipment reduces paid labor hours or rework per comparable seat without impairing quality, the benefit can persist at steady output. But acquiring the capability does not establish deployment or payback. Count only staffing savings attributable to Seating that persist at comparable production, and deduct equipment depreciation and maintenance. Upfront capital spending matters for payback; it is not itself an operating margin expense. [1](https://en.wikipedia.org/w/index.php?oldid=1276338674)

## Outlook

The base case is that productivity helps defend margin rather than establishing a higher long-term level. S&P Global Mobility expected 2025 production to fall 2.4% in North America and 2.6% in Europe. At lower build rates, headcount can fall without labor hours per seat improving, while fixed plant costs are spread across fewer seats. Automakers seeking price concessions could also capture part of any efficiency gain. The vehicle-price outlook makes that a risk, not evidence of a Lear contract price cut. Regional forecasts likewise do not establish Lear’s program volumes or a permanent decline. [2](https://web.archive.org/web/20250125021925/https://press.spglobal.com/2024-12-20-S-P-Global-Mobility-forecasts-89-6M-auto-sales-worldwide-in-2025#:~:text=In%20mainland%20China%2C%20S%26P%20Global%20Mobility%20forecasts%20stable%20production,incoming%20Trump%20administration%2C%20with%20premium%20vehicles%20particularly%20at%20risk.) [3](https://web.archive.org/web/20250125034302/https://press.spglobal.com/2024-12-19-S-P-Global-Mobility-Solid-finish-to-close-out-2024-US-auto-sales#:~:text=Looking%20forward%2C%20S%26P%20Global%20Mobility%20projects%20US%20sales%20volumes,S%26P%20Global%20Mobility%20%28Est%29%2C%20U.S.%20Bureau%20of%20Economic%20Analysis)

## What would change the view

The strongest upside case is that Lear replicates automated testing across enough Seating lines to lower unit costs even at subdued build rates and retains the savings after customer negotiations. Raise the forecast if lower labor hours and rework per comparable seat are accompanied by sustained Seating adjusted margin gains, with a segment profit reconciliation showing that recurring savings exceed depreciation, upkeep and price concessions after isolating volume and mix. A revenue beat or a margin rebound driven by fuller plants would not pass that test. [1](https://en.wikipedia.org/w/index.php?oldid=1276338674) [2](https://web.archive.org/web/20250125021925/https://press.spglobal.com/2024-12-20-S-P-Global-Mobility-forecasts-89-6M-auto-sales-worldwide-in-2025#:~:text=In%20mainland%20China%2C%20S%26P%20Global%20Mobility%20forecasts%20stable%20production,incoming%20Trump%20administration%2C%20with%20premium%20vehicles%20particularly%20at%20risk.)

## Sources

1. [Lear Corporation](https://en.wikipedia.org/w/index.php?oldid=1276338674), available by 2025-02-18.
2. [S&P Global Mobility forecasts 89.6M auto sales worldwide in 2025 - Dec 20, 2024](https://web.archive.org/web/20250125021925/https://press.spglobal.com/2024-12-20-S-P-Global-Mobility-forecasts-89-6M-auto-sales-worldwide-in-2025#:~:text=In%20mainland%20China%2C%20S%26P%20Global%20Mobility%20forecasts%20stable%20production,incoming%20Trump%20administration%2C%20with%20premium%20vehicles%20particularly%20at%20risk.), available by 2025-01-25.
3. [S&P Global Mobility: Solid finish to close out 2024 US auto sales - Dec 19, 2024](https://web.archive.org/web/20250125034302/https://press.spglobal.com/2024-12-19-S-P-Global-Mobility-Solid-finish-to-close-out-2024-US-auto-sales#:~:text=Looking%20forward%2C%20S%26P%20Global%20Mobility%20projects%20US%20sales%20volumes,S%26P%20Global%20Mobility%20%28Est%29%2C%20U.S.%20Bureau%20of%20Economic%20Analysis), available by 2025-01-25.
