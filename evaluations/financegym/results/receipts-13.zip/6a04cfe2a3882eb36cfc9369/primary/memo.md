# Investment research memo

As of 2025-05-27

**Research question**
Evaluate the drivers of institutional demand and speculative positioning in the ProShares Bitcoin Strategy ETF (BITO) between Q3 2024 and May 2025, specifically addressing its futures-based structure and the significant 669% surge in call options volume observed in early May 2025.

Some parts of the question could not be established from eligible evidence.

## Evidence

BITO’s clearest demand driver is access: a manager can trade shares in a brokerage account without arranging bitcoin custody. That benefit is not unique to BITO since spot ETFs became available. The choice turns in part on the exposure a manager wants: BITO can suit a tactical futures position, but the price of the next contract relative to the expiring one can cause its return to diverge from spot. That is a reason to choose between the products, not evidence that managers chose BITO. [1](https://web.archive.org/web/20211202134356/https://www.proshares.com/news/proshares_launches_first_us_bitcoin_linked_etf.html#:~:text=BITO%20will%20offer%20investors%20an%20opportunity%20to%20gain%20exposure,providers%20may%20be%20unregulated%20and%20subject%20to%20security%20risks.%E2%80%9D) [2](https://web.archive.org/web/20211202134356/https://www.proshares.com/news/proshares_launches_first_us_bitcoin_linked_etf.html#:~:text=%E2%80%9CBITO%20will%20continue%20the%20legacy%20of%20ETFs%20that%20provide,launched%20the%20first%20bitcoin-linked%20mutual%20fund%20in%20the%20U.S.) [3](https://en.wikipedia.org/w/index.php?oldid=1292212004)

The holdings report puts the scale in perspective: institutions reporting bitcoin ETFs had about one-half of one percent of their assets in bitcoin. The denominator is those reporting investors’ assets, not BITO’s assets, and the report gives no BITO share count across quarters. Its expectation of higher future allocations is a forecast, not evidence that managers kept or added BITO shares through May. [4](https://web.archive.org/web/20250208065555/https://www.etf.com/sections/news/institutional-investors-warming-bitcoin-etfs-survey#:~:text=Room%20to%20Grow%3A%20Bitcoin%20ETF%20Holdings%20The%20report%2C%20compiled,that%20bitcoin%20ETFs%20are%20predominantly%20owned%20by%20retail%20investors.)

## What would change the view

The base case is that broad ETF adoption and the reported call activity do not identify a lasting bullish position in BITO. The strongest alternative is that managers retained BITO for futures exposure and traders bought calls to add upside. Repeated BITO shareholdings by the same managers across quarter-ends would support the demand claim; net share creations through May would corroborate fund demand without identifying the buyers. For the options claim, first verify contract volume against the stated comparison period. Then look for buyer-initiated opening trades and rising open interest at the affected strikes, after accounting for offsetting spread legs and hedges. Call writing or the closing of old positions could produce heavy volume without new bullish bets. [4](https://web.archive.org/web/20250208065555/https://www.etf.com/sections/news/institutional-investors-warming-bitcoin-etfs-survey#:~:text=Room%20to%20Grow%3A%20Bitcoin%20ETF%20Holdings%20The%20report%2C%20compiled,that%20bitcoin%20ETFs%20are%20predominantly%20owned%20by%20retail%20investors.) [5](https://en.wikipedia.org/w/index.php?oldid=1282937596)

## Sources

1. [ProShares ETFs: News Center - ProShares to Launch the First U.S. Bitcoin-Linked ETF on October 19](https://web.archive.org/web/20211202134356/https://www.proshares.com/news/proshares_launches_first_us_bitcoin_linked_etf.html#:~:text=BITO%20will%20offer%20investors%20an%20opportunity%20to%20gain%20exposure,providers%20may%20be%20unregulated%20and%20subject%20to%20security%20risks.%E2%80%9D), available by 2021-12-02.
2. [ProShares ETFs: News Center - ProShares to Launch the First U.S. Bitcoin-Linked ETF on October 19](https://web.archive.org/web/20211202134356/https://www.proshares.com/news/proshares_launches_first_us_bitcoin_linked_etf.html#:~:text=%E2%80%9CBITO%20will%20continue%20the%20legacy%20of%20ETFs%20that%20provide,launched%20the%20first%20bitcoin-linked%20mutual%20fund%20in%20the%20U.S.), available by 2021-12-02.
3. [Bitcoin](https://en.wikipedia.org/w/index.php?oldid=1292212004), available by 2025-05-25.
4. [Bitcoin ETFs See Surge in Institutional Investors | etf.com](https://web.archive.org/web/20250208065555/https://www.etf.com/sections/news/institutional-investors-warming-bitcoin-etfs-survey#:~:text=Room%20to%20Grow%3A%20Bitcoin%20ETF%20Holdings%20The%20report%2C%20compiled,that%20bitcoin%20ETFs%20are%20predominantly%20owned%20by%20retail%20investors.), available by 2025-02-08.
5. [Option (finance)](https://en.wikipedia.org/w/index.php?oldid=1282937596), available by 2025-03-29.
