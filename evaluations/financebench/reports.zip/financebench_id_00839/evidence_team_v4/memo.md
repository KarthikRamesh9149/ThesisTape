# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
Does Foot Locker's new CEO have previous CEO experience in a similar company to Footlocker?

## Answer

Yes. Mary N. Dillon, Foot Locker’s most recent CEO appointee identified in the records available as of 2024-12-04T00:00:00Z, had already served as CEO of Ulta Beauty from July 2013 through June 2021. She succeeded Richard A. Johnson at Foot Locker effective September 1, 2022. Her experience was relevant because both companies are specialty retailers that sell through stores and digital channels. The difference is what they sell: beauty products at Ulta, sneakers and athletic merchandise at Foot Locker. [1, PDF p29 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/FOOTLOCKER_2022_8K_dated_2022-08-19.pdf#page=29&search=Exhibit%2099.1%20N%20%7C%20E%20%7C) [2, PDF p2 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/FOOTLOCKER_2022_8K_dated_2022-08-19.pdf#page=2&search=Item%205.02.%20%7C%20Departure%20of%20Directors) [3, PDF p30 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/FOOTLOCKER_2022_8K_dated_2022-08-19.pdf#page=30&search=Young%20added%2C%20%E2%80%9CToday%E2%80%99s%20Board%20and%20leadership) [4, PDF p30 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/FOOTLOCKER_2022_8K_dated_2022-08-19.pdf#page=30&search=Foot%20Locker%2C%20Inc.%20leads%20the%20celebration)

## Evidence

After her CEO tenure, Dillon served as Ulta’s executive chair through June 2022. Foot Locker announced her appointment as president and CEO on August 19, 2022. The filing establishes that succession but does not independently rule out a later CEO appointment before the cutoff. [2, PDF p2 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/FOOTLOCKER_2022_8K_dated_2022-08-19.pdf#page=2&search=Item%205.02.%20%7C%20Departure%20of%20Directors)

## Outlook

If Dillon uses purchase history to tailor offers across Foot Locker’s stores and digital channels, the base case is higher repeat purchasing among loyalty members over several reporting quarters. The strongest alternative is that shoppers replace sneakers less often than they replenish beauty products, so more relevant offers may attract members without prompting another purchase. Rising sign-ups alongside flat repeat-purchase rates for comparable groups of members would favor that explanation. Ulta’s loyalty record makes this a useful test, not an observed Foot Locker result. [3, PDF p30 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/FOOTLOCKER_2022_8K_dated_2022-08-19.pdf#page=30&search=Young%20added%2C%20%E2%80%9CToday%E2%80%99s%20Board%20and%20leadership) [4, PDF p30 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/FOOTLOCKER_2022_8K_dated_2022-08-19.pdf#page=30&search=Foot%20Locker%2C%20Inc.%20leads%20the%20celebration)

## Sources

1. [FOOTLOCKER 2022 8K dated 2022-08-19, PDF p29 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/FOOTLOCKER_2022_8K_dated_2022-08-19.pdf#page=29&search=Exhibit%2099.1%20N%20%7C%20E%20%7C), available by 2024-12-03.
2. [FOOTLOCKER 2022 8K dated 2022-08-19, PDF p2 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/FOOTLOCKER_2022_8K_dated_2022-08-19.pdf#page=2&search=Item%205.02.%20%7C%20Departure%20of%20Directors), available by 2024-12-03.
3. [FOOTLOCKER 2022 8K dated 2022-08-19, PDF p30 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/FOOTLOCKER_2022_8K_dated_2022-08-19.pdf#page=30&search=Young%20added%2C%20%E2%80%9CToday%E2%80%99s%20Board%20and%20leadership), available by 2024-12-03.
4. [FOOTLOCKER 2022 8K dated 2022-08-19, PDF p30 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/FOOTLOCKER_2022_8K_dated_2022-08-19.pdf#page=30&search=Foot%20Locker%2C%20Inc.%20leads%20the%20celebration), available by 2024-12-03.
