# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
Does Foot Locker's new CEO have previous CEO experience in a similar company to Footlocker?

## Answer

Yes—by retail operating model, not by merchandise. As of 2024-12-04T00:00:00Z, Foot Locker’s CEO was Mary N. Dillon. She became its CEO on September 1, 2022, after serving as CEO of Ulta Beauty from July 2013 through June 2021. That gave her experience running a specialty retailer across stores and digital channels, but Ulta sold beauty products, not Foot Locker’s core athletic footwear and apparel. [1, PDF p29 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/FOOTLOCKER_2022_8K_dated_2022-08-19.pdf#page=29&search=Exhibit%2099.1%20N%20%7C%20E%20%7C) [2, PDF p2 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/FOOTLOCKER_2022_8K_dated_2022-08-19.pdf#page=2&search=Item%205.02.%20%7C%20Departure%20of%20Directors) [3, PDF p30 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/FOOTLOCKER_2022_8K_dated_2022-08-19.pdf#page=30&search=Young%20added%2C%20%E2%80%9CToday%E2%80%99s%20Board%20and%20leadership) [4, PDF p23 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/FOOTLOCKER_2022_8K_dated_2022-08-19.pdf#page=23&search=the%20retail%2C%20catalog%2C%20or%20on-line%20sale)

## Evidence

The strongest parallel is how the companies reach and retain shoppers. Under Dillon, Ulta combined omnichannel retail with a loyalty program. When Foot Locker announced her appointment, it reported approximately 2,800 stores alongside websites and mobile apps. Experience giving customers reasons to return across those channels was relevant at that scale; it did not require the chains to stock the same products. [3, PDF p30 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/FOOTLOCKER_2022_8K_dated_2022-08-19.pdf#page=30&search=Young%20added%2C%20%E2%80%9CToday%E2%80%99s%20Board%20and%20leadership) [5, PDF p30 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/FOOTLOCKER_2022_8K_dated_2022-08-19.pdf#page=30&search=Foot%20Locker%2C%20Inc.%20leads%20the%20celebration)

## What would change the view

If “similar” means a sneaker retailer, the answer is no: Dillon’s Ulta tenure does not establish experience choosing a sneaker assortment. The base case is narrower: her retail experience should help Foot Locker retain customers across channels. A useful test over subsequent selling seasons would be whether customers return more often after loyalty or digital changes. If engagement rose without more repeat purchases, that would weaken the case for transfer. The appointment materials establish her credentials, not that outcome. [3, PDF p30 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/FOOTLOCKER_2022_8K_dated_2022-08-19.pdf#page=30&search=Young%20added%2C%20%E2%80%9CToday%E2%80%99s%20Board%20and%20leadership) [5, PDF p30 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/FOOTLOCKER_2022_8K_dated_2022-08-19.pdf#page=30&search=Foot%20Locker%2C%20Inc.%20leads%20the%20celebration)

## Sources

1. [FOOTLOCKER 2022 8K dated 2022-08-19, PDF p29 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/FOOTLOCKER_2022_8K_dated_2022-08-19.pdf#page=29&search=Exhibit%2099.1%20N%20%7C%20E%20%7C), available by 2024-12-03.
2. [FOOTLOCKER 2022 8K dated 2022-08-19, PDF p2 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/FOOTLOCKER_2022_8K_dated_2022-08-19.pdf#page=2&search=Item%205.02.%20%7C%20Departure%20of%20Directors), available by 2024-12-03.
3. [FOOTLOCKER 2022 8K dated 2022-08-19, PDF p30 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/FOOTLOCKER_2022_8K_dated_2022-08-19.pdf#page=30&search=Young%20added%2C%20%E2%80%9CToday%E2%80%99s%20Board%20and%20leadership), available by 2024-12-03.
4. [FOOTLOCKER 2022 8K dated 2022-08-19, PDF p23 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/FOOTLOCKER_2022_8K_dated_2022-08-19.pdf#page=23&search=the%20retail%2C%20catalog%2C%20or%20on-line%20sale), available by 2024-12-03.
5. [FOOTLOCKER 2022 8K dated 2022-08-19, PDF p30 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/FOOTLOCKER_2022_8K_dated_2022-08-19.pdf#page=30&search=Foot%20Locker%2C%20Inc.%20leads%20the%20celebration), available by 2024-12-03.
