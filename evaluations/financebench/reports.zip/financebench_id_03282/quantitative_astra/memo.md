# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
What is Netflix's year end FY2017 total current liabilities (in USD millions)? Base your judgments on the information provided primarily in the balance sheet.

## Answer

Netflix, Inc.’s consolidated total current liabilities at December 31, 2017 were USD (5,466,312 ÷ one thousand) million. The audited balance sheet reports the “Total current liabilities” subtotal in thousands of dollars, so dividing by one thousand converts it to millions. [1, PDF p45 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/NETFLIX_2017_10K.pdf#page=45&search=Table%20of%20Contents%20NETFLIX%2C%20INC.%20CONSOLIDATED)

## Evidence

The subtotal includes current content liabilities, accounts payable, accrued expenses and deferred revenue. The streaming content commitments note is not a substitute: it covers only content and includes obligations not recognized on the balance sheet. [1, PDF p45 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/NETFLIX_2017_10K.pdf#page=45&search=Table%20of%20Contents%20NETFLIX%2C%20INC.%20CONSOLIDATED) [2, PDF p54 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/NETFLIX_2017_10K.pdf#page=54&search=Table%20of%20Contents%20Company%20and%20its)

## Sources

1. [NETFLIX 2017 10K, PDF p45 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/NETFLIX_2017_10K.pdf#page=45&search=Table%20of%20Contents%20NETFLIX%2C%20INC.%20CONSOLIDATED), available by 2024-12-03.
2. [NETFLIX 2017 10K, PDF p54 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/NETFLIX_2017_10K.pdf#page=54&search=Table%20of%20Contents%20Company%20and%20its), available by 2024-12-03.
