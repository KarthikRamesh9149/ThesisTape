# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
What is Netflix's year end FY2017 total current liabilities (in USD millions)? Base your judgments on the information provided primarily in the balance sheet.

## Answer

At December 31, 2017, Netflix, Inc.’s total current liabilities were USD (5,466,312 ÷ one thousand) million. The audited consolidated balance sheet reports the numerator in thousands of dollars; dividing by one thousand expresses the same balance in millions. [1, PDF p45 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/NETFLIX_2017_10K.pdf#page=45&search=Table%20of%20Contents%20NETFLIX%2C%20INC.%20CONSOLIDATED) [2, PDF p54 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/NETFLIX_2017_10K.pdf#page=54&search=Table%20of%20Contents%20Company%20and%20its)

## Evidence

The larger amount scheduled for streaming content payments within a year is not an alternative liability total. That schedule includes commitments not yet recognized on the balance sheet and shows expected payment timing, not cash actually paid. It should neither replace nor be added to the audited total. [2, PDF p54 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/NETFLIX_2017_10K.pdf#page=54&search=Table%20of%20Contents%20Company%20and%20its)

## Sources

1. [NETFLIX 2017 10K, PDF p45 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/NETFLIX_2017_10K.pdf#page=45&search=Table%20of%20Contents%20NETFLIX%2C%20INC.%20CONSOLIDATED), available by 2024-12-03.
2. [NETFLIX 2017 10K, PDF p54 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/NETFLIX_2017_10K.pdf#page=54&search=Table%20of%20Contents%20Company%20and%20its), available by 2024-12-03.
