# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
How much has the effective tax rate of Corning changed between FY2021 and FY2022?

## Answer

Corning Incorporated’s reported GAAP effective income tax rate rose by two and seven-tenths of a percentage point, from 20.2% in FY2021 to 22.9% in FY2022. The calculation is 22.9% − 20.2%, using the rates for the full fiscal years ended December 31 in Corning’s income tax note. Tax expense therefore accounted for a larger share of pretax income. [1, PDF p77 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CORNING_2022_10K.pdf#page=77&search=Table%20of%20Contents%207.%20Income%20Taxes)

## Evidence

The operating summary rounds the rates to whole percentages, which overstates the increase if those figures are subtracted. Corning’s reconciliation confirms that the more precise rates in the tax note are the reported GAAP rates, not adjusted core rates. [2, PDF p24 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CORNING_2022_10K.pdf#page=24&search=to%20common%20shareholders%20in%202021%2C%20partially) [3, PDF p32 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CORNING_2022_10K.pdf#page=32&search=Table%20of%20Contents%20The%20following%20tables)

## Outlook

Audit settlements and reserve changes contributed more to the rate in the later year. If their contribution returns to its earlier level, the rate would fall, all else equal. If it stays elevated, there would be no such reversal. The same line in a subsequent annual tax reconciliation would distinguish those cases; the historical comparison alone does not establish which is more likely. [1, PDF p77 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CORNING_2022_10K.pdf#page=77&search=Table%20of%20Contents%207.%20Income%20Taxes)

## Sources

1. [CORNING 2022 10K, PDF p77 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CORNING_2022_10K.pdf#page=77&search=Table%20of%20Contents%207.%20Income%20Taxes), available by 2024-12-03.
2. [CORNING 2022 10K, PDF p24 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CORNING_2022_10K.pdf#page=24&search=to%20common%20shareholders%20in%202021%2C%20partially), available by 2024-12-03.
3. [CORNING 2022 10K, PDF p32 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CORNING_2022_10K.pdf#page=32&search=Table%20of%20Contents%20The%20following%20tables), available by 2024-12-03.
