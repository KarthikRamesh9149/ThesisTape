# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
How much has the effective tax rate of Corning changed between FY2021 and FY2022?

## Answer

Corning Incorporated’s consolidated GAAP effective tax rate rose from 20.2% in FY2021 to 22.9% in FY2022. The increase in percentage points is 22.9 minus 20.2. Income taxes therefore absorbed a larger share of pretax income. [1, PDF p77 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CORNING_2022_10K.pdf#page=77&search=Table%20of%20Contents%207.%20Income%20Taxes) [2, PDF p32 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CORNING_2022_10K.pdf#page=32&search=Table%20of%20Contents%20The%20following%20tables)

## Evidence

The operating summary shows 23% and 20% because it rounds the same rates to whole percentages. The income-tax note reports both years to a decimal place and is the more precise basis for the comparison. [3, PDF p24 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CORNING_2022_10K.pdf#page=24&search=to%20common%20shareholders%20in%202021%2C%20partially) [1, PDF p77 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CORNING_2022_10K.pdf#page=77&search=Table%20of%20Contents%207.%20Income%20Taxes)

## Sources

1. [CORNING 2022 10K, PDF p77 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CORNING_2022_10K.pdf#page=77&search=Table%20of%20Contents%207.%20Income%20Taxes), available by 2024-12-03.
2. [CORNING 2022 10K, PDF p32 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CORNING_2022_10K.pdf#page=32&search=Table%20of%20Contents%20The%20following%20tables), available by 2024-12-03.
3. [CORNING 2022 10K, PDF p24 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CORNING_2022_10K.pdf#page=24&search=to%20common%20shareholders%20in%202021%2C%20partially), available by 2024-12-03.
