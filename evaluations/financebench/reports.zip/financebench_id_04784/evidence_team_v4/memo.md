# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
Based on the information provided primarily in the statement of income, what is the FY2018 - FY2019 change in unadjusted operating income % margin for Walmart? Answer in units of percents and round to one decimal place.

## Answer

Walmart’s unadjusted operating income margin rose by two-tenths of a percentage point, rounded to one decimal place. For the full fiscal years ended January 31, the margin increased from 4.0846% in FY2018 to 4.2684% in FY2019. Subtracting the earlier margin from the later one before rounding gives +0.1838 percentage points: Walmart earned more operating income per dollar of total revenue. [1, PDF p33 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/WALMART_2019_10K.pdf#page=33&search=depreciation%20and%20amortization%2C%20accounts%20payable%20and) [2, PDF p80 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/WALMART_2019_10K.pdf#page=80&search=Note%2016.%20Subsequent%20Event%20Dividends%20Declared)

## Evidence

The supplied excerpts omit the Consolidated Statements of Income, so direct verification against that statement is unavailable. Elsewhere in the same filing, the return-on-investment reconciliation gives operating income before adjustments, and the unaudited quarterly note gives full-year total revenues rather than just fourth-quarter revenues. Using those figures, in USD millions, the ratios are 20,437 ÷ 500,343 for the earlier year and 21,957 ÷ 514,405 for the later year. [1, PDF p33 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/WALMART_2019_10K.pdf#page=33&search=depreciation%20and%20amortization%2C%20accounts%20payable%20and) [2, PDF p80 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/WALMART_2019_10K.pdf#page=80&search=Note%2016.%20Subsequent%20Event%20Dividends%20Declared)

## Checked calculations

- C1. operating income margin (percent) — 20,437 ÷ 500,343 × 100 ≈ 4.084598 [2, PDF p80 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/WALMART_2019_10K.pdf#page=80&search=Note%2016.%20Subsequent%20Event%20Dividends%20Declared) [1, PDF p33 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/WALMART_2019_10K.pdf#page=33&search=depreciation%20and%20amortization%2C%20accounts%20payable%20and)
- C2. operating income margin (percent) — 21,957 ÷ 514,405 × 100 ≈ 4.268427 [2, PDF p80 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/WALMART_2019_10K.pdf#page=80&search=Note%2016.%20Subsequent%20Event%20Dividends%20Declared) [1, PDF p33 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/WALMART_2019_10K.pdf#page=33&search=depreciation%20and%20amortization%2C%20accounts%20payable%20and)
- C3. Operating income margin change (percentage points) — C2 − C1 ≈ 0.183829 [2, PDF p80 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/WALMART_2019_10K.pdf#page=80&search=Note%2016.%20Subsequent%20Event%20Dividends%20Declared) [1, PDF p33 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/WALMART_2019_10K.pdf#page=33&search=depreciation%20and%20amortization%2C%20accounts%20payable%20and)

## Sources

1. [WALMART 2019 10K, PDF p33 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/WALMART_2019_10K.pdf#page=33&search=depreciation%20and%20amortization%2C%20accounts%20payable%20and), available by 2024-12-03.
2. [WALMART 2019 10K, PDF p80 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/WALMART_2019_10K.pdf#page=80&search=Note%2016.%20Subsequent%20Event%20Dividends%20Declared), available by 2024-12-03.
