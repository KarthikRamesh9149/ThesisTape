# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
Based on the information provided primarily in the statement of income, what is the FY2018 - FY2019 change in unadjusted operating income % margin for Walmart? Answer in units of percents and round to one decimal place.

## Answer

Walmart’s unadjusted consolidated operating income margin increased by +0.1838 percentage points, from 4.0846% in FY2018 to 4.2684% in FY2019. Walmart earned slightly more operating income per dollar of total revenue. [1, PDF p48 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/WALMART_2019_10K.pdf#page=48&search=Walmart%20Inc.%20Consolidated%20Statements%20of%20Income)

## Evidence

For the fiscal year ended January 31, 2018, Walmart reported USD 20,437 million in operating income on USD 500,343 million in total revenues. For the year ended January 31, 2019, it reported USD 21,957 million on USD 514,405 million. Each margin is reported operating income divided by total revenues, expressed as a percent. The denominator includes membership and other income, not just net sales. The signed change subtracts the earlier margin from the later one before rounding. [1, PDF p48 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/WALMART_2019_10K.pdf#page=48&search=Walmart%20Inc.%20Consolidated%20Statements%20of%20Income) [2, PDF p79 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/WALMART_2019_10K.pdf#page=79&search=Total%20revenues%2C%20consisting%20of%20net%20sales)

## Checked calculations

- C1. Prior-year operating income margin (percent) — 20,437 ÷ 500,343 × 100 ≈ 4.084598 [1, PDF p48 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/WALMART_2019_10K.pdf#page=48&search=Walmart%20Inc.%20Consolidated%20Statements%20of%20Income)
- C2. Current-year operating income margin (percent) — 21,957 ÷ 514,405 × 100 ≈ 4.268427 [1, PDF p48 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/WALMART_2019_10K.pdf#page=48&search=Walmart%20Inc.%20Consolidated%20Statements%20of%20Income)
- C3. Operating income margin change (percentage points) — C2 − C1 ≈ 0.183829 [1, PDF p48 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/WALMART_2019_10K.pdf#page=48&search=Walmart%20Inc.%20Consolidated%20Statements%20of%20Income)

## Sources

1. [WALMART 2019 10K, PDF p48 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/WALMART_2019_10K.pdf#page=48&search=Walmart%20Inc.%20Consolidated%20Statements%20of%20Income), available by 2024-12-03.
2. [WALMART 2019 10K, PDF p79 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/WALMART_2019_10K.pdf#page=79&search=Total%20revenues%2C%20consisting%20of%20net%20sales), available by 2024-12-03.
