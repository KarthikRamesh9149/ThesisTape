# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
What is the FY2019 cash conversion cycle (CCC) for General Mills? CCC is defined as: DIO + DSO - DPO. DIO is defined as: 365 * (average inventory between FY2018 and FY2019) / (FY2019 COGS). DSO is defined as: 365 * (average accounts receivable between FY2018 and FY2019) / (FY2019 Revenue). DPO is defined as: 365 * (average accounts payable between FY2018 and FY2019) / (FY2019 COGS + change in inventory between FY2018 and FY2019). Round your answer to two decimal places. Address the question by using the line items and information shown within the income statement and the balance sheet.

## Answer

General Mills’ FY2019 cash conversion cycle was negative three point seven zero days. On the measure requested, supplier payment days exceeded the combined time to sell inventory and collect receivables. The calculation uses FY2019 consolidated net sales of USD 16,865.2 million as revenue and cost of sales of USD 11,108.4 million as COGS. [1, PDF p53 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=53&search=Table%20of%20Contents%20Consolidated%20Statements%20of) [2, PDF p55 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=55&search=Table%20of%20Contents%20Consolidated%20Balance%20Sheets)

## Evidence

From FY2018 to FY2019 year-end, inventory fell from 1,642.2 to 1,559.3 and receivables fell from 1,684.2 to 1,679.7 (USD millions). Using the question’s annual day count, DIO is that count times the average of the inventory balances divided by 11,108.4, or about fifty-two point six days. DSO uses the average of the receivables balances divided by 16,865.2 and the same day count, or about thirty-six point four days. [2, PDF p55 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=55&search=Table%20of%20Contents%20Consolidated%20Balance%20Sheets) [1, PDF p53 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=53&search=Table%20of%20Contents%20Consolidated%20Statements%20of)

Accounts payable rose from USD 2,746.2 million to USD 2,854.1 million. For DPO, the denominator is estimated purchases, not cost of sales alone: ending inventory less beginning inventory was USD -82.9 million, bringing cost of sales plus the inventory change to USD 11,025.5 million. Multiplying average payables by the annual day count and dividing by estimated purchases gives about ninety-two point seven days. The reported cycle subtracts DPO from DIO plus DSO before rounding. [2, PDF p55 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=55&search=Table%20of%20Contents%20Consolidated%20Balance%20Sheets) [1, PDF p53 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=53&search=Table%20of%20Contents%20Consolidated%20Statements%20of)

C3. Sum of year-end inventories (USD millions) — 1,559.3 + 1,642.2 = 3,201.5 [2, PDF p55 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=55&search=Table%20of%20Contents%20Consolidated%20Balance%20Sheets)

C4. Sum of year-end receivables (USD millions) — 1,679.7 + 1,684.2 = 3,363.9 [2, PDF p55 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=55&search=Table%20of%20Contents%20Consolidated%20Balance%20Sheets)

C5. Sum of year-end accounts payable (USD millions) — 2,854.1 + 2,746.2 = 5,600.3 [2, PDF p55 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=55&search=Table%20of%20Contents%20Consolidated%20Balance%20Sheets)

C6. Inventory sum to cost of sales (ratio) — C3 ÷ 11,108.4 ≈ 0.288205 [1, PDF p53 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=53&search=Table%20of%20Contents%20Consolidated%20Statements%20of) [2, PDF p55 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=55&search=Table%20of%20Contents%20Consolidated%20Balance%20Sheets)

C7. Receivables sum to net sales (ratio) — C4 ÷ 16,865.2 ≈ 0.199458 [1, PDF p53 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=53&search=Table%20of%20Contents%20Consolidated%20Statements%20of) [2, PDF p55 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=55&search=Table%20of%20Contents%20Consolidated%20Balance%20Sheets)

C8. Payables sum to estimated purchases (ratio) — C5 ÷ C2 ≈ 0.507941 [1, PDF p53 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=53&search=Table%20of%20Contents%20Consolidated%20Statements%20of) [2, PDF p55 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=55&search=Table%20of%20Contents%20Consolidated%20Balance%20Sheets)

## Outlook

If collection, inventory and payment days hold near their measured levels in the next comparable fiscal year, the cycle stays slightly negative. A testable alternative is faster supplier payment: with inventory and collection days unchanged, the cycle turns positive when DPO falls below their sum. The year-end balances do not establish actual invoice payment dates or whether supplier terms will persist. [2, PDF p55 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=55&search=Table%20of%20Contents%20Consolidated%20Balance%20Sheets)

## Checked calculations

- C1. Inventory change (USD millions) — 1,559.3 − 1,642.2 = -82.9 [2, PDF p55 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=55&search=Table%20of%20Contents%20Consolidated%20Balance%20Sheets)
- C2. Estimated inventory purchases (USD millions) — 11,108.4 + C1 = 11,025.5 [1, PDF p53 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=53&search=Table%20of%20Contents%20Consolidated%20Statements%20of) [2, PDF p55 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=55&search=Table%20of%20Contents%20Consolidated%20Balance%20Sheets)

## Sources

1. [GENERALMILLS 2019 10K, PDF p53 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=53&search=Table%20of%20Contents%20Consolidated%20Statements%20of), available by 2024-12-03.
2. [GENERALMILLS 2019 10K, PDF p55 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=55&search=Table%20of%20Contents%20Consolidated%20Balance%20Sheets), available by 2024-12-03.
