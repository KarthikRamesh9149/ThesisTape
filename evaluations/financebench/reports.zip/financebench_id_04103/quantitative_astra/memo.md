# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
What is the FY2019 cash conversion cycle (CCC) for General Mills? CCC is defined as: DIO + DSO - DPO. DIO is defined as: 365 * (average inventory between FY2018 and FY2019) / (FY2019 COGS). DSO is defined as: 365 * (average accounts receivable between FY2018 and FY2019) / (FY2019 Revenue). DPO is defined as: 365 * (average accounts payable between FY2018 and FY2019) / (FY2019 COGS + change in inventory between FY2018 and FY2019). Round your answer to two decimal places. Address the question by using the line items and information shown within the income statement and the balance sheet.

Some parts of the question could not be established from eligible evidence.

## Evidence

C1. Sum of beginning and ending inventory (USD millions) — 1,642.2 + 1,559.3 = 3,201.5 [1, PDF p55 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=55&search=Table%20of%20Contents%20Consolidated%20Balance%20Sheets)

C2. Sum of beginning and ending receivables (USD millions) — 1,684.2 + 1,679.7 = 3,363.9 [1, PDF p55 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=55&search=Table%20of%20Contents%20Consolidated%20Balance%20Sheets)

C3. Sum of beginning and ending accounts payable (USD millions) — 2,746.2 + 2,854.1 = 5,600.3 [1, PDF p55 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=55&search=Table%20of%20Contents%20Consolidated%20Balance%20Sheets)

C4. Change in inventory (USD millions) — 1,559.3 − 1,642.2 = -82.9 [1, PDF p55 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=55&search=Table%20of%20Contents%20Consolidated%20Balance%20Sheets)

C5. Inventory-adjusted cost of sales (USD millions) — 11,108.4 + C4 = 11,025.5 [2, PDF p53 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=53&search=Table%20of%20Contents%20Consolidated%20Statements%20of) [1, PDF p55 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=55&search=Table%20of%20Contents%20Consolidated%20Balance%20Sheets)

C6. Inventory balance sum over cost of sales (ratio) — C1 ÷ 11,108.4 ≈ 0.288205 [2, PDF p53 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=53&search=Table%20of%20Contents%20Consolidated%20Statements%20of) [1, PDF p55 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=55&search=Table%20of%20Contents%20Consolidated%20Balance%20Sheets)

C7. Receivables balance sum over net sales (ratio) — C2 ÷ 16,865.2 ≈ 0.199458 [2, PDF p53 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=53&search=Table%20of%20Contents%20Consolidated%20Statements%20of) [1, PDF p55 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=55&search=Table%20of%20Contents%20Consolidated%20Balance%20Sheets)

C8. Payables balance sum over inventory-adjusted cost of sales (ratio) — C3 ÷ C5 ≈ 0.507941 [2, PDF p53 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=53&search=Table%20of%20Contents%20Consolidated%20Statements%20of) [1, PDF p55 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=55&search=Table%20of%20Contents%20Consolidated%20Balance%20Sheets)

## Sources

1. [GENERALMILLS 2019 10K, PDF p55 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=55&search=Table%20of%20Contents%20Consolidated%20Balance%20Sheets), available by 2024-12-03.
2. [GENERALMILLS 2019 10K, PDF p53 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/GENERALMILLS_2019_10K.pdf#page=53&search=Table%20of%20Contents%20Consolidated%20Statements%20of), available by 2024-12-03.
