# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
Has Microsoft increased its debt on balance sheet between FY2023 and the FY2022 period?

## Answer

No. Microsoft’s total balance-sheet borrowings fell from USD 49,781 million at June 30, 2022 to USD 47,237 million at June 30, 2023, a change of USD -2,544 million. The company carried less debt overall, even though more of it was due within a year. [1, PDF p60 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MICROSOFT_2023_10K.pdf#page=60&search=PART%20II%20Item%208%20BALANCE%20SHEETS)

## Evidence

Microsoft’s fiscal 2023 Form 10-K shows no separate short-term debt line at either year-end. The fiscal 2022 total therefore comprises USD 2,749 million of current maturities plus USD 47,032 million of noncurrent debt. The fiscal 2023 total comprises USD 5,247 million plus USD 41,990 million, respectively. The decline in noncurrent debt outweighed the rise in current maturities. These carrying balances establish the net change, not how much Microsoft repaid or refinanced during the year. [1, PDF p60 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MICROSOFT_2023_10K.pdf#page=60&search=PART%20II%20Item%208%20BALANCE%20SHEETS) [2, PDF p51 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MICROSOFT_2023_10K.pdf#page=51&search=PART%20II%20Item%207%20Debt%20Proceeds)

## Outlook

From the fiscal 2023 year-end, the no-refinancing base case is lower debt by the next year-end: USD 5,250 million of principal was due in fiscal 2024, and paying it from cash would reduce borrowings, all else equal. The strongest alternative is roughly unchanged debt if Microsoft replaces the maturing principal with new borrowing. New issuance matching repayments would distinguish refinancing from a paydown; the maturity schedule alone does not establish which occurred. [1, PDF p60 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MICROSOFT_2023_10K.pdf#page=60&search=PART%20II%20Item%208%20BALANCE%20SHEETS) [3, PDF p82 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MICROSOFT_2023_10K.pdf#page=82&search=PART%20II%20Item%208%20The%20following) [2, PDF p51 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MICROSOFT_2023_10K.pdf#page=51&search=PART%20II%20Item%207%20Debt%20Proceeds)

## Checked calculations

- C1. total balance-sheet borrowings (USD millions) — 2,749 + 47,032 = 49,781 [1, PDF p60 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MICROSOFT_2023_10K.pdf#page=60&search=PART%20II%20Item%208%20BALANCE%20SHEETS)
- C2. total balance-sheet borrowings (USD millions) — 5,247 + 41,990 = 47,237 [1, PDF p60 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MICROSOFT_2023_10K.pdf#page=60&search=PART%20II%20Item%208%20BALANCE%20SHEETS)
- C3. Change in total balance-sheet borrowings (USD millions) — C2 − C1 = -2,544 [1, PDF p60 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MICROSOFT_2023_10K.pdf#page=60&search=PART%20II%20Item%208%20BALANCE%20SHEETS)

## Sources

1. [MICROSOFT 2023 10K, PDF p60 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MICROSOFT_2023_10K.pdf#page=60&search=PART%20II%20Item%208%20BALANCE%20SHEETS), available by 2024-12-03.
2. [MICROSOFT 2023 10K, PDF p51 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MICROSOFT_2023_10K.pdf#page=51&search=PART%20II%20Item%207%20Debt%20Proceeds), available by 2024-12-03.
3. [MICROSOFT 2023 10K, PDF p82 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MICROSOFT_2023_10K.pdf#page=82&search=PART%20II%20Item%208%20The%20following), available by 2024-12-03.
