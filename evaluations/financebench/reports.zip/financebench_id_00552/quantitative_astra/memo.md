# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
Has Microsoft increased its debt on balance sheet between FY2023 and the FY2022 period?

## Answer

No. Microsoft’s total balance-sheet debt fell from USD 49,781 million at fiscal year-end 2022 to USD 47,237 million at fiscal year-end 2023, a signed change of USD -2,544 million. At both June year-ends, the balance sheet showed no separate short-term debt, so the total sums the current portion of long-term debt and noncurrent long-term debt once each. The current portion rose, but the noncurrent balance fell by more: Microsoft had less debt overall, even as more was due within a year. [1, PDF p60 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MICROSOFT_2023_10K.pdf#page=60&search=PART%20II%20Item%208%20BALANCE%20SHEETS)

## Evidence

A broader borrowing measure that includes finance leases gives a smaller decline, not an increase. Finance lease liabilities rose from USD 14,902 million to USD 17,067 million, less than the decline in reported debt. Microsoft classified those leases in other liabilities, outside the debt lines used above. The year-end comparison establishes the direction of the balance-sheet change, not how much debt Microsoft repaid in cash. [2, PDF p87 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MICROSOFT_2023_10K.pdf#page=87&search=PART%20II%20Item%208%20Supplemental%20balance) [1, PDF p60 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MICROSOFT_2023_10K.pdf#page=60&search=PART%20II%20Item%208%20BALANCE%20SHEETS)

## Checked calculations

- C1. Current year-end total debt (USD millions) — 5,247 + 41,990 = 47,237 [1, PDF p60 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MICROSOFT_2023_10K.pdf#page=60&search=PART%20II%20Item%208%20BALANCE%20SHEETS)
- C2. Prior year-end total debt (USD millions) — 2,749 + 47,032 = 49,781 [1, PDF p60 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MICROSOFT_2023_10K.pdf#page=60&search=PART%20II%20Item%208%20BALANCE%20SHEETS)
- C3. Year-over-year change in total debt (USD millions) — C1 − C2 = -2,544 [1, PDF p60 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MICROSOFT_2023_10K.pdf#page=60&search=PART%20II%20Item%208%20BALANCE%20SHEETS)

## Sources

1. [MICROSOFT 2023 10K, PDF p60 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MICROSOFT_2023_10K.pdf#page=60&search=PART%20II%20Item%208%20BALANCE%20SHEETS), available by 2024-12-03.
2. [MICROSOFT 2023 10K, PDF p87 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MICROSOFT_2023_10K.pdf#page=87&search=PART%20II%20Item%208%20Supplemental%20balance), available by 2024-12-03.
