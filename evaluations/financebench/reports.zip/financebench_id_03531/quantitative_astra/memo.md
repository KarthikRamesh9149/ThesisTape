# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
According to the details clearly outlined within the balance sheet, how much total current assets did Nike have at the end of FY2019? Answer in USD millions.

## Answer

NIKE, Inc. reported total current assets of USD 16,525 million on its consolidated balance sheet at fiscal year-end, May 31, 2019. The accounting note confirms this is the reported balance, not the hypothetical balance without adoption of Topic 606. [1, PDF p54 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/NIKE_2019_10K.pdf#page=54&search=Table%20of%20Contents%20NIKE%2C%20INC.%20CONSOLIDATED) [2, PDF p64 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/NIKE_2019_10K.pdf#page=64&search=related%20reserves%20for%20the%20Company%27s%20direct)

## Sources

1. [NIKE 2019 10K, PDF p54 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/NIKE_2019_10K.pdf#page=54&search=Table%20of%20Contents%20NIKE%2C%20INC.%20CONSOLIDATED), available by 2024-12-03.
2. [NIKE 2019 10K, PDF p64 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/NIKE_2019_10K.pdf#page=64&search=related%20reserves%20for%20the%20Company%27s%20direct), available by 2024-12-03.
