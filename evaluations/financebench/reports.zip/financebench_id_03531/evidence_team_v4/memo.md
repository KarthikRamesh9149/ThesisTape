# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
According to the details clearly outlined within the balance sheet, how much total current assets did Nike have at the end of FY2019? Answer in USD millions.

## Answer

NIKE, Inc. reported total current assets of USD 16,525 million at its fiscal year-end on May 31, 2019. This is the “Total current assets” subtotal in the 2019 column of its consolidated balance sheet, not the total for all assets. [1, PDF p54 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/NIKE_2019_10K.pdf#page=54&search=Table%20of%20Contents%20NIKE%2C%20INC.%20CONSOLIDATED) [2, PDF p89 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/NIKE_2019_10K.pdf#page=89&search=Table%20of%20Contents%20PART%20IV%20ITEM)

## Sources

1. [NIKE 2019 10K, PDF p54 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/NIKE_2019_10K.pdf#page=54&search=Table%20of%20Contents%20NIKE%2C%20INC.%20CONSOLIDATED), available by 2024-12-03.
2. [NIKE 2019 10K, PDF p89 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/NIKE_2019_10K.pdf#page=89&search=Table%20of%20Contents%20PART%20IV%20ITEM), available by 2024-12-03.
