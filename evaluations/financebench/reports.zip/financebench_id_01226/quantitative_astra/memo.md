# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
What drove operating margin change as of FY2022 for 3M? If operating margin is not a useful metric for a company like this, then please state that and explain why.

Some parts of the question could not be established from eligible evidence.

## Answer

3M’s consolidated operating margin fell from 20.8429 in FY2021 to 19.1037 in FY2022, a change of -1.7392 percentage points. In the prior year, operating income was USD 7,369 million on net sales of USD 35,355 million; in the current year, it was USD 6,539 million on net sales of USD 34,229 million. Reported margin is useful: it shows how much of each sales dollar remained as operating income before nonoperating items and taxes. But it does not reveal the main reason that share fell: higher raw-material costs outweighed operating offsets, while a divestiture gain masked much of the litigation and exit expense. [1, PDF p48 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/3M_2022_10K.pdf#page=48&search=Table%20of%20Contents%203M%20Company%20and) [2, PDF p20 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/3M_2022_10K.pdf#page=20&search=impacts.%20Though%203M%20monitors%20relevant%20factors) [3, PDF p20 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/3M_2022_10K.pdf#page=20&search=Gain%20on%20business%20divestitures%20%7C%208.0)

## Evidence

Excluding management-defined special items, non-GAAP operating margin fell from 22.2% to 20.8%, a change of -1.4 percentage points. In management’s reconciliation, the raw-material contribution was (2.4) points, against a positive 1.0 point from organic growth, productivity and other factors combined. Higher selling prices partly offset cost pressure; higher logistics costs and disruptions to manufacturing in Belgium worked in the opposite direction. The reconciliation does not isolate pricing’s contribution, so the positive combined figure should not be read as a productivity gain. [4, PDF p24 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/3M_2022_10K.pdf#page=24&search=Table%20of%20Contents%20Operating%20Income%20%28Loss%29) [2, PDF p20 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/3M_2022_10K.pdf#page=20&search=impacts.%20Though%203M%20monitors%20relevant%20factors) [5, PDF p27 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/3M_2022_10K.pdf#page=27&search=Table%20of%20Contents%20RESULTS%20OF%20OPERATIONS)

## What would change the view

Use adjusted margin to compare trading performance, but keep reported margin in view when judging sustainable profitability. If input pressure eases and pricing holds, the base case is for adjusted margin to recover in subsequent annual results, other things equal. The strongest alternative is that litigation costs are persistent enough for adjusted margin to overstate the profit available from the business. A wider gap between reported and adjusted margins driven by litigation even as raw-material pressure subsides would favor that interpretation. The historical reconciliation establishes neither when input costs will ease nor whether legal charges will recur at a comparable scale. [2, PDF p20 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/3M_2022_10K.pdf#page=20&search=impacts.%20Though%203M%20monitors%20relevant%20factors) [3, PDF p20 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/3M_2022_10K.pdf#page=20&search=Gain%20on%20business%20divestitures%20%7C%208.0)

## Checked calculations

- C1. Prior-year reported operating margin (percent) — 7,369 ÷ 35,355 × 100 ≈ 20.842879 [1, PDF p48 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/3M_2022_10K.pdf#page=48&search=Table%20of%20Contents%203M%20Company%20and)
- C2. Current-year reported operating margin (percent) — 6,539 ÷ 34,229 × 100 ≈ 19.103684 [1, PDF p48 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/3M_2022_10K.pdf#page=48&search=Table%20of%20Contents%203M%20Company%20and)
- C3. Reported operating margin change (percentage points) — C2 − C1 ≈ -1.739195 [1, PDF p48 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/3M_2022_10K.pdf#page=48&search=Table%20of%20Contents%203M%20Company%20and)
- C4. Adjusted operating margin change (percentage points) — 20.8 − 22.2 = -1.4 [2, PDF p20 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/3M_2022_10K.pdf#page=20&search=impacts.%20Though%203M%20monitors%20relevant%20factors) [4, PDF p24 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/3M_2022_10K.pdf#page=24&search=Table%20of%20Contents%20Operating%20Income%20%28Loss%29)

## Sources

1. [3M 2022 10K, PDF p48 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/3M_2022_10K.pdf#page=48&search=Table%20of%20Contents%203M%20Company%20and), available by 2024-12-03.
2. [3M 2022 10K, PDF p20 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/3M_2022_10K.pdf#page=20&search=impacts.%20Though%203M%20monitors%20relevant%20factors), available by 2024-12-03.
3. [3M 2022 10K, PDF p20 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/3M_2022_10K.pdf#page=20&search=Gain%20on%20business%20divestitures%20%7C%208.0), available by 2024-12-03.
4. [3M 2022 10K, PDF p24 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/3M_2022_10K.pdf#page=24&search=Table%20of%20Contents%20Operating%20Income%20%28Loss%29), available by 2024-12-03.
5. [3M 2022 10K, PDF p27 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/3M_2022_10K.pdf#page=27&search=Table%20of%20Contents%20RESULTS%20OF%20OPERATIONS), available by 2024-12-03.
