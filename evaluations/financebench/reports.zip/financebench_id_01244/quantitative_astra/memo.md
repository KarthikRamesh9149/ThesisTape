# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
Has CVS Health paid dividends to common shareholders in Q2 of FY2022?

## Answer

Yes. CVS Health paid a cash dividend of $0.55 per common share in fiscal Q2 2022, the quarter ended June 30, 2022. In its common-equity disclosure, CVS reports that it paid cash dividends every quarter and identifies the quarterly rate for that year. That payment history includes the June quarter; a board declaration alone would not establish payment. [1, PDF p68 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CVSHEALTH_2022_10K.pdf#page=68&search=Table%20of%20Contents%20PART%20II%20Item) [2, PDF p188 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CVSHEALTH_2022_10K.pdf#page=188&search=10.1%2A%20%7C%20Five%20Year%20Credit%20Agreement)

## Evidence

The evidence establishes payment within the quarter through CVS’s explicit every-quarter statement, not through a six-month total. The cited disclosures do not give the exact payment date or total cash distributed in the June quarter. A dated dividend-payment record would verify the day; a record showing no payment during the quarter would contradict CVS’s stated history. [3, PDF p168 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CVSHEALTH_2022_10K.pdf#page=168&search=20%25%20of%20the%20%241.5%20billion%20notional)

## Sources

1. [CVSHEALTH 2022 10K, PDF p68 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CVSHEALTH_2022_10K.pdf#page=68&search=Table%20of%20Contents%20PART%20II%20Item), available by 2024-12-03.
2. [CVSHEALTH 2022 10K, PDF p188 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CVSHEALTH_2022_10K.pdf#page=188&search=10.1%2A%20%7C%20Five%20Year%20Credit%20Agreement), available by 2024-12-03.
3. [CVSHEALTH 2022 10K, PDF p168 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CVSHEALTH_2022_10K.pdf#page=168&search=20%25%20of%20the%20%241.5%20billion%20notional), available by 2024-12-03.
