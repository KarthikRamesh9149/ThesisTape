# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
Has CVS Health paid dividends to common shareholders in Q2 of FY2022?

## Answer

Yes. CVS Health paid common shareholders a cash dividend of $0.55 per share during its fiscal second quarter, from the first day of April through June 30, 2022. Its common-equity disclosure reports both the quarterly rate and that CVS paid cash dividends every quarter. The latter establishes a payment within the quarter, not merely a board declaration. [1, PDF p188 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CVSHEALTH_2022_10K.pdf#page=188&search=10.1%2A%20%7C%20Five%20Year%20Credit%20Agreement) [2, PDF p68 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CVSHEALTH_2022_10K.pdf#page=68&search=Table%20of%20Contents%20PART%20II%20Item)

## Evidence

A dividend declared during the quarter could have been paid after June closed, so the declaration alone would not answer the question. Nor would a six-month payment total alone show which quarter contained a payment. CVS’s statement that it paid cash every quarter rules out a quarter with no payment. The excerpts do not identify the exact payment date or total cash disbursed that quarter; a dated shareholder payment record would verify those details directly. [3, PDF p168 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CVSHEALTH_2022_10K.pdf#page=168&search=20%25%20of%20the%20%241.5%20billion%20notional) [4, PDF p92 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CVSHEALTH_2022_10K.pdf#page=92&search=Dividends%20During%202022%2C%202021%20and%202020)

## Sources

1. [CVSHEALTH 2022 10K, PDF p188 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CVSHEALTH_2022_10K.pdf#page=188&search=10.1%2A%20%7C%20Five%20Year%20Credit%20Agreement), available by 2024-12-03.
2. [CVSHEALTH 2022 10K, PDF p68 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CVSHEALTH_2022_10K.pdf#page=68&search=Table%20of%20Contents%20PART%20II%20Item), available by 2024-12-03.
3. [CVSHEALTH 2022 10K, PDF p168 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CVSHEALTH_2022_10K.pdf#page=168&search=20%25%20of%20the%20%241.5%20billion%20notional), available by 2024-12-03.
4. [CVSHEALTH 2022 10K, PDF p92 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/CVSHEALTH_2022_10K.pdf#page=92&search=Dividends%20During%202022%2C%202021%20and%202020), available by 2024-12-03.
