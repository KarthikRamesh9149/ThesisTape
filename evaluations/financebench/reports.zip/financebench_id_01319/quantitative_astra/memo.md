# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
What is the quantity of restructuring costs directly outlined in AES Corporation's income statements for FY2022? If restructuring costs are not explicitly outlined then state 0.

## Answer

Report zero. The AES Corporation does not separately identify a restructuring-cost amount on the face of its FY2022 consolidated statement of operations. Zero is the requested result for an absent disclosure, not a measured amount drawn from a broader expense line. [1, PDF p209 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AES_2022_10K.pdf#page=209&search=204%20%7C%202022%20Annual%20Report%20PART) [2, PDF p132 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AES_2022_10K.pdf#page=132&search=AMOUNTS%20ATTRIBUTABLE%20TO%20THE%20AES%20CORPORATION) [3, PDF p95 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AES_2022_10K.pdf#page=95&search=We%20are%20organized%20into%20four%20market-oriented)

## Evidence

AES’s non-GAAP discussion says it incurred no costs for the specific restructuring program announced in 2018 during the requested year. That supports the answer but does not establish that every broader expense category excluded restructuring-related spending. The supplied statement excerpt covers net income and earnings per share rather than the full expense section; only an explicit restructuring amount on the statement itself would change the result. [3, PDF p95 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AES_2022_10K.pdf#page=95&search=We%20are%20organized%20into%20four%20market-oriented) [2, PDF p132 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AES_2022_10K.pdf#page=132&search=AMOUNTS%20ATTRIBUTABLE%20TO%20THE%20AES%20CORPORATION)

## Sources

1. [AES 2022 10K, PDF p209 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AES_2022_10K.pdf#page=209&search=204%20%7C%202022%20Annual%20Report%20PART), available by 2024-12-03.
2. [AES 2022 10K, PDF p132 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AES_2022_10K.pdf#page=132&search=AMOUNTS%20ATTRIBUTABLE%20TO%20THE%20AES%20CORPORATION), available by 2024-12-03.
3. [AES 2022 10K, PDF p95 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AES_2022_10K.pdf#page=95&search=We%20are%20organized%20into%20four%20market-oriented), available by 2024-12-03.
