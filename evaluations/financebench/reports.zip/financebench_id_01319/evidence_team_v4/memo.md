# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
What is the quantity of restructuring costs directly outlined in AES Corporation's income statements for FY2022? If restructuring costs are not explicitly outlined then state 0.

Some parts of the question could not be established from eligible evidence.

## Evidence

AES says it incurred no costs in the requested year from its 2018 restructuring program. That non-GAAP disclosure is program-specific; it does not establish how the consolidated statement presents expenses. Only a separately labeled restructuring-cost row on the full statement would replace the fallback with the amount and units shown for the requested year. [1, PDF p95 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AES_2022_10K.pdf#page=95&search=We%20are%20organized%20into%20four%20market-oriented)

## Sources

1. [AES 2022 10K, PDF p95 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AES_2022_10K.pdf#page=95&search=We%20are%20organized%20into%20four%20market-oriented), available by 2024-12-03.
