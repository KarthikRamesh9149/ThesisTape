# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
In agreement with the information outlined in the income statement, what is the FY2015 - FY2017 3 year average net profit margin (as a %) for Best Buy? Answer in units of percents and round to one decimal place.

Some parts of the question could not be established from eligible evidence.

## Evidence

The numerator includes discontinued operations and is not adjusted earnings. The closest alternative income-statement measure, net earnings including noncontrolling interests, changes only FY2015: USD 1,235 million rather than USD 1,233 million. That distinction does not change the average at the requested precision. Neither measure establishes a future margin. [1, PDF p56 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BESTBUY_2017_10K.pdf#page=56&search=Table%20of%20Contents%20Consolidated%20Statements%20of)

C1. net profit margin (percent) — 1,233 ÷ 40,339 × 100 ≈ 3.056595 [1, PDF p56 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BESTBUY_2017_10K.pdf#page=56&search=Table%20of%20Contents%20Consolidated%20Statements%20of)

C2. net profit margin (percent) — 897 ÷ 39,528 × 100 ≈ 2.269277 [1, PDF p56 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BESTBUY_2017_10K.pdf#page=56&search=Table%20of%20Contents%20Consolidated%20Statements%20of)

C3. net profit margin (percent) — 1,228 ÷ 39,403 × 100 ≈ 3.116514 [1, PDF p56 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BESTBUY_2017_10K.pdf#page=56&search=Table%20of%20Contents%20Consolidated%20Statements%20of)

C4. – margin sum (percent) — C1 + C2 ≈ 5.325873 [1, PDF p56 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BESTBUY_2017_10K.pdf#page=56&search=Table%20of%20Contents%20Consolidated%20Statements%20of)

C5. – margin sum (percent) — C4 + C3 ≈ 8.442387 [1, PDF p56 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BESTBUY_2017_10K.pdf#page=56&search=Table%20of%20Contents%20Consolidated%20Statements%20of)

C6. Fiscal years after through (years) — 2017 − 2014 = 3 [2, PDF p26 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BESTBUY_2017_10K.pdf#page=26&search=Table%20of%20Contents%20Item%206.%20Selected)

## Sources

1. [BESTBUY 2017 10K, PDF p56 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BESTBUY_2017_10K.pdf#page=56&search=Table%20of%20Contents%20Consolidated%20Statements%20of), available by 2024-12-03.
2. [BESTBUY 2017 10K, PDF p26 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BESTBUY_2017_10K.pdf#page=26&search=Table%20of%20Contents%20Item%206.%20Selected), available by 2024-12-03.
