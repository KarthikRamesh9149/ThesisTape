# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
What is the FY2019 - FY2020 total revenue growth rate for Block (formerly known as Square)? Answer in units of percents and round to one decimal place. Approach the question asked by assuming the standpoint of an investment banking analyst who only has access to the statement of income.

## Answer

Square (now Block) grew total net revenue by 101.4974 from FY2019 to FY2020. Its annual consolidated statement of operations shows USD 4,713,500 thousand in the prior year and USD 9,497,578 thousand in the current year. The growth rate divides the difference between those unrounded totals by the prior-year total and expresses it as a percentage rounded to one decimal place. [1, PDF p86 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BLOCK_2020_10K.pdf#page=86&search=SQUARE%2C%20INC.%20CONSOLIDATED%20STATEMENTS%20OF%20OPERATIONS)

## Evidence

The full-year totals include bitcoin revenue in both years. Bitcoin accounted for most of the dollar increase, so an ex-bitcoin comparison would show slower growth but would not measure reported total net revenue. The statement establishes that annual revenue more than doubled, not that this pace was sustainable. [1, PDF p86 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BLOCK_2020_10K.pdf#page=86&search=SQUARE%2C%20INC.%20CONSOLIDATED%20STATEMENTS%20OF%20OPERATIONS) [2, PDF p52 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BLOCK_2020_10K.pdf#page=52&search=Item%206.%20SELECTED%20FINANCIAL%20DATA%20The)

## Checked calculations

- C1. Total net revenue growth rate (percent) — (9,497,578 − 4,713,500) ÷ |4,713,500| × 100 ≈ 101.497359 [1, PDF p86 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BLOCK_2020_10K.pdf#page=86&search=SQUARE%2C%20INC.%20CONSOLIDATED%20STATEMENTS%20OF%20OPERATIONS)

## Sources

1. [BLOCK 2020 10K, PDF p86 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BLOCK_2020_10K.pdf#page=86&search=SQUARE%2C%20INC.%20CONSOLIDATED%20STATEMENTS%20OF%20OPERATIONS), available by 2024-12-03.
2. [BLOCK 2020 10K, PDF p52 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BLOCK_2020_10K.pdf#page=52&search=Item%206.%20SELECTED%20FINANCIAL%20DATA%20The), available by 2024-12-03.
