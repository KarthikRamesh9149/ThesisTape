# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
What is the FY2019 - FY2020 total revenue growth rate for Block (formerly known as Square)? Answer in units of percents and round to one decimal place. Approach the question asked by assuming the standpoint of an investment banking analyst who only has access to the statement of income.

## Answer

Block’s consolidated total net revenue grew one hundred one point five percent from FY2019 to FY2020, rounded to one decimal place. For the fiscal years ended December 31, Square’s consolidated statement of operations shows that total net revenue more than doubled, from USD 4,713,500 thousand to USD 9,497,578 thousand. Subtracting the earlier revenue from the later revenue and dividing by the earlier revenue gives 101.4974% before rounding to the requested precision. [1, PDF p52 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BLOCK_2020_10K.pdf#page=52&search=Item%206.%20SELECTED%20FINANCIAL%20DATA%20The)

## Checked calculations

- C1. -to- total net revenue growth (percent) — (9,497,578 − 4,713,500) ÷ |4,713,500| × 100 ≈ 101.497359 [1, PDF p52 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BLOCK_2020_10K.pdf#page=52&search=Item%206.%20SELECTED%20FINANCIAL%20DATA%20The)

## Sources

1. [BLOCK 2020 10K, PDF p52 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BLOCK_2020_10K.pdf#page=52&search=Item%206.%20SELECTED%20FINANCIAL%20DATA%20The), available by 2024-12-03.
