# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
What is the FY2022 unadjusted EBITDA less capex for PepsiCo? Define unadjusted EBITDA as unadjusted operating income + depreciation and amortization [from cash flow statement]. Answer in USD millions. Respond to the question by assuming the perspective of an investment analyst who can only use the details shown within the statement of cash flows and the income statement.

## Answer

PepsiCo’s FY2022 unadjusted EBITDA less capex was USD 9,068 million. Under the requested definition, reported operating profit of USD 11,512 million plus cash flow statement depreciation and amortization of USD 2,763 million gives unadjusted EBITDA of USD 14,275 million. From that subtotal, the calculation subtracts the magnitude of the capital spending outflow, reported as USD (5,207) million. [1, PDF p62 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PEPSICO_2022_10K.pdf#page=62&search=Table%20of%20Contents%20Consolidated%20Statement%20of) [2, PDF p64 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PEPSICO_2022_10K.pdf#page=64&search=Table%20of%20Contents%20Consolidated%20Statement%20of)

## Evidence

The result measures EBITDA after gross capital spending, not cash generated after investment. PepsiCo reports proceeds from sales of property, plant and equipment separately; netting those proceeds against capex would answer a different question. The EBITDA calculation also does not reflect working-capital changes included in operating cash flow. [2, PDF p64 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PEPSICO_2022_10K.pdf#page=64&search=Table%20of%20Contents%20Consolidated%20Statement%20of)

## Checked calculations

- C1. Unadjusted EBITDA (USD millions) — 11,512 + 2,763 = 14,275 [1, PDF p62 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PEPSICO_2022_10K.pdf#page=62&search=Table%20of%20Contents%20Consolidated%20Statement%20of) [2, PDF p64 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PEPSICO_2022_10K.pdf#page=64&search=Table%20of%20Contents%20Consolidated%20Statement%20of)
- C2. Unadjusted EBITDA less capex (USD millions) — C1 + (5,207) = 9,068 [1, PDF p62 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PEPSICO_2022_10K.pdf#page=62&search=Table%20of%20Contents%20Consolidated%20Statement%20of) [2, PDF p64 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PEPSICO_2022_10K.pdf#page=64&search=Table%20of%20Contents%20Consolidated%20Statement%20of)

## Sources

1. [PEPSICO 2022 10K, PDF p62 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PEPSICO_2022_10K.pdf#page=62&search=Table%20of%20Contents%20Consolidated%20Statement%20of), available by 2024-12-03.
2. [PEPSICO 2022 10K, PDF p64 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PEPSICO_2022_10K.pdf#page=64&search=Table%20of%20Contents%20Consolidated%20Statement%20of), available by 2024-12-03.
