# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
What is the FY2022 unadjusted EBITDA less capex for PepsiCo? Define unadjusted EBITDA as unadjusted operating income + depreciation and amortization [from cash flow statement]. Answer in USD millions. Respond to the question by assuming the perspective of an investment analyst who can only use the details shown within the statement of cash flows and the income statement.

## Answer

PepsiCo’s unadjusted EBITDA exceeded capital expenditures by USD 9,068 million for the full fiscal year ended December 31, 2022. The calculation uses the first annual column in both consolidated statements. Reported operating profit of USD 11,512 million plus cash-flow depreciation and amortization of USD 2,763 million gives unadjusted EBITDA of USD 14,275 million under the requested definition. The cash-flow statement shows capital spending of USD (5,207) million; the calculation subtracts the magnitude of that outflow from EBITDA. [1, PDF p62 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PEPSICO_2022_10K.pdf#page=62&search=Table%20of%20Contents%20Consolidated%20Statement%20of) [2, PDF p64 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PEPSICO_2022_10K.pdf#page=64&search=Table%20of%20Contents%20Consolidated%20Statement%20of)

## Evidence

Using net capital spending would give a higher result: the cash-flow statement lists proceeds from sales of property, plant and equipment separately from capital spending. Those proceeds do not reduce the requested deduction. The result measures EBITDA less capex, not free cash flow, because the starting point is reported operating profit rather than cash provided by operating activities. [2, PDF p64 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PEPSICO_2022_10K.pdf#page=64&search=Table%20of%20Contents%20Consolidated%20Statement%20of) [1, PDF p62 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PEPSICO_2022_10K.pdf#page=62&search=Table%20of%20Contents%20Consolidated%20Statement%20of)

## Outlook

Capital spending increased by more than unadjusted EBITDA from the prior fiscal year, so EBITDA less capex declined. If that pattern continued, the measure would decline again the next fiscal year. The signal for a reversal would be a year-over-year increase in operating profit plus depreciation and amortization greater than the increase in capital spending. The historical statements establish the comparison, not which outcome is more likely. [1, PDF p62 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PEPSICO_2022_10K.pdf#page=62&search=Table%20of%20Contents%20Consolidated%20Statement%20of) [2, PDF p64 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PEPSICO_2022_10K.pdf#page=64&search=Table%20of%20Contents%20Consolidated%20Statement%20of)

## Checked calculations

- C1. unadjusted EBITDA (USD millions) — 11,512 + 2,763 = 14,275 [1, PDF p62 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PEPSICO_2022_10K.pdf#page=62&search=Table%20of%20Contents%20Consolidated%20Statement%20of) [2, PDF p64 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PEPSICO_2022_10K.pdf#page=64&search=Table%20of%20Contents%20Consolidated%20Statement%20of)
- C2. unadjusted EBITDA less capex (USD millions) — C1 + (5,207) = 9,068 [1, PDF p62 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PEPSICO_2022_10K.pdf#page=62&search=Table%20of%20Contents%20Consolidated%20Statement%20of) [2, PDF p64 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PEPSICO_2022_10K.pdf#page=64&search=Table%20of%20Contents%20Consolidated%20Statement%20of)

## Sources

1. [PEPSICO 2022 10K, PDF p62 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PEPSICO_2022_10K.pdf#page=62&search=Table%20of%20Contents%20Consolidated%20Statement%20of), available by 2024-12-03.
2. [PEPSICO 2022 10K, PDF p64 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PEPSICO_2022_10K.pdf#page=64&search=Table%20of%20Contents%20Consolidated%20Statement%20of), available by 2024-12-03.
