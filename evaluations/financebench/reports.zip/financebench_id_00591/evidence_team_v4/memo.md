# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
Does Adobe have an improving Free cashflow conversion as of FY2022?

## Answer

Yes. Adobe’s free cash flow conversion rose from 142.7209% in FY2021 to 155.5088% in FY2022, a gain of 12.788 percentage points. Conversion is (operating cash flow minus capital expenditures) divided by GAAP net income. It measures free cash flow per dollar of earnings, not the growth rate of free cash flow itself. From 100.9125% in FY2020, conversion rose in both annual comparisons. That supports calling the improvement sustained over the observed period, but it does not establish that the trend continued afterward. [1, PDF p57 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=57&search=Table%20of%20Contents%20ADOBE%20%7C%20INC.)

## Evidence

Adobe generated more free cash flow each year even as GAAP net income fell, so the higher ratio was not merely the result of lower earnings. In chronological order from FY2020 through FY2022, Adobe’s annual filing reports operating cash flow of USD 5,727 million, USD 7,230 million and USD 7,838 million. Capital expenditures are cash purchases of property and equipment, not total investing outflows. Subtracting the reported outflows of USD (419) million, USD (348) million and USD (442) million at their absolute amounts gives free cash flow of USD 5,308 million, USD 6,882 million and USD 7,396 million, respectively. GAAP net income was USD 5,260 million, USD 4,822 million and USD 4,756 million in the same years. [2, PDF p47 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=47&search=Table%20of%20Contents%20LIQUIDITY%20AND%20CAPITAL) [1, PDF p57 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=57&search=Table%20of%20Contents%20ADOBE%20%7C%20INC.)

Higher conversion does not by itself show that customers paid faster. From FY2021 to FY2022, the noncash stock-based compensation expense added back to earnings rose from USD 1,069 million to USD 1,440 million. Meanwhile, the cash contribution from deferred revenue fell from USD 1,053 million to USD 536 million. The ratio improved despite that smaller working-capital inflow. [1, PDF p57 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=57&search=Table%20of%20Contents%20ADOBE%20%7C%20INC.)

## Outlook

The base case from FY2022 is that free cash flow remains above GAAP net income in the following fiscal year, not that conversion necessarily rises again. The alternative is that a further drop in deferred-revenue inflows or higher capital spending cuts free cash flow relative to earnings. The test is the same ratio in the next annual cash-flow statement: a lower reading would break the upward trend, while free cash flow at or below net income would overturn the base case. [1, PDF p57 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=57&search=Table%20of%20Contents%20ADOBE%20%7C%20INC.)

## Checked calculations

- C1. free cash flow (USD millions) — 5,727 + (419) = 5,308 [1, PDF p57 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=57&search=Table%20of%20Contents%20ADOBE%20%7C%20INC.)
- C2. free cash flow / GAAP net income (percent) — C1 ÷ 5,260 × 100 ≈ 100.912548 [1, PDF p57 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=57&search=Table%20of%20Contents%20ADOBE%20%7C%20INC.)
- C3. free cash flow (USD millions) — 7,230 + (348) = 6,882 [1, PDF p57 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=57&search=Table%20of%20Contents%20ADOBE%20%7C%20INC.)
- C4. free cash flow / GAAP net income (percent) — C3 ÷ 4,822 × 100 ≈ 142.720863 [1, PDF p57 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=57&search=Table%20of%20Contents%20ADOBE%20%7C%20INC.)
- C5. free cash flow (USD millions) — 7,838 + (442) = 7,396 [1, PDF p57 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=57&search=Table%20of%20Contents%20ADOBE%20%7C%20INC.)
- C6. free cash flow / GAAP net income (percent) — C5 ÷ 4,756 × 100 ≈ 155.508831 [1, PDF p57 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=57&search=Table%20of%20Contents%20ADOBE%20%7C%20INC.)
- C7. year-over-year conversion change (percentage points) — C6 − C4 ≈ 12.787968 [1, PDF p57 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=57&search=Table%20of%20Contents%20ADOBE%20%7C%20INC.)

## Sources

1. [ADOBE 2022 10K, PDF p57 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=57&search=Table%20of%20Contents%20ADOBE%20%7C%20INC.), available by 2024-12-03.
2. [ADOBE 2022 10K, PDF p47 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=47&search=Table%20of%20Contents%20LIQUIDITY%20AND%20CAPITAL), available by 2024-12-03.
