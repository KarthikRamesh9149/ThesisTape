# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
Does Adobe have an improving Free cashflow conversion as of FY2022?

## Answer

Yes. Adobe’s free cash flow conversion rose from 142.7209% in FY2021 to 155.5088% in FY2022, an improvement of 12.788 percentage points. Adobe generated more cash after capital spending per dollar of GAAP net income. That establishes a year-over-year improvement, not a sustained trend. [1, PDF p57 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=57&search=Table%20of%20Contents%20ADOBE%20%7C%20INC.)

## Evidence

Conversion is free cash flow divided by GAAP net income. Free cash flow is operating cash flow less cash purchases of property and equipment. All amounts are in USD millions, with cash outflows in parentheses. In FY2021, operating cash flow of 7,230 and a property and equipment outflow of (348) yielded free cash flow of 6,882, against net income of 4,822. In FY2022, operating cash flow of 7,838 and an outflow of (442) yielded free cash flow of 7,396, against net income of 4,756. Operating cash flow growth more than covered the extra capital spending; lower net income also lifted the ratio. [1, PDF p57 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=57&search=Table%20of%20Contents%20ADOBE%20%7C%20INC.) [2, PDF p47 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=47&search=Table%20of%20Contents%20LIQUIDITY%20AND%20CAPITAL)

## What would change the view

The base case is a historical gain without assuming it will recur: Adobe added back more noncash stock compensation, and receivables absorbed less cash than in the prior year. Adobe attributed the increase in receivables to billing timing. A durable improvement in cash generation is the alternative. A further annual conversion gain with rising net income and no larger stock compensation add-back or benefit from receivables timing would strengthen that interpretation. A reversal as receivables absorb more cash would favor the timing explanation. [1, PDF p57 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=57&search=Table%20of%20Contents%20ADOBE%20%7C%20INC.) [3, PDF p47 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=47&search=adjusted%20for%20the%20net%20effect%20of)

## Checked calculations

- C1. Current year free cash flow (USD millions) — 7,838 + (442) = 7,396 [1, PDF p57 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=57&search=Table%20of%20Contents%20ADOBE%20%7C%20INC.)
- C2. Prior year free cash flow (USD millions) — 7,230 + (348) = 6,882 [1, PDF p57 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=57&search=Table%20of%20Contents%20ADOBE%20%7C%20INC.)
- C3. Current year free cash flow to GAAP net income (percent) — C1 ÷ 4,756 × 100 ≈ 155.508831 [1, PDF p57 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=57&search=Table%20of%20Contents%20ADOBE%20%7C%20INC.)
- C4. Prior year free cash flow to GAAP net income (percent) — C2 ÷ 4,822 × 100 ≈ 142.720863 [1, PDF p57 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=57&search=Table%20of%20Contents%20ADOBE%20%7C%20INC.)
- C5. Year-over-year change in free cash flow conversion (percentage points) — C3 − C4 ≈ 12.787968 [1, PDF p57 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=57&search=Table%20of%20Contents%20ADOBE%20%7C%20INC.)

## Sources

1. [ADOBE 2022 10K, PDF p57 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=57&search=Table%20of%20Contents%20ADOBE%20%7C%20INC.), available by 2024-12-03.
2. [ADOBE 2022 10K, PDF p47 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=47&search=Table%20of%20Contents%20LIQUIDITY%20AND%20CAPITAL), available by 2024-12-03.
3. [ADOBE 2022 10K, PDF p47 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ADOBE_2022_10K.pdf#page=47&search=adjusted%20for%20the%20net%20effect%20of), available by 2024-12-03.
