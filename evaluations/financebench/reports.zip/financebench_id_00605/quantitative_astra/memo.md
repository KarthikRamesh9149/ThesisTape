# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
What percent of Ulta Beauty's total spend on stock repurchases for FY 2023 occurred in Q4 of FY2023?

## Answer

Ulta Beauty’s fourth-quarter share of fiscal 2023 stock repurchase spending cannot be determined from the supplied disclosures. They report neither actual fourth-quarter spending nor actual full-year spending for the requested year. The only repurchase amount given for that year is a full-year plan of approximately $900 million, not an actual denominator. [1, PDF p3 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ULTABEAUTY_2023Q4_EARNINGS.pdf#page=3&search=Diluted%20earnings%20per%20share%20increased%2033.5%25) [2, PDF p3 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ULTABEAUTY_2023Q4_EARNINGS.pdf#page=3&search=Fiscal%202023%20Outlook%20For%20fiscal%202023%2C)

## Evidence

The fiscal-year label resolves the apparent alternative: the release covers the year ended January 28, 2023, which Ulta calls fiscal 2022. Its share repurchase program cost $328.1 million in the fourth quarter and $900.0 million for the full year. Those amounts are comparable, but dividing them would measure the prior year’s spending pattern. [3, PDF p1 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ULTABEAUTY_2023Q4_EARNINGS.pdf#page=1&search=March%209%2C%202023%20Ulta%20Beauty%20Announces) [1, PDF p3 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ULTABEAUTY_2023Q4_EARNINGS.pdf#page=3&search=Diluted%20earnings%20per%20share%20increased%2033.5%25)

## What would change the view

The missing evidence is Ulta’s actual fourth-quarter program cost in its fiscal 2023 results and the corresponding full-year program cost in its annual disclosure. Dividing the former by the latter and expressing the result as a percentage would answer the question without mixing program repurchases with separately reported treasury-share purchases. [1, PDF p3 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ULTABEAUTY_2023Q4_EARNINGS.pdf#page=3&search=Diluted%20earnings%20per%20share%20increased%2033.5%25) [4, PDF p8 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ULTABEAUTY_2023Q4_EARNINGS.pdf#page=8&search=Exhibit%204%20Ulta%20Beauty%2C%20Inc.%20Condensed)

## Sources

1. [ULTABEAUTY 2023Q4 EARNINGS, PDF p3 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ULTABEAUTY_2023Q4_EARNINGS.pdf#page=3&search=Diluted%20earnings%20per%20share%20increased%2033.5%25), available by 2024-12-03.
2. [ULTABEAUTY 2023Q4 EARNINGS, PDF p3 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ULTABEAUTY_2023Q4_EARNINGS.pdf#page=3&search=Fiscal%202023%20Outlook%20For%20fiscal%202023%2C), available by 2024-12-03.
3. [ULTABEAUTY 2023Q4 EARNINGS, PDF p1 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ULTABEAUTY_2023Q4_EARNINGS.pdf#page=1&search=March%209%2C%202023%20Ulta%20Beauty%20Announces), available by 2024-12-03.
4. [ULTABEAUTY 2023Q4 EARNINGS, PDF p8 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ULTABEAUTY_2023Q4_EARNINGS.pdf#page=8&search=Exhibit%204%20Ulta%20Beauty%2C%20Inc.%20Condensed), available by 2024-12-03.
