# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
What percent of Ulta Beauty's total spend on stock repurchases for FY 2023 occurred in Q4 of FY2023?

Some parts of the question could not be established from eligible evidence.

## Answer

Ulta Beauty’s fourth-quarter share of fiscal 2023 stock repurchase spending cannot be determined from the supplied disclosures as of 2024-12-04T00:00:00Z. Ulta identifies the quarter and year ended January 28, 2023 as fiscal 2022. Using that release’s actual spending—$328.1 million in the fourth quarter and $900.0 million for the full year—would measure the timing of the prior year’s buybacks, not the requested year’s. [1, PDF p1 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ULTABEAUTY_2023Q4_EARNINGS.pdf#page=1&search=March%209%2C%202023%20Ulta%20Beauty%20Announces) [2, PDF p3 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ULTABEAUTY_2023Q4_EARNINGS.pdf#page=3&search=Diluted%20earnings%20per%20share%20increased%2033.5%25)

## Evidence

The disclosures do not verify the requested quarter and year’s reporting dates or either period’s actual repurchase cost. Ulta’s fiscal 2023 outlook called for approximately $900 million of repurchases. Even if Ulta spent exactly what it planned, the annual total would not show how much it spent in the fourth quarter. The $1.1 billion remaining under the program was unused authorization, not spending. [3, PDF p3 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ULTABEAUTY_2023Q4_EARNINGS.pdf#page=3&search=Fiscal%202023%20Outlook%20For%20fiscal%202023%2C) [2, PDF p3 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ULTABEAUTY_2023Q4_EARNINGS.pdf#page=3&search=Diluted%20earnings%20per%20share%20increased%2033.5%25)

## What would change the view

The decisive evidence would be Ulta’s fiscal 2023 year-end results identifying the reporting periods and giving actual repurchase costs for both, as its prior-year release did. Dividing the fourth-quarter cost by the full-year cost on that same basis and expressing the ratio as a percentage would answer the question. [2, PDF p3 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ULTABEAUTY_2023Q4_EARNINGS.pdf#page=3&search=Diluted%20earnings%20per%20share%20increased%2033.5%25)

## Sources

1. [ULTABEAUTY 2023Q4 EARNINGS, PDF p1 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ULTABEAUTY_2023Q4_EARNINGS.pdf#page=1&search=March%209%2C%202023%20Ulta%20Beauty%20Announces), available by 2024-12-03.
2. [ULTABEAUTY 2023Q4 EARNINGS, PDF p3 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ULTABEAUTY_2023Q4_EARNINGS.pdf#page=3&search=Diluted%20earnings%20per%20share%20increased%2033.5%25), available by 2024-12-03.
3. [ULTABEAUTY 2023Q4 EARNINGS, PDF p3 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ULTABEAUTY_2023Q4_EARNINGS.pdf#page=3&search=Fiscal%202023%20Outlook%20For%20fiscal%202023%2C), available by 2024-12-03.
