# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
Are JnJ's FY2022 financials that of a high growth company?

Some parts of the question could not be established from eligible evidence.

## Answer

No. Johnson & Johnson’s FY2022 results do not support a high-growth classification. For this assessment, high growth means sustained double-digit growth in consolidated sales supported by rising earnings. From FY2021 to FY2022, the Consolidated Statements of Earnings show that sales rose from USD 93,775 million to USD 94,943 million (1.2455). Net earnings fell from USD 20,878 million to USD 17,941 million (-14.0674), and diluted earnings per share fell from USD 7.81 to USD 6.73 (-13.8284). Sales growth missed the benchmark, and earnings declined both overall and per share. [1, PDF p47 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JOHNSON_JOHNSON_2022_10K.pdf#page=47&search=JOHNSON%20%26%20JOHNSON%20AND%20SUBSIDIARIES%20CONSOLIDATED)

## Evidence

The decline in reported GAAP earnings was not solely a tax effect: pretax earnings fell, and a higher tax provision widened the decline in net earnings. One-time vaccine manufacturing exit costs also weighed on profitability. The available excerpts contain no comparable adjusted earnings reconciliation, so they do not establish whether adjusted diluted earnings per share rose or fell. [1, PDF p47 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JOHNSON_JOHNSON_2022_10K.pdf#page=47&search=JOHNSON%20%26%20JOHNSON%20AND%20SUBSIDIARIES%20CONSOLIDATED) [2, PDF p34 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JOHNSON_JOHNSON_2022_10K.pdf#page=34&search=Analysis%20of%20Consolidated%20Earnings%20Before%20Provision) [3, PDF p56 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JOHNSON_JOHNSON_2022_10K.pdf#page=56&search=The%20Company%20has%20recorded%20deferred%20tax)

C4. Worldwide operational sales growth (%) — 6.9 + (0.8) = 6.1 [4, PDF p28 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JOHNSON_JOHNSON_2022_10K.pdf#page=28&search=Results%20of%20Operations%20Analysis%20of%20Consolidated)

## Outlook

Based on the FY2022 evidence, the base case for the next comparable fiscal year is positive sales growth below double digits. The 13.6% increase in FY2021 shows that a double-digit year was possible, but the five-year worldwide compound annual growth rate of 4.4% argues against treating that pace as persistent. A smaller currency drag could lift reported growth without faster volume growth. I would change the classification if comparable annual results showed sustained double-digit growth in both operational and reported sales alongside rising diluted earnings per share. That is a test for subsequent results, not company guidance. [4, PDF p28 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JOHNSON_JOHNSON_2022_10K.pdf#page=28&search=Results%20of%20Operations%20Analysis%20of%20Consolidated)

## Checked calculations

- C1. Reported consolidated revenue growth (%) — (94,943 − 93,775) ÷ |93,775| × 100 ≈ 1.245535 [1, PDF p47 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JOHNSON_JOHNSON_2022_10K.pdf#page=47&search=JOHNSON%20%26%20JOHNSON%20AND%20SUBSIDIARIES%20CONSOLIDATED)
- C2. Reported consolidated net earnings growth (%) — (17,941 − 20,878) ÷ |20,878| × 100 ≈ -14.067439 [1, PDF p47 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JOHNSON_JOHNSON_2022_10K.pdf#page=47&search=JOHNSON%20%26%20JOHNSON%20AND%20SUBSIDIARIES%20CONSOLIDATED)
- C3. Reported diluted EPS growth (%) — (6.73 − 7.81) ÷ |7.81| × 100 ≈ -13.828425 [1, PDF p47 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JOHNSON_JOHNSON_2022_10K.pdf#page=47&search=JOHNSON%20%26%20JOHNSON%20AND%20SUBSIDIARIES%20CONSOLIDATED)

## Sources

1. [JOHNSON JOHNSON 2022 10K, PDF p47 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JOHNSON_JOHNSON_2022_10K.pdf#page=47&search=JOHNSON%20%26%20JOHNSON%20AND%20SUBSIDIARIES%20CONSOLIDATED), available by 2024-12-03.
2. [JOHNSON JOHNSON 2022 10K, PDF p34 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JOHNSON_JOHNSON_2022_10K.pdf#page=34&search=Analysis%20of%20Consolidated%20Earnings%20Before%20Provision), available by 2024-12-03.
3. [JOHNSON JOHNSON 2022 10K, PDF p56 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JOHNSON_JOHNSON_2022_10K.pdf#page=56&search=The%20Company%20has%20recorded%20deferred%20tax), available by 2024-12-03.
4. [JOHNSON JOHNSON 2022 10K, PDF p28 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JOHNSON_JOHNSON_2022_10K.pdf#page=28&search=Results%20of%20Operations%20Analysis%20of%20Consolidated), available by 2024-12-03.
