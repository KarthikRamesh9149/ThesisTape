# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
Are JnJ's FY2022 financials that of a high growth company?

## Answer

No. Johnson & Johnson’s consolidated GAAP results from FY2021 to FY2022 do not support a high-growth label. Sales rose from USD 93,775 million to USD 94,943 million (1.2455), but net earnings fell from USD 20,878 million to USD 17,941 million (-14.0674). Diluted EPS fell from USD 7.81 to USD 6.73 (-13.8284). Modest revenue growth did not translate into earnings growth, either in total or per share. [1, PDF p47 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JOHNSON_JOHNSON_2022_10K.pdf#page=47&search=JOHNSON%20%26%20JOHNSON%20AND%20SUBSIDIARIES%20CONSOLIDATED)

## Evidence

The strongest case for faster growth is that exchange rates masked volume gains. In management’s sales breakdown, volume contributed 6.9 percentage points. After the negative pricing contribution of (0.8) points, operational sales growth was 6.1. The currency contribution of (4.8) points brought growth to 1.3% in management’s rounded breakdown, versus 13.6% the prior year. Operational growth excludes currency effects; it is not the increase in reported dollars or a measure of adjusted earnings. [2, PDF p28 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JOHNSON_JOHNSON_2022_10K.pdf#page=28&search=Results%20of%20Operations%20Analysis%20of%20Consolidated)

Profitability weakened even before taxes: the consolidated pretax margin fell from 24.3% to 22.9%. Vaccine manufacturing exit costs, currency effects and commodity inflation raised product costs relative to sales. A higher tax provision further reduced net earnings. The vaccine exit costs were one-time, so reported earnings need not tell the whole story. But the available evidence lacks a consolidated adjusted-EPS reconciliation for both years; it does not establish that adjusted earnings grew. [3, PDF p34 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JOHNSON_JOHNSON_2022_10K.pdf#page=34&search=Analysis%20of%20Consolidated%20Earnings%20Before%20Provision) [1, PDF p47 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JOHNSON_JOHNSON_2022_10K.pdf#page=47&search=JOHNSON%20%26%20JOHNSON%20AND%20SUBSIDIARIES%20CONSOLIDATED)

## Outlook

Moderate sales growth is the base case suggested by the fiscal-year evidence: worldwide sales compounded at 4.4% over five years. A smaller currency drag could lift reported growth without stronger demand. The signal that would change the classification is sustained acceleration in both operational and reported sales across several annual reports, accompanied by rising net earnings and diluted EPS. That is a test for subsequent results, not a forecast counted as FY2022 performance. [2, PDF p28 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JOHNSON_JOHNSON_2022_10K.pdf#page=28&search=Results%20of%20Operations%20Analysis%20of%20Consolidated)

## Checked calculations

- C1. Reported sales growth (%) — (94,943 − 93,775) ÷ |93,775| × 100 ≈ 1.245535 [1, PDF p47 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JOHNSON_JOHNSON_2022_10K.pdf#page=47&search=JOHNSON%20%26%20JOHNSON%20AND%20SUBSIDIARIES%20CONSOLIDATED)
- C2. Reported net earnings growth (%) — (17,941 − 20,878) ÷ |20,878| × 100 ≈ -14.067439 [1, PDF p47 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JOHNSON_JOHNSON_2022_10K.pdf#page=47&search=JOHNSON%20%26%20JOHNSON%20AND%20SUBSIDIARIES%20CONSOLIDATED)
- C3. Reported diluted EPS growth (%) — (6.73 − 7.81) ÷ |7.81| × 100 ≈ -13.828425 [1, PDF p47 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JOHNSON_JOHNSON_2022_10K.pdf#page=47&search=JOHNSON%20%26%20JOHNSON%20AND%20SUBSIDIARIES%20CONSOLIDATED)
- C4. Operational sales growth excluding currency effects (%) — 6.9 + (0.8) = 6.1 [2, PDF p28 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JOHNSON_JOHNSON_2022_10K.pdf#page=28&search=Results%20of%20Operations%20Analysis%20of%20Consolidated)

## Sources

1. [JOHNSON JOHNSON 2022 10K, PDF p47 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JOHNSON_JOHNSON_2022_10K.pdf#page=47&search=JOHNSON%20%26%20JOHNSON%20AND%20SUBSIDIARIES%20CONSOLIDATED), available by 2024-12-03.
2. [JOHNSON JOHNSON 2022 10K, PDF p28 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JOHNSON_JOHNSON_2022_10K.pdf#page=28&search=Results%20of%20Operations%20Analysis%20of%20Consolidated), available by 2024-12-03.
3. [JOHNSON JOHNSON 2022 10K, PDF p34 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JOHNSON_JOHNSON_2022_10K.pdf#page=34&search=Analysis%20of%20Consolidated%20Earnings%20Before%20Provision), available by 2024-12-03.
