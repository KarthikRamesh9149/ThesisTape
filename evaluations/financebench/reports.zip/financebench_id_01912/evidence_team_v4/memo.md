# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
Which region had the worst topline performance for MGM during FY2022?

Some parts of the question could not be established from eligible evidence.

## Evidence

C1. Las Vegas Strip Resorts full-year net revenue change (percent) — (8,398,372 − 4,737,185) ÷ |4,737,185| × 100 ≈ 77.286131 [1, PDF p13 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MGMRESORTS_2022Q4_EARNINGS.pdf#page=13&search=MGM%20RESORTS%20INTERNATIONAL%20AND%20SUBSIDIARIES%20SUPPLEMENTAL)

C2. Regional Operations full-year net revenue change (percent) — (3,815,885 − 3,392,363) ÷ |3,392,363| × 100 ≈ 12.484572 [1, PDF p13 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MGMRESORTS_2022Q4_EARNINGS.pdf#page=13&search=MGM%20RESORTS%20INTERNATIONAL%20AND%20SUBSIDIARIES%20SUPPLEMENTAL)

## Outlook

At year-end, the base case was a revenue rebound over subsequent quarters if easier entry brought visitors back to Macau’s casinos and hotels. MGM identified travel restrictions and a temporary MGM Cotai closure as fourth-quarter headwinds, but did not quantify how much either contributed to the full-year decline. [2, PDF p2 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MGMRESORTS_2022Q4_EARNINGS.pdf#page=2&search=%E2%80%A2%20%7C%20Adjusted%20Property%20EBITDAR%20margin%282%29)

## What would change the view

The strongest alternative was a profit recovery without sustained revenue growth. MGM reported a return to profitability early in 2023, but that alone does not establish a sales rebound. Rising Macau visitation followed by year-over-year quarterly net revenue growth would support the base case; continued revenue declines despite returning visitors would favor the alternative. The supplied evidence does not resolve that test by the cutoff. [3, PDF p1 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MGMRESORTS_2022Q4_EARNINGS.pdf#page=1&search=Exhibit%2099.1%20MGM%20RESORTS%20INTERNATIONAL%20REPORTS) [2, PDF p2 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MGMRESORTS_2022Q4_EARNINGS.pdf#page=2&search=%E2%80%A2%20%7C%20Adjusted%20Property%20EBITDAR%20margin%282%29)

## Sources

1. [MGMRESORTS 2022Q4 EARNINGS, PDF p13 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MGMRESORTS_2022Q4_EARNINGS.pdf#page=13&search=MGM%20RESORTS%20INTERNATIONAL%20AND%20SUBSIDIARIES%20SUPPLEMENTAL), available by 2024-12-03.
2. [MGMRESORTS 2022Q4 EARNINGS, PDF p2 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MGMRESORTS_2022Q4_EARNINGS.pdf#page=2&search=%E2%80%A2%20%7C%20Adjusted%20Property%20EBITDAR%20margin%282%29), available by 2024-12-03.
3. [MGMRESORTS 2022Q4 EARNINGS, PDF p1 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MGMRESORTS_2022Q4_EARNINGS.pdf#page=1&search=Exhibit%2099.1%20MGM%20RESORTS%20INTERNATIONAL%20REPORTS), available by 2024-12-03.
