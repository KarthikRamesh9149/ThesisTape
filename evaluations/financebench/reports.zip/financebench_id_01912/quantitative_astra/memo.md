# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
Which region had the worst topline performance for MGM during FY2022?

## Answer

MGM China had MGM Resorts International’s weakest topline performance in FY2022, measured by the year-over-year percentage change in reported full-year net revenue. Its net revenue fell from USD 1,210,761 thousand in FY2021 to USD 673,593 thousand in FY2022, a change of -44.3661. It was the only reporting region to decline: Regional Operations grew by 12.4846 and Las Vegas Strip Resorts grew by 77.2861. [1, PDF p13 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MGMRESORTS_2022Q4_EARNINGS.pdf#page=13&search=MGM%20RESORTS%20INTERNATIONAL%20AND%20SUBSIDIARIES%20SUPPLEMENTAL)

## Evidence

Ranking by FY2022 net revenue alone leaves the order unchanged. MGM China was the smallest region, below Regional Operations at USD 3,815,885 thousand and Las Vegas Strip Resorts at USD 8,398,372 thousand. The smaller “Management and other operations” line is not a geographic region. [1, PDF p13 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MGMRESORTS_2022Q4_EARNINGS.pdf#page=13&search=MGM%20RESORTS%20INTERNATIONAL%20AND%20SUBSIDIARIES%20SUPPLEMENTAL)

The ranking establishes reported revenue performance, not underlying growth at comparable properties. The Cosmopolitan acquisition and a full year of Aria and Vdara affected the Las Vegas comparison. MGM also identified Macau travel restrictions as a fourth-quarter headwind for MGM China, but that observation does not quantify their contribution to the full-year decline. [2, PDF p3 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MGMRESORTS_2022Q4_EARNINGS.pdf#page=3&search=Adjusted%20EPS%20The%20following%20table%20reconciles) [3, PDF p2 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MGMRESORTS_2022Q4_EARNINGS.pdf#page=2&search=%E2%80%A2%20%7C%20Adjusted%20Property%20EBITDAR%20margin%282%29)

## Checked calculations

- C1. MGM China net revenue YoY change (%) — (673,593 − 1,210,761) ÷ |1,210,761| × 100 ≈ -44.366147 [1, PDF p13 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MGMRESORTS_2022Q4_EARNINGS.pdf#page=13&search=MGM%20RESORTS%20INTERNATIONAL%20AND%20SUBSIDIARIES%20SUPPLEMENTAL)
- C2. Regional Operations net revenue YoY change (%) — (3,815,885 − 3,392,363) ÷ |3,392,363| × 100 ≈ 12.484572 [1, PDF p13 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MGMRESORTS_2022Q4_EARNINGS.pdf#page=13&search=MGM%20RESORTS%20INTERNATIONAL%20AND%20SUBSIDIARIES%20SUPPLEMENTAL)
- C3. Las Vegas Strip Resorts net revenue YoY change (%) — (8,398,372 − 4,737,185) ÷ |4,737,185| × 100 ≈ 77.286131 [1, PDF p13 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MGMRESORTS_2022Q4_EARNINGS.pdf#page=13&search=MGM%20RESORTS%20INTERNATIONAL%20AND%20SUBSIDIARIES%20SUPPLEMENTAL)

## Sources

1. [MGMRESORTS 2022Q4 EARNINGS, PDF p13 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MGMRESORTS_2022Q4_EARNINGS.pdf#page=13&search=MGM%20RESORTS%20INTERNATIONAL%20AND%20SUBSIDIARIES%20SUPPLEMENTAL), available by 2024-12-03.
2. [MGMRESORTS 2022Q4 EARNINGS, PDF p3 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MGMRESORTS_2022Q4_EARNINGS.pdf#page=3&search=Adjusted%20EPS%20The%20following%20table%20reconciles), available by 2024-12-03.
3. [MGMRESORTS 2022Q4 EARNINGS, PDF p2 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/MGMRESORTS_2022Q4_EARNINGS.pdf#page=2&search=%E2%80%A2%20%7C%20Adjusted%20Property%20EBITDAR%20margin%282%29), available by 2024-12-03.
