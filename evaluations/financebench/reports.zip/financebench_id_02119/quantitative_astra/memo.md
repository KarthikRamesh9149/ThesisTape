# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
If JPM went bankrupted by the end by 2021 Q1 and liquidated all of its assets to pay its shareholders, how much could each shareholder get?

## Answer

In the hypothetical liquidation of JPMorgan Chase & Co. on March 31, 2021, the book-value estimate was USD 82.31 per JPM common share. A holder’s estimated proceeds would equal that amount times the number of shares held. The bankruptcy is an unverified question premise, not a reported event. The estimate assumes assets sell at their carrying values, liabilities and preferred claims are settled at their recorded amounts, and no liquidation costs reduce the remainder. Actual sale prices, costs and senior claims could leave common shareholders with nothing. [1, PDF p1 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=1&search=UNITED%20STATES%20SECURITIES%20AND%20EXCHANGE%20COMMISSION) [2, PDF p3 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=3&search=JPMorgan%20Chase%20%26%20Co.%20Consolidated%20financial)

## Evidence

Consolidated assets minus liabilities already equaled total stockholders’ equity of USD 280,714 million. Subtracting preferred stock of USD 31,563 million left USD 249,151 million of common equity. Dividing by the 3,027.1 million common shares outstanding at quarter-end gives approximately USD 82.31 per share (unrounded calculation: 82.3068). The quarter’s weighted-average diluted share count measures earnings per share, not how many common shares would divide the quarter-end remainder. [3, PDF p82 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=82&search=JPMorgan%20Chase%20%26%20Co.%20Consolidated%20statements) [2, PDF p3 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=3&search=JPMorgan%20Chase%20%26%20Co.%20Consolidated%20financial) [4, PDF p148 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=148&search=Note%20%7C%2018%20%7C%20%E2%80%93%20%7C)

## What would change the view

JPMorgan’s tangible book value of USD 66.56 per share adjusts for goodwill, other intangibles and related deferred taxes. It is another accounting measure, not a minimum payout. The decisive evidence would be the cash left at the end of the wind-down: if asset sale proceeds did not exceed liquidation costs, creditor claims and preferred shareholders’ claims, common shares would receive zero. The quarter-end accounts establish neither those proceeds nor the timing of a distribution. [5, PDF p17 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=17&search=The%20following%20summary%20table%20provides%20a)

## Checked calculations

- C1. Subtract (USD millions) — 280,714 − 31,563 = 249,151 [3, PDF p82 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=82&search=JPMorgan%20Chase%20%26%20Co.%20Consolidated%20statements)
- C2. Book-value liquidation estimate per common share (USD per common share) — C1 ÷ 3,027.1 ≈ 82.306828 [3, PDF p82 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=82&search=JPMorgan%20Chase%20%26%20Co.%20Consolidated%20statements) [2, PDF p3 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=3&search=JPMorgan%20Chase%20%26%20Co.%20Consolidated%20financial)

## Sources

1. [JPMORGAN 2021Q1 10Q, PDF p1 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=1&search=UNITED%20STATES%20SECURITIES%20AND%20EXCHANGE%20COMMISSION), available by 2024-12-03.
2. [JPMORGAN 2021Q1 10Q, PDF p3 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=3&search=JPMorgan%20Chase%20%26%20Co.%20Consolidated%20financial), available by 2024-12-03.
3. [JPMORGAN 2021Q1 10Q, PDF p82 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=82&search=JPMorgan%20Chase%20%26%20Co.%20Consolidated%20statements), available by 2024-12-03.
4. [JPMORGAN 2021Q1 10Q, PDF p148 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=148&search=Note%20%7C%2018%20%7C%20%E2%80%93%20%7C), available by 2024-12-03.
5. [JPMORGAN 2021Q1 10Q, PDF p17 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=17&search=The%20following%20summary%20table%20provides%20a), available by 2024-12-03.
