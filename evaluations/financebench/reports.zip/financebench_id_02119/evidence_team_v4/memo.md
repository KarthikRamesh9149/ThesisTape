# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
If JPM went bankrupted by the end by 2021 Q1 and liquidated all of its assets to pay its shareholders, how much could each shareholder get?

Some parts of the question could not be established from eligible evidence.

## Answer

For each JPMorgan Chase & Co. common share held on March 31, 2021, the carrying-value liquidation estimate is slightly below the reported book value of USD 82.31 per share. Bankruptcy is an unverified premise of the question, not a reported event. Creditors would be paid first, preferred shareholders next, and common shareholders would divide only the remainder. The actual payout per common share is therefore unknown and could be zero. [1, PDF p1 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=1&search=UNITED%20STATES%20SECURITIES%20AND%20EXCHANGE%20COMMISSION) [2, PDF p5 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=5&search=Return%20on%20common%20equity%20%7C%2023) [3, PDF p147 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=147&search=%28b%29%20%7C%20No%20dividends%20were%20declared)

## Evidence

The filing verifies the book value of assets *net of liabilities*: USD 280,714 million of total stockholders’ equity. The supplied excerpts do not show gross quarter-end assets and liabilities separately, so neither total can be independently verified here. Deducting preferred stock at its carrying value of USD 31,563 million leaves USD 249,151 million of common book equity, which the funding table also reports directly. [4, PDF p82 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=82&search=JPMorgan%20Chase%20%26%20Co.%20Consolidated%20statements) [5, PDF p44 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=44&search=Total%20long-term%20secured%20funding%20%7C%20%24)

Common book equity divided by reported book value per share implies approximately 3,026.9834 million quarter-end common shares. This is an estimate because the per-share figure is rounded; the excerpts do not give an exact closing share count. The 3,073.5 million basic shares used for earnings per share are a quarterly weighted average, not the shares that would divide a quarter-end distribution. [4, PDF p82 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=82&search=JPMorgan%20Chase%20%26%20Co.%20Consolidated%20statements) [2, PDF p5 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=5&search=Return%20on%20common%20equity%20%7C%2023) [6, PDF p148 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=148&search=Note%20%7C%2018%20%7C%20%E2%80%93%20%7C)

## What would change the view

The decisive test during liquidation would be realized sale proceeds versus wind-down costs, allowed creditor claims and preferred entitlements. If proceeds did not exceed that total, common shareholders would receive nothing. JPMorgan’s reported nonperforming assets illustrate why sale proceeds might differ from book values, but they do not establish a liquidation loss, payout amount or payment date. [2, PDF p5 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=5&search=Return%20on%20common%20equity%20%7C%2023) [3, PDF p147 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=147&search=%28b%29%20%7C%20No%20dividends%20were%20declared)

## Checked calculations

- C1. Common equity at carrying value (USD millions) — 280,714 − 31,563 = 249,151 [4, PDF p82 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=82&search=JPMorgan%20Chase%20%26%20Co.%20Consolidated%20statements)
- C2. Implied quarter-end common shares outstanding (million shares) — C1 ÷ 82.31 ≈ 3,026.983356 [4, PDF p82 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=82&search=JPMorgan%20Chase%20%26%20Co.%20Consolidated%20statements) [2, PDF p5 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=5&search=Return%20on%20common%20equity%20%7C%2023)

## Sources

1. [JPMORGAN 2021Q1 10Q, PDF p1 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=1&search=UNITED%20STATES%20SECURITIES%20AND%20EXCHANGE%20COMMISSION), available by 2024-12-03.
2. [JPMORGAN 2021Q1 10Q, PDF p5 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=5&search=Return%20on%20common%20equity%20%7C%2023), available by 2024-12-03.
3. [JPMORGAN 2021Q1 10Q, PDF p147 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=147&search=%28b%29%20%7C%20No%20dividends%20were%20declared), available by 2024-12-03.
4. [JPMORGAN 2021Q1 10Q, PDF p82 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=82&search=JPMorgan%20Chase%20%26%20Co.%20Consolidated%20statements), available by 2024-12-03.
5. [JPMORGAN 2021Q1 10Q, PDF p44 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=44&search=Total%20long-term%20secured%20funding%20%7C%20%24), available by 2024-12-03.
6. [JPMORGAN 2021Q1 10Q, PDF p148 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/JPMORGAN_2021Q1_10Q.pdf#page=148&search=Note%20%7C%2018%20%7C%20%E2%80%93%20%7C), available by 2024-12-03.
