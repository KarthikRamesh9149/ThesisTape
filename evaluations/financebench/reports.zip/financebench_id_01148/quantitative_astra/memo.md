# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
What industry does AMCOR primarily operate in?

## Answer

As of 2024-12-04T00:00:00Z, Amcor plc’s primary industry was packaging manufacturing. Its Flexibles and Rigid Packaging businesses accounted for all reported net sales in fiscal 2023: approximately 76% came from Flexibles and 24% from Rigid Packaging. That sales mix supports the classification without relying on any proposed transaction. [1, PDF p7 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AMCOR_2023_10K.pdf#page=7&search=Segment%20Information%20Accounting%20Standards%20Codification%20%28%22ASC%22%29) [2, PDF p101 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AMCOR_2023_10K.pdf#page=101&search=The%20following%20table%20presents%20information%20about)

## Evidence

Flexible packaging was Amcor’s largest line, but it is too narrow a label for the company: Amcor also sold rigid containers, preforms and closures. Food, beverage and healthcare were customer markets, not competing descriptions of what Amcor made. [3, PDF p102 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AMCOR_2023_10K.pdf#page=102&search=The%20tables%20below%20present%20additional%20financial) [4, PDF p55 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AMCOR_2023_10K.pdf#page=55&search=Amcor%20plc%20and%20Subsidiaries%20Notes%20to)

## What would change the view

The segment figures establish the historical sales mix, not the exact mix on the cutoff date. A later operating disclosure showing that a non-packaging business had become Amcor’s largest source of sales by the cutoff would warrant reconsideration; a transaction proposal alone would not. [2, PDF p101 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AMCOR_2023_10K.pdf#page=101&search=The%20following%20table%20presents%20information%20about)

## Sources

1. [AMCOR 2023 10K, PDF p7 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AMCOR_2023_10K.pdf#page=7&search=Segment%20Information%20Accounting%20Standards%20Codification%20%28%22ASC%22%29), available by 2024-12-03.
2. [AMCOR 2023 10K, PDF p101 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AMCOR_2023_10K.pdf#page=101&search=The%20following%20table%20presents%20information%20about), available by 2024-12-03.
3. [AMCOR 2023 10K, PDF p102 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AMCOR_2023_10K.pdf#page=102&search=The%20tables%20below%20present%20additional%20financial), available by 2024-12-03.
4. [AMCOR 2023 10K, PDF p55 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AMCOR_2023_10K.pdf#page=55&search=Amcor%20plc%20and%20Subsidiaries%20Notes%20to), available by 2024-12-03.
