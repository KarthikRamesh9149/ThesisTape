# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
What industry does AMCOR primarily operate in?

## Answer

As of 2024-12-04T00:00:00Z, Amcor plc’s primary industry was packaging manufacturing (containers and packaging). Amcor made flexible packaging, rigid containers, specialty cartons and closures. Food, beverage, pharmaceutical and personal-care companies bought that packaging; their industries describe whom Amcor served, not what it produced. [1, PDF p55 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AMCOR_2023_10K.pdf#page=55&search=Amcor%20plc%20and%20Subsidiaries%20Notes%20to)

## Evidence

Flexible packaging was Amcor’s largest business, but calling it solely a flexible-packaging manufacturer would be too narrow. In fiscal 2023, Flexibles accounted for approximately 76% of consolidated net sales and Rigid Packaging for approximately 24%. That split supports the broader industry classification without establishing the exact sales mix at the cutoff. [2, PDF p7 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AMCOR_2023_10K.pdf#page=7&search=Segment%20Information%20Accounting%20Standards%20Codification%20%28%22ASC%22%29)

## Outlook

The base case for the next reporting period is an unchanged industry classification: a change in customer demand can shift orders between packaging formats without changing Amcor’s principal activity. A filing showing that non-packaging products accounted for most sales would warrant reclassification; a shift between films and rigid containers would not. [3, PDF p14 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AMCOR_2023_10K.pdf#page=14&search=Item%201A.%20-%20Risk%20Factors%20The) [4, PDF p102 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AMCOR_2023_10K.pdf#page=102&search=The%20tables%20below%20present%20additional%20financial)

## Sources

1. [AMCOR 2023 10K, PDF p55 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AMCOR_2023_10K.pdf#page=55&search=Amcor%20plc%20and%20Subsidiaries%20Notes%20to), available by 2024-12-03.
2. [AMCOR 2023 10K, PDF p7 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AMCOR_2023_10K.pdf#page=7&search=Segment%20Information%20Accounting%20Standards%20Codification%20%28%22ASC%22%29), available by 2024-12-03.
3. [AMCOR 2023 10K, PDF p14 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AMCOR_2023_10K.pdf#page=14&search=Item%201A.%20-%20Risk%20Factors%20The), available by 2024-12-03.
4. [AMCOR 2023 10K, PDF p102 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/AMCOR_2023_10K.pdf#page=102&search=The%20tables%20below%20present%20additional%20financial), available by 2024-12-03.
