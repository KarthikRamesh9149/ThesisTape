# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
Among all of the derivative instruments that Verizon used to manage the exposure to fluctuations of foreign currencies exchange rates or interest rates, which one had the highest notional value in FY 2021?

## Answer

The available excerpts do not establish which Verizon derivative had the highest outstanding notional at December 31, 2021, what that maximum was, or whether there was a tie. Forward-starting interest rate swaps had $1.0 billion outstanding, versus no outstanding notional for Treasury rate locks. That ranks those two instruments, not the full portfolio: the filing introduces a table of outstanding notionals, but the supplied excerpt does not show its instrument-by-instrument balances. [1, PDF p85 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/VERIZON_2021_10K.pdf#page=85&search=At%20December%2031%2C%202020%20%7C%20Foreign) [2, PDF p47 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/VERIZON_2021_10K.pdf#page=47&search=Forward%20Starting%20Interest%20Rate%20Swaps%20We)

## Evidence

For interest rate swaps, cross currency swaps and foreign exchange forwards, the activity tables report contracts entered into or settled, not year-end balances. For example, Verizon entered into USD 12,604 million of foreign exchange forwards and settled USD 13,077 million during the year. Neither figure measures what remained outstanding. Likewise, equal swaption notionals sold and settled do not by themselves establish the closing balance, and the filing names interest rate caps as a possible instrument without establishing a year-end position. [3, PDF p86 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/VERIZON_2021_10K.pdf#page=86&search=The%20following%20tables%20summarize%20the%20activities) [4, PDF p87 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/VERIZON_2021_10K.pdf#page=87&search=Treasury%20Rate%20Locks%20We%20enter%20into) [1, PDF p85 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/VERIZON_2021_10K.pdf#page=85&search=At%20December%2031%2C%202020%20%7C%20Foreign)

## What would change the view

The decisive evidence would be the complete outstanding-notional table with instrument labels, units and the year-end column intact. Ranking that column would identify the maximum and any tie. Ranking balance-sheet fair values instead would answer a different question: those values measure what the contracts were worth, not their contractual reference amounts. [1, PDF p85 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/VERIZON_2021_10K.pdf#page=85&search=At%20December%2031%2C%202020%20%7C%20Foreign) [5, PDF p63 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/VERIZON_2021_10K.pdf#page=63&search=We%20enter%20into%20derivative%20transactions%20primarily)

## Sources

1. [VERIZON 2021 10K, PDF p85 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/VERIZON_2021_10K.pdf#page=85&search=At%20December%2031%2C%202020%20%7C%20Foreign), available by 2024-12-03.
2. [VERIZON 2021 10K, PDF p47 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/VERIZON_2021_10K.pdf#page=47&search=Forward%20Starting%20Interest%20Rate%20Swaps%20We), available by 2024-12-03.
3. [VERIZON 2021 10K, PDF p86 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/VERIZON_2021_10K.pdf#page=86&search=The%20following%20tables%20summarize%20the%20activities), available by 2024-12-03.
4. [VERIZON 2021 10K, PDF p87 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/VERIZON_2021_10K.pdf#page=87&search=Treasury%20Rate%20Locks%20We%20enter%20into), available by 2024-12-03.
5. [VERIZON 2021 10K, PDF p63 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/VERIZON_2021_10K.pdf#page=63&search=We%20enter%20into%20derivative%20transactions%20primarily), available by 2024-12-03.
