# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
Among all of the derivative instruments that Verizon used to manage the exposure to fluctuations of foreign currencies exchange rates or interest rates, which one had the highest notional value in FY 2021?

## Answer

Verizon’s cross currency swaps had the highest outstanding notional amount at December 31, 2021: $32.5 billion, versus $19.8 billion for interest rate swaps. The cross currency swaps fixed the dollar cost of foreign-currency payments. Their top ranking measures the amount of contracts outstanding, not their fair value or Verizon’s remaining currency risk. [1, PDF p47 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/VERIZON_2021_10K.pdf#page=47&search=We%20have%20entered%20into%20cross%20currency) [2, PDF p46 §4](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/VERIZON_2021_10K.pdf#page=46&search=%24473%20million%20and%20%24666%20million%2C%20respectively.)

## Evidence

The other disclosed year-end balances were smaller: $1.0 billion for forward starting interest rate swaps, $932 million for foreign exchange forwards and none for treasury rate locks. Ranking contracts by the amount entered into during the year would answer a different question: a contract settled before year-end no longer counts toward outstanding notional. The excerpts do not show the complete year-end notional table; an omitted instrument would change the conclusion only if its notional on that same date exceeded that of the cross currency swaps. [3, PDF p47 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/VERIZON_2021_10K.pdf#page=47&search=Forward%20Starting%20Interest%20Rate%20Swaps%20We) [1, PDF p47 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/VERIZON_2021_10K.pdf#page=47&search=We%20have%20entered%20into%20cross%20currency) [4, PDF p86 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/VERIZON_2021_10K.pdf#page=86&search=The%20following%20tables%20summarize%20the%20activities)

## Sources

1. [VERIZON 2021 10K, PDF p47 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/VERIZON_2021_10K.pdf#page=47&search=We%20have%20entered%20into%20cross%20currency), available by 2024-12-03.
2. [VERIZON 2021 10K, PDF p46 §4](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/VERIZON_2021_10K.pdf#page=46&search=%24473%20million%20and%20%24666%20million%2C%20respectively.), available by 2024-12-03.
3. [VERIZON 2021 10K, PDF p47 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/VERIZON_2021_10K.pdf#page=47&search=Forward%20Starting%20Interest%20Rate%20Swaps%20We), available by 2024-12-03.
4. [VERIZON 2021 10K, PDF p86 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/VERIZON_2021_10K.pdf#page=86&search=The%20following%20tables%20summarize%20the%20activities), available by 2024-12-03.
