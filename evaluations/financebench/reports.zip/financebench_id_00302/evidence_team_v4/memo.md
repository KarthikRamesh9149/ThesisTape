# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
Did Pfizer grow its PPNE between FY20 and FY21?

## Answer

Yes. Pfizer’s consolidated net PP&E rose from USD 13,745 million at FY2020 year-end to USD 14,882 million at FY2021 year-end, an increase of USD 1,137 million. The comparable balance-sheet figures measure the carrying value of Pfizer’s physical assets after accumulated depreciation, not how much Pfizer spent on them. [1, PDF p59 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PFIZER_2021_10K.pdf#page=59&search=Consolidated%20Balance%20Sheets%20Pfizer%20Inc.%20and) [2, PDF p88 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PFIZER_2021_10K.pdf#page=88&search=Land%20%7C%20-%20%24%20%7C%20423)

## Outlook

For FY2022, the base case was a further rise in net PP&E: Pfizer expected to spend approximately $3.3 billion on PP&E. A flat or lower balance was plausible if depreciation and disposals offset additions. The test is whether the next year-end net balance exceeded USD 14,882 million; the spending forecast alone establishes neither actual spending nor the closing balance. [3, PDF p53 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PFIZER_2021_10K.pdf#page=53&search=may%20arise%20in%20connection%20with%20the) [4, PDF p68 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PFIZER_2021_10K.pdf#page=68&search=Notes%20to%20Consolidated%20Financial%20Statements%20Pfizer) [1, PDF p59 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PFIZER_2021_10K.pdf#page=59&search=Consolidated%20Balance%20Sheets%20Pfizer%20Inc.%20and)

## Checked calculations

- C1. Subtract (USD millions) — 14,882 − 13,745 = 1,137 [1, PDF p59 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PFIZER_2021_10K.pdf#page=59&search=Consolidated%20Balance%20Sheets%20Pfizer%20Inc.%20and)

## Sources

1. [PFIZER 2021 10K, PDF p59 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PFIZER_2021_10K.pdf#page=59&search=Consolidated%20Balance%20Sheets%20Pfizer%20Inc.%20and), available by 2024-12-03.
2. [PFIZER 2021 10K, PDF p88 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PFIZER_2021_10K.pdf#page=88&search=Land%20%7C%20-%20%24%20%7C%20423), available by 2024-12-03.
3. [PFIZER 2021 10K, PDF p53 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PFIZER_2021_10K.pdf#page=53&search=may%20arise%20in%20connection%20with%20the), available by 2024-12-03.
4. [PFIZER 2021 10K, PDF p68 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PFIZER_2021_10K.pdf#page=68&search=Notes%20to%20Consolidated%20Financial%20Statements%20Pfizer), available by 2024-12-03.
