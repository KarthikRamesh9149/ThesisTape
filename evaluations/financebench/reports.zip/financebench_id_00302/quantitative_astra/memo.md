# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
Did Pfizer grow its PPNE between FY20 and FY21?

## Answer

Yes. Pfizer’s consolidated net PP&E increased from USD 13,745 million at FY2020 year-end to USD 14,882 million at FY2021 year-end, a gain of USD 1,137 million. The increase was in the carrying value of PP&E after accumulated depreciation. [1, PDF p59 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PFIZER_2021_10K.pdf#page=59&search=Consolidated%20Balance%20Sheets%20Pfizer%20Inc.%20and) [2, PDF p88 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PFIZER_2021_10K.pdf#page=88&search=Land%20%7C%20-%20%24%20%7C%20423)

## Evidence

The separate PP&E disclosure for discontinued operations is not the consolidated PP&E line: Pfizer classified those noncurrent assets under other noncurrent assets. The consolidated balances establish growth in net book value, but they do not by themselves establish an increase in production capacity. [3, PDF p72 §4](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PFIZER_2021_10K.pdf#page=72&search=%28MILLIONS%29%20%7C%202021%20%7C%202020%20Current) [1, PDF p59 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PFIZER_2021_10K.pdf#page=59&search=Consolidated%20Balance%20Sheets%20Pfizer%20Inc.%20and) [4, PDF p68 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PFIZER_2021_10K.pdf#page=68&search=Notes%20to%20Consolidated%20Financial%20Statements%20Pfizer)

## Checked calculations

- C1. Subtract (USD millions) — 14,882 − 13,745 = 1,137 [1, PDF p59 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PFIZER_2021_10K.pdf#page=59&search=Consolidated%20Balance%20Sheets%20Pfizer%20Inc.%20and)

## Sources

1. [PFIZER 2021 10K, PDF p59 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PFIZER_2021_10K.pdf#page=59&search=Consolidated%20Balance%20Sheets%20Pfizer%20Inc.%20and), available by 2024-12-03.
2. [PFIZER 2021 10K, PDF p88 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PFIZER_2021_10K.pdf#page=88&search=Land%20%7C%20-%20%24%20%7C%20423), available by 2024-12-03.
3. [PFIZER 2021 10K, PDF p72 §4](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PFIZER_2021_10K.pdf#page=72&search=%28MILLIONS%29%20%7C%202021%20%7C%202020%20Current), available by 2024-12-03.
4. [PFIZER 2021 10K, PDF p68 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/PFIZER_2021_10K.pdf#page=68&search=Notes%20to%20Consolidated%20Financial%20Statements%20Pfizer), available by 2024-12-03.
