# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
What production rate changes is Boeing forecasting for FY2023?

## Answer

In Boeing’s FY2022 filing, the 787 was the only program with a numerical production target explicitly tied to FY2023: a gradual increase from an unspecified low rate to 5 per month during the year. Boeing also expected the paused 777X to restart during the year and planned further 737 increases from 31 per month, but it gave neither a restart rate for the former nor a target rate or date for the latter. For investors, the Dreamliner target is a factory milestone, not a forecast of annual deliveries or a statement of achieved output. [1, PDF p35 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=35&search=and%20rework.%20At%20December%2031%2C%202022%2C) [2, PDF p9 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=9&search=In%20addition%2C%20we%20have%20experienced%20production) [3, PDF p33 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=33&search=We%20increased%20the%20production%20rate%20to)

The 777X forecast was a change from paused to active production, not a ramp to 3 per month: that figure was the then-current rate for the combined 777/777X programs. The program discussion says the April 2022 decision paused 777X-9 production during 2022 and 2023. A pause extending into the year could coexist with a restart later that year, but the filing does not establish a restart month for the variant. The explicit revision from late 2023 to 2025 concerned first delivery, not the restart date. [2, PDF p9 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=9&search=In%20addition%2C%20we%20have%20experienced%20production) [4, PDF p34 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=34&search=737-10%20aircraft%20in%20inventory%20and%20236) [5, PDF p34 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=34&search=freighter%20during%20the%20first%20quarter%20of)

## Evidence

The Dreamliner slowdown was not a documented cut to the annual rate target. Boeing said it had slowed near-term production in the fourth quarter of 2022 because of supply constraints and higher inspection and rework costs, yet the same discussion retained the 5 per month objective. The available filing excerpts do not establish any subsequent revision to that target or its timing, actual FY2023 output, or a monthly target for a later year. [1, PDF p35 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=35&search=and%20rework.%20At%20December%2031%2C%202022%2C)

Neither the 747 nor the 767 adds a forecast rate change. Boeing finished building the former in the fourth quarter of 2022; early 2023 was the expected final handover. For the latter, Boeing reported a current rate of 3 aircraft per month across commercial and tanker production, with no new rate or effective date. [4, PDF p34 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=34&search=737-10%20aircraft%20in%20inventory%20and%20236)

## Outlook

Base case on Boeing’s stated outlook: Dreamliner builds rise gradually toward the target during FY2023. The strongest alternative is a delayed ramp if parts shortages and rework persist. The test is the monthly pace of new builds: sustained production below target at year-end would signal delay even if deliveries rose, because Boeing could hand over stored aircraft. For the 737, evidence of sustained builds above 31 per month would distinguish an actual increase from the conditional plan. [1, PDF p35 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=35&search=and%20rework.%20At%20December%2031%2C%202022%2C) [3, PDF p33 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=33&search=We%20increased%20the%20production%20rate%20to)

## Sources

1. [BOEING 2022 10K, PDF p35 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=35&search=and%20rework.%20At%20December%2031%2C%202022%2C), available by 2024-12-03.
2. [BOEING 2022 10K, PDF p9 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=9&search=In%20addition%2C%20we%20have%20experienced%20production), available by 2024-12-03.
3. [BOEING 2022 10K, PDF p33 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=33&search=We%20increased%20the%20production%20rate%20to), available by 2024-12-03.
4. [BOEING 2022 10K, PDF p34 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=34&search=737-10%20aircraft%20in%20inventory%20and%20236), available by 2024-12-03.
5. [BOEING 2022 10K, PDF p34 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=34&search=freighter%20during%20the%20first%20quarter%20of), available by 2024-12-03.
