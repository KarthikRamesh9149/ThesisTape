# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
What production rate changes is Boeing forecasting for FY2023?

## Answer

In its FY2022 annual report, Boeing gave only the 787 a numerical FY2023 production target: a gradual increase from an unspecified low rate to 5 per month during the year. Boeing also expected 777X production to resume from a pause during the year, without specifying a monthly restart rate. For the 737, Boeing planned gradual increases from 31 per month, conditional on demand and supply-chain capacity, but gave neither a higher monthly target nor a deadline. Only the first plan therefore provides a numerical benchmark for FY2023 production. [1, PDF p35 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=35&search=and%20rework.%20At%20December%2031%2C%202022%2C) [2, PDF p9 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=9&search=In%20addition%2C%20we%20have%20experienced%20production) [3, PDF p33 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=33&search=We%20increased%20the%20production%20rate%20to)

No in-year revision can be verified from the supplied disclosures as of 2024-12-04T00:00:00Z. The decision to slow near-term 787 production was made in the fourth quarter of 2022, so it was already reflected in the original forecast. Likewise, Boeing decided in April 2022 to pause 777X-9 production. A pause extending into FY2023 is consistent with a restart later that year; the two statements are not evidence of a revision during the year. [1, PDF p35 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=35&search=and%20rework.%20At%20December%2031%2C%202022%2C) [4, PDF p34 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=34&search=freighter%20during%20the%20first%20quarter%20of) [2, PDF p9 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=9&search=In%20addition%2C%20we%20have%20experienced%20production)

## Evidence

The 3 per month figure was the existing combined 777/777X line rate, not the target for the restart. Boeing likewise reported an existing combined 767 commercial and tanker rate of 3 aircraft per month, not a planned change. The final 747 delivery expected in early 2023 was not a production change either: assembly had ended the previous quarter. [5, PDF p34 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=34&search=737-10%20aircraft%20in%20inventory%20and%20236)

## Outlook

The base case in Boeing’s original outlook was a gradual production increase, not an immediate step up. The strongest alternative was a slower increase if suppliers could not support the schedule, as had already happened on the 787. The signal that would establish a forecast revision would be a dated FY2023 Boeing update changing a planned monthly rate or its timing. Delivery totals alone would not establish that: Boeing could deliver aircraft from inventory without raising current production. [1, PDF p35 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=35&search=and%20rework.%20At%20December%2031%2C%202022%2C) [3, PDF p33 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=33&search=We%20increased%20the%20production%20rate%20to)

## Sources

1. [BOEING 2022 10K, PDF p35 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=35&search=and%20rework.%20At%20December%2031%2C%202022%2C), available by 2024-12-03.
2. [BOEING 2022 10K, PDF p9 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=9&search=In%20addition%2C%20we%20have%20experienced%20production), available by 2024-12-03.
3. [BOEING 2022 10K, PDF p33 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=33&search=We%20increased%20the%20production%20rate%20to), available by 2024-12-03.
4. [BOEING 2022 10K, PDF p34 §3](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=34&search=freighter%20during%20the%20first%20quarter%20of), available by 2024-12-03.
5. [BOEING 2022 10K, PDF p34 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/BOEING_2022_10K.pdf#page=34&search=737-10%20aircraft%20in%20inventory%20and%20236), available by 2024-12-03.
