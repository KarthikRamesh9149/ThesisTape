# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
What is the FY2017 - FY2019 3 year average of capex as a % of revenue for Activision Blizzard? Answer in units of percents and round to one decimal place. Calculate (or extract) the answer from the statement of income and the cash flow statement.

Some parts of the question could not be established from eligible evidence.

## Answer

Activision Blizzard spent just under two percent of consolidated net revenue on capital expenditures in an average fiscal year from FY2017 through FY2019. This gives each year equal weight rather than giving the highest-revenue year the most weight. The filing supplies all six inputs, but the verified calculations do not include the mean rounded to one decimal place. [1, PDF p73 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ACTIVISIONBLIZZARD_2019_10K.pdf#page=73&search=Table%20of%20Contents%20ACTIVISION%20BLIZZARD%2C%20INC.) [2, PDF p30 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ACTIVISIONBLIZZARD_2019_10K.pdf#page=30&search=Table%20of%20Contents%20Item%206.%20%7C)

## Evidence

The revenue figures come from the filing’s summary of consolidated statement-of-operations data. They are comparable as reported, but not on a uniform accounting basis: Activision Blizzard adopted a new revenue standard in 2018 without restating FY2017. [2, PDF p30 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ACTIVISIONBLIZZARD_2019_10K.pdf#page=30&search=Table%20of%20Contents%20Item%206.%20%7C) [3, PDF p30 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ACTIVISIONBLIZZARD_2019_10K.pdf#page=30&search=%281%29%20On%20January%201%2C%202018%2C%20we)

C6. Fiscal years in averaging period (years) — 2019 − 2016 = 3 [2, PDF p30 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ACTIVISIONBLIZZARD_2019_10K.pdf#page=30&search=Table%20of%20Contents%20Item%206.%20%7C)

## Sources

1. [ACTIVISIONBLIZZARD 2019 10K, PDF p73 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ACTIVISIONBLIZZARD_2019_10K.pdf#page=73&search=Table%20of%20Contents%20ACTIVISION%20BLIZZARD%2C%20INC.), available by 2024-12-03.
2. [ACTIVISIONBLIZZARD 2019 10K, PDF p30 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ACTIVISIONBLIZZARD_2019_10K.pdf#page=30&search=Table%20of%20Contents%20Item%206.%20%7C), available by 2024-12-03.
3. [ACTIVISIONBLIZZARD 2019 10K, PDF p30 §2](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ACTIVISIONBLIZZARD_2019_10K.pdf#page=30&search=%281%29%20On%20January%201%2C%202018%2C%20we), available by 2024-12-03.
