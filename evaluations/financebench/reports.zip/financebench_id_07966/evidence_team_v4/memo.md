# Investment research memo

As of 2024-12-04T00:00:00Z

**Research question**
What is the FY2017 - FY2019 3 year average of capex as a % of revenue for Activision Blizzard? Answer in units of percents and round to one decimal place. Calculate (or extract) the answer from the statement of income and the cash flow statement.

Some parts of the question could not be established from eligible evidence.

## Answer

Activision Blizzard’s capital expenditures averaged **one and nine-tenths percent** of consolidated net revenue over FY2017–FY2019, rounded to one decimal place. That measures the share of revenue spent on capital expenditures in an average fiscal year: each year receives equal weight, regardless of its revenue. [1, PDF p73 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ACTIVISIONBLIZZARD_2019_10K.pdf#page=73&search=Table%20of%20Contents%20ACTIVISION%20BLIZZARD%2C%20INC.) [2, PDF p70 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ACTIVISIONBLIZZARD_2019_10K.pdf#page=70&search=Table%20of%20Contents%20ACTIVISION%20BLIZZARD%2C%20INC.)

## Sources

1. [ACTIVISIONBLIZZARD 2019 10K, PDF p73 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ACTIVISIONBLIZZARD_2019_10K.pdf#page=73&search=Table%20of%20Contents%20ACTIVISION%20BLIZZARD%2C%20INC.), available by 2024-12-03.
2. [ACTIVISIONBLIZZARD 2019 10K, PDF p70 §1](https://raw.githubusercontent.com/patronus-ai/financebench/cc39aeb4afdf33909ee1412188bf89035950c2eb/pdfs/ACTIVISIONBLIZZARD_2019_10K.pdf#page=70&search=Table%20of%20Contents%20ACTIVISION%20BLIZZARD%2C%20INC.), available by 2024-12-03.
