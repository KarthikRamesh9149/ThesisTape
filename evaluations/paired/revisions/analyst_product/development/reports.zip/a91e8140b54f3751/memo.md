# Investment research memo

As of 2020-05-08T12:00:00Z

Forecast direction: lower

**Research question**
At Nintendo’s FY2020 results, what profit attributable to owners of parent did it guide for the year ending March 2021? Compare it with the just-reported year, discuss the risk to the supply of components, and forecast the full-year actual relative to guidance (within means ±2% of the guide, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Outlook

Lower is my base case, with limited conviction. Demand entered the year strong: Animal Crossing sold 11.77 million units after its March release. Component availability looks more likely than weak consumer interest to constrain sales: a console Nintendo cannot ship costs it a potential hardware sale and delays that buyer’s software purchases. The strongest alternative is within. Delays were easing, their prior-year earnings impact was limited, and Nintendo expected to meet full-year demand and release software as planned. The release does not quantify a parts shortfall large enough to establish a miss. [1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=3&search=Description%20of%20Operating%20Results%201.%20Operating) [2](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=3&search=Net%20cash%20provided%20by%20%28used%20in%29) [3](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=4&search=forecasting%20are%20105%20yen%20per%20US)

As of 2020-05-08T12:00:00Z, my base case is lower than guidance for Nintendo’s year ending March 2021. Nintendo guided to JPY 200,000 million in consolidated profit attributable to owners of parent. The inclusive within-guidance band is an inclusive ±2% band around the reference, calculated by subtracting and adding the stated tolerance times the guide. My call is below the lower endpoint: if component shortages persist, Nintendo could lose Switch sales for the year rather than merely ship them later. [4](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=2&search=Consolidated%20Financial%20Forecast%20for%20the%20Fiscal) [5](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=4&search=There%20are%20concerns%20that%20COVID-19%20will) [2](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=3&search=Net%20cash%20provided%20by%20%28used%20in%29)

## What would change the view

I would switch to within if Nintendo reported that parts were arriving reliably and Switch shipments were filling deferred orders while it maintained its full-year hardware unit forecast. That would distinguish sales shifted between quarters from sales lost for the year; an improving delivery trend alone does not. [2](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=3&search=Net%20cash%20provided%20by%20%28used%20in%29) [6](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=14&search=%284%29%20Consolidated%20sales%20units%2C%20number%20of) [3](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=4&search=forecasting%20are%20105%20yen%20per%20US)

## Sources

1. [Nintendo consolidated financial statements for year ended March 2020, PDF p3 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=3&search=Description%20of%20Operating%20Results%201.%20Operating), available by 2020-05-07.
2. [Nintendo consolidated financial statements for year ended March 2020, PDF p3 §4](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=3&search=Net%20cash%20provided%20by%20%28used%20in%29), available by 2020-05-07.
3. [Nintendo consolidated financial statements for year ended March 2020, PDF p4 §3](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=4&search=forecasting%20are%20105%20yen%20per%20US), available by 2020-05-07.
4. [Nintendo consolidated financial statements for year ended March 2020, PDF p2 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=2&search=Consolidated%20Financial%20Forecast%20for%20the%20Fiscal), available by 2020-05-07.
5. [Nintendo consolidated financial statements for year ended March 2020, PDF p4 §2](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=4&search=There%20are%20concerns%20that%20COVID-19%20will), available by 2020-05-07.
6. [Nintendo consolidated financial statements for year ended March 2020, PDF p14 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=14&search=%284%29%20Consolidated%20sales%20units%2C%20number%20of), available by 2020-05-07.
