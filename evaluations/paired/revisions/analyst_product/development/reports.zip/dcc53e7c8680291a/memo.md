# Investment research memo

As of 2018-08-05T12:00:00Z

**Research question**
How much of Berkshire’s second-quarter 2018 net earnings came from operating earnings and how much from investment and derivatives gains? What changed in its accounting? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

Use Berkshire Hathaway’s operating earnings as the guide to recurring performance, not its full net earnings. In the second quarter of 2018, operating earnings accounted for 6,893 million dollars of the $12,011 million attributable to shareholders: 6,893 ÷ 12,011 = 57.3891. Investment and derivative gains accounted for the rest: 5,118 ÷ 12,011 = 42.6109. The after-tax amounts reconcile exactly: in millions of dollars, investment gains of 4,824 plus derivative gains of 294 equal 5,118; adding operating earnings of 6,893 gives 12,011, matching reported net earnings. [1](https://www.berkshirehathaway.com/news/aug0418.pdf#page=1&search=BERKSHIRE%20HATHAWAY%20INC.%20NEWS%20RELEASE%20FOR)

## Evidence

Beginning in 2018, GAAP required Berkshire to include changes in unrealized gains and losses on equity securities in earnings. Previously those changes affected shareholders’ equity but bypassed earnings. The new treatment put approximately $4.5 billion of unrealized gains into the quarter’s investment result. A share-price rise could therefore lift reported earnings without a sale or an improvement in the underlying businesses; the change concerned equity securities, not the entire investment and derivatives line. [2](https://www.berkshirehathaway.com/news/aug0418.pdf#page=1&search=Berkshire%20shareholders%20.......................................................................%20%7C%20%247%2C301%20%242%2C592)

## Outlook

The base case is to exclude market gains when assessing quarterly business performance, not to disregard investing altogether. The strongest alternative is that gains matter to long-run shareholder returns because investing insurance premiums is integral to Berkshire. That is a different question from whether this quarter’s gains will recur. In subsequent releases, compare net earnings with underwriting, insurance investment income and noninsurance operating results: a reversal in net earnings alongside stable operating results would support the base case. [3](https://www.berkshirehathaway.com/news/aug0418.pdf#page=2&search=At%20June%2030%2C%202018%2C%20%7C%20our) [4](https://www.berkshirehathaway.com/news/aug0418.pdf#page=1&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earnings)

## What would change the view

Berkshire’s second-quarter operating earnings are a guide to recurring performance, not a forecast. They include an underwriting profit of 943 million dollars, compared with an underwriting result of (22) million dollars in the prior-year quarter. The release does not establish which result is typical. A return to underwriting losses would weaken the case for treating this quarter’s operating earnings as a repeatable level, even if equity prices were unchanged. [4](https://www.berkshirehathaway.com/news/aug0418.pdf#page=1&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earnings) [3](https://www.berkshirehathaway.com/news/aug0418.pdf#page=2&search=At%20June%2030%2C%202018%2C%20%7C%20our)

## Checked calculations

- C1. Q2 2018 after-tax gains: investments (4,824) plus derivatives (294) = 5,118 (PDF p. 1) (USD millions) — 4,824 + 294 = 5,118 [1](https://www.berkshirehathaway.com/news/aug0418.pdf#page=1&search=BERKSHIRE%20HATHAWAY%20INC.%20NEWS%20RELEASE%20FOR)
- C2. Q2 2018 after-tax operating earnings plus gains = 12,011, matching reported net earnings (PDF p. 1) (USD millions) — 6,893 + C1 = 12,011 [1](https://www.berkshirehathaway.com/news/aug0418.pdf#page=1&search=BERKSHIRE%20HATHAWAY%20INC.%20NEWS%20RELEASE%20FOR)
- C3. Q2 2018 operating share: 57.4%. Use as a recurring guide, not a forecast; it includes underwriting (PDF pp. 1–2). (% of Q2 2018 net earnings) — 6,893 ÷ 12,011 × 100 ≈ 57.389060 [1](https://www.berkshirehathaway.com/news/aug0418.pdf#page=1&search=BERKSHIRE%20HATHAWAY%20INC.%20NEWS%20RELEASE%20FOR)
- C4. Q2 2018 gains share: 42.6%. GAAP moved unrealized equity changes from equity-only reporting into earnings (PDF p. 1). (% of Q2 2018 net earnings) — 5,118 ÷ 12,011 × 100 ≈ 42.610940 [1](https://www.berkshirehathaway.com/news/aug0418.pdf#page=1&search=BERKSHIRE%20HATHAWAY%20INC.%20NEWS%20RELEASE%20FOR)

## Sources

1. [Berkshire Hathaway second-quarter 2018 earnings, PDF p1 §1](https://www.berkshirehathaway.com/news/aug0418.pdf#page=1&search=BERKSHIRE%20HATHAWAY%20INC.%20NEWS%20RELEASE%20FOR), available by 2018-08-04.
2. [Berkshire Hathaway second-quarter 2018 earnings, PDF p1 §2](https://www.berkshirehathaway.com/news/aug0418.pdf#page=1&search=Berkshire%20shareholders%20.......................................................................%20%7C%20%247%2C301%20%242%2C592), available by 2018-08-04.
3. [Berkshire Hathaway second-quarter 2018 earnings, PDF p2 §1](https://www.berkshirehathaway.com/news/aug0418.pdf#page=2&search=At%20June%2030%2C%202018%2C%20%7C%20our), available by 2018-08-04.
4. [Berkshire Hathaway second-quarter 2018 earnings, PDF p1 §3](https://www.berkshirehathaway.com/news/aug0418.pdf#page=1&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earnings), available by 2018-08-04.
