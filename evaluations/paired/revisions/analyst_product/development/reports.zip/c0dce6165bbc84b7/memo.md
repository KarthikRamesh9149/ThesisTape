# Investment research memo

As of 2018-08-05T12:00:00Z

**Research question**
How much of Berkshire’s second-quarter 2018 net earnings came from operating earnings and how much from investment and derivatives gains? What changed in its accounting? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

As of 2018-08-05T12:00:00Z, Berkshire Hathaway’s second-quarter 2018 results showed that operating earnings contributed 6,893 million dollars, or 57.3891% of net earnings attributable to shareholders, while investment and derivative gains contributed 5,118 million dollars, or 42.6109%. The release’s after-tax bridge, in USD millions, is 4,824 in investment gains plus 294 in derivative gains, equaling the reported 5,118. Adding 6,893 in operating earnings reconciles to $12,011 million, the denominator for both shares. With that much of the total coming from gains, headline profit is not a sound standalone forecast. [1](https://www.berkshirehathaway.com/news/aug0418.pdf#page=1&search=BERKSHIRE%20HATHAWAY%20INC.%20NEWS%20RELEASE%20FOR)

## Evidence

Starting in 2018, GAAP required Berkshire to report changes in unrealized gains and losses on its equity investments in earnings. Previously, those changes were reflected in shareholders’ equity but not in the income statement. The change in unrealized gains and losses contributed approximately $4.5 billion to second-quarter investment gains, but was a net loss over the first six months. That contrast shows why headline profit can move with stock prices without a corresponding change in operating performance. [2](https://www.berkshirehathaway.com/news/aug0418.pdf#page=1&search=Berkshire%20shareholders%20.......................................................................%20%7C%20%247%2C301%20%242%2C592) [3](https://www.berkshirehathaway.com/news/aug0418.pdf#page=2&search=At%20June%2030%2C%202018%2C%20%7C%20our)

## Outlook

The base case is to forecast from Berkshire’s operating businesses and model investment and derivative gains separately, rather than extrapolate the headline. Berkshire’s non-GAAP operating measure excludes those gains and losses but retains insurance investment income. It is a better starting point for forecasting business performance, not a measure that strips out all investment activity. [3](https://www.berkshirehathaway.com/news/aug0418.pdf#page=2&search=At%20June%2030%2C%202018%2C%20%7C%20our) [4](https://www.berkshirehathaway.com/news/aug0418.pdf#page=1&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earnings)

## What would change the view

The strongest alternative is that the quarter signaled a sustainably higher operating run rate: underwriting swung to a profit, and earnings rose in railroad, utilities and energy and in other businesses versus the prior-year quarter. The release shows where earnings improved, but not how much of the improvement will recur. Sustained underwriting profitability and continued year-over-year gains across those businesses in subsequent filings would justify raising the operating forecast; another unrealized equity gain alone would not. [4](https://www.berkshirehathaway.com/news/aug0418.pdf#page=1&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earnings) [1](https://www.berkshirehathaway.com/news/aug0418.pdf#page=1&search=BERKSHIRE%20HATHAWAY%20INC.%20NEWS%20RELEASE%20FOR)

## Checked calculations

- C1. Q2 2018 after-tax investment (4,824) plus derivative (294) gains; matches reported 5,118 (PDF p. 1) (USD millions) — 4,824 + 294 = 5,118 [1](https://www.berkshirehathaway.com/news/aug0418.pdf#page=1&search=BERKSHIRE%20HATHAWAY%20INC.%20NEWS%20RELEASE%20FOR)
- C3. Q2 2018 operating share (~57.39%); headline net profit is not a sound standalone forecast (PDF pp. 1–2) (percent) — 6,893 ÷ 12,011 × 100 ≈ 57.389060 [1](https://www.berkshirehathaway.com/news/aug0418.pdf#page=1&search=BERKSHIRE%20HATHAWAY%20INC.%20NEWS%20RELEASE%20FOR)
- C4. Q2 2018 gains share (~42.61%); GAAP moved unrealized equity changes from equity into earnings (~$4.5B gain, PDF p. 1) (percent) — 5,118 ÷ 12,011 × 100 ≈ 42.610940 [1](https://www.berkshirehathaway.com/news/aug0418.pdf#page=1&search=BERKSHIRE%20HATHAWAY%20INC.%20NEWS%20RELEASE%20FOR)

## Sources

1. [Berkshire Hathaway second-quarter 2018 earnings, PDF p1 §1](https://www.berkshirehathaway.com/news/aug0418.pdf#page=1&search=BERKSHIRE%20HATHAWAY%20INC.%20NEWS%20RELEASE%20FOR), available by 2018-08-04.
2. [Berkshire Hathaway second-quarter 2018 earnings, PDF p1 §2](https://www.berkshirehathaway.com/news/aug0418.pdf#page=1&search=Berkshire%20shareholders%20.......................................................................%20%7C%20%247%2C301%20%242%2C592), available by 2018-08-04.
3. [Berkshire Hathaway second-quarter 2018 earnings, PDF p2 §1](https://www.berkshirehathaway.com/news/aug0418.pdf#page=2&search=At%20June%2030%2C%202018%2C%20%7C%20our), available by 2018-08-04.
4. [Berkshire Hathaway second-quarter 2018 earnings, PDF p1 §3](https://www.berkshirehathaway.com/news/aug0418.pdf#page=1&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earnings), available by 2018-08-04.
