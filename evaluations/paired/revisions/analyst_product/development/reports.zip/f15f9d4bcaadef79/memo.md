# Investment research memo

As of 2019-06-20T12:00:00Z

Forecast direction: lower

**Research question**
What did the Federal Reserve decide on 2019-06-19, what in the statement qualifies its policy stance, and where do you expect the upper endpoint of the federal funds target range at the 2019-07-31 scheduled decision relative to its 2019-06-19 level? Identify the direction and size of the dissent and the inflation evidence. Within means unchanged. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

On June 19, 2019, the FOMC held the federal funds target range at 2-1/4 to 2- | 1/2percent. James Bullard was the only dissenter: he favored lowering the range by 25 basis points. For 2019-07-31, I expect a lower upper endpoint. The June hold preserved the current setting, but increased uncertainty and muted inflation made a cut more likely at the next decision. [1](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT) [2](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=2&search=For%20release%20at%202%20p.m.%20EDT)

## Evidence

The June statement still described a strong labor market and sustained expansion as the most likely outcome, but it said uncertainty had increased. Both overall inflation and inflation excluding food and energy were below the 2 percent objective. Market-based inflation compensation had declined, while survey-based longer-term expectations were little changed. That is evidence of muted inflation pressure, not evidence that longer-term expectations had broadly fallen. [1](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT)

## Outlook

Base case: lower. May’s pledge to be patient gave way in June to a willingness to act as appropriate. With uncertainty rising and inflation below target, I favor subtracting a 25-basis-point step from the upper end of the June range. That step matches Bullard’s proposal; neither his dissent nor the change in wording establishes that a majority will back it in July. The strongest alternative is within: the upper endpoint stays at its June level, under the inclusive threshold unchanged, if the strong labor market and continued expansion persuade the Committee to wait. [3](https://www.federalreserve.gov/monetarypolicy/files/monetary20190501a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT) [1](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT) [2](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=2&search=For%20release%20at%202%20p.m.%20EDT)

## What would change the view

A materially stronger-than-expected June jobs report—particularly payroll gains well above the pre-release consensus—would shift the call toward within. It would make a near-term cut less urgent without resolving the inflation undershoot. As of 2019-06-20T12:00:00Z, the statements establish that labor-market data matter, but not how large a surprise would change the Committee’s vote. [4](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=1&search=funds%20rate%2C%20the%20Committee%20will%20assess) [1](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT)

## Sources

1. [Federal Reserve FOMC statement of 2019-06-19, PDF p1 §1](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT), available by 2019-06-19.
2. [Federal Reserve FOMC statement of 2019-06-19, PDF p2 §1](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=2&search=For%20release%20at%202%20p.m.%20EDT), available by 2019-06-19.
3. [Federal Reserve FOMC statement of 2019-05-01, PDF p1 §1](https://www.federalreserve.gov/monetarypolicy/files/monetary20190501a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT), available by 2019-05-01.
4. [Federal Reserve FOMC statement of 2019-06-19, PDF p1 §2](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=1&search=funds%20rate%2C%20the%20Committee%20will%20assess), available by 2019-06-19.
