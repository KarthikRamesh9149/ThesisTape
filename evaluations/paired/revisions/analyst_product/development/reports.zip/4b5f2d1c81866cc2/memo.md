# Investment research memo

As of 2019-04-27T12:00:00Z

Forecast direction: within

**Research question**
How did the first BEA estimate for Q1 2019 distinguish real GDP growth from the domestic purchases price index? Explain how personal consumption expenditures affected the growth reading. In the second estimate, will gross domestic purchases price index growth be revised lower, remain within, or go higher? Within means unchanged at the published one-decimal precision. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

BEA’s advance estimate for the first quarter of 2019 put U.S. real GDP growth at 3.2 percent and gross domestic purchases price growth at 0.8 percent, both at annual rates. Output grew faster while purchase prices rose more slowly. The distinction matters: real GDP measures inflation-adjusted domestic production; the price index tracks what U.S. residents pay for final goods and services, including imports. My call for the second estimate is within: unchanged at 0.8 percent as published. [1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [2](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=2&search=The%20acceleration%20in%20real%20GDP%20growth) [3](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=4&search=paid%20to%20ROW.%20Current-dollar%20estimates%20are) [4](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=4&search=Gross%20domestic%20product%20%28GDP%29%20is%20the)

## Evidence

Comparing the first quarter with the preceding fourth quarter, real GDP growth accelerated: 3.2% − 2.2% = 1 percentage points. Gross domestic purchases price growth slowed: 0.8% − 1.7% = -0.9 percentage points. The latter is a change between quarters, not evidence that BEA will mark down its estimate for the same quarter. [1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [2](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=2&search=The%20acceleration%20in%20real%20GDP%20growth)

Personal consumption expenditures (PCE) added percentage points to first-quarter real GDP growth, but consumption grew more slowly than in the fourth quarter, tempering the acceleration rather than driving it. Faster inventory investment and export growth helped explain the pickup. The supplied passages establish the sign of PCE’s contribution but do not show its exact table entry. The separate 0.6 percent PCE price increase measures consumer inflation, not consumption’s contribution to real growth. [1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [2](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=2&search=The%20acceleration%20in%20real%20GDP%20growth) [5](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=10&search=1.%20Real%20gross%20domestic%20income%20is)

## Outlook

Within is my base case for BEA’s May 30 release (inclusive threshold: unchanged). The main driver is the absence, as of 2019-04-27T12:00:00Z, of fresh price evidence that the advance estimate missed in either direction. Slower consumer inflation was already in that estimate. I therefore retain the published rate as a forecast, not as a claim that the underlying unrounded rate will be unchanged. [2](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=2&search=The%20acceleration%20in%20real%20GDP%20growth) [6](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=3&search=Upcoming%20Annual%20Update%20of%20the%20National) [7](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=5&search=to%20further%20revision%20by%20the%20source)

## What would change the view

Lower is the strongest alternative if fuller first-quarter consumer price data show that household purchases were cheaper than BEA estimated. I would switch on a downward revision to first-quarter PCE prices large enough, after allowing for investment and government purchase prices, to put the domestic purchases estimate below 0.8 percent at published precision. A lower PCE reading alone would not settle the call: it covers only part of resident purchases. [1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [3](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=4&search=paid%20to%20ROW.%20Current-dollar%20estimates%20are) [2](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=2&search=The%20acceleration%20in%20real%20GDP%20growth)

## Checked calculations

- C1. Q1 2019 minus Q4 2018: real GDP growth accelerated by 1.0 percentage point (PDF p. 1) (percentage points, annual rates) — 3.2 − 2.2 = 1.0 [1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.)
- C2. Q1 2019 minus Q4 2018: gross domestic purchases price growth slowed by 0.9 percentage point (PDF p. 2) (percentage points, annual rates) — 0.8 − 1.7 = -0.9 [2](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=2&search=The%20acceleration%20in%20real%20GDP%20growth)

## Sources

1. [BEA GDP advance estimate, Q1 2019, PDF p1 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.), available by 2019-04-26.
2. [BEA GDP advance estimate, Q1 2019, PDF p2 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=2&search=The%20acceleration%20in%20real%20GDP%20growth), available by 2019-04-26.
3. [BEA GDP advance estimate, Q1 2019, PDF p4 §3](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=4&search=paid%20to%20ROW.%20Current-dollar%20estimates%20are), available by 2019-04-26.
4. [BEA GDP advance estimate, Q1 2019, PDF p4 §2](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=4&search=Gross%20domestic%20product%20%28GDP%29%20is%20the), available by 2019-04-26.
5. [BEA GDP advance estimate, Q1 2019, PDF p10 §4](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=10&search=1.%20Real%20gross%20domestic%20income%20is), available by 2019-04-26.
6. [BEA GDP advance estimate, Q1 2019, PDF p3 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=3&search=Upcoming%20Annual%20Update%20of%20the%20National), available by 2019-04-26.
7. [BEA GDP advance estimate, Q1 2019, PDF p5 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=5&search=to%20further%20revision%20by%20the%20source), available by 2019-04-26.
