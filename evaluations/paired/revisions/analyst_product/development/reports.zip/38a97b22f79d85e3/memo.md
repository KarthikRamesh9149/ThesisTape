# Investment research memo

As of 2022-04-27T12:00:00Z

Forecast direction: within

**Research question**
Using Canon’s first quarter FY2022 release, what consolidated net income attributable to Canon Inc. remained to be earned to meet its December year-end projection? Give your call on the reported annual result relative to the projection (within means ±2% of guidance, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

Canon’s release confirms guidance for consolidated net income attributable to Canon Inc. for the year ending December 2022. The amount still to be earned after March was **252,000 − 45,975** (JPY million): full-year guidance less the first-quarter actual. The subtraction uses income after deducting noncontrolling interests, not total consolidated net income. [1](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=1&search=CONSOLIDATED%20RESULTS%20FOR%20THE%20FIRST%20QUARTER) [2](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=7&search=CANON%20INC.%20AND%20SUBSIDIARIES%20CONSOLIDATED%202.)

## Outlook

Within. As of 2022-04-27T12:00:00Z, I expect annual attributable income to finish inside an inclusive ±2% band around the reference. The main driver is Canon’s ability to ship against firm demand: it had already substituted parts and added suppliers during the quarter. That makes a supply recovery credible, but the revised guidance already assumes those measures will increase shipments. Their continuation supports meeting guidance rather than beating it. [3](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=2&search=production%20delays%20%7C%20due%20to%20the) [4](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=4&search=devices%20including%20laptops%20and%20tablets.%20With)

## What would change the view

The strongest alternative is lower: chip shortages could keep office multifunction-device sales from recovering while parts and freight costs erode profit on the units Canon does ship. I would switch to lower if the next quarterly release again reports chip-driven year-on-year unit declines for those devices despite recovering demand, alongside a further decline in consolidated gross margin from 44.9%. The March release shows both pressures, but cannot establish how long they will last. [5](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=3&search=Results%20by%20Segment%20Looking%20at%20Canon%E2%80%99s) [3](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=2&search=production%20delays%20%7C%20due%20to%20the)

## Sources

1. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p1 §1](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=1&search=CONSOLIDATED%20RESULTS%20FOR%20THE%20FIRST%20QUARTER), available by 2022-04-26.
2. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p7 §1](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=7&search=CANON%20INC.%20AND%20SUBSIDIARIES%20CONSOLIDATED%202.), available by 2022-04-26.
3. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p2 §2](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=2&search=production%20delays%20%7C%20due%20to%20the), available by 2022-04-26.
4. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p4 §3](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=4&search=devices%20including%20laptops%20and%20tablets.%20With), available by 2022-04-26.
5. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p3 §1](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=3&search=Results%20by%20Segment%20Looking%20at%20Canon%E2%80%99s), available by 2022-04-26.
