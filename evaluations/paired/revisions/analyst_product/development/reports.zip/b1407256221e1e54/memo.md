# Investment research memo

As of 2021-11-05T12:00:00Z

**Research question**
After the tribunal remittal in JD Sports’ Footasylum acquisition, which markets and constraints did the CMA reconsider, and did its disposal requirement change? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Answer

As of 2021-11-05T12:00:00Z, the CMA’s remittal decision changed neither UK competition finding nor the remedy for JD Sports’ completed acquisition of Footasylum. The CMA again found a substantial lessening of competition in the retail supply of sports-inspired casual footwear and, separately, sports-inspired casual apparel, each covering stores and online sales. JD therefore had to sell all of Footasylum to a CMA-approved buyer. The decision required a sale; it did not establish that one had closed. [1](https://assets.publishing.service.gov.uk/media/5eb185f0d3bf7f6534faf114/Summary_of_final_report.pdf#page=1&search=Summary%20Overview%20of%20our%20findings%201.) [2](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=1&search=Summary%20Overview%20of%20our%20findings%201.) [3](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=11&search=Entry%20or%20expansion%2052.%20%7C%20For)

## Evidence

What changed was the direction of the main competitive concern. Footasylum had become a weaker rival to JD, and other retailers had become stronger rivals to JD. That supported a narrower case for harm to JD shoppers, but not clearance: JD remained the closest alternative for Footasylum’s online shoppers in footwear and apparel. The CMA’s principal concern was that removing that alternative as an independent rival would let Footasylum worsen its offer. [3](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=11&search=Entry%20or%20expansion%2052.%20%7C%20For) [4](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=6&search=found%20some%20differences.%20For%20example%2C%20Footasylum)

The original CMA decision already required a full sale to keep Footasylum independent. The remittal confirmed that remedy: the shift in which shoppers were most at risk did not give JD a basis to retain any part of Footasylum. [1](https://assets.publishing.service.gov.uk/media/5eb185f0d3bf7f6534faf114/Summary_of_final_report.pdf#page=1&search=Summary%20Overview%20of%20our%20findings%201.) [3](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=11&search=Entry%20or%20expansion%2052.%20%7C%20For)

## What would change the view

The base case is that losing JD as an independent rival matters more to Footasylum shoppers than the reverse. In the May 2021 online survey, over 40% of Footasylum footwear customers and half its apparel customers said they would choose JD if Footasylum were unavailable; the reverse responses were 9% for footwear and 8% for apparel. These are reported responses, not calculated rates or observed purchases. The strongest qualification is that rivalry could be more mutual in stores: evidence that JD store shoppers switch to Footasylum more often than JD online shoppers do would strengthen the case for harm on JD’s side, not overturn the finding on Footasylum’s side. [4](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=6&search=found%20some%20differences.%20For%20example%2C%20Footasylum)

Higher switching between the chains in stores would not, by itself, show that their rivalry was more mutual there. The useful test is to measure store shoppers’ next choices separately by chain and product category. If JD’s store shoppers named Footasylum materially more often than JD’s online shoppers did, that would strengthen the case for harm to JD shoppers; if higher store switching ran mainly from Footasylum to JD, it would reinforce the CMA’s main concern. [4](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=6&search=found%20some%20differences.%20For%20example%2C%20Footasylum)

## Sources

1. [CMA phase 2 final report summary on JD Sports and Footasylum, PDF p1 §1](https://assets.publishing.service.gov.uk/media/5eb185f0d3bf7f6534faf114/Summary_of_final_report.pdf#page=1&search=Summary%20Overview%20of%20our%20findings%201.), available by 2020-05-06.
2. [CMA remittal final report summary on JD Sports and Footasylum, PDF p1 §1](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=1&search=Summary%20Overview%20of%20our%20findings%201.), available by 2021-11-04.
3. [CMA remittal final report summary on JD Sports and Footasylum, PDF p11 §1](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=11&search=Entry%20or%20expansion%2052.%20%7C%20For), available by 2021-11-04.
4. [CMA remittal final report summary on JD Sports and Footasylum, PDF p6 §1](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=6&search=found%20some%20differences.%20For%20example%2C%20Footasylum), available by 2021-11-04.
