# Investment research memo

As of 2020-05-08T12:00:00Z

Forecast direction: within

**Research question**
At Nintendo’s FY2020 results, what profit attributable to owners of parent did it guide for the year ending March 2021? Compare it with the just-reported year, discuss the risk to the supply of components, and forecast the full-year actual relative to guidance (within means ±2% of the guide, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Evidence

The year-over-year calculation is (200,000 million yen minus prior-year consolidated profit attributable to owners of parent) divided by that same prior-year profit, expressed as a percentage. The supplied excerpts verify Nintendo’s published decline but do not show the exact prior-year consolidated profit input, so the calculation cannot be independently reproduced. The 210,842 million yen figure is parent-company-only profit, not the consolidated comparator. Using the question’s unverified tolerance premise, the lower endpoint is the guide multiplied by one minus the tolerance and the upper endpoint is the guide multiplied by one plus the tolerance. The inclusive band is an inclusive ±2% band around the reference. [1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=2&search=Consolidated%20Financial%20Forecast%20for%20the%20Fiscal) [2](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=2&search=Net%20sales%20%7C%20Operating%20profit%20%7C)

## Outlook

Within is the base case. The main driver is whether Nintendo can make up near-term Switch shipment delays: delays had eased, and the annual hardware plan did not require matching the prior year’s unit sales. That makes a temporary disruption compatible with the guide, but does not establish that component supply has normalized. The strongest alternative is lower: if key parts stay scarce long enough that lost shipments cannot be recovered within the fiscal year, hardware sales and the associated opportunity to sell software would suffer. [3](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=3&search=Net%20cash%20provided%20by%20%28used%20in%29) [4](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=14&search=%284%29%20Consolidated%20sales%20units%2C%20number%20of) [5](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=4&search=forecasting%20are%20105%20yen%20per%20US)

## What would change the view

I would switch to lower if a subsequent results update cut the full-year Switch hardware unit forecast materially and attributed the cut to component shortages that Nintendo no longer expected to make up by year-end. That would directly challenge the recovery assumption behind the within call. The excerpts do not quantify how a hardware unit shortfall would translate into consolidated profit. [4](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=14&search=%284%29%20Consolidated%20sales%20units%2C%20number%20of) [5](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=4&search=forecasting%20are%20105%20yen%20per%20US)

## Sources

1. [Nintendo consolidated financial statements for year ended March 2020, PDF p2 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=2&search=Consolidated%20Financial%20Forecast%20for%20the%20Fiscal), available by 2020-05-07.
2. [Nintendo consolidated financial statements for year ended March 2020, PDF p2 §2](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=2&search=Net%20sales%20%7C%20Operating%20profit%20%7C), available by 2020-05-07.
3. [Nintendo consolidated financial statements for year ended March 2020, PDF p3 §4](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=3&search=Net%20cash%20provided%20by%20%28used%20in%29), available by 2020-05-07.
4. [Nintendo consolidated financial statements for year ended March 2020, PDF p14 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=14&search=%284%29%20Consolidated%20sales%20units%2C%20number%20of), available by 2020-05-07.
5. [Nintendo consolidated financial statements for year ended March 2020, PDF p4 §3](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=4&search=forecasting%20are%20105%20yen%20per%20US), available by 2020-05-07.
