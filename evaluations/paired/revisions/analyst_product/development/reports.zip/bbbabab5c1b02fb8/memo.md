# Investment research memo

As of 2021-01-29T12:00:00Z

Forecast direction: within

**Research question**
How did the first BEA estimate for Q4 2020 distinguish real GDP growth from the domestic purchases price index? Explain how goods exports affected the growth reading. In the second estimate, will real GDP growth be revised lower, remain within, or go higher? Within means unchanged at the published one-decimal precision. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Answer

BEA’s advance estimate put U.S. real GDP growth in the fourth quarter of 2020 at 4.0 percent annualized. The 1.7 percent rise in the gross domestic purchases price index measured prices paid by U.S. residents for final goods and services, not growth in domestic output. My call as of 2021-01-29T12:00:00Z is within: the second estimate will still show 4.0 percent real growth at the published precision. [1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [2](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020) [3](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=6&search=Additional%20Information%20Resources%20%7C%20The%20%7C)

## Evidence

Goods exports added to real growth and accounted for most of the export increase, led by industrial supplies and materials. That is a gross contribution, not a net trade result: rising imports worked in the opposite direction. A percentage-point figure requires the fourth-quarter goods-exports contribution row from BEA’s table 2; the excerpts reference the table but omit that row. [2](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020) [1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.)

The rounded GDP figures imply that the implicit GDP deflator rose more than the gross domestic purchases price index. The cross-check divides the nominal GDP growth factor (6.0 percent annualized growth) by the real GDP growth factor (4.0 percent annualized growth) and subtracts one. That is an approximation from rounded inputs, not a verification of the published GDP price index, which the excerpts do not show. [2](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020) [1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.)

## Outlook

Within (unchanged) is a low-confidence forecast. Private inventories are the main revision driver I would monitor: manufacturing and wholesale stockbuilding outweighed a retail decline, so the update depends on the balance across sectors. The base case assumes the net update, including other components, leaves the rounded headline unchanged. BEA’s average absolute advance-to-second revision was 0.5 percentage points. That cautions against confidence in an unchanged print but gives no reason to favor a higher revision over a lower one. [2](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020) [4](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=7&search=Statistical%20conventions%20%7C%20Updates%20to%20GDP) [5](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=7&search=adjusted%20values%20are%20calculated%20from%20the)

## What would change the view

Higher is the strongest alternative. Compare updated December manufacturing and wholesale inventory reports with BEA’s advance source assumptions. I would switch to higher if those reports imply enough additional real stockbuilding, after retail and other component updates, to lift rounded growth above 4.0 percent. An increase in inventories alone is not the signal: BEA already counted one. The excerpts identify the assumptions file but do not show a surprise against it at the cutoff. [6](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=4&search=Source%20Data%20for%20the%20Advance%20Estimate) [2](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020) [1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.)

## Sources

1. [BEA GDP advance estimate, Q4 2020, PDF p1 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.), available by 2021-01-28.
2. [BEA GDP advance estimate, Q4 2020, PDF p2 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020), available by 2021-01-28.
3. [BEA GDP advance estimate, Q4 2020, PDF p6 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=6&search=Additional%20Information%20Resources%20%7C%20The%20%7C), available by 2021-01-28.
4. [BEA GDP advance estimate, Q4 2020, PDF p7 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=7&search=Statistical%20conventions%20%7C%20Updates%20to%20GDP), available by 2021-01-28.
5. [BEA GDP advance estimate, Q4 2020, PDF p7 §2](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=7&search=adjusted%20values%20are%20calculated%20from%20the), available by 2021-01-28.
6. [BEA GDP advance estimate, Q4 2020, PDF p4 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=4&search=Source%20Data%20for%20the%20Advance%20Estimate), available by 2021-01-28.
