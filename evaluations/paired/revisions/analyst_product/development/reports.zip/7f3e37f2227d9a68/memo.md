# Investment research memo

As of 2022-04-27T12:00:00Z

Forecast direction: within

**Research question**
Using Canon’s first quarter FY2022 release, what consolidated net income attributable to Canon Inc. remained to be earned to meet its December year-end projection? Give your call on the reported annual result relative to the projection (within means ±2% of guidance, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

Canon Inc. reported first-quarter FY2022 consolidated net income attributable to Canon Inc. of 45,975 million yen. Its December year-end projection in force at 2022-04-27T12:00:00Z was 252,000 million yen, leaving 252,000 − 45,975 million yen to earn over the rest of the year. The inclusive band around the full-year projection is an inclusive ±2% band around the reference. [1](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=1&search=CONSOLIDATED%20RESULTS%20FOR%20THE%20FIRST%20QUARTER) [2](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=7&search=CANON%20INC.%20AND%20SUBSIDIARIES%20CONSOLIDATED%202.) [3](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=4&search=devices%20including%20laptops%20and%20tablets.%20With)

## Evidence

The strongest alternative is lower: persistent chip shortages could keep Canon from filling orders, while elevated parts and freight costs squeeze margins on what it does ship. Both risks were already visible in the first quarter. The release does not quantify their potential full-year effect on attributable net income, so it does not establish that the shortfall would breach the band. [4](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=3&search=Results%20by%20Segment%20Looking%20at%20Canon%E2%80%99s) [5](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=2&search=production%20delays%20%7C%20due%20to%20the) [6](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=4&search=Cash%20Flow%20In%20the%20first%20quarter%2C)

## Outlook

Within. The main driver is a recovery in shipments as Canon substitutes parts, adds suppliers and expects chip and logistics constraints to ease moderately in the second half. That could turn firm demand into sales. The revised guidance already assumes better supply and a weaker yen, so those factors support meeting the projection rather than beating it on their own. [3](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=4&search=devices%20including%20laptops%20and%20tablets.%20With) [7](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=4&search=and%20region.%20In%20the%20markets%20in) [5](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=2&search=production%20delays%20%7C%20due%20to%20the)

## What would change the view

I would switch to lower if Canon’s midyear update showed office multifunction device unit sales still falling year on year despite recovering demand, and management pushed the expected easing of chip constraints beyond year-end. That would undermine the shipment recovery on which the within call rests. [4](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=3&search=Results%20by%20Segment%20Looking%20at%20Canon%E2%80%99s) [7](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=4&search=and%20region.%20In%20the%20markets%20in)

## Sources

1. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p1 §1](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=1&search=CONSOLIDATED%20RESULTS%20FOR%20THE%20FIRST%20QUARTER), available by 2022-04-26.
2. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p7 §1](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=7&search=CANON%20INC.%20AND%20SUBSIDIARIES%20CONSOLIDATED%202.), available by 2022-04-26.
3. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p4 §3](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=4&search=devices%20including%20laptops%20and%20tablets.%20With), available by 2022-04-26.
4. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p3 §1](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=3&search=Results%20by%20Segment%20Looking%20at%20Canon%E2%80%99s), available by 2022-04-26.
5. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p2 §2](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=2&search=production%20delays%20%7C%20due%20to%20the), available by 2022-04-26.
6. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p4 §1](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=4&search=Cash%20Flow%20In%20the%20first%20quarter%2C), available by 2022-04-26.
7. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p4 §2](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=4&search=and%20region.%20In%20the%20markets%20in), available by 2022-04-26.
