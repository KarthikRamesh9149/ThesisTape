# Investment research memo

As of 2020-05-03T12:00:00Z

**Research question**
Bridge Berkshire’s first-quarter 2020 operating earnings to its shareholder net loss. What makes it risky to read the net loss as a cash outflow? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Evidence

The largest component was an approximately $55.5 billion unrealized equity loss. GAAP required Berkshire to recognize the decline in earnings without selling the holdings. Actual investment sales produced an after-tax realized gain of approximately $965 million, partly offsetting the mark within the investment line. That gain measures profit on sales, not cash proceeds. The mark therefore explains more than the entire shareholder loss, but subtracting it from the loss would not isolate cash use. [1](https://www.berkshirehathaway.com/news/may0220.pdf#page=1&search=Net%20earnings%20%28loss%29%20per%20average%20equivalent)

## Outlook

For assessing business performance, the base case is positive operating profitability alongside a real decline in portfolio value. Berkshire’s operating measure excludes investment and derivative gains and losses but retains insurance investment income. It is a better starting point than the headline loss for assessing recurring earnings, not a measure of cash generated or a reason to disregard the decline in shareholder wealth. [2](https://www.berkshirehathaway.com/news/may0220.pdf#page=2&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earnings) [3](https://www.berkshirehathaway.com/news/may0220.pdf#page=2&search=investment%20and%20derivative%20gains%2Flo%20sses.%20Although)

## What would change the view

A material cash drain could have coincided with the noncash mark. The supplied release directs readers to the quarterly filing but does not supply its cash-flow statement, so neither operating cash flow nor total cash use can be verified here. The test is to trace the noncash loss adjustment in the reconciliation from consolidated net earnings to operating cash flow, then examine investing and financing flows. A material operating cash deficit after the adjustment would signal weaker cash generation than operating earnings suggest; net investment purchases would instead show cash deployed into assets. Neither would make the unrealized loss itself a payment. [4](https://www.berkshirehathaway.com/news/may0220.pdf#page=1&search=BERKSHIRE%20HATHAWAY%20INC.%20NEWS%20RELEASE%20FOR) [1](https://www.berkshirehathaway.com/news/may0220.pdf#page=1&search=Net%20earnings%20%28loss%29%20per%20average%20equivalent)

## Sources

1. [Berkshire Hathaway first-quarter 2020 earnings, PDF p1 §2](https://www.berkshirehathaway.com/news/may0220.pdf#page=1&search=Net%20earnings%20%28loss%29%20per%20average%20equivalent), available by 2020-05-02.
2. [Berkshire Hathaway first-quarter 2020 earnings, PDF p2 §1](https://www.berkshirehathaway.com/news/may0220.pdf#page=2&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earnings), available by 2020-05-02.
3. [Berkshire Hathaway first-quarter 2020 earnings, PDF p2 §2](https://www.berkshirehathaway.com/news/may0220.pdf#page=2&search=investment%20and%20derivative%20gains%2Flo%20sses.%20Although), available by 2020-05-02.
4. [Berkshire Hathaway first-quarter 2020 earnings, PDF p1 §1](https://www.berkshirehathaway.com/news/may0220.pdf#page=1&search=BERKSHIRE%20HATHAWAY%20INC.%20NEWS%20RELEASE%20FOR), available by 2020-05-02.
