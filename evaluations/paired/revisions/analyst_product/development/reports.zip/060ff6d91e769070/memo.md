# Investment research memo

As of 2019-01-31T12:00:00Z

Forecast direction: undetermined

**Research question**
Prepare an auction preview for the U.S. Treasury 10-year nominal note sale scheduled for 2019-02-06. Identify the offering and maturity, report the prior comparable auction’s bid-to-cover and clearing rate, and forecast the new bid-to-cover ratio relative to that auction (within means ±0.05 ratio points, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Answer

As of 2019-01-31T12:00:00Z, my base case is lower bid-to-cover for the U.S. Treasury’s February 06, 2019 nominal 10-Year Note auction. Treasury is offering $27,000,000,000, more than it accepted at the January reopening. Bids must grow with the larger sale just to preserve the prior coverage ratio. [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2019/A_20190130_1.pdf#page=1&search=Embargoed%20Until%2008%3A30%20A.M.%20%7C%20CONTACT%3A) [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2019/R_20190109_1.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Evidence

The January announcement confirms this is a new issue, CUSIP 9128286B1, with nothing outstanding. It settles on February 15, 2019 and matures on February 15, 2029. The coupon and clearing yield are determined at auction. [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2019/A_20190130_1.pdf#page=1&search=Embargoed%20Until%2008%3A30%20A.M.%20%7C%20CONTACT%3A)

The prior comparable was Treasury’s January 09, 2019 reopening of the nominal note maturing November 15, 2028. It was a 9-Year 10-Month Note by remaining term, so it is comparable by benchmark tenor, not by issue type. It cleared at a high yield of 2.728%. Treasury reports bid-to-cover of 2.51, calculated as $60,237,325,500 tendered divided by $24,000,004,600 accepted. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2019/R_20190109_1.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## What would change the view

The strongest alternative is within the band: demand for the new benchmark could offset the larger sale, especially if buyers get a yield concession. I would switch to within if the when-issued note developed a clear yield premium to the fitted Treasury curve and held it into the competitive bidding deadline. The auction PDFs do not establish whether that concession is present. [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2019/A_20190130_1.pdf#page=1&search=Embargoed%20Until%2008%3A30%20A.M.%20%7C%20CONTACT%3A) [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2019/R_20190109_1.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Sources

1. [U.S. Treasury offering announcement of 2019-01-30, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2019/A_20190130_1.pdf#page=1&search=Embargoed%20Until%2008%3A30%20A.M.%20%7C%20CONTACT%3A), available by 2019-01-30.
2. [U.S. Treasury competitive auction results of 2019-01-09, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2019/R_20190109_1.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C), available by 2019-01-09.
