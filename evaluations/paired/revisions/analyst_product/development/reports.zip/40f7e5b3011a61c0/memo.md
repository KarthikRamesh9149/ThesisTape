# Investment research memo

As of 2021-01-29T12:00:00Z

Forecast direction: higher

**Research question**
How did the first BEA estimate for Q4 2020 distinguish real GDP growth from the domestic purchases price index? Explain how goods exports affected the growth reading. In the second estimate, will real GDP growth be revised lower, remain within, or go higher? Within means unchanged at the published one-decimal precision. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

As of 2021-01-29T12:00:00Z, I expect BEA’s second estimate of Q4 2020 annualized real GDP growth to print above the advance reading of 4.0 percent. This is a low-confidence call: a stronger inventory estimate could lift the published growth rate without implying stronger final demand. The inclusive unchanged band is unchanged. [1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [2](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020)

## Evidence

The 4.0 percent advance reading measured growth in real domestic output. The separate 1.7 percent annualized rise in the gross domestic purchases price index measured inflation in final goods and services bought by U.S. residents. That index covers purchases rather than domestic production, so it is not the deflator to subtract from nominal GDP growth to obtain real GDP growth. [1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [2](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020) [3](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=6&search=Additional%20Information%20Resources%20%7C%20The%20%7C) [4](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=7&search=Statistical%20conventions%20%7C%20Updates%20to%20GDP)

Goods exports, led by industrial supplies and materials, drove most of the increase in exports and made a positive contribution to real GDP growth. That is not the net-export contribution: the inputs are the contributions from goods exports and services exports, less the contributions from goods and services imports measured before the GDP subtraction. Imports rose, offsetting the export boost. The excerpts do not supply the contribution figures needed to quantify the goods-export lift or determine the sign of the net contribution. [2](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020) [1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.)

## Outlook

Base case: higher, with private inventory investment the main revision driver. The advance estimate already credits manufacturing and wholesale stockbuilding, so the upside case requires more accumulation than BEA assumed, not merely confirmation that stocks rose. Fuller source data could show that the factory and wholesale buildup outweighed the retail drawdown by more than initially estimated. The release establishes that these inputs can be revised, but it does not show that BEA underestimated them. [2](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020) [1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.)

## What would change the view

The strongest alternative is lower if the inventory revision runs the other way. Compare updated December manufacturing, wholesale and retail inventory data, adjusted for prices, with BEA’s advance source-data inputs and assumptions. A smaller factory and wholesale buildup or a deeper retail drawdown would flip the call to lower if the resulting inventory drag were large enough to lower the rounded print and other revisions did not offset it. [5](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=4&search=Source%20Data%20for%20the%20Advance%20Estimate) [2](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020) [6](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=7&search=adjusted%20values%20are%20calculated%20from%20the)

## Sources

1. [BEA GDP advance estimate, Q4 2020, PDF p1 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.), available by 2021-01-28.
2. [BEA GDP advance estimate, Q4 2020, PDF p2 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020), available by 2021-01-28.
3. [BEA GDP advance estimate, Q4 2020, PDF p6 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=6&search=Additional%20Information%20Resources%20%7C%20The%20%7C), available by 2021-01-28.
4. [BEA GDP advance estimate, Q4 2020, PDF p7 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=7&search=Statistical%20conventions%20%7C%20Updates%20to%20GDP), available by 2021-01-28.
5. [BEA GDP advance estimate, Q4 2020, PDF p4 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=4&search=Source%20Data%20for%20the%20Advance%20Estimate), available by 2021-01-28.
6. [BEA GDP advance estimate, Q4 2020, PDF p7 §2](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=7&search=adjusted%20values%20are%20calculated%20from%20the), available by 2021-01-28.
