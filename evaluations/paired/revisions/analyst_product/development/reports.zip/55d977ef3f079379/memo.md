# Investment research memo

As of 2022-04-27T12:00:00Z

Forecast direction: lower

**Research question**
Using Canon’s first quarter FY2022 release, what consolidated net income attributable to Canon Inc. remained to be earned to meet its December year-end projection? Give your call on the reported annual result relative to the projection (within means ±2% of guidance, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Evidence

The actual is parent-attributable income, not total consolidated profit. The income statement reconciles the two: consolidated net income of ¥49,793 million less ¥3,818 million attributable to noncontrolling interests equals ¥45,975 million. The inclusive tolerance applies to full-year guidance, not to the smaller amount remaining after March. [1](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=7&search=CANON%20INC.%20AND%20SUBSIDIARIES%20CONSOLIDATED%202.)

## Outlook

Lower. The main driver is the risk that supply improves more slowly than Canon assumed, not that customers stop ordering. Office multifunction device unit sales fell despite recovering demand because chips were scarce. Parts and logistics costs also cut consolidated gross margin by 0.7 percentage points to 44.9%. Those pressures affected both the number of machines Canon could sell and the profit it could earn on sales. The release does not quantify their remaining-year impact, so a below-band finish is a judgment, not a measured shortfall. [2](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=3&search=Results%20by%20Segment%20Looking%20at%20Canon%E2%80%99s) [3](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=2&search=production%20delays%20%7C%20due%20to%20the) [4](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=4&search=devices%20including%20laptops%20and%20tablets.%20With)

The strongest alternative is within the band. Canon had already used substitute parts and new suppliers to support production. If those measures let it fill more of the firm demand without further margin erosion, the raised projection was plausible. Both the expected supply improvement and a weaker yen against the dollar were already in that projection; neither should be counted again as incremental upside. [3](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=2&search=production%20delays%20%7C%20due%20to%20the) [4](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=4&search=devices%20including%20laptops%20and%20tablets.%20With)

## What would change the view

I would switch to within if the next quarterly release showed office multifunction device unit sales growing year over year and consolidated gross margin recovering above 44.9%. Together those observations would show that more equipment was reaching customers and that shipment recovery was not coming at the expense of margin. [2](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=3&search=Results%20by%20Segment%20Looking%20at%20Canon%E2%80%99s) [3](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=2&search=production%20delays%20%7C%20due%20to%20the)

## Sources

1. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p7 §1](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=7&search=CANON%20INC.%20AND%20SUBSIDIARIES%20CONSOLIDATED%202.), available by 2022-04-26.
2. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p3 §1](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=3&search=Results%20by%20Segment%20Looking%20at%20Canon%E2%80%99s), available by 2022-04-26.
3. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p2 §2](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=2&search=production%20delays%20%7C%20due%20to%20the), available by 2022-04-26.
4. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p4 §3](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=4&search=devices%20including%20laptops%20and%20tablets.%20With), available by 2022-04-26.
