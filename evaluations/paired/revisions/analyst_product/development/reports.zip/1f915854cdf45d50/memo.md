# Investment research memo

As of 2022-03-17T12:00:00Z

Forecast direction: higher

**Research question**
What did the Federal Reserve decide on 2022-03-16, what in the statement qualifies its policy stance, and where do you expect the upper endpoint of the federal funds target range at the 2022-05-04 scheduled decision relative to its 2022-03-16 level? Compare to January. Within means unchanged. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

On March 16, 2022, the FOMC moved from signaling a rate increase to delivering one. It raised the federal funds target range from January’s 0 to 1/4 percent to 1/4 to 1/2 percent. The upper endpoint rose by a quarter percentage point: the new 1/2 percent ceiling minus January’s 1/4 percent ceiling. [1](https://www.federalreserve.gov/monetarypolicy/files/monetary20220126a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EST) [2](https://www.federalreserve.gov/monetarypolicy/files/monetary20220316a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT)

## Evidence

March signaled further tightening, not a preset sequence. In January the Committee expected a rate increase would soon be appropriate and planned to end net asset purchases in early March. In March it anticipated ongoing rate increases and expected to start reducing its securities holdings at a coming meeting. Ending purchases meant ceasing to add to holdings; it was not itself a decision to shrink them. Neither signal committed the Committee to act in May. [1](https://www.federalreserve.gov/monetarypolicy/files/monetary20220126a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EST) [2](https://www.federalreserve.gov/monetarypolicy/files/monetary20220316a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT)

## Outlook

Higher is the base case for 2022-05-04: an upper endpoint above the unchanged threshold of unchanged. Elevated inflation is the main driver. The March statement identified price pressures beyond energy, while strengthening employment gave the Committee room to respond. That supports another increase, but does not establish its size. [2](https://www.federalreserve.gov/monetarypolicy/files/monetary20220316a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT)

## What would change the view

The strongest alternative is within: a pause at March’s ceiling. Russia’s invasion of Ukraine cut both ways for policy, adding inflation pressure but threatening activity. A sharp contraction in the next U.S. business activity survey would shift the call toward a pause by showing that the growth risk was materializing. That is a test of the forecast, not a trigger the Fed announced. [2](https://www.federalreserve.gov/monetarypolicy/files/monetary20220316a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT)

## Sources

1. [Federal Reserve FOMC statement of 2022-01-26, PDF p1 §1](https://www.federalreserve.gov/monetarypolicy/files/monetary20220126a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EST), available by 2022-01-26.
2. [Federal Reserve FOMC statement of 2022-03-16, PDF p1 §1](https://www.federalreserve.gov/monetarypolicy/files/monetary20220316a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT), available by 2022-03-16.
