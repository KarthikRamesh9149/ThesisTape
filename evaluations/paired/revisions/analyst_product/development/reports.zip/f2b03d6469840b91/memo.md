# Investment research memo

As of 2022-03-22T12:00:00Z

**Research question**
How should a holder read Berkshire’s cash offer for Alleghany, its premiums to the prior month and 52-week high and the possibility of another bid? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Answer

As of 2022-03-22T12:00:00Z, an Alleghany holder should use Berkshire Hathaway’s $848.02 per share in cash as the base-case takeover value if the merger closes, without adding a meaningful premium for a rival bid. Berkshire’s price is in a signed agreement covering all outstanding shares, worth approximately $11.6 billion in total equity value. The right to seek a better offer is not itself a better offer. [1](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=Berkshire%20Hathaway%20to%20Acquire%20Alleghany%20Corporation) [2](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=alternative%20acquisition%20proposals%20during%20a%2025-day)

As of 2022-03-22T12:00:00Z, an Alleghany holder should use Berkshire Hathaway’s $848.02 per share in cash as the base-case takeover value if the merger closes, without adding meaningful value for a rival bid. Berkshire signed a definitive agreement to acquire all outstanding shares for approximately $11.6 billion in total equity value. The right to seek a better offer is not itself a better offer. [1](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=Berkshire%20Hathaway%20to%20Acquire%20Alleghany%20Corporation) [2](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=alternative%20acquisition%20proposals%20during%20a%2025-day)

## Evidence

Both premiums measure the same offer against historical trading prices. The implied average over the prior 30 days is $848.02 ÷ (one plus 29%); the implied 52-week high closing price is $848.02 ÷ (one plus 16%). The smaller premium reflects the higher benchmark: the best close, not an intraday high. The announcement reports the offer and the percentages but not the observed dollar value of either benchmark. Back-solving from rounded percentages therefore gives estimates, not verified historical quotes or alternative bid prices. [1](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=Berkshire%20Hathaway%20to%20Acquire%20Alleghany%20Corporation)

The reported premiums compare the same cash offer with two historical trading benchmarks. The implied average over the prior 30 days is $848.02 ÷ (one plus 29%); the implied 52-week closing high is $848.02 ÷ (one plus 16%). The smaller premium reflects the higher benchmark: the highest close, not an intraday high. The release does not provide either benchmark’s dollar value, so back-solving from the rounded percentages yields estimates, not verified historical prices or alternative bids. [1](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=Berkshire%20Hathaway%20to%20Acquire%20Alleghany%20Corporation)

## Outlook

The strongest upside case is a competing buyer emerging during the 25-day go-shop. Alleghany can actively solicit bids and, subject to the agreement’s terms, terminate to accept a superior proposal. For a holder, that is a reason to watch for public disclosure of a superior proposal, not to count on extra proceeds today. Such a disclosure would warrant revising the base case; silence during the window would not rule out discussions. [3](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=our%20ownership%20will%20culminate%20through%20this) [2](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=alternative%20acquisition%20proposals%20during%20a%2025-day) [4](https://www.berkshirehathaway.com/news/mar2122.pdf#page=2&search=the%20process%20unless%20and%20until%20Alleghany%E2%80%99s)

Closing risk keeps the cash offer from being a floor for Alleghany shares. The parties expected the merger to close in the fourth quarter of 2022, but stockholder and regulatory approvals and other customary conditions remained outstanding. A delay would defer payment; termination could leave holders owning standalone Alleghany instead of receiving cash. Neither premium establishes what those shares would then be worth. [3](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=our%20ownership%20will%20culminate%20through%20this) [5](https://www.berkshirehathaway.com/news/mar2122.pdf#page=2&search=forward-looking%20statements%20to%20differ%20include%3A%20%28i%29)

## What would change the view

Closing risk limits the use of the offer as a valuation floor. The parties expected payment upon a close in the fourth quarter of 2022, but stockholder and regulatory approvals were still conditions. A delay would defer the cash; a failed deal could leave holders owning standalone Alleghany. Neither historical premium establishes what those shares would then be worth. [3](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=our%20ownership%20will%20culminate%20through%20this) [5](https://www.berkshirehathaway.com/news/mar2122.pdf#page=2&search=forward-looking%20statements%20to%20differ%20include%3A%20%28i%29)

The strongest upside case is a superior proposal emerging during the 25-day go-shop. Alleghany can actively solicit alternatives and, subject to the agreement’s terms, terminate to accept a superior proposal. Public disclosure of such a proposal would warrant revisiting the base case. Silence would not rule out discussions: Alleghany did not intend to report developments unless its board made a determination requiring further disclosure. [3](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=our%20ownership%20will%20culminate%20through%20this) [2](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=alternative%20acquisition%20proposals%20during%20a%2025-day) [4](https://www.berkshirehathaway.com/news/mar2122.pdf#page=2&search=the%20process%20unless%20and%20until%20Alleghany%E2%80%99s)

## Sources

1. [Berkshire Hathaway to acquire Alleghany, PDF p1 §1](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=Berkshire%20Hathaway%20to%20Acquire%20Alleghany%20Corporation), available by 2022-03-21.
2. [Berkshire Hathaway to acquire Alleghany, PDF p1 §3](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=alternative%20acquisition%20proposals%20during%20a%2025-day), available by 2022-03-21.
3. [Berkshire Hathaway to acquire Alleghany, PDF p1 §2](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=our%20ownership%20will%20culminate%20through%20this), available by 2022-03-21.
4. [Berkshire Hathaway to acquire Alleghany, PDF p2 §1](https://www.berkshirehathaway.com/news/mar2122.pdf#page=2&search=the%20process%20unless%20and%20until%20Alleghany%E2%80%99s), available by 2022-03-21.
5. [Berkshire Hathaway to acquire Alleghany, PDF p2 §2](https://www.berkshirehathaway.com/news/mar2122.pdf#page=2&search=forward-looking%20statements%20to%20differ%20include%3A%20%28i%29), available by 2022-03-21.
