# Investment research memo

As of 2019-04-27T12:00:00Z

Forecast direction: lower

**Research question**
How did the first BEA estimate for Q1 2019 distinguish real GDP growth from the domestic purchases price index? Explain how personal consumption expenditures affected the growth reading. In the second estimate, will gross domestic purchases price index growth be revised lower, remain within, or go higher? Within means unchanged at the published one-decimal precision. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

BEA’s advance estimate for Q1 2019 put real GDP growth at 3.2 percent and gross domestic purchases price growth at 0.8 percent, both annualized. GDP measures inflation-adjusted domestic production; the purchases index measures prices paid by U.S. residents. Stronger output growth therefore did not imply faster inflation: purchases price growth slowed from 1.7 percent in the preceding quarter. [1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [2](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=2&search=The%20acceleration%20in%20real%20GDP%20growth) [3](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=4&search=paid%20to%20ROW.%20Current-dollar%20estimates%20are)

## Evidence

Personal consumption expenditures (PCE) added to real GDP growth but slowed from the preceding quarter, so consumption was a drag on the acceleration, not on growth itself. Real PCE growth is the growth rate of inflation-adjusted consumer spending; its contribution is the percentage-point amount it adds to GDP growth. The contribution table reports 0.96 percentage point from consumer services alone. The supplied excerpts omit the aggregate PCE rows needed to verify the exact real PCE growth rate and total contribution. [1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [2](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=2&search=The%20acceleration%20in%20real%20GDP%20growth) [4](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=6&search=List%20of%20GDP%20News%20Release%20Tables) [5](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=8&search=8%20%7C%20Other%20durable%20goods%20%7C)

## Outlook

Lower, with low conviction: I expect the second estimate to publish purchases price growth below 0.8 percent. The unchanged band is unchanged, applied at published precision. The main downside candidate is a softer estimate of March consumer-services prices as more complete data replace advance inputs. Headline PCE price growth was already only 0.6 percent, but that shows softness in the quarter, not that BEA overestimated March prices. The strongest alternative is unchanged if the new services data are close to the advance assumptions or revisions elsewhere offset the downside. [2](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=2&search=The%20acceleration%20in%20real%20GDP%20growth) [6](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=2&search=increased%202.4%20percent%2C%20compared%20with%20an) [7](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=9&search=8%20%7C%20Other%20durable%20goods%20%7C)

## What would change the view

Compare the detailed March PCE services price indexes in BEA’s Personal Income and Outlays release with the advance source inputs and assumptions, including any revisions to earlier months. If the new data show no meaningful net downside to quarterly services prices, or if firmer prices elsewhere offset it enough to keep the purchases index at the advance published rate, I would switch to unchanged. The supplied excerpts do not give the March assumptions or the unrounded purchases rate, so they cannot establish how much of a source-data surprise would change the published figure. [6](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=2&search=increased%202.4%20percent%2C%20compared%20with%20an) [8](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=5&search=to%20further%20revision%20by%20the%20source)

## Sources

1. [BEA GDP advance estimate, Q1 2019, PDF p1 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.), available by 2019-04-26.
2. [BEA GDP advance estimate, Q1 2019, PDF p2 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=2&search=The%20acceleration%20in%20real%20GDP%20growth), available by 2019-04-26.
3. [BEA GDP advance estimate, Q1 2019, PDF p4 §3](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=4&search=paid%20to%20ROW.%20Current-dollar%20estimates%20are), available by 2019-04-26.
4. [BEA GDP advance estimate, Q1 2019, PDF p6 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=6&search=List%20of%20GDP%20News%20Release%20Tables), available by 2019-04-26.
5. [BEA GDP advance estimate, Q1 2019, PDF p8 §2](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=8&search=8%20%7C%20Other%20durable%20goods%20%7C), available by 2019-04-26.
6. [BEA GDP advance estimate, Q1 2019, PDF p2 §2](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=2&search=increased%202.4%20percent%2C%20compared%20with%20an), available by 2019-04-26.
7. [BEA GDP advance estimate, Q1 2019, PDF p9 §2](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=9&search=8%20%7C%20Other%20durable%20goods%20%7C), available by 2019-04-26.
8. [BEA GDP advance estimate, Q1 2019, PDF p5 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=5&search=to%20further%20revision%20by%20the%20source), available by 2019-04-26.
