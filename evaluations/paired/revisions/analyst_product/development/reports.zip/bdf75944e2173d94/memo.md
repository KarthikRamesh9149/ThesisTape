# Investment research memo

As of 2022-03-17T12:00:00Z

Forecast direction: higher

**Research question**
What did the Federal Reserve decide on 2022-03-16, what in the statement qualifies its policy stance, and where do you expect the upper endpoint of the federal funds target range at the 2022-05-04 scheduled decision relative to its 2022-03-16 level? Compare to January. Within means unchanged. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Answer

On 2022-03-16, the FOMC raised the federal funds target range from January’s 0 to 1/4 percent to 1/4 to 1/2 percent. The move began the tightening that January’s statement had signaled: March’s lower endpoint was January’s upper endpoint. The change in the upper endpoint was March’s 1/2 percent minus January’s 1/4 percent. [1](https://www.federalreserve.gov/monetarypolicy/files/monetary20220126a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EST) [2](https://www.federalreserve.gov/monetarypolicy/files/monetary20220316a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT)

## Evidence

Subtracting January’s upper endpoint of 1/4 percent from March’s upper endpoint gives an increase equal to the full width of January’s range: March’s lower endpoint matched January’s upper endpoint. [1](https://www.federalreserve.gov/monetarypolicy/files/monetary20220126a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EST) [2](https://www.federalreserve.gov/monetarypolicy/files/monetary20220316a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT)

## Outlook

As of 2022-03-17T12:00:00Z, my base case for the FOMC’s 2022-05-04 decision is higher: I expect the upper endpoint to exceed unchanged. The main driver is the Committee’s expectation of ongoing increases while inflation remains elevated. A repeat of the March increase would clear the threshold, but the statement did not commit the Committee to a May hike or specify its size. [2](https://www.federalreserve.gov/monetarypolicy/files/monetary20220316a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT)

## What would change the view

The strongest alternative is within: no hike would leave the upper endpoint at exactly March’s 1/2 percent. I would switch to that call if, before the May decision, the Fed Chair publicly said that incoming data favored holding the range unchanged at that meeting. March’s risk language permits such a pause but does not predict one. [2](https://www.federalreserve.gov/monetarypolicy/files/monetary20220316a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT)

## Sources

1. [Federal Reserve FOMC statement of 2022-01-26, PDF p1 §1](https://www.federalreserve.gov/monetarypolicy/files/monetary20220126a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EST), available by 2022-01-26.
2. [Federal Reserve FOMC statement of 2022-03-16, PDF p1 §1](https://www.federalreserve.gov/monetarypolicy/files/monetary20220316a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT), available by 2022-03-16.
