# Investment research memo

As of 2019-06-20T12:00:00Z

Forecast direction: lower

**Research question**
What did the Federal Reserve decide on 2019-06-19, what in the statement qualifies its policy stance, and where do you expect the upper endpoint of the federal funds target range at the 2019-07-31 scheduled decision relative to its 2019-06-19 level? Identify the direction and size of the dissent and the inflation evidence. Within means unchanged. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

On 2019-06-19, the Federal Open Market Committee held its target range at 2-1/4 to 2-1/2 percent. James Bullard was the sole dissenter, favoring a 25-basis-point cut at that meeting. The shift from May’s pledge to “be patient” to June’s “act as appropriate” opened the door to easing without committing the Committee to a cut. [1](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT) [2](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=2&search=For%20release%20at%202%20p.m.%20EDT) [3](https://www.federalreserve.gov/monetarypolicy/files/monetary20190501a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT)

## Evidence

The change from May was not that inflation had suddenly fallen below target; it was already below target when the Committee pledged to “be patient.” In June the Committee still saw sustained expansion as the most likely outcome, but judged uncertainty to have increased. Its promise to “act as appropriate” made a preventive cut more plausible without committing to its size or timing. [3](https://www.federalreserve.gov/monetarypolicy/files/monetary20190501a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT) [1](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT)

Both headline inflation and inflation excluding food and energy ran below 2 percent over the prior year. Declining market-based inflation compensation strengthened the case for easing, though longer-term survey expectations were little changed. Inflation compensation is not a price for the July policy decision; the supplied documents do not establish market-implied cut odds. [1](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT)

## Outlook

Base case for 2019-07-31: lower. Below-target inflation and increased uncertainty tip the balance toward a preventive cut despite a strong labor market. The forecast assumes a 25-basis-point July cut—the size Bullard favored in June, not a July commitment. Subtracting that cut from June’s upper endpoint of 2-1/2 percent would bring it down to June’s floor of 2-1/4 percent, below the unchanged threshold (unchanged). [1](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT) [2](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=2&search=For%20release%20at%202%20p.m.%20EDT)

## What would change the view

The strongest alternative is within: leave the upper endpoint unchanged. The labor market remained strong and activity was growing moderately. A June jobs report showing materially stronger payroll gains than expected would switch the call to within: it would weaken the case that sustaining the expansion required a July cut. [1](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT) [4](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=1&search=funds%20rate%2C%20the%20Committee%20will%20assess)

## Sources

1. [Federal Reserve FOMC statement of 2019-06-19, PDF p1 §1](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT), available by 2019-06-19.
2. [Federal Reserve FOMC statement of 2019-06-19, PDF p2 §1](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=2&search=For%20release%20at%202%20p.m.%20EDT), available by 2019-06-19.
3. [Federal Reserve FOMC statement of 2019-05-01, PDF p1 §1](https://www.federalreserve.gov/monetarypolicy/files/monetary20190501a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT), available by 2019-05-01.
4. [Federal Reserve FOMC statement of 2019-06-19, PDF p1 §2](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=1&search=funds%20rate%2C%20the%20Committee%20will%20assess), available by 2019-06-19.
