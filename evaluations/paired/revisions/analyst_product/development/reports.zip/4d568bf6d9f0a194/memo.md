# Investment research memo

As of 2022-10-14T12:00:00Z

Forecast direction: higher

**Research question**
Prepare an auction preview for the U.S. Treasury 5-year inflation-protected note (TIPS) sale scheduled for 2022-10-20. Identify the offering and maturity, report the prior comparable auction’s bid-to-cover and clearing rate, and forecast the new high real yield relative to that auction (within means ±5 basis points, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Evidence

The October note, CUSIP 91282CFR7, will be issued on October 31, 2022 and mature on October 15, 2027. The June 23, 2022 sale is the latest documented auction in the same tenor, not an identical new issue: it reopened the April 29, 2022 issue with 4-Year 10-Month remaining to its April 15, 2027 maturity. April would be the cleaner new-issue comparison, but its clearing yield is not in the supplied results. [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/A_20221013_4.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A) [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/R_20220623_3.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Outlook

**Higher** is the base case. Against June’s $18,000,003,300 accepted before SOMA, October’s $21,000,000,000 offering also excludes SOMA. If demand is otherwise similar, the marginal buyer may require a lower price and thus a higher real yield. That supply comparison supports the direction, not the size of the move; neither PDF supplies a current market yield to anchor the forecast. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/R_20220623_3.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C) [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/A_20221013_4.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A)

## What would change the view

The strongest alternative is **within**: demand for the new issue could absorb the extra supply without a material yield concession. I would switch to within if the when-issued real yield for 91282CFR7 held inside an inclusive ±0.05 percentage points band around the reference of 0.362% heading into bidding. That would be direct evidence of the yield buyers require for this note, more informative than June’s demand for the reopening. It is a signal to monitor, not a quote observed at the cutoff. [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/A_20221013_4.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A) [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/R_20220623_3.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Sources

1. [U.S. Treasury offering announcement of 2022-10-13, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/A_20221013_4.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A), available by 2022-10-13.
2. [U.S. Treasury competitive auction results of 2022-06-23, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/R_20220623_3.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C), available by 2022-06-23.
