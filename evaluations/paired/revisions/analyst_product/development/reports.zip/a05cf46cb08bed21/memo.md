# Investment research memo

As of 2022-10-14T12:00:00Z

Forecast direction: higher

**Research question**
Prepare an auction preview for the U.S. Treasury 5-year inflation-protected note (TIPS) sale scheduled for 2022-10-20. Identify the offering and maturity, report the prior comparable auction’s bid-to-cover and clearing rate, and forecast the new high real yield relative to that auction (within means ±5 basis points, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

As of 2022-10-14T12:00:00Z, I forecast a higher clearing real yield for Treasury’s October 20, 2022 sale than for its June reopening, by more than the an inclusive ±0.05 percentage points band around the reference tolerance. Treasury is offering $21,000,000,000 of new 5-Year TIPS maturing October 15, 2027. A higher clearing yield would mean investors secure a greater real return at issue than at the June sale. [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/A_20221013_4.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A) [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/R_20220623_3.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Evidence

The comparator is the June 23, 2022 reopening of the note originally issued on April 29, 2022; its shorter 4-Year 10-Month designation reflects the remaining term. It cleared at a high real yield of 0.362%. Bid-to-cover was 2.611 times: $46,997,593,300 tendered divided by $18,000,003,300 accepted, using the subtotals before SOMA. That ratio measures June demand, not the October market yield. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/R_20220623_3.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Outlook

Higher is the base case. The unverified question premise is that Fed tightening raised expected real rates enough for investors to demand a yield above the June high by more than the tolerance. To test it, subtract 0.362% from the prevailing five-year market real yield, both in percent, and convert the difference to basis points. Neither the June result nor the October announcement supplies a cutoff market quote, so the gap cannot be calculated and its attribution to tightening is not established. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/R_20220623_3.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C) [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/A_20221013_4.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A)

## What would change the view

The strongest alternative is a growth-driven Treasury rally: weaker growth expectations could pull real yields back toward the June clearing rate. I would switch to within if the new note’s when-issued real yield settled inside the inclusive an inclusive ±0.05 percentage points band around the reference band around 0.362% ahead of bidding. A rally in nominal Treasuries alone would not change the call; the test is the real yield. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/R_20220623_3.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C) [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/A_20221013_4.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A)

## Checked calculations

- C1. June 23 five-year TIPS reopening: bid-to-cover (subtotal tendered ÷ accepted), rounded to 2.61 (times) — 46,997,593,300 ÷ 18,000,003,300 ≈ 2.610977 [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/R_20220623_3.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Sources

1. [U.S. Treasury offering announcement of 2022-10-13, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/A_20221013_4.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A), available by 2022-10-13.
2. [U.S. Treasury competitive auction results of 2022-06-23, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/R_20220623_3.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C), available by 2022-06-23.
