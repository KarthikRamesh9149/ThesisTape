# Investment research memo

As of 2022-03-22T12:00:00Z

**Research question**
How should a holder read Berkshire’s cash offer for Alleghany, its premiums to the prior month and 52-week high and the possibility of another bid? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

As of 2022-03-22T12:00:00Z, Alleghany holders should treat Berkshire Hathaway’s $848.02 per share in cash as the likely endpoint, conditional on closing. The roughly $11.6 billion deal has unanimous approval from both boards. The 25-day go-shop gives Alleghany a real chance to find a better offer, but I would not pay a meaningful premium to Berkshire’s price on that possibility alone. [1](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=Berkshire%20Hathaway%20to%20Acquire%20Alleghany%20Corporation) [2](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=our%20ownership%20will%20culminate%20through%20this)

## Evidence

The joint release dated March 21, 2022 reports a 29% premium to the average stock price over the last 30 days and a 16% premium to the 52-week high closing price. The offer input for both is $848.02 per share. The prior-month average is implied by $848.02 divided by (one plus 29%); the high close is implied by $848.02 divided by (one plus 16%). The premium calculation in each case is the offer divided by the benchmark price, minus one. Both benchmark prices are inferred from rounded premiums: the release verifies the percentages and what they measure, but does not give the exact underlying prices. [1](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=Berkshire%20Hathaway%20to%20Acquire%20Alleghany%20Corporation)

The smaller premium to the high is not a contradiction: it uses a tougher benchmark. For a holder, the cash offer locks in a price above even the prior year’s highest close if the deal completes. But both benchmarks describe past trading, not what Alleghany could earn or be worth on its own. An independent valuation above the offer would make the historical premiums less persuasive as evidence of a good sale price; it would not establish that another buyer is willing or able to pay more. [1](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=Berkshire%20Hathaway%20to%20Acquire%20Alleghany%20Corporation) [3](https://www.berkshirehathaway.com/news/mar2122.pdf#page=2&search=forward-looking%20statements%20to%20differ%20include%3A%20%28i%29)

## Outlook

The testable base case is that the go-shop ends without a superior proposal and Berkshire closes at the signed price in the fourth quarter of 2022, subject to stockholder and regulatory approvals. Cash fixes the payment at closing; it does not guarantee closing or eliminate the cost of waiting. The premium figures do not quantify either the risk that the Berkshire deal fails or the odds that a rival tops it. [2](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=our%20ownership%20will%20culminate%20through%20this) [4](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=alternative%20acquisition%20proposals%20during%20a%2025-day)

## What would change the view

The strongest alternative is a buyer that values Alleghany more highly and can submit a credible, financed offer during the go-shop. Alleghany can terminate the Berkshire agreement to accept a superior proposal, subject to the agreement’s terms. A disclosed competing bid with higher consideration and credible closing terms, or a board determination that a proposal is superior, would justify giving a higher endpoint meaningful weight. Silence during the search is weak evidence because Alleghany does not plan to report interim developments unless the board determines disclosure is required. [4](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=alternative%20acquisition%20proposals%20during%20a%2025-day) [5](https://www.berkshirehathaway.com/news/mar2122.pdf#page=2&search=the%20process%20unless%20and%20until%20Alleghany%E2%80%99s)

## Sources

1. [Berkshire Hathaway to acquire Alleghany, PDF p1 §1](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=Berkshire%20Hathaway%20to%20Acquire%20Alleghany%20Corporation), available by 2022-03-21.
2. [Berkshire Hathaway to acquire Alleghany, PDF p1 §2](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=our%20ownership%20will%20culminate%20through%20this), available by 2022-03-21.
3. [Berkshire Hathaway to acquire Alleghany, PDF p2 §2](https://www.berkshirehathaway.com/news/mar2122.pdf#page=2&search=forward-looking%20statements%20to%20differ%20include%3A%20%28i%29), available by 2022-03-21.
4. [Berkshire Hathaway to acquire Alleghany, PDF p1 §3](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=alternative%20acquisition%20proposals%20during%20a%2025-day), available by 2022-03-21.
5. [Berkshire Hathaway to acquire Alleghany, PDF p2 §1](https://www.berkshirehathaway.com/news/mar2122.pdf#page=2&search=the%20process%20unless%20and%20until%20Alleghany%E2%80%99s), available by 2022-03-21.
