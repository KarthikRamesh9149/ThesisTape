# Investment research memo

As of 2022-03-22T12:00:00Z

**Research question**
How should a holder read Berkshire’s cash offer for Alleghany, its premiums to the prior month and 52-week high and the possibility of another bid? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

As of 2022-03-22T12:00:00Z, use Berkshire Hathaway’s agreed $848.02 per Alleghany share in cash as the base case, not a higher bid. The roughly $11.6 billion transaction is expected to close in the fourth quarter of 2022. For a holder, the choice is cash from a sale now versus a conditional payment later. The release gives no current market quote: favor selling at or above the offer absent credible evidence of a better bid; below it, hold only if the discount compensates for the wait and the risk of failure. [1](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=Berkshire%20Hathaway%20to%20Acquire%20Alleghany%20Corporation) [2](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=our%20ownership%20will%20culminate%20through%20this)

## Evidence

The benchmarks are distinct. Berkshire’s $848.02 offer is reported as a 29% premium to Alleghany’s average stock price over the last 30 days, not to its last unaffected close. The reported 16% premium uses the 52-week high closing price, not an intraday high. Each premium is the offer minus its own benchmark, divided by that benchmark. The release identifies the denominators but supplies neither underlying dollar price, so the percentages can be checked for meaning, not independently recomputed. Clearing even the prior high makes the offer attractive relative to past trading; neither premium measures the return still available today. [1](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=Berkshire%20Hathaway%20to%20Acquire%20Alleghany%20Corporation)

## Outlook

Both boards unanimously approved the agreement, supporting completion on the signed terms as the base case. To test whether waiting pays, subtract the executable sale price from $848.02 and divide by that sale price. That is the gross return forgone by selling only if Berkshire closes on those terms. A delayed approval lengthens the wait without raising the cash payment; a failed vote or regulatory rejection could leave the holder with shares worth less than today’s sale price. [1](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=Berkshire%20Hathaway%20to%20Acquire%20Alleghany%20Corporation) [2](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=our%20ownership%20will%20culminate%20through%20this)

## What would change the view

The strongest reason to hold even near the offer is a competing bid: Alleghany may solicit alternatives during the 25-day go-shop and may terminate the agreement to accept a superior proposal, subject to its terms. A disclosed superior cash proposal with credible closing terms would warrant comparing its payment and timing with Berkshire’s. Permission to solicit is not evidence that a bidder exists, and silence during the search is weak evidence either way because Alleghany does not plan routine updates. [3](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=alternative%20acquisition%20proposals%20during%20a%2025-day) [4](https://www.berkshirehathaway.com/news/mar2122.pdf#page=2&search=the%20process%20unless%20and%20until%20Alleghany%E2%80%99s)

## Sources

1. [Berkshire Hathaway to acquire Alleghany, PDF p1 §1](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=Berkshire%20Hathaway%20to%20Acquire%20Alleghany%20Corporation), available by 2022-03-21.
2. [Berkshire Hathaway to acquire Alleghany, PDF p1 §2](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=our%20ownership%20will%20culminate%20through%20this), available by 2022-03-21.
3. [Berkshire Hathaway to acquire Alleghany, PDF p1 §3](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=alternative%20acquisition%20proposals%20during%20a%2025-day), available by 2022-03-21.
4. [Berkshire Hathaway to acquire Alleghany, PDF p2 §1](https://www.berkshirehathaway.com/news/mar2122.pdf#page=2&search=the%20process%20unless%20and%20until%20Alleghany%E2%80%99s), available by 2022-03-21.
