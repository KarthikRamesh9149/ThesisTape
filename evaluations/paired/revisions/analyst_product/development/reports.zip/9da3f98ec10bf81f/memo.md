# Investment research memo

As of 2020-05-08T12:00:00Z

Forecast direction: higher

**Research question**
At Nintendo’s FY2020 results, what profit attributable to owners of parent did it guide for the year ending March 2021? Compare it with the just-reported year, discuss the risk to the supply of components, and forecast the full-year actual relative to guidance (within means ±2% of the guide, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

Nintendo guided consolidated profit attributable to owners of parent to JPY 200,000 million for the year ending March 2021, a decline from the just-reported year. My call as of 2020-05-08T12:00:00Z is higher: I expect Switch demand to lift profit above the upper end of an inclusive ±2% band around the reference. Beating that threshold would not require profit to regain its prior-year level. [1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=4&search=There%20are%20concerns%20that%20COVID-19%20will) [2](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=2&search=Consolidated%20Financial%20Forecast%20for%20the%20Fiscal) [3](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=3&search=Description%20of%20Operating%20Results%201.%20Operating)

## Evidence

The supplied excerpts do not verify the exact consolidated actual, A. JPY 210,842 million is the non-consolidated result; JPY 194,009 million is consolidated parent profit for the preceding year. In JPY million, G−A is 200,000−A, and (G−A)/A is (200,000−A)/A. The reported percentage decline is rounded, so it cannot establish A or the exact yen gap. Under the question's inclusive an inclusive ±2% band around the reference rule, the lower endpoint is JPY 200,000 million minus the tolerance times that guide; the upper endpoint is the same guide plus the same amount. [2](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=2&search=Consolidated%20Financial%20Forecast%20for%20the%20Fiscal) [4](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=2&search=Net%20sales%20%7C%20Operating%20profit%20%7C) [5](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=9&search=Consolidated%20Statements%20of%20Changes%20in%20Equity)

## Outlook

Higher. Nintendo planned for fewer Switch hardware units than it had just sold: 1,900 versus 2,103, both in ten-thousand-unit lots. Yet Animal Crossing sold 11.77 million units in its March launch, and older titles were still growing. With shipping delays already easing, I expect replenishment to support more console sales than planned and those buyers to purchase software as well. Recovery alone is not the upside: Nintendo already assumed supply would meet full-year demand. The call depends on demand exceeding its unit plan; the disclosures do not quantify the profit per incremental sale. [6](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=14&search=%284%29%20Consolidated%20sales%20units%2C%20number%20of) [3](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=3&search=Description%20of%20Operating%20Results%201.%20Operating) [7](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=3&search=Net%20cash%20provided%20by%20%28used%20in%29) [8](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=4&search=forecasting%20are%20105%20yen%20per%20US)

## What would change the view

The strongest alternative is that missing components turn delayed shipments into lost fiscal-year sales. I would shift the call downward if retailers continued selling through replenishments quickly while Nintendo repeatedly missed planned shipments and failed to catch up. That combination, unlike a temporary stockout, would challenge the full-year supply assumption: willing buyers cannot generate hardware revenue or expand the console base until units reach them. [7](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=3&search=Net%20cash%20provided%20by%20%28used%20in%29) [8](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=4&search=forecasting%20are%20105%20yen%20per%20US)

## Sources

1. [Nintendo consolidated financial statements for year ended March 2020, PDF p4 §2](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=4&search=There%20are%20concerns%20that%20COVID-19%20will), available by 2020-05-07.
2. [Nintendo consolidated financial statements for year ended March 2020, PDF p2 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=2&search=Consolidated%20Financial%20Forecast%20for%20the%20Fiscal), available by 2020-05-07.
3. [Nintendo consolidated financial statements for year ended March 2020, PDF p3 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=3&search=Description%20of%20Operating%20Results%201.%20Operating), available by 2020-05-07.
4. [Nintendo consolidated financial statements for year ended March 2020, PDF p2 §2](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=2&search=Net%20sales%20%7C%20Operating%20profit%20%7C), available by 2020-05-07.
5. [Nintendo consolidated financial statements for year ended March 2020, PDF p9 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=9&search=Consolidated%20Statements%20of%20Changes%20in%20Equity), available by 2020-05-07.
6. [Nintendo consolidated financial statements for year ended March 2020, PDF p14 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=14&search=%284%29%20Consolidated%20sales%20units%2C%20number%20of), available by 2020-05-07.
7. [Nintendo consolidated financial statements for year ended March 2020, PDF p3 §4](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=3&search=Net%20cash%20provided%20by%20%28used%20in%29), available by 2020-05-07.
8. [Nintendo consolidated financial statements for year ended March 2020, PDF p4 §3](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=4&search=forecasting%20are%20105%20yen%20per%20US), available by 2020-05-07.
