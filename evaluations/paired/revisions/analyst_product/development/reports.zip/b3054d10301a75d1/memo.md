# Investment research memo

As of 2019-01-31T12:00:00Z

Forecast direction: lower

**Research question**
Prepare an auction preview for the U.S. Treasury 10-year nominal note sale scheduled for 2019-02-06. Identify the offering and maturity, report the prior comparable auction’s bid-to-cover and clearing rate, and forecast the new bid-to-cover ratio relative to that auction (within means ±0.05 ratio points, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

The U.S. Treasury scheduled a $27,000,000,000 nominal 10-Year Note auction for February 06, 2019, maturing February 15, 2029. It is a new issue: the original issue date matches the issue date, and none of the note is outstanding. As of 2019-01-31T12:00:00Z, my call is lower bid-to-cover than at the January reopening: bidders must absorb a larger offering. [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2019/A_20190130_1.pdf#page=1&search=Embargoed%20Until%2008%3A30%20A.M.%20%7C%20CONTACT%3A) [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2019/R_20190109_1.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Evidence

Use Treasury’s January 09, 2019 auction as the prior comparable. Its 9-Year 10-Month Note was a reopening of the November benchmark, not a shorter original tenor: Treasury issued the additional notes on January 15, 2019 with the original November 15, 2028 maturity. The clearing rate was the high yield of 2.728%. Bid-to-cover was 2.51: $60,237,325,500 tendered divided by $24,000,004,600 accepted, as reported by Treasury. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2019/R_20190109_1.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Outlook

Lower: I expect coverage below the inclusive comparison band an inclusive ±0.05 ratio points band around the reference. To match January’s ratio, total tenders would have to grow in proportion to the step from $24,000,004,600 accepted to $27,000,000,000 offered. My base case is that bids grow too little to keep coverage even inside the band. That is a judgment about demand, not a mechanical consequence of the larger sale. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2019/R_20190109_1.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C) [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2019/A_20190130_1.pdf#page=1&search=Embargoed%20Until%2008%3A30%20A.M.%20%7C%20CONTACT%3A)

## What would change the view

The strongest alternative is that reinvestment demand keeps coverage within the band. Treasury estimates $54,129,000,000 of publicly held coupon securities mature on the new note’s issue date, but does not say how much will be reinvested in this note. I would switch to within if pre-auction dealer indications showed aggregate intended tenders rising roughly in proportion to the offering relative to January. The announcement contains no such order evidence. [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2019/A_20190130_1.pdf#page=1&search=Embargoed%20Until%2008%3A30%20A.M.%20%7C%20CONTACT%3A) [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2019/R_20190109_1.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Sources

1. [U.S. Treasury offering announcement of 2019-01-30, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2019/A_20190130_1.pdf#page=1&search=Embargoed%20Until%2008%3A30%20A.M.%20%7C%20CONTACT%3A), available by 2019-01-30.
2. [U.S. Treasury competitive auction results of 2019-01-09, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2019/R_20190109_1.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C), available by 2019-01-09.
