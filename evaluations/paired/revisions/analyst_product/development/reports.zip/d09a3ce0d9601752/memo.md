# Investment research memo

As of 2021-01-29T12:00:00Z

Forecast direction: higher

**Research question**
How did the first BEA estimate for Q4 2020 distinguish real GDP growth from the domestic purchases price index? Explain how goods exports affected the growth reading. In the second estimate, will real GDP growth be revised lower, remain within, or go higher? Within means unchanged at the published one-decimal precision. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

BEA’s advance estimate put Q4 2020 real GDP growth at 4.0 percent from the preceding quarter, seasonally adjusted at an annual rate. The 1.7 percent annualized rise in the gross domestic purchases price index measured prices paid for final goods and services by U.S. residents. The former measures growth in domestic output after adjusting for prices; the latter is neither output growth nor a figure to subtract from it. [1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [2](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=The%20price%20index%20for%20gross%20domestic) [3](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=6&search=Additional%20Information%20Resources%20%7C%20The%20%7C)

## Evidence

Goods exports made a positive percentage-point contribution to real GDP growth: industrial supplies and materials led the goods increase. Net exports are a separate contribution: add the goods-export and services-export contributions, then subtract the contribution from import growth. Imports rose, offsetting at least part of the export gain. The supplied excerpts omit the contribution rows, so they establish the sign of the goods-export contribution but not its exact size or the size or sign of net exports’ contribution. [4](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020) [1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.)

## Outlook

Higher, with low conviction: I expect the second estimate due February 25, 2021 to exceed 4.0 percent at the published one-decimal precision; an unchanged reading counts as within (unchanged). My main revision candidate is private inventory investment. I expect more complete December data to show that manufacturers and wholesalers added more to stocks than the advance estimate allowed for. BEA already counted inventory gains in both sectors, so it is the surprise relative to that estimate—not restocking itself—that would lift growth. [5](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=5&search=Release%20Dates%20in%202021%202020%20Q4) [1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [4](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020)

## What would change the view

Lower is the strongest alternative: the retail inventory decline may have been deeper than BEA estimated. I would switch to lower if the Census Bureau’s December Manufacturing and Trade Inventories and Sales release implied, after allowing for price changes, a smaller overall stockbuild than BEA assumed, with no offset elsewhere. BEA’s historical average advance-to-second revision of 0.5 percentage points is measured without regard to sign. It illustrates the scope for a revision but gives no reason to favor an upward one. [4](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020) [6](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=7&search=Statistical%20conventions%20%7C%20Updates%20to%20GDP) [7](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=7&search=adjusted%20values%20are%20calculated%20from%20the)

## Sources

1. [BEA GDP advance estimate, Q4 2020, PDF p1 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.), available by 2021-01-28.
2. [BEA GDP advance estimate, Q4 2020, PDF p2 §2](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=The%20price%20index%20for%20gross%20domestic), available by 2021-01-28.
3. [BEA GDP advance estimate, Q4 2020, PDF p6 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=6&search=Additional%20Information%20Resources%20%7C%20The%20%7C), available by 2021-01-28.
4. [BEA GDP advance estimate, Q4 2020, PDF p2 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020), available by 2021-01-28.
5. [BEA GDP advance estimate, Q4 2020, PDF p5 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=5&search=Release%20Dates%20in%202021%202020%20Q4), available by 2021-01-28.
6. [BEA GDP advance estimate, Q4 2020, PDF p7 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=7&search=Statistical%20conventions%20%7C%20Updates%20to%20GDP), available by 2021-01-28.
7. [BEA GDP advance estimate, Q4 2020, PDF p7 §2](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=7&search=adjusted%20values%20are%20calculated%20from%20the), available by 2021-01-28.
