# Investment research memo

As of 2022-10-14T12:00:00Z

Forecast direction: higher

**Research question**
Prepare an auction preview for the U.S. Treasury 5-year inflation-protected note (TIPS) sale scheduled for 2022-10-20. Identify the offering and maturity, report the prior comparable auction’s bid-to-cover and clearing rate, and forecast the new high real yield relative to that auction (within means ±5 basis points, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

As of 2022-10-14T12:00:00Z, the U.S. Treasury had announced a $21,000,000,000 new five-year TIPS auction for October 20, 2022, CUSIP 91282CFR7, settling October 31, 2022 and maturing October 15, 2027. With nothing outstanding, this is a new issue, so April’s new issue is the like-for-like benchmark. [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/A_20221013_4.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A)

## Evidence

The supplied results identify the prior security’s original issue date as April 29, 2022, but report a June reopening, not the April auction or the proposed August reopening. June’s high real yield was 0.362% and its bid-to-cover was 2.61, from $46,997,593,300 tendered divided by $18,000,003,300 accepted. Neither statistic can be attributed to April or August. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/R_20220623_3.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

April’s bid-to-cover and clearing yield cannot be verified from the supplied PDFs. The inclusive band is an inclusive ±0.05 percentage points band around the reference under the task rule: subtract and add the stipulated tolerance to April’s high real yield, including both endpoints. The April yield is the missing input, so numerical endpoints cannot be verified from these sources. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/R_20220623_3.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C) [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/A_20221013_4.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A)

## Outlook

Base case: higher than the upper edge of April’s band, with low confidence. The main driver is a potential supply concession: October asks investors to absorb a larger amount than Treasury accepted in June before SOMA awards, which could require a higher real yield if demand does not rise with supply. That comparison is not evidence that October is larger than April, and the PDFs contain no contemporaneous real-yield quote to test the call. [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/A_20221013_4.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A) [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/R_20220623_3.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## What would change the view

Alternative: within the band. Once the April auction result is verified, switch to within if the when-issued real yield for the October CUSIP trades and holds inside April’s inclusive band into the competitive bidding deadline. That would show that the market is absorbing the larger offering without the yield concession the base case assumes. [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/A_20221013_4.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A) [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/R_20220623_3.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Sources

1. [U.S. Treasury offering announcement of 2022-10-13, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/A_20221013_4.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A), available by 2022-10-13.
2. [U.S. Treasury competitive auction results of 2022-06-23, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2022/R_20220623_3.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C), available by 2022-06-23.
