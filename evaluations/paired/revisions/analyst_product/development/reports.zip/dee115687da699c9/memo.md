# Investment research memo

As of 2022-03-17T12:00:00Z

Forecast direction: higher

**Research question**
What did the Federal Reserve decide on 2022-03-16, what in the statement qualifies its policy stance, and where do you expect the upper endpoint of the federal funds target range at the 2022-05-04 scheduled decision relative to its 2022-03-16 level? Compare to January. Within means unchanged. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

On 2022-03-16, the Federal Open Market Committee raised the federal funds target range from January’s 0 to 1/4 percent to 1/4 to 1/2 percent. The increase in the upper endpoint is the difference between March’s 1/2 percent and January’s 1/4 percent. Elevated inflation was the main reason to expect further tightening: March’s statement pointed to broader price pressures as well as higher energy prices and pandemic-related imbalances. [1](https://www.federalreserve.gov/monetarypolicy/files/monetary20220126a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EST) [2](https://www.federalreserve.gov/monetarypolicy/files/monetary20220316a1.pdf#page=3&search=For%20release%20at%202%20p.m.%20EDT) [3](https://www.federalreserve.gov/monetarypolicy/files/monetary20220316a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT)

## Evidence

March strengthened the rate guidance without committing to a move at the next meeting. In January, above-target inflation and a strong labor market made a hike likely ‘soon’; in March, the Committee anticipated ‘ongoing increases’ and expected inflation to return to target and the labor market to remain strong with appropriate firming. Both statements reserved the option to adjust policy as risks emerged. March also said Russia’s invasion of Ukraine would likely push inflation up and weigh on activity in the near term, making the pace of tightening less certain. [1](https://www.federalreserve.gov/monetarypolicy/files/monetary20220126a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EST) [3](https://www.federalreserve.gov/monetarypolicy/files/monetary20220316a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT) [4](https://www.federalreserve.gov/monetarypolicy/files/monetary20220126a1.pdf#page=2&search=For%20release%20at%202%20p.m.%20EST)

January was about ending net purchases; March was about eventually shrinking holdings. January scheduled net purchases to end in early March. In March, the Committee said it expected to begin reducing its Treasury, agency debt and agency mortgage-backed securities holdings at a coming meeting, but the implementation directive still called for rolling over Treasury principal and reinvesting agency principal. The March statement did not establish a start date or pace for runoff. [1](https://www.federalreserve.gov/monetarypolicy/files/monetary20220126a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EST) [3](https://www.federalreserve.gov/monetarypolicy/files/monetary20220316a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT) [2](https://www.federalreserve.gov/monetarypolicy/files/monetary20220316a1.pdf#page=3&search=For%20release%20at%202%20p.m.%20EDT)

## Outlook

As of 2022-03-17T12:00:00Z, the base case for 2022-05-04 is higher: another move the size of March’s would bring the upper endpoint to 3/4 percent. Elevated inflation and the shift to ‘ongoing increases’ favor another hike over a pause, but the statement does not pin down the size. Bullard preferred reaching that upper endpoint in March; his dissent shows that a larger move had an advocate, not that the Committee endorsed that pace for May. [3](https://www.federalreserve.gov/monetarypolicy/files/monetary20220316a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT) [5](https://www.federalreserve.gov/monetarypolicy/files/monetary20220316a1.pdf#page=2&search=For%20release%20at%202%20p.m.%20EDT)

## What would change the view

The strongest alternative is within (unchanged): a pause leaving the upper endpoint at March’s 1/2 percent. A reported contraction in March payrolls would shift the call toward a pause because it would challenge the Committee’s assessment of strong job gains. That release was not available at the cutoff, and a contraction would not guarantee a pause while inflation remained elevated. [2](https://www.federalreserve.gov/monetarypolicy/files/monetary20220316a1.pdf#page=3&search=For%20release%20at%202%20p.m.%20EDT) [3](https://www.federalreserve.gov/monetarypolicy/files/monetary20220316a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT)

## Sources

1. [Federal Reserve FOMC statement of 2022-01-26, PDF p1 §1](https://www.federalreserve.gov/monetarypolicy/files/monetary20220126a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EST), available by 2022-01-26.
2. [Federal Reserve FOMC statement of 2022-03-16, PDF p3 §1](https://www.federalreserve.gov/monetarypolicy/files/monetary20220316a1.pdf#page=3&search=For%20release%20at%202%20p.m.%20EDT), available by 2022-03-16.
3. [Federal Reserve FOMC statement of 2022-03-16, PDF p1 §1](https://www.federalreserve.gov/monetarypolicy/files/monetary20220316a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT), available by 2022-03-16.
4. [Federal Reserve FOMC statement of 2022-01-26, PDF p2 §1](https://www.federalreserve.gov/monetarypolicy/files/monetary20220126a1.pdf#page=2&search=For%20release%20at%202%20p.m.%20EST), available by 2022-01-26.
5. [Federal Reserve FOMC statement of 2022-03-16, PDF p2 §1](https://www.federalreserve.gov/monetarypolicy/files/monetary20220316a1.pdf#page=2&search=For%20release%20at%202%20p.m.%20EDT), available by 2022-03-16.
