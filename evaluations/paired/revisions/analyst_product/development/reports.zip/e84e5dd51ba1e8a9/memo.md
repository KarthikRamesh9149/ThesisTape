# Investment research memo

As of 2019-01-31T12:00:00Z

Forecast direction: undetermined

**Research question**
Prepare an auction preview for the U.S. Treasury 10-year nominal note sale scheduled for 2019-02-06. Identify the offering and maturity, report the prior comparable auction’s bid-to-cover and clearing rate, and forecast the new bid-to-cover ratio relative to that auction (within means ±0.05 ratio points, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Answer

As of 2019-01-31T12:00:00Z, expect lower bid-to-cover at Treasury’s February 06, 2019 sale of a $27,000,000,000 nominal 10-Year Note maturing February 15, 2029. The new issue is larger than January’s reopening, so even an increase in tenders need not keep coverage near January’s 2.51. [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2019/A_20190130_1.pdf#page=1&search=Embargoed%20Until%2008%3A30%20A.M.%20%7C%20CONTACT%3A) [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2019/R_20190109_1.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Evidence

The comparable January 09, 2019 reopening cleared at a high yield of 2.728%. The 9-Year 10-Month Note label describes the remaining term of a note originally issued November 15, 2018, not a separate original tenor. February’s note is a new issue: it had $0 outstanding, and its issue and original issue dates match. The supplied PDFs establish that January is a comparable reopening, but do not provide an auction chronology to verify that it was the immediately preceding nominal auction of the same original tenor. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2019/R_20190109_1.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C) [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2019/A_20190130_1.pdf#page=1&search=Embargoed%20Until%2008%3A30%20A.M.%20%7C%20CONTACT%3A)

## Sources

1. [U.S. Treasury offering announcement of 2019-01-30, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2019/A_20190130_1.pdf#page=1&search=Embargoed%20Until%2008%3A30%20A.M.%20%7C%20CONTACT%3A), available by 2019-01-30.
2. [U.S. Treasury competitive auction results of 2019-01-09, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2019/R_20190109_1.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C), available by 2019-01-09.
