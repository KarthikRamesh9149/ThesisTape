# Investment research memo

As of 2019-06-20T12:00:00Z

Forecast direction: lower

**Research question**
What did the Federal Reserve decide on 2019-06-19, what in the statement qualifies its policy stance, and where do you expect the upper endpoint of the federal funds target range at the 2019-07-31 scheduled decision relative to its 2019-06-19 level? Identify the direction and size of the dissent and the inflation evidence. Within means unchanged. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

On June 19, 2019, the Federal Open Market Committee held the federal funds target range at 2-1/4 to 2- | 1/2percent. What changed was its guidance: May’s promise of patience gave way to a willingness to “act as appropriate” to sustain the expansion. That put a July cut in play without committing the Committee to one. [1](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT) [2](https://www.federalreserve.gov/monetarypolicy/files/monetary20190501a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT)

## Evidence

Inflation was the main reason to lean toward a cut. Both headline inflation and inflation excluding food and energy were below 2percent over the prior year. Below-target inflation was not new; the more telling change was that market-based inflation compensation, described as persistently low in May, had declined by June. Longer-term survey expectations were little changed, so the evidence did not show a broad fall in expectations. [1](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT) [2](https://www.federalreserve.gov/monetarypolicy/files/monetary20190501a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT)

James Bullard was the sole dissenter. He wanted to lower the range immediately by 25 basis points. His vote shows that a cut of that size already had an advocate, not that the majority had agreed to one for July. [3](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=2&search=For%20release%20at%202%20p.m.%20EDT)

## Outlook

Lower is my base case for 2019-07-31 relative to the June upper endpoint (unchanged band: unchanged). Subtracting a 25-basis-point cut from the upper end of June’s 2-1/4 to 2- | 1/2percent range would put the new ceiling at the old floor, 2.25percent. Muted inflation gives the Committee room to cut as insurance against the increased uncertainty, even if continued expansion remains its most likely outcome. [1](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT) [4](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=3&search=For%20release%20at%202%20p.m.%20EDT) [3](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=2&search=For%20release%20at%202%20p.m.%20EDT)

## What would change the view

The strongest alternative is within: leave the upper endpoint unchanged. The labor market remained strong, and the Committee said its next move would depend on incoming information. A clear rebound in core PCE inflation toward 2 percent before the July decision would shift my call to a hold by weakening the main case for easing. [1](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT) [5](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=1&search=funds%20rate%2C%20the%20Committee%20will%20assess)

## Sources

1. [Federal Reserve FOMC statement of 2019-06-19, PDF p1 §1](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT), available by 2019-06-19.
2. [Federal Reserve FOMC statement of 2019-05-01, PDF p1 §1](https://www.federalreserve.gov/monetarypolicy/files/monetary20190501a1.pdf#page=1&search=For%20release%20at%202%20p.m.%20EDT), available by 2019-05-01.
3. [Federal Reserve FOMC statement of 2019-06-19, PDF p2 §1](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=2&search=For%20release%20at%202%20p.m.%20EDT), available by 2019-06-19.
4. [Federal Reserve FOMC statement of 2019-06-19, PDF p3 §1](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=3&search=For%20release%20at%202%20p.m.%20EDT), available by 2019-06-19.
5. [Federal Reserve FOMC statement of 2019-06-19, PDF p1 §2](https://www.federalreserve.gov/monetarypolicy/files/monetary20190619a1.pdf#page=1&search=funds%20rate%2C%20the%20Committee%20will%20assess), available by 2019-06-19.
