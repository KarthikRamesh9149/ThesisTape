# Investment research memo

As of 2020-05-03T12:00:00Z

**Research question**
Bridge Berkshire’s first-quarter 2020 operating earnings to its shareholder net loss. What makes it risky to read the net loss as a cash outflow? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

Give Berkshire Hathaway’s first-quarter 2020 shareholder net loss little weight as evidence of cash burn or weaker operations. The after-tax bridge, in millions of dollars, is operating earnings of 5,871 plus investment losses of (54,517) and derivative losses of (1,100). Those two losses total (55,617), taking Berkshire to a shareholder net loss of (49,746). The largest component was a decline in unrealized equity gains, not cash spent. [1](https://www.berkshirehathaway.com/news/may0220.pdf#page=1&search=BERKSHIRE%20HATHAWAY%20INC.%20NEWS%20RELEASE%20FOR) [2](https://www.berkshirehathaway.com/news/may0220.pdf#page=1&search=Net%20earnings%20%28loss%29%20per%20average%20equivalent)

## Evidence

The equity marks matter for the value of Berkshire’s portfolio, but they are not cash outflows. GAAP puts changes in unrealized equity gains and losses into earnings, and Berkshire attributed approximately $55.5 billion of investment losses to those changes. The investment line also included an after-tax realized gain on sales of about 965 million dollars, but a realized gain is not the cash proceeds from the sale. The earnings release does not establish net cash burn or show how much cash, if any, was paid on derivatives during the quarter. [3](https://www.berkshirehathaway.com/news/may0220.pdf#page=2&search=investment%20and%20derivative%20gains%2Flo%20sses.%20Although) [2](https://www.berkshirehathaway.com/news/may0220.pdf#page=1&search=Net%20earnings%20%28loss%29%20per%20average%20equivalent)

## Outlook

Operating earnings are a better starting point than net income for judging the businesses, but the increase is not a reliable run rate. Operating earnings rose to 5,871 from 5,555 million dollars, while the swing in Other alone—from (129) to 333 million dollars—exceeded the entire increase. Insurance investment income rose, but underwriting, railroad, utilities and energy, and other businesses each earned less. The base case is therefore mixed operating performance, not broad improvement. [4](https://www.berkshirehathaway.com/news/may0220.pdf#page=2&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earnings)

## What would change the view

The strongest alternative is that the declines in several operating lines are early signs of sustained weakness, masked by gains elsewhere. Repeated declines in those lines alongside weaker operating cash flow would strengthen that interpretation; a segment rebound with resilient cash flow would weaken it. The release shows the earnings mix but cannot establish persistence or cash conversion. Check the quarterly cash-flow statement before drawing a conclusion about cash burn. [4](https://www.berkshirehathaway.com/news/may0220.pdf#page=2&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earnings) [1](https://www.berkshirehathaway.com/news/may0220.pdf#page=1&search=BERKSHIRE%20HATHAWAY%20INC.%20NEWS%20RELEASE%20FOR)

## Sources

1. [Berkshire Hathaway first-quarter 2020 earnings, PDF p1 §1](https://www.berkshirehathaway.com/news/may0220.pdf#page=1&search=BERKSHIRE%20HATHAWAY%20INC.%20NEWS%20RELEASE%20FOR), available by 2020-05-02.
2. [Berkshire Hathaway first-quarter 2020 earnings, PDF p1 §2](https://www.berkshirehathaway.com/news/may0220.pdf#page=1&search=Net%20earnings%20%28loss%29%20per%20average%20equivalent), available by 2020-05-02.
3. [Berkshire Hathaway first-quarter 2020 earnings, PDF p2 §2](https://www.berkshirehathaway.com/news/may0220.pdf#page=2&search=investment%20and%20derivative%20gains%2Flo%20sses.%20Although), available by 2020-05-02.
4. [Berkshire Hathaway first-quarter 2020 earnings, PDF p2 §1](https://www.berkshirehathaway.com/news/may0220.pdf#page=2&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earnings), available by 2020-05-02.
