# Investment research memo

As of 2021-11-04T12:00:00Z

Forecast direction: within

**Research question**
Prepare an auction preview for the U.S. Treasury 30-year nominal bond sale scheduled for 2021-11-10. Identify the offering and maturity, report the prior comparable auction’s bid-to-cover and clearing rate, and forecast the new high yield relative to that auction (within means ±5 basis points, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Answer

The U.S. Treasury will auction $25,000,000,000 of a new 30-Year Bond on November 10, 2021. The nominal bond (CUSIP 912810TB4) issues on November 15, 2021 and matures on November 15, 2051. As of 2021-11-04T12:00:00Z, my call is **within**: the larger sale may require a slightly higher clearing yield, but its size alone is not a strong reason to forecast a move outside the band. [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2021/A_20211103_1.pdf#page=1&search=Embargoed%20Until%2008%3A30%20A.M.%20%7C%20CONTACT%3A) [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2021/R_20211013_2.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Evidence

The October 13, 2021 comparator was a reopening of the August bond, then a 29-Year 10-Month Bond. It cleared at a high yield of 2.049%, not its coupon of 2%. Bid-to-cover was 2.36: $56,628,143,600 tendered divided by $24,000,023,000 accepted, excluding SOMA. That ratio measures bidding at the October sale, not demand for the new bond. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2021/R_20211013_2.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Outlook

**Within.** Apply the question’s inclusive comparison band, an inclusive ±0.05 percentage points band around the reference, to the October high yield of 2.049%. The main observable driver is supply: November’s $25,000,000,000 offering is modestly larger than October’s $24,000,023,000 accepted before SOMA. If long-end market yields and investor demand remain near October levels, bidders may ask for a small yield concession to absorb the extra bonds. The documents do not establish current market pricing or how much concession bidders will require, so conviction is limited. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2021/R_20211013_2.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C) [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2021/A_20211103_1.pdf#page=1&search=Embargoed%20Until%2008%3A30%20A.M.%20%7C%20CONTACT%3A)

Within. For the U.S. Treasury’s November 10, 2021 auction, the inclusive band is an inclusive ±0.05 percentage points band around the reference, centered on the October auction’s high yield of 2.049%. A high yield below the lower bound is lower; one above the upper bound is higher. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2021/R_20211013_2.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C) [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2021/A_20211103_1.pdf#page=1&search=Embargoed%20Until%2008%3A30%20A.M.%20%7C%20CONTACT%3A)

## What would change the view

**Higher** is the strongest alternative: if investors cut long-duration exposure, the larger offering could clear above the band. I would switch to higher if the new bond’s when-issued yield traded persistently above the upper boundary approaching the auction, far enough above it that a slightly lower auction yield would still be outside the band. That is a prospective test, not a price observed at the cutoff. [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2021/A_20211103_1.pdf#page=1&search=Embargoed%20Until%2008%3A30%20A.M.%20%7C%20CONTACT%3A) [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2021/R_20211013_2.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Sources

1. [U.S. Treasury offering announcement of 2021-11-03, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2021/A_20211103_1.pdf#page=1&search=Embargoed%20Until%2008%3A30%20A.M.%20%7C%20CONTACT%3A), available by 2021-11-03.
2. [U.S. Treasury competitive auction results of 2021-10-13, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2021/R_20211013_2.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C), available by 2021-10-13.
