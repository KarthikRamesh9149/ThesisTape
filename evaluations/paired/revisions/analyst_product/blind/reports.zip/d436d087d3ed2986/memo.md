# Investment research memo

As of 2020-07-31T12:00:00Z

Forecast direction: within

**Research question**
How did the first BEA estimate for Q2 2020 distinguish real GDP growth from the domestic purchases price index? Explain how services consumption and health care affected the growth reading. In the second estimate, will gross domestic purchases price index growth be revised lower, remain within, or go higher? Within means unchanged at the published one-decimal precision. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Answer

As of 2020-07-31T12:00:00Z, my call is within: I expect BEA’s second estimate for Q2 2020 to retain the advance estimate’s annualized decline of 1.5 percent in gross domestic purchases prices. BEA separately reported that real GDP fell at an annual rate of 32.9 percent. The distinction matters: real GDP measures inflation-adjusted domestic output, while the purchases index tracks prices of final goods and services bought by U.S. residents. The collapse in output does not imply a comparable fall in prices. [1](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=2&search=The%20decrease%20in%20real%20GDP%20reflected) [2](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [3](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=5&search=%22current-price%20estimates.%22%20Statistical%20conventions%20Real%20%7C) [4](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=5&search=capital%20consumption%20adjustment%20%28CCAdj%29%20in%20the)

## Evidence

Falling services consumption accounted for much of the real GDP contraction. In the advance estimate’s second-quarter contribution column, total services contributed -22.93 annualized percentage points and health care, the leading services drag, contributed -9.50 points. Health care is part of services: subtracting it gives -22.93 − (-9.50) = -13.43 points for all other services combined. These are contributions to real growth, not changes in service prices. [5](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=9&search=8%20%7C%20Other%20durable%20goods%20%7C) [1](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=2&search=The%20decrease%20in%20real%20GDP%20reflected)

Falling services consumption accounted for much of the real GDP contraction, with health care the largest services drag. In the advance estimate’s second-quarter column, total services contributed -22.93 annualized percentage points and health care contributed -9.50 points. Subtracting health care from total services leaves -13.43 annualized percentage points for all other services combined. These are contributions to real GDP growth, not changes in service prices. [1](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=2&search=The%20decrease%20in%20real%20GDP%20reflected) [5](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=9&search=8%20%7C%20Other%20durable%20goods%20%7C)

## Outlook

Base case: within (inclusive threshold: unchanged), meaning the same published one-decimal rate. The main revision driver I would watch is more complete services spending data, especially for health care. If the new data mainly change how much care was delivered rather than the prices paid, they can revise real growth while affecting the purchases price index indirectly through spending weights. The advance release does not establish that reweighting would be large enough to change the published rate. [2](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [1](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=2&search=The%20decrease%20in%20real%20GDP%20reflected) [6](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=6&search=Quantity%20and%20price%20indexes%20are%20calculated)

Base case: within (unchanged), meaning the same published one-decimal rate. The main revision driver to watch is more complete services spending data, especially for health care. If those data mostly revise how much care was delivered rather than the prices paid, they can change real GDP growth while affecting the purchases price index indirectly through spending weights. The advance release does not establish that reweighting would be large enough to change the published rate. [2](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [1](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=2&search=The%20decrease%20in%20real%20GDP%20reflected) [6](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=6&search=Quantity%20and%20price%20indexes%20are%20calculated)

## What would change the view

The strongest alternative is higher—a smaller price decline. I would switch if updated services receipts, matched to component price data, showed that BEA had put too much weight on services with the steepest price declines and that correcting those weights would make the aggregate rate round above the advance reading. A revision to health care receipts alone would not meet that test: it would not show how health care prices moved relative to the rest of the basket. [6](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=6&search=Quantity%20and%20price%20indexes%20are%20calculated) [2](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [1](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=2&search=The%20decrease%20in%20real%20GDP%20reflected)

The strongest alternative is higher: a smaller price decline. I would switch if updated services receipts, matched to component price data, showed that the advance estimate put too much weight on services with the steepest price declines and that correcting the weights would make the aggregate rate round above the advance reading. A revision to health care receipts alone would not show how health care prices moved relative to the rest of the basket. [2](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [6](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=6&search=Quantity%20and%20price%20indexes%20are%20calculated) [1](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=2&search=The%20decrease%20in%20real%20GDP%20reflected)

## Checked calculations

- C1. Q2 2020 advance estimate (PDF p. 9): services excluding health care contribution to real GDP growth (annualized percentage points) — -22.93 − -9.50 = -13.43 [5](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=9&search=8%20%7C%20Other%20durable%20goods%20%7C)

## Sources

1. [BEA GDP advance estimate, Q2 2020, PDF p2 §1](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=2&search=The%20decrease%20in%20real%20GDP%20reflected), available by 2020-07-30.
2. [BEA GDP advance estimate, Q2 2020, PDF p1 §1](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.), available by 2020-07-30.
3. [BEA GDP advance estimate, Q2 2020, PDF p5 §3](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=5&search=%22current-price%20estimates.%22%20Statistical%20conventions%20Real%20%7C), available by 2020-07-30.
4. [BEA GDP advance estimate, Q2 2020, PDF p5 §2](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=5&search=capital%20consumption%20adjustment%20%28CCAdj%29%20in%20the), available by 2020-07-30.
5. [BEA GDP advance estimate, Q2 2020, PDF p9 §2](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=9&search=8%20%7C%20Other%20durable%20goods%20%7C), available by 2020-07-30.
6. [BEA GDP advance estimate, Q2 2020, PDF p6 §2](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=6&search=Quantity%20and%20price%20indexes%20are%20calculated), available by 2020-07-30.
