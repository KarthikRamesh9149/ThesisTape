# Investment research memo

As of 2020-08-21T12:00:00Z

Forecast direction: undetermined

**Research question**
Prepare an auction preview for the U.S. Treasury 7-year nominal note sale scheduled for 2020-08-27. Identify the offering and maturity, report the prior comparable auction’s bid-to-cover and clearing rate, and forecast the new bid-to-cover ratio relative to that auction (within means ±0.05 ratio points, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Answer

As of 2020-08-21T12:00:00Z, the base case is lower bid-to-cover for the U.S. Treasury’s nominal 7-Year Note sale. Treasury is scheduled to auction $47,000,000,000 of CUSIP 91282CAH4 on August 27, 2020, with maturity on August 31, 2027. The larger offering needs more bids than July’s sale to maintain the same coverage. [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2020/A_20200820_3.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A) [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2020/R_20200728_3.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Evidence

The comparable July 28, 2020 auction cleared at a high yield of 0.446%. Treasury reported bid-to-cover of 2.45, calculated as $107,769,283,300 tendered divided by $44,000,013,300 accepted. Both amounts exclude SOMA, as does the August offering amount. The supplied releases establish the July result but do not independently verify that no comparable auction intervened. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2020/R_20200728_3.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C) [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2020/A_20200820_3.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A)

## What would change the view

The strongest alternative is within: investors reinvesting proceeds from maturing Treasuries could lift bids roughly in proportion to supply. Treasury estimates $86,894,000,000 of publicly held coupon securities mature on the new note’s issue date, but gives no allocation to this note. I would switch to within if the when-issued note consistently traded at a lower yield than comparable outstanding Treasuries after adjusting for maturity, indicating buyers were absorbing the larger issue without a yield concession. The announcement does not establish that signal. [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2020/A_20200820_3.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A)

## Sources

1. [U.S. Treasury offering announcement of 2020-08-20, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2020/A_20200820_3.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A), available by 2020-08-20.
2. [U.S. Treasury competitive auction results of 2020-07-28, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2020/R_20200728_3.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C), available by 2020-07-28.
