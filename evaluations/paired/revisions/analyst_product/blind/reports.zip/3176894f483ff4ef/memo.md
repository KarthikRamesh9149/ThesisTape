# Investment research memo

As of 2017-10-04T12:00:00Z

**Research question**
How did Berkshire’s announced Pilot Flying J investment divide ownership and control initially, and what change was planned for 2023? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

As of 2017-10-04T12:00:00Z, Berkshire had bought a minority interest in Pilot Flying J, not control. At closing, Berkshire held 38.6%, the Haslam family retained the majority with 50.1%, and the Maggelet family’s FJ Management held 11.3%. Berkshire thus gained economic exposure immediately, but the agreement placed the shift in majority ownership in 2023. The equity split supports a Haslam voting majority at closing if votes followed ownership; the release does not specify separate voting rights. [1](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=NEWS%20RELEASE%20CONTACT%3A%20Kim%20Metcalfe%20Zeno) [2](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=Maggelet%20family%2C%20will%20retain%2011.3%20percent)

## Evidence

The planned purchase reconciles across all owners. Berkshire’s 38.6% plus 41.4 percentage points would give it 80%. The Haslams would retain 20%, a reduction of 50.1 − 20 = 30.1 percentage points. The balance of Berkshire’s increase, 41.4 − 30.1 = 11.3 percentage points, equals FJ Management’s entire closing stake, leaving it with no equity. [1](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=NEWS%20RELEASE%20CONTACT%3A%20Kim%20Metcalfe%20Zeno) [2](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=Maggelet%20family%2C%20will%20retain%2011.3%20percent)

Management continuity was distinct from shareholder control. Jimmy Haslam would stay as CEO, Ken Parent as president, the management team would remain, and headquarters would stay in Knoxville. The family’s planned continued involvement after Berkshire became the majority owner did not imply a continuing Haslam voting majority or a promise that Jimmy would remain CEO through the transition. [1](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=NEWS%20RELEASE%20CONTACT%3A%20Kim%20Metcalfe%20Zeno) [2](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=Maggelet%20family%2C%20will%20retain%2011.3%20percent)

## Outlook

Berkshire’s minority stake let it share in any earnings growth across Pilot’s North American travel-center network before the planned shift to majority ownership in 2023. The base case is that expansion raises operating earnings; the strongest alternative is that sales grow without a corresponding increase in profit. The release describes growth opportunities but cautions that actual results may differ from forecasts. Subsequent operating earnings would test the economic case; a closing disclosure confirming the new equity split would test the ownership case. [1](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=NEWS%20RELEASE%20CONTACT%3A%20Kim%20Metcalfe%20Zeno) [2](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=Maggelet%20family%2C%20will%20retain%2011.3%20percent) [3](https://www.berkshirehathaway.com/news/oct0317.pdf#page=2&search=Securities%20Litigation%20Reform%20Act%20of%201995.)

## Checked calculations

- C1. Berkshire: 38.6% minority at closing; planned 2023 purchase adds 41.4 points for an 80% majority (PDF p. 1) (% of Pilot equity) — 38.6 + 41.4 = 80.0 [1](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=NEWS%20RELEASE%20CONTACT%3A%20Kim%20Metcalfe%20Zeno) [2](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=Maggelet%20family%2C%20will%20retain%2011.3%20percent)
- C2. Haslams: 50.1% majority at closing, 20% planned for 2023; reduction of 30.1 points (PDF p. 1) (percentage points) — 50.1 − 20 = 30.1 [1](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=NEWS%20RELEASE%20CONTACT%3A%20Kim%20Metcalfe%20Zeno) [2](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=Maggelet%20family%2C%20will%20retain%2011.3%20percent)
- C3. FJ Management: 11.3% at closing, none planned for 2023; its stake supplies the other 11.3 points (PDF p. 1) (percentage points) — 41.4 − C2 = 11.3 [1](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=NEWS%20RELEASE%20CONTACT%3A%20Kim%20Metcalfe%20Zeno) [2](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=Maggelet%20family%2C%20will%20retain%2011.3%20percent)

## Sources

1. [Berkshire Hathaway invests in Pilot Flying J, PDF p1 §1](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=NEWS%20RELEASE%20CONTACT%3A%20Kim%20Metcalfe%20Zeno), available by 2017-10-03.
2. [Berkshire Hathaway invests in Pilot Flying J, PDF p1 §2](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=Maggelet%20family%2C%20will%20retain%2011.3%20percent), available by 2017-10-03.
3. [Berkshire Hathaway invests in Pilot Flying J, PDF p2 §2](https://www.berkshirehathaway.com/news/oct0317.pdf#page=2&search=Securities%20Litigation%20Reform%20Act%20of%201995.), available by 2017-10-03.
