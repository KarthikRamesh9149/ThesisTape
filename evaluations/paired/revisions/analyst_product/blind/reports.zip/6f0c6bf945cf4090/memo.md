# Investment research memo

As of 2016-07-27T12:00:00Z

Forecast direction: lower

**Research question**
Using Canon’s first half FY2016 release, what consolidated operating profit remained to be earned to meet its December year-end projection? Give your call on the reported annual result relative to the projection (within means ±2% of guidance, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Evidence

Currency leaves little room for an operating shortfall. Yen appreciation had reduced first-half operating profit by ¥43.5 billion year on year, but that is not a loss to subtract again: July guidance already assumed second-half rates of 105 yen per dollar and 115 per euro. Canon estimated second-half operating-profit sensitivity per yen at JPY 2.6 billion for the dollar and JPY 1.5 billion for the euro. A stronger yen than budgeted would compound a volume miss; the release does not establish that exchange rates would move that way. [1](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=2&search=The%20average%20value%20of%20the%20yen) [2](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=4&search=semiconductor%20lithography%20equipment%2C%20FPD%20lithography%20equipment) [3](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=19&search=Canon%20Inc.%206.%20PROFITABILITY%202016%20%7C)

## Outlook

**Lower** as of 2016-07-27T12:00:00Z: I expect annual operating profit below the lower edge of an inclusive ±2% band around the reference, not merely below the projection. My main concern is the step-up in quarterly earnings required while Canon expected laser-printer demand to remain weak and inkjet demand to keep falling. Those pressures were known in July; the downside judgment is that the rest of the business would not offset them fast enough, not that management overlooked them. [4](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=1&search=CONSOLIDATED%20RESULTS%20FOR%20THE%20SECOND%20QUARTER) [5](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=4&search=Outlook%20As%20for%20the%20outlook%20in)

Lower as of 2016-07-27T12:00:00Z. The inclusive within band around Canon’s JPY 265,000 million projection is an inclusive ±2% band around the reference. The forecast is for reported full-year operating profit strictly below the band’s lower endpoint, not merely below the projection. [4](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=1&search=CONSOLIDATED%20RESULTS%20FOR%20THE%20SECOND%20QUARTER)

The strongest alternative is within: if exchange rates stay near Canon’s assumptions, continued growth in flat-panel and OLED production equipment sales could help offset weak printer demand. Canon had already reported higher industrial equipment sales, but the release did not establish how much additional operating profit those sales could deliver. [1](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=2&search=The%20average%20value%20of%20the%20yen) [5](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=4&search=Outlook%20As%20for%20the%20outlook%20in) [2](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=4&search=semiconductor%20lithography%20equipment%2C%20FPD%20lithography%20equipment)

## What would change the view

I would switch to within if the next quarterly release showed continued growth in display-equipment sales and reported nine-month operating profit that, with another quarter at the newly reported quarterly profit level, would put the full year inside an inclusive ±2% band around the reference. The sales trend would show that the offset was developing; the consolidated profit test would check whether it was large enough. [1](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=2&search=The%20average%20value%20of%20the%20yen) [4](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=1&search=CONSOLIDATED%20RESULTS%20FOR%20THE%20SECOND%20QUARTER)

## Sources

1. [Canon consolidated results for the second quarter and first half ended June 30, 2016, PDF p2 §2](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=2&search=The%20average%20value%20of%20the%20yen), available by 2016-07-26.
2. [Canon consolidated results for the second quarter and first half ended June 30, 2016, PDF p4 §2](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=4&search=semiconductor%20lithography%20equipment%2C%20FPD%20lithography%20equipment), available by 2016-07-26.
3. [Canon consolidated results for the second quarter and first half ended June 30, 2016, PDF p19 §1](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=19&search=Canon%20Inc.%206.%20PROFITABILITY%202016%20%7C), available by 2016-07-26.
4. [Canon consolidated results for the second quarter and first half ended June 30, 2016, PDF p1 §1](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=1&search=CONSOLIDATED%20RESULTS%20FOR%20THE%20SECOND%20QUARTER), available by 2016-07-26.
5. [Canon consolidated results for the second quarter and first half ended June 30, 2016, PDF p4 §1](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=4&search=Outlook%20As%20for%20the%20outlook%20in), available by 2016-07-26.
