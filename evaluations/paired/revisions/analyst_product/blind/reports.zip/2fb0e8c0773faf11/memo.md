# Investment research memo

As of 2018-10-25T12:00:00Z

Forecast direction: within

**Research question**
What did the Bank of Canada decide on 2018-10-24, what in the statement qualifies its policy stance, and where do you expect the overnight rate target at the 2018-12-05 scheduled decision relative to its 2018-10-24 level? Explain the role of the new trade agreement. Within means unchanged. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

On October 24, 2018, the Bank of Canada raised its overnight rate target to 1 ¾ per cent from September’s 1 ½ per cent. The increase was 0.25 (October target minus September target). The Bank said rates would need to rise further to reach a neutral stance, but it did not commit to another increase in December. [1](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [2](https://www.bankofcanada.ca/wp-content/uploads/2018/09/fad-press-release-2018-09-05.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [3](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=competitiveness%20challenges%20and%20limited%20transportation%20capacity.)

## Evidence

The new US–Mexico–Canada Agreement strengthened the case for further increases by reducing a source of uncertainty for businesses. The Bank revised up its investment and export projections, but attributed the revision to both the agreement and a natural gas project in British Columbia. That was a stronger forecast, not evidence that the agreement had already lifted investment: the Bank still intended to watch for that response. [1](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [3](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=competitiveness%20challenges%20and%20limited%20transportation%20capacity.)

## Outlook

Base case for 2018-12-05: within (unchanged), at 1 ¾ per cent relative to October (inclusive threshold: unchanged). The main reason to pause is that core inflation remained around 2 per cent, giving the Bank room to assess how indebted households were absorbing higher rates. October’s emphasis on reaching neutral sounded firmer than September’s pledge of a gradual approach, but household adjustment still governed the pace. [3](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=competitiveness%20challenges%20and%20limited%20transportation%20capacity.) [4](https://www.bankofcanada.ca/wp-content/uploads/2018/09/fad-press-release-2018-09-05.pdf#page=1&search=exports.%20While%20uncertainty%20abo%20ut%20trade) [1](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media)

## What would change the view

The strongest alternative is higher, at 2 (October’s 1 ¾ per cent plus a repeat of the 0.25 increase). With the economy operating at capacity, a broad acceleration across the Bank’s core inflation measures before the decision would shift my call to a hike. A headline move driven by airfares alone would not: it would say less about underlying price pressure. This is a forecast trigger, not a threshold announced by the Bank. [1](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [2](https://www.bankofcanada.ca/wp-content/uploads/2018/09/fad-press-release-2018-09-05.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [3](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=competitiveness%20challenges%20and%20limited%20transportation%20capacity.)

## Checked calculations

- C1. 2018-10-24 overnight rate target increase from the 2018-09-05 level (percentage points) — 1 ¾ − 1 ½ = 0.25 [1](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [2](https://www.bankofcanada.ca/wp-content/uploads/2018/09/fad-press-release-2018-09-05.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media)
- C2. 2018-12-05 alternative overnight rate target if the October increase is repeated (percent) — 1 ¾ + C1 = 2.00 [1](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [2](https://www.bankofcanada.ca/wp-content/uploads/2018/09/fad-press-release-2018-09-05.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media)

## Sources

1. [Bank of Canada policy rate announcement of 2018-10-24, PDF p1 §1](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media), available by 2018-10-24.
2. [Bank of Canada policy rate announcement of 2018-09-05, PDF p1 §1](https://www.bankofcanada.ca/wp-content/uploads/2018/09/fad-press-release-2018-09-05.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media), available by 2018-09-05.
3. [Bank of Canada policy rate announcement of 2018-10-24, PDF p1 §2](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=competitiveness%20challenges%20and%20limited%20transportation%20capacity.), available by 2018-10-24.
4. [Bank of Canada policy rate announcement of 2018-09-05, PDF p1 §2](https://www.bankofcanada.ca/wp-content/uploads/2018/09/fad-press-release-2018-09-05.pdf#page=1&search=exports.%20While%20uncertainty%20abo%20ut%20trade), available by 2018-09-05.
