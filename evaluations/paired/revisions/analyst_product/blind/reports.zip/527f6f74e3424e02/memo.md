# Investment research memo

As of 2017-10-04T12:00:00Z

**Research question**
How did Berkshire’s announced Pilot Flying J investment divide ownership and control initially, and what change was planned for 2023? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Evidence

Operating leadership also stayed in place: Jimmy Haslam remained CEO, Ken Parent remained president, and the management team continued. An analyst should therefore read the initial investment as a minority partnership, not a handover of day-to-day operations. Management continuity does not, however, establish what board or veto rights Berkshire may have negotiated. [1](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=NEWS%20RELEASE%20CONTACT%3A%20Kim%20Metcalfe%20Zeno)

## What would change the view

The material alternative was that the additional purchase might be delayed or not close, leaving Berkshire a minority owner beyond the planned date. The release cautioned that forward-looking statements were not guarantees; it did not report a closing of the future purchase. Confirmation that Berkshire had acquired the additional stake would distinguish an actual transfer of majority ownership from the announced plan. [2](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=Maggelet%20family%2C%20will%20retain%2011.3%20percent) [3](https://www.berkshirehathaway.com/news/oct0317.pdf#page=2&search=Securities%20Litigation%20Reform%20Act%20of%201995.)

## Sources

1. [Berkshire Hathaway invests in Pilot Flying J, PDF p1 §1](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=NEWS%20RELEASE%20CONTACT%3A%20Kim%20Metcalfe%20Zeno), available by 2017-10-03.
2. [Berkshire Hathaway invests in Pilot Flying J, PDF p1 §2](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=Maggelet%20family%2C%20will%20retain%2011.3%20percent), available by 2017-10-03.
3. [Berkshire Hathaway invests in Pilot Flying J, PDF p2 §2](https://www.berkshirehathaway.com/news/oct0317.pdf#page=2&search=Securities%20Litigation%20Reform%20Act%20of%201995.), available by 2017-10-03.
