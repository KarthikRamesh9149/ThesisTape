# Investment research memo

As of 2021-11-04T12:00:00Z

Forecast direction: within

**Research question**
Prepare an auction preview for the U.S. Treasury 30-year nominal bond sale scheduled for 2021-11-10. Identify the offering and maturity, report the prior comparable auction’s bid-to-cover and clearing rate, and forecast the new high yield relative to that auction (within means ±5 basis points, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

As of 2021-11-04T12:00:00Z, my call is **within** for the U.S. Treasury’s November 10, 2021 auction. Treasury is offering $25,000,000,000 of a new nominal 30-Year Bond maturing November 15, 2051. The key pricing question is whether buyers will require a materially higher yield to absorb the new issue than they accepted at the October reopening. [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2021/A_20211103_1.pdf#page=1&search=Embargoed%20Until%2008%3A30%20A.M.%20%7C%20CONTACT%3A)

## Evidence

The October 13, 2021 sale is comparable by remaining maturity, not by security identity: it reopened the bond originally issued August 16, 2021, with a remaining term Treasury described as a 29-Year 10-Month Bond. It cleared at a high yield of 2.049%, not the coupon rate of 2%. The inclusive comparison band is an inclusive ±0.05 percentage points band around the reference, centered on that clearing yield. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2021/R_20211013_2.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Outlook

**Within** is a low-confidence base case. October demand is the main reason not to assume a large upward move solely because November supply is larger: Treasury reports $56,628,143,600 tendered divided by $24,000,023,000 accepted, for bid-to-cover of 2.36. That shows buyers bid for more than Treasury sold, not that they would bid at October yields in November. The supplied releases contain no pre-cutoff market yield for the new bond, so the October clearing yield is a fallback pricing reference, not a verified current quote. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2021/R_20211013_2.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C) [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2021/A_20211103_1.pdf#page=1&search=Embargoed%20Until%2008%3A30%20A.M.%20%7C%20CONTACT%3A)

## What would change the view

**Higher** is the strongest alternative: the larger new issue may require a yield concession despite October’s bid coverage. I would switch to higher if the new bond’s when-issued yield traded persistently above the upper edge of the band approaching the competitive bidding deadline. That would be price evidence for the actual bond on offer and would outweigh a demand ratio from the prior sale. [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2021/A_20211103_1.pdf#page=1&search=Embargoed%20Until%2008%3A30%20A.M.%20%7C%20CONTACT%3A) [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2021/R_20211013_2.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Sources

1. [U.S. Treasury offering announcement of 2021-11-03, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2021/A_20211103_1.pdf#page=1&search=Embargoed%20Until%2008%3A30%20A.M.%20%7C%20CONTACT%3A), available by 2021-11-03.
2. [U.S. Treasury competitive auction results of 2021-10-13, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2021/R_20211013_2.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C), available by 2021-10-13.
