# Investment research memo

As of 2022-11-06T12:00:00Z

**Research question**
For Berkshire’s third quarter of 2022, did insurance investment income cover the underwriting loss, and how did the combined contribution compare with Q3 2021? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

Yes. Berkshire Hathaway’s after-tax insurance investment income more than covered its underwriting loss in the third quarter of 2022, leaving a larger combined contribution than in the third quarter of 2021. In USD millions, the sums were 1,408 + (962) = 446 and 1,161 + (784) = 377, respectively. Parentheses denote losses. [1](https://www.berkshirehathaway.com/news/nov0522.pdf#page=2&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earn) [2](https://www.berkshirehathaway.com/news/nov0522.pdf#page=1&search=BERKSHIRE%20HATHAWAY%20INC.%20NEWS%20RELEASE%20FOR)

## Evidence

The combined contribution rose by 446 − 377 = 69 million dollars, or 18.3024% (69 ÷ 377, expressed as a percentage). Higher investment income more than offset the deeper underwriting loss, so the increase in insurance operating earnings did not signal an improvement in underwriting. [1](https://www.berkshirehathaway.com/news/nov0522.pdf#page=2&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earn)

## Outlook

As of 2022-11-06T12:00:00Z, the offset in both quarters supports treating investment income as a cushion, but not assuming a fixed quarterly contribution. The comparison does not establish why income rose or whether it will keep pace with underwriting losses. The base case to test is a positive combined contribution; the alternative is that lower income or a deeper loss erases it. The observable signal is the next reported pair of insurance lines: if investment income is no greater than the magnitude of the underwriting loss, their combined contribution is no longer positive. [1](https://www.berkshirehathaway.com/news/nov0522.pdf#page=2&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earn)

## Checked calculations

- C1. Q3 2022 after-tax net insurance: $446m; investment income covered the underwriting loss (PDF p. 2; tax basis p. 1) (USD million) — 1,408 + (962) = 446 [1](https://www.berkshirehathaway.com/news/nov0522.pdf#page=2&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earn)
- C2. Q3 2021 after-tax net insurance: $377m; both components on PDF p. 2 (USD million) — 1,161 + (784) = 377 [1](https://www.berkshirehathaway.com/news/nov0522.pdf#page=2&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earn)
- C3. Q3 2022 vs. Q3 2021: net rose $69m; higher income outweighed a larger underwriting loss (PDF p. 2) (USD million) — C1 − C2 = 69 [1](https://www.berkshirehathaway.com/news/nov0522.pdf#page=2&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earn)
- C4. Q3 2022 vs. Q3 2021: net rose 18.3%; offset held in both quarters, but income and losses can vary (PDF p. 2) (percent) — (C1 − C2) ÷ |C2| × 100 ≈ 18.302387 [1](https://www.berkshirehathaway.com/news/nov0522.pdf#page=2&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earn)

## Sources

1. [Berkshire Hathaway third-quarter 2022 earnings, PDF p2 §1](https://www.berkshirehathaway.com/news/nov0522.pdf#page=2&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earn), available by 2022-11-05.
2. [Berkshire Hathaway third-quarter 2022 earnings, PDF p1 §1](https://www.berkshirehathaway.com/news/nov0522.pdf#page=1&search=BERKSHIRE%20HATHAWAY%20INC.%20NEWS%20RELEASE%20FOR), available by 2022-11-05.
