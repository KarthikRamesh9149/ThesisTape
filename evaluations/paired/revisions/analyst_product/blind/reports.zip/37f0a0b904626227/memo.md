# Investment research memo

As of 2015-08-11T12:00:00Z

**Research question**
What was Berkshire offering Precision Castparts shareholders, how was the headline deal value defined, and what stood between signing and closing? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

As of 2015-08-11T12:00:00Z, Berkshire Hathaway’s offer was $235 in cash for each outstanding Precision Castparts (PCC) share, payable if the deal closed. The companies announced on Aug. 10, 2015 that both boards had unanimously approved a definitive agreement. The approximately $ 37.2 billion headline includes PCC’s outstanding net debt; it is not the amount payable to shareholders. [1](https://www.berkshirehathaway.com/news/aug1015.pdf#page=1&search=Berkshire%20Hathaway%20Inc.%20to%20Acquire%20Precision)

## Evidence

The release establishes a cash price, not the size of a market premium. Measuring the premium requires a dated, unaffected pre-announcement closing price. Estimating aggregate equity proceeds requires a dated share count, and reconciling that estimate to the headline requires a dated net-debt amount. The release supplies none of those inputs, so neither a premium percentage nor an equity-to-headline reconciliation is supportable here. [1](https://www.berkshirehathaway.com/news/aug1015.pdf#page=1&search=Berkshire%20Hathaway%20Inc.%20to%20Acquire%20Precision)

The companies expected closing in the first calendar quarter of 2016, but that was not a guaranteed payment date. Approval required a majority of all outstanding PCC shares, not merely a majority of votes cast. U.S. Hart–Scott–Rodino clearance, competition clearance in certain foreign jurisdictions, and other customary closing conditions also remained. A prolonged review could delay payment; a failed shareholder vote or failure to obtain a required clearance could prevent closing. [2](https://www.berkshirehathaway.com/news/aug1015.pdf#page=1&search=The%20transaction%20requires%20approval%20by%20a)

## Outlook

PCC’s CEO endorsed the deal as compelling value. The case for cash is that, once paid, it shields selling shareholders from any subsequent operating weakness at PCC. The strongest alternative is that the same cash price gives up upside if PCC’s established aerospace components business generates more cash than the offer implies. The release describes PCC’s market position but does not quantify standalone cash flows, so even a verified market premium would not settle which interpretation is stronger. [1](https://www.berkshirehathaway.com/news/aug1015.pdf#page=1&search=Berkshire%20Hathaway%20Inc.%20to%20Acquire%20Precision) [3](https://www.berkshirehathaway.com/news/aug1015.pdf#page=2&search=10%3A00%20a.m.%2C%20Pacific%20Time%2C%20in%20the)

## What would change the view

Test the cash offer against PCC’s standalone per-share value using contemporaneous filings and any forecasts or valuation assumptions disclosed in the planned merger proxy. If a credible valuation exceeds $235 per share even under conservative aerospace demand assumptions, the case for accepting cash weakens despite any verified market premium. If standalone value exceeds the offer only under optimistic assumptions, the cash offer is more persuasive. [1](https://www.berkshirehathaway.com/news/aug1015.pdf#page=1&search=Berkshire%20Hathaway%20Inc.%20to%20Acquire%20Precision) [4](https://www.berkshirehathaway.com/news/aug1015.pdf#page=2&search=This%20communication%20may%20be%20deemed%20to) [5](https://www.berkshirehathaway.com/news/aug1015.pdf#page=4&search=consummation%20of%20the%20proposed%20transaction%20on)

## Sources

1. [Berkshire Hathaway to acquire Precision Castparts, PDF p1 §1](https://www.berkshirehathaway.com/news/aug1015.pdf#page=1&search=Berkshire%20Hathaway%20Inc.%20to%20Acquire%20Precision), available by 2015-08-10.
2. [Berkshire Hathaway to acquire Precision Castparts, PDF p1 §2](https://www.berkshirehathaway.com/news/aug1015.pdf#page=1&search=The%20transaction%20requires%20approval%20by%20a), available by 2015-08-10.
3. [Berkshire Hathaway to acquire Precision Castparts, PDF p2 §1](https://www.berkshirehathaway.com/news/aug1015.pdf#page=2&search=10%3A00%20a.m.%2C%20Pacific%20Time%2C%20in%20the), available by 2015-08-10.
4. [Berkshire Hathaway to acquire Precision Castparts, PDF p2 §2](https://www.berkshirehathaway.com/news/aug1015.pdf#page=2&search=This%20communication%20may%20be%20deemed%20to), available by 2015-08-10.
5. [Berkshire Hathaway to acquire Precision Castparts, PDF p4 §1](https://www.berkshirehathaway.com/news/aug1015.pdf#page=4&search=consummation%20of%20the%20proposed%20transaction%20on), available by 2015-08-10.
