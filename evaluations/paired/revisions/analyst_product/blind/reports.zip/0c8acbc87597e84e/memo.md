# Investment research memo

As of 2017-09-29T12:00:00Z

Forecast direction: undetermined

**Research question**
Prepare an auction preview for the U.S. Treasury 13-week bill sale scheduled for 2017-10-02. Identify the offering and maturity, report the prior comparable auction’s bid-to-cover and clearing rate, and forecast the new high discount rate relative to that auction (within means ±5 basis points, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Answer

As of 2017-09-29T12:00:00Z, I expect the U.S. Treasury’s October 02, 2017 auction to clear within the comparison band. Treasury will offer $42,000,000,000 in 13-Week Bills maturing January 04, 2018. Bidders therefore face nearly the same supply as at the preceding auction, but must hold the new bill past year-end to receive payment at maturity. [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2017/A_20170928_1.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A) [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2017/R_20170925_1.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Evidence

The immediately preceding 91-Day Bill auction on September 25, 2017 drew $121,370,119,500 in tenders against $42,000,519,500 accepted, for a bid-to-cover ratio of 2.89. It cleared at a high discount rate of 1.050%. The comparison uses that high rate, not the 1.067% investment rate, which expresses the yield on a coupon-equivalent basis. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2017/R_20170925_1.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## What would change the view

The strongest alternative is higher: unlike the prior bill maturing December 28, 2017, the new bill carries past year-end. If investors prefer cash before year-end, they could demand a higher discount rate despite the similar sale size. I would switch to higher if the new bill’s when-issued discount rate traded persistently above the upper endpoint ahead of competitive bidding close. The maturity dates establish the difference in timing, not the existence of a premium. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2017/R_20170925_1.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C) [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2017/A_20170928_1.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A)

## Sources

1. [U.S. Treasury offering announcement of 2017-09-28, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2017/A_20170928_1.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A), available by 2017-09-28.
2. [U.S. Treasury competitive auction results of 2017-09-25, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2017/R_20170925_1.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C), available by 2017-09-25.
