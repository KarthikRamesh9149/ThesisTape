# Investment research memo

As of 2022-11-06T12:00:00Z

**Research question**
For Berkshire’s third quarter of 2022, did insurance investment income cover the underwriting loss, and how did the combined contribution compare with Q3 2021? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

Yes. In the third quarter of 2022, Berkshire Hathaway’s insurance investment income more than covered its underwriting loss. In after-tax millions of dollars, investment income of +1,408 plus the underwriting result of (962) yielded +446 in operating earnings. [1](https://www.berkshirehathaway.com/news/nov0522.pdf#page=2&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earn) [2](https://www.berkshirehathaway.com/news/nov0522.pdf#page=1&search=BERKSHIRE%20HATHAWAY%20INC.%20NEWS%20RELEASE%20FOR)

## Evidence

Investment income, not better underwriting, drove the year-over-year improvement. In the third quarter of 2021, investment income of +1,161 plus the underwriting result of (784) yielded +377, in after-tax millions of dollars. Investment income then rose by more than the underwriting loss widened, so the two lines added 446 minus 377, or 69 million dollars more to operating earnings. [1](https://www.berkshirehathaway.com/news/nov0522.pdf#page=2&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earn)

## What would change the view

The base case is conditional: if investment income and underwriting losses stay near their latest quarterly levels, insurance should remain a positive contributor. Larger catastrophe losses could erase the year-over-year improvement without wiping out that contribution: holding investment income fixed, an additional 69 million dollars of after-tax underwriting loss would bring the sum back to +377 million dollars. The signal to watch is whether the reported underwriting loss widens relative to investment income. The quarterly totals do not isolate catastrophe losses or establish how likely they are to recur. [1](https://www.berkshirehathaway.com/news/nov0522.pdf#page=2&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earn)

## Checked calculations

- C1. Q3 2022: Investment income covered the underwriting loss, leaving +446 (both inputs: PDF p. 2). (USD millions, after tax) — 1,408 + (962) = 446 [1](https://www.berkshirehathaway.com/news/nov0522.pdf#page=2&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earn)
- C2. Q3 2021: Investment income covered the underwriting loss, leaving +377 (both inputs: PDF p. 2). (USD millions, after tax) — 1,161 + (784) = 377 [1](https://www.berkshirehathaway.com/news/nov0522.pdf#page=2&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earn)
- C3. Q3 2022 vs. Q3 2021: Insurance added 69 more to operating earnings; larger catastrophe losses could erase that increase. (USD millions, after tax) — C1 − C2 = 69 [1](https://www.berkshirehathaway.com/news/nov0522.pdf#page=2&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earn)

## Sources

1. [Berkshire Hathaway third-quarter 2022 earnings, PDF p2 §1](https://www.berkshirehathaway.com/news/nov0522.pdf#page=2&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earn), available by 2022-11-05.
2. [Berkshire Hathaway third-quarter 2022 earnings, PDF p1 §1](https://www.berkshirehathaway.com/news/nov0522.pdf#page=1&search=BERKSHIRE%20HATHAWAY%20INC.%20NEWS%20RELEASE%20FOR), available by 2022-11-05.
