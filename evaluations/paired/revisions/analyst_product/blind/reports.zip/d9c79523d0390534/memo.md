# Investment research memo

As of 2017-07-13T12:00:00Z

Forecast direction: within

**Research question**
What did the Bank of Canada decide on 2017-07-12, what in the statement qualifies its policy stance, and where do you expect the overnight rate target at the 2017-09-06 scheduled decision relative to its 2017-07-12 level? Compare to May and explain the Bank’s view of inflation softness. Within means unchanged. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

On July 12, 2017, the Bank of Canada raised its overnight rate target to 3/4 per cent from the 1/2 per cent it had maintained in May. The July target minus the May target gives an increase of 0.25 percentage points. The Bank tightened before inflation recovered: it expected growth to absorb spare capacity and recognized that a rate change takes time to affect prices. [1](https://www.bankofcanada.ca/wp-content/uploads/2017/07/fad-press-release-2017-07-12.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [2](https://www.bankofcanada.ca/wp-content/uploads/2017/05/fad-press-release-2017-05-24.pdf#page=1&search=housing%20markets.%20Meanwhile%2C%20e%20%7C%20xport)

## Evidence

The shift since May was in the Bank’s assessment of spare capacity, not in the inflation readings. In May, subdued wages and low core inflation pointed to ongoing slack. By July, the Bank expected the output gap to close around year-end, earlier than it had expected in April. It judged the inflation softness mostly temporary, citing food price competition, Ontario electricity rebates and changes in car pricing. But it left open how long it could look past weak readings: future rate moves would depend on what incoming data implied for inflation. [3](https://www.bankofcanada.ca/wp-content/uploads/2017/05/fad-press-release-2017-05-24.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [4](https://www.bankofcanada.ca/wp-content/uploads/2017/07/fad-press-release-2017-07-12.pdf#page=1&search=adjustment%20to%20lower%20oil%20prices%20is)

## Outlook

Base case for September 6, 2017: within (unchanged), meaning unchanged at 3/4 per cent. The main reason to pause is uncertainty about how quickly less spare capacity will lift underlying inflation. All of the Bank’s core measures were still below 2 per cent. The July statement explains why the Bank was willing to act ahead of inflation, but it does not establish that another increase will be warranted by September. [5](https://www.bankofcanada.ca/wp-content/uploads/2017/07/fad-press-release-2017-07-12.pdf#page=2&search=Information%20note%3A%20The%20next%20scheduled%20date) [1](https://www.bankofcanada.ca/wp-content/uploads/2017/07/fad-press-release-2017-07-12.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [4](https://www.bankofcanada.ca/wp-content/uploads/2017/07/fad-press-release-2017-07-12.pdf#page=1&search=adjustment%20to%20lower%20oil%20prices%20is)

## What would change the view

The strongest alternative is higher: continued above-potential growth could justify further tightening before the output gap closes. A broad pickup across the Bank’s core inflation measures before the September decision would shift the call to another hike. That would be more persuasive evidence of underlying price pressure than a headline rebound driven by fading rebates or food discounts. [1](https://www.bankofcanada.ca/wp-content/uploads/2017/07/fad-press-release-2017-07-12.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [4](https://www.bankofcanada.ca/wp-content/uploads/2017/07/fad-press-release-2017-07-12.pdf#page=1&search=adjustment%20to%20lower%20oil%20prices%20is)

## Checked calculations

- C1. Increase in the overnight rate target from May 24 to July 12, 2017 (0.25 percentage points, or 25 basis points) (percentage points) — 3/4 − 1/2 = 0.25 [1](https://www.bankofcanada.ca/wp-content/uploads/2017/07/fad-press-release-2017-07-12.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [2](https://www.bankofcanada.ca/wp-content/uploads/2017/05/fad-press-release-2017-05-24.pdf#page=1&search=housing%20markets.%20Meanwhile%2C%20e%20%7C%20xport)

## Sources

1. [Bank of Canada policy rate announcement of 2017-07-12, PDF p1 §1](https://www.bankofcanada.ca/wp-content/uploads/2017/07/fad-press-release-2017-07-12.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media), available by 2017-07-12.
2. [Bank of Canada policy rate announcement of 2017-05-24, PDF p1 §2](https://www.bankofcanada.ca/wp-content/uploads/2017/05/fad-press-release-2017-05-24.pdf#page=1&search=housing%20markets.%20Meanwhile%2C%20e%20%7C%20xport), available by 2017-05-24.
3. [Bank of Canada policy rate announcement of 2017-05-24, PDF p1 §1](https://www.bankofcanada.ca/wp-content/uploads/2017/05/fad-press-release-2017-05-24.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media), available by 2017-05-24.
4. [Bank of Canada policy rate announcement of 2017-07-12, PDF p1 §2](https://www.bankofcanada.ca/wp-content/uploads/2017/07/fad-press-release-2017-07-12.pdf#page=1&search=adjustment%20to%20lower%20oil%20prices%20is), available by 2017-07-12.
5. [Bank of Canada policy rate announcement of 2017-07-12, PDF p2 §1](https://www.bankofcanada.ca/wp-content/uploads/2017/07/fad-press-release-2017-07-12.pdf#page=2&search=Information%20note%3A%20The%20next%20scheduled%20date), available by 2017-07-12.
