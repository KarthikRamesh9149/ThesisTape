# Investment research memo

As of 2017-10-25T12:00:00Z

Forecast direction: within

**Research question**
Using Canon’s first nine months FY2017 release, what consolidated net sales remained to be earned to meet its December year-end projection? Give your call on the reported annual result relative to the projection (within means ±2% of guidance, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Answer

Canon’s October 24, 2017 consolidated results for the third quarter and nine months ended September were public by 2017-10-25T12:00:00Z. To meet its December year-end projection, Canon still needed fourth-quarter consolidated net sales equal to full-year guidance of 4,080,000¥ less reported nine-month sales of 2,959,724¥, both in millions of yen. That requirement was above reported third-quarter sales of 994,490¥ million. [1](https://global.canon/en/ir/results/2017/rslt2017q3e.pdf#page=1&search=CONSOLIDATED%20RESULTS%20FOR%20THE%20THIRD%20QUARTER)

## Evidence

Apply the question’s inclusive an inclusive ±2% band around the reference rule to Canon’s full-year guidance of 4,080,000¥ million. The equivalent fourth-quarter bounds are the annual floor and ceiling each less reported nine-month sales of 2,959,724¥ million. A miss against the point projection can therefore still count as within; equality at either bound counts as within. [1](https://global.canon/en/ir/results/2017/rslt2017q3e.pdf#page=1&search=CONSOLIDATED%20RESULTS%20FOR%20THE%20THIRD%20QUARTER)

## Outlook

Base case: within. The main driver is panel makers’ spending on flat-panel lithography and OLED manufacturing equipment. Canon reported that sales of those products were substantially higher than a year earlier and expected continued investment to support demand. The forecast assumes enough of that demand converts into fourth-quarter shipments to lift consolidated sales above the floor, even if Canon misses the point projection. The reported equipment growth was year over year, not evidence of a sequential increase, and Canon did not quantify the equipment lines’ expected fourth-quarter contribution. [2](https://global.canon/en/ir/results/2017/rslt2017q3e.pdf#page=2&search=depreciation%20of%20approximately%20%C2%A59%2C%20and%20%C2%A5130.42) [3](https://global.canon/en/ir/results/2017/rslt2017q3e.pdf#page=4&search=out%2C%20with%20demand%20leveling%20off%20to)

## What would change the view

The strongest alternative is lower if panel makers defer equipment purchases and shipments slip past year-end. I would switch to lower if Canon disclosed deferrals large enough to put expected fourth-quarter consolidated sales below the annual floor less the nine-month actual of 2,959,724¥ million. A delay without a quantified sales impact would be a warning, not enough to change the call; reported sales exactly at the floor would still count as within. [3](https://global.canon/en/ir/results/2017/rslt2017q3e.pdf#page=4&search=out%2C%20with%20demand%20leveling%20off%20to) [1](https://global.canon/en/ir/results/2017/rslt2017q3e.pdf#page=1&search=CONSOLIDATED%20RESULTS%20FOR%20THE%20THIRD%20QUARTER)

## Sources

1. [Canon consolidated results for the third quarter and nine months ended September 30, 2017, PDF p1 §1](https://global.canon/en/ir/results/2017/rslt2017q3e.pdf#page=1&search=CONSOLIDATED%20RESULTS%20FOR%20THE%20THIRD%20QUARTER), available by 2017-10-24.
2. [Canon consolidated results for the third quarter and nine months ended September 30, 2017, PDF p2 §2](https://global.canon/en/ir/results/2017/rslt2017q3e.pdf#page=2&search=depreciation%20of%20approximately%20%C2%A59%2C%20and%20%C2%A5130.42), available by 2017-10-24.
3. [Canon consolidated results for the third quarter and nine months ended September 30, 2017, PDF p4 §2](https://global.canon/en/ir/results/2017/rslt2017q3e.pdf#page=4&search=out%2C%20with%20demand%20leveling%20off%20to), available by 2017-10-24.
