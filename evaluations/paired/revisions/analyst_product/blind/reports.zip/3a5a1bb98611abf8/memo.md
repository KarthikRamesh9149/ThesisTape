# Investment research memo

As of 2017-10-25T12:00:00Z

Forecast direction: within

**Research question**
Using Canon’s first nine months FY2017 release, what consolidated net sales remained to be earned to meet its December year-end projection? Give your call on the reported annual result relative to the projection (within means ±2% of guidance, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

Canon needed fourth-quarter consolidated net sales of exactly **(4,080,000 − 2,959,724) million yen** to meet its December year-end projection. The first input is revised full-year guidance, not the previous outlook of 4,050,000 million yen; the second is consolidated sales already earned through September. My full-year call is **within guidance**. [1](https://global.canon/en/ir/results/2017/rslt2017q3e.pdf#page=4&search=Fiscal%20year%20%7C%20Millions%20of%20yen) [2](https://global.canon/en/ir/results/2017/rslt2017q3e.pdf#page=9&search=Overseas%3A%20Americas%20%7C%20804%2C238%20%7C%20696%2C077)

## Evidence

The hurdle requires a step up from third-quarter sales of ¥994.5 billion, but not an acceleration in year-on-year growth. Last year's fourth-quarter comparison was (3,401,487 − 2,436,314) million yen. Against that base, the required growth is slower than the 21.5% Canon had already delivered through September. [3](https://global.canon/en/ir/results/2017/rslt2017q3e.pdf#page=2&search=depreciation%20of%20approximately%20%C2%A59%2C%20and%20%C2%A5130.42) [1](https://global.canon/en/ir/results/2017/rslt2017q3e.pdf#page=4&search=Fiscal%20year%20%7C%20Millions%20of%20yen) [2](https://global.canon/en/ir/results/2017/rslt2017q3e.pdf#page=9&search=Overseas%3A%20Americas%20%7C%20804%2C238%20%7C%20696%2C077)

## Outlook

**Within** the inclusive an inclusive ±2% band around the reference band is the base case. The main support is the acquired medical business: Medical System generated ¥112.1 billion in the third quarter, and Canon expected replacement purchases to sustain medical demand in developed markets. Continued panel-maker investment also supports display-equipment sales. Both drivers help explain why the hurdle is attainable, but neither is a reason by itself to call for an overshoot: Canon already incorporated the acquisition and its demand outlook in guidance. [4](https://global.canon/en/ir/results/2017/rslt2017q3e.pdf#page=3&search=the%20high-image-quality%20PowerShot%20G-series%20lineup%2C%20leading) [5](https://global.canon/en/ir/results/2017/rslt2017q3e.pdf#page=4&search=out%2C%20with%20demand%20leveling%20off%20to)

## What would change the view

The strongest alternative is **lower** if panel makers defer equipment deliveries: camera markets were already contracting, and Canon expected flat overall office MFD demand, leaving little evidence that those markets could offset a shortfall. I would switch on a Canon sales update showing that the value of shipments pushed past December, net of gains elsewhere, puts expected fourth-quarter sales below the band's lower annual bound less September year-to-date sales. The release gives a panel investment outlook, not a delivery schedule; it cannot establish when those sales will be booked. [5](https://global.canon/en/ir/results/2017/rslt2017q3e.pdf#page=4&search=out%2C%20with%20demand%20leveling%20off%20to) [6](https://global.canon/en/ir/results/2017/rslt2017q3e.pdf#page=4&search=Outlook%20As%20for%20the%20outlook%20in)

## Sources

1. [Canon consolidated results for the third quarter and nine months ended September 30, 2017, PDF p4 §3](https://global.canon/en/ir/results/2017/rslt2017q3e.pdf#page=4&search=Fiscal%20year%20%7C%20Millions%20of%20yen), available by 2017-10-24.
2. [Canon consolidated results for the third quarter and nine months ended September 30, 2017, PDF p9 §2](https://global.canon/en/ir/results/2017/rslt2017q3e.pdf#page=9&search=Overseas%3A%20Americas%20%7C%20804%2C238%20%7C%20696%2C077), available by 2017-10-24.
3. [Canon consolidated results for the third quarter and nine months ended September 30, 2017, PDF p2 §2](https://global.canon/en/ir/results/2017/rslt2017q3e.pdf#page=2&search=depreciation%20of%20approximately%20%C2%A59%2C%20and%20%C2%A5130.42), available by 2017-10-24.
4. [Canon consolidated results for the third quarter and nine months ended September 30, 2017, PDF p3 §2](https://global.canon/en/ir/results/2017/rslt2017q3e.pdf#page=3&search=the%20high-image-quality%20PowerShot%20G-series%20lineup%2C%20leading), available by 2017-10-24.
5. [Canon consolidated results for the third quarter and nine months ended September 30, 2017, PDF p4 §2](https://global.canon/en/ir/results/2017/rslt2017q3e.pdf#page=4&search=out%2C%20with%20demand%20leveling%20off%20to), available by 2017-10-24.
6. [Canon consolidated results for the third quarter and nine months ended September 30, 2017, PDF p4 §1](https://global.canon/en/ir/results/2017/rslt2017q3e.pdf#page=4&search=Outlook%20As%20for%20the%20outlook%20in), available by 2017-10-24.
