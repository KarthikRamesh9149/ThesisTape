# Investment research memo

As of 2020-03-05T12:00:00Z

Forecast direction: undetermined

**Research question**
What did the Bank of Canada decide on 2020-03-04, what in the statement qualifies its policy stance, and where do you expect the overnight rate target at the 2020-04-15 scheduled decision relative to its 2020-03-04 level? Explain how the outbreak changed the outlook, compare to January and use the scheduled April meeting as the horizon. Within means unchanged. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Answer

On March 4, 2020, the Bank of Canada cut its overnight rate target by 50 basis points in response to the outbreak’s threat to growth. Subtracting that cut from January’s target of 1 ¾ percent gives the reported March target of 1 ¼ percent. As of 2020-03-05T12:00:00Z, I expect the target to be lower at the scheduled 2020-04-15 decision. [1](https://www.bankofcanada.ca/wp-content/uploads/2020/01/fad-press-release-2020-01-22.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [2](https://www.bankofcanada.ca/wp-content/uploads/2020/03/fad-press-release-2020-03-04.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [3](https://www.bankofcanada.ca/wp-content/uploads/2020/03/fad-press-release-2020-03-04.pdf#page=1&search=weakened.%20It%20is%20becoming%20clear%20that)

## Evidence

January’s hold did not reflect an absence of weakness. The Bank saw a wider output gap but expected stronger global demand to help Canadian investment and exports. Its policy question was whether the slowdown would persist. By March, the Bank judged the current quarter weaker than expected and no longer saw the anticipated investment recovery. That change explains the shift from monitoring the slowdown to acting on it. [1](https://www.bankofcanada.ca/wp-content/uploads/2020/01/fad-press-release-2020-01-22.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [4](https://www.bankofcanada.ca/wp-content/uploads/2020/01/fad-press-release-2020-01-22.pdf#page=1&search=Moreover%2C%20during%20the%20past%20year%20Canadians) [3](https://www.bankofcanada.ca/wp-content/uploads/2020/03/fad-press-release-2020-03-04.pdf#page=1&search=weakened.%20It%20is%20becoming%20clear%20that)

The March statement left room for further easing without committing to it. Governing Council stood ready to adjust policy only if required to support growth and keep inflation on target. The separate pledge to keep the financial system adequately supplied with liquidity was not a promise of another rate cut. [3](https://www.bankofcanada.ca/wp-content/uploads/2020/03/fad-press-release-2020-03-04.pdf#page=1&search=weakened.%20It%20is%20becoming%20clear%20that)

## What would change the view

The strongest alternative is an unchanged target. Consumption had surprised on the upside and core inflation was near target, giving the Bank room to wait for the March cut to take effect. A sustained rebound in Canadian business investment in data available before the scheduled decision would switch my call to unchanged: it would reverse the investment weakness the Bank reported in March. [2](https://www.bankofcanada.ca/wp-content/uploads/2020/03/fad-press-release-2020-03-04.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [3](https://www.bankofcanada.ca/wp-content/uploads/2020/03/fad-press-release-2020-03-04.pdf#page=1&search=weakened.%20It%20is%20becoming%20clear%20that)

## Sources

1. [Bank of Canada policy rate announcement of 2020-01-22, PDF p1 §1](https://www.bankofcanada.ca/wp-content/uploads/2020/01/fad-press-release-2020-01-22.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media), available by 2020-01-22.
2. [Bank of Canada policy rate announcement of 2020-03-04, PDF p1 §1](https://www.bankofcanada.ca/wp-content/uploads/2020/03/fad-press-release-2020-03-04.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media), available by 2020-03-04.
3. [Bank of Canada policy rate announcement of 2020-03-04, PDF p1 §2](https://www.bankofcanada.ca/wp-content/uploads/2020/03/fad-press-release-2020-03-04.pdf#page=1&search=weakened.%20It%20is%20becoming%20clear%20that), available by 2020-03-04.
4. [Bank of Canada policy rate announcement of 2020-01-22, PDF p1 §2](https://www.bankofcanada.ca/wp-content/uploads/2020/01/fad-press-release-2020-01-22.pdf#page=1&search=Moreover%2C%20during%20the%20past%20year%20Canadians), available by 2020-01-22.
