# Investment research memo

As of 2020-07-31T12:00:00Z

Forecast direction: within

**Research question**
How did the first BEA estimate for Q2 2020 distinguish real GDP growth from the domestic purchases price index? Explain how services consumption and health care affected the growth reading. In the second estimate, will gross domestic purchases price index growth be revised lower, remain within, or go higher? Within means unchanged at the published one-decimal precision. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

BEA’s advance estimate for Q2 2020 showed real GDP falling at an annual rate of 32.9 percent, while the gross domestic purchases price index fell at an annual rate of 1.5 percent. The first figure measures the contraction in inflation-adjusted domestic output; the second measures the change in prices of final goods and services bought by U.S. residents. For the second estimate, my call is unchanged on prices: the output collapse is not evidence that BEA understated the price decline. [1](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [2](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=2&search=The%20decrease%20in%20real%20GDP%20reflected) [3](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=5&search=%22current-price%20estimates.%22%20Statistical%20conventions%20Real%20%7C) [4](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=6&search=Percent%20changes.%20Percent%20changes%20in%20quarterly)

## Evidence

Households consumed fewer services, with health care leading the services decline. That pulled real personal consumption expenditures down and contributed to the fall in real GDP. Goods consumption also fell, and federal spending partly offset the broader contraction. BEA identifies health care as a driver of lost services activity; the passage neither quantifies its contribution to GDP growth nor says that health-care prices led the purchases-price decline. [2](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=2&search=The%20decrease%20in%20real%20GDP%20reflected)

## Outlook

Within: I expect the published purchases-price decline to remain 1.5 percent at one-decimal precision (revision tolerance: unchanged). The main assumption is that more complete spending data will change the estimated mix of purchases without materially changing the aggregate price reading. The advance estimate already incorporates a PCE price decline of 1.9 percent; that is a component, not the forecast baseline. Nothing in the available evidence establishes a directional error in either the component prices or their weights, so unchanged is a judgment, not a measured revision tendency. [2](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=2&search=The%20decrease%20in%20real%20GDP%20reflected) [5](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=6&search=Quantity%20and%20price%20indexes%20are%20calculated) [1](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.)

## What would change the view

Higher is the strongest alternative: if purchases shifted further away from categories with steep price declines than BEA initially estimated, revised weights could make the aggregate decline smaller even without new price quotes. I would compare incoming category spending with BEA’s advance source assumptions. I would switch to higher if applying the revised spending weights to component price changes produced a purchases-price decline that rounds to less than 1.5 percent in magnitude. An upward revision to services volume alone would not pass that test. [6](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=2&search=increase%20of%20%24193.4%20billion%20in%20the) [5](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=6&search=Quantity%20and%20price%20indexes%20are%20calculated) [2](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=2&search=The%20decrease%20in%20real%20GDP%20reflected)

## Sources

1. [BEA GDP advance estimate, Q2 2020, PDF p1 §1](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.), available by 2020-07-30.
2. [BEA GDP advance estimate, Q2 2020, PDF p2 §1](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=2&search=The%20decrease%20in%20real%20GDP%20reflected), available by 2020-07-30.
3. [BEA GDP advance estimate, Q2 2020, PDF p5 §3](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=5&search=%22current-price%20estimates.%22%20Statistical%20conventions%20Real%20%7C), available by 2020-07-30.
4. [BEA GDP advance estimate, Q2 2020, PDF p6 §1](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=6&search=Percent%20changes.%20Percent%20changes%20in%20quarterly), available by 2020-07-30.
5. [BEA GDP advance estimate, Q2 2020, PDF p6 §2](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=6&search=Quantity%20and%20price%20indexes%20are%20calculated), available by 2020-07-30.
6. [BEA GDP advance estimate, Q2 2020, PDF p2 §2](https://www.bea.gov/sites/default/files/2020-07/gdp2q20_adv.pdf#page=2&search=increase%20of%20%24193.4%20billion%20in%20the), available by 2020-07-30.
