# Investment research memo

As of 2021-07-30T12:00:00Z

Forecast direction: within

**Research question**
How did the first BEA estimate for Q2 2021 distinguish real GDP growth from the domestic purchases price index? Explain how federal government spending affected the growth reading. In the second estimate, will gross domestic purchases price index growth be revised lower, remain within, or go higher? Within means unchanged at the published one-decimal precision. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

BEA’s advance estimate for Q2 2021 put U.S. real GDP growth at 6.5 percent annualized and gross domestic purchases price growth at 5.7 percent annualized. The first rate measures growth in the volume of domestic production; the second measures how fast prices rose for purchases by U.S. residents, including imports. The price rate is not a deduction from the real growth rate: BEA’s real GDP figure already removes price changes. [1](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [2](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=2&search=declined%20%7C%20.%20Current%20%7C%20-dollar) [3](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=5&search=Personal%20%7C%20outlays%20%7C%20is%20%7C) [4](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=6&search=adjusted%20values%20are%20calculated%20from%20the)

## Evidence

Federal spending made a negative percentage-point contribution to real GDP growth. Banks processed fewer Paycheck Protection Program applications for the government, so federal purchases of nondefense services fell. This was a drag on the volume of output, not evidence of lower purchase prices. The supplied contribution-table excerpt covers private investment but omits the federal row, so the sign is clear but the exact percentage-point drag cannot be verified from it. [5](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Second-Quarter%202021) [1](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [6](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=9&search=institutions%20%7C%200.12%20%7C%200.17%20%7C)

## Outlook

Within: my base case at 2021-07-30T12:00:00Z is that the second estimate still prints 5.7 percent annualized, unchanged at one decimal (revision band: unchanged). The advance estimate already incorporated the acceleration from the prior quarter and reported PCE inflation of 6.4 percent. That consumer-price reading is part of the evidence behind the advance estimate, not fresh evidence for revising the broader index. The available record identifies no replacement price or spending input that points to a different rounded rate. [2](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=2&search=declined%20%7C%20.%20Current%20%7C%20-dollar) [7](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=3&search=Disposable%20personal%20income%20decreased%20%241.42%20trillion%2C)

## What would change the view

Higher is the strongest alternative. I would switch if a newly reported price for a large purchases component exceeded the assumption BEA used, and applying the updated expenditure weights moved the aggregate above the rounding boundary. The test is against BEA’s input, not a market forecast: a price release can surprise investors yet leave the estimate unchanged. More complete data allow revisions in either direction; the supplied passages do not show the unrounded advance rate or how close it was to that boundary. [1](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [4](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=6&search=adjusted%20values%20are%20calculated%20from%20the) [7](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=3&search=Disposable%20personal%20income%20decreased%20%241.42%20trillion%2C)

## Sources

1. [BEA GDP advance estimate, Q2 2021, PDF p1 §1](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.), available by 2021-07-29.
2. [BEA GDP advance estimate, Q2 2021, PDF p2 §2](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=2&search=declined%20%7C%20.%20Current%20%7C%20-dollar), available by 2021-07-29.
3. [BEA GDP advance estimate, Q2 2021, PDF p5 §2](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=5&search=Personal%20%7C%20outlays%20%7C%20is%20%7C), available by 2021-07-29.
4. [BEA GDP advance estimate, Q2 2021, PDF p6 §2](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=6&search=adjusted%20values%20are%20calculated%20from%20the), available by 2021-07-29.
5. [BEA GDP advance estimate, Q2 2021, PDF p2 §1](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Second-Quarter%202021), available by 2021-07-29.
6. [BEA GDP advance estimate, Q2 2021, PDF p9 §4](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=9&search=institutions%20%7C%200.12%20%7C%200.17%20%7C), available by 2021-07-29.
7. [BEA GDP advance estimate, Q2 2021, PDF p3 §1](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=3&search=Disposable%20personal%20income%20decreased%20%241.42%20trillion%2C), available by 2021-07-29.
