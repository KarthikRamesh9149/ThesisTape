# Investment research memo

As of 2018-10-25T12:00:00Z

Forecast direction: within

**Research question**
What did the Bank of Canada decide on 2018-10-24, what in the statement qualifies its policy stance, and where do you expect the overnight rate target at the 2018-12-05 scheduled decision relative to its 2018-10-24 level? Explain the role of the new trade agreement. Within means unchanged. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Answer

On October 24, 2018, the Bank of Canada raised its overnight rate target to 1 ¾ per cent from the 1 ½ per cent it had maintained in September. The new target minus the prior target gives a hike of 0.25 percentage points. The Bank signaled that rates would need to rise further to reach a neutral stance, but it did not set a timetable. [1](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [2](https://www.bankofcanada.ca/wp-content/uploads/2018/09/fad-press-release-2018-09-05.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [3](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=competitiveness%20challenges%20and%20limited%20transportation%20capacity.)

## Evidence

The Bank expected the new USMCA to reduce trade-policy uncertainty, which had held back business confidence and investment. It attributed higher projections for business investment and exports to both the agreement and the newly approved British Columbia LNG project. Next year’s projected real GDP growth of 2.1 per cent minus this year’s 2.1 per cent yields 0 percentage points. That compares two forecast years, not growth with and without the agreement. The statement neither quantified a standalone GDP effect nor established that investment had already responded. [1](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [3](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=competitiveness%20challenges%20and%20limited%20transportation%20capacity.)

## Outlook

As of 2018-10-25T12:00:00Z, my base case for 2018-12-05 is within: unchanged at 1 ¾ per cent. The forecast minus October’s 1 ¾ per cent target is 0 percentage points (inclusive threshold: unchanged). The main reason to pause is elevated household debt: higher borrowing costs can weigh on spending, and the Bank said the pace of increases would depend on how the economy adjusts. With core inflation around 2 per cent, it could assess the October hike before acting again without abandoning its plan to tighten. [1](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [3](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=competitiveness%20challenges%20and%20limited%20transportation%20capacity.) [4](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=higher%20interest%20rates%2C%20given%20the%20elevated)

## What would change the view

The strongest alternative is higher: repeating October’s move would take the target from 1 ¾ per cent plus 0.25 percentage points to 2 per cent. I would switch to that call if incoming data before the meeting showed a material upside surprise across the Bank’s core inflation measures. In an economy already operating at capacity, broad price pressure would argue for tightening sooner; an airfare-driven headline move would be less persuasive. This is a forecast test, not a numerical trigger announced by the Bank. [3](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=competitiveness%20challenges%20and%20limited%20transportation%20capacity.) [1](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [2](https://www.bankofcanada.ca/wp-content/uploads/2018/09/fad-press-release-2018-09-05.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media)

## Checked calculations

- C1. October 24 hike: new target (Oct. 24 PDF p1 §1) less prior target (Sept. 5 PDF p1 §1); 0.25 pp = 25 bp (percentage points) — 1 ¾ − 1 ½ = 0.25 [1](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [2](https://www.bankofcanada.ca/wp-content/uploads/2018/09/fad-press-release-2018-09-05.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media)
- C2. Dec. 5 base: within at 1.75%; tightening toward neutral is data-dependent given household debt (Oct. 24 PDF p1 §§2–3) (percentage points) — 1 ¾ − 1 ¾ = 0.00 [1](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media)
- C3. Dec. 5 higher if core inflation materially exceeds ~2% before meeting; test a repeat hike (Oct. 24 PDF p1 §§2–3) (percent) — 1 ¾ + C1 = 2.00 [1](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [2](https://www.bankofcanada.ca/wp-content/uploads/2018/09/fad-press-release-2018-09-05.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media)
- C4. 2019 GDP forecast vs 2018; USMCA cuts uncertainty, but no standalone growth effect is quantified (Oct. 24 PDF p1 §1) (percentage points) — 2.1 − 2.1 = 0.0 [1](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media)

## Sources

1. [Bank of Canada policy rate announcement of 2018-10-24, PDF p1 §1](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media), available by 2018-10-24.
2. [Bank of Canada policy rate announcement of 2018-09-05, PDF p1 §1](https://www.bankofcanada.ca/wp-content/uploads/2018/09/fad-press-release-2018-09-05.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media), available by 2018-09-05.
3. [Bank of Canada policy rate announcement of 2018-10-24, PDF p1 §2](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=competitiveness%20challenges%20and%20limited%20transportation%20capacity.), available by 2018-10-24.
4. [Bank of Canada policy rate announcement of 2018-10-24, PDF p1 §3](https://www.bankofcanada.ca/wp-content/uploads/2018/10/fad-press-release-2018-10-24.pdf#page=1&search=higher%20interest%20rates%2C%20given%20the%20elevated), available by 2018-10-24.
