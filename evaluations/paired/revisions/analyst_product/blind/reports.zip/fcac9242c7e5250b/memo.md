# Investment research memo

As of 2022-10-28T12:00:00Z

Forecast direction: lower

**Research question**
How did the first BEA estimate for Q3 2022 distinguish real GDP growth from the domestic purchases price index? Explain how exports and residential fixed investment affected the growth reading. In the second estimate, will real GDP growth be revised lower, remain within, or go higher? Within means unchanged at the published one-decimal precision. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Evidence

Exports of both goods and services added to growth. Residential fixed investment subtracted from it, led by declines in new single-family construction and brokers’ commissions. Falling imports gave GDP a separate lift that should not be credited to exports. BEA directs readers to table 2 for percentage-point contributions. The supplied excerpts establish the signs but omit the numerical rows, so they do not verify how much of the export lift housing offset; chained-dollar levels are not a substitute. [1](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=2&search=The%20increase%20in%20exports%20reflected%20increases) [2](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20a.m.) [3](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=9&search=Note.%20Users%20are%20cautioned%20that%20particularly)

## Outlook

**Lower**, rather than within unchanged at published precision. My main driver is a smaller export contribution: I expect fuller September trade data to trim estimated real goods exports without a compensating decline in imports. Exports could still add to growth while adding less than in the advance estimate. Confidence is low: BEA identifies industrial supplies and capital goods as sources of export growth, not as observed overestimates. Its historical average revision is unsigned and gives no directional edge. [2](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20a.m.) [1](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=2&search=The%20increase%20in%20exports%20reflected%20increases) [4](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=5&search=Statistical%20conventions%20%7C%20Updates%20to%20GDP)

As of 2022-10-28T12:00:00Z, my call is lower: I expect BEA’s second estimate of third-quarter 2022 U.S. real GDP growth to round below the advance estimate of 2.6 percent annualized, rather than fall within the unchanged band (unchanged). The advance estimate showed inflation-adjusted output returning to growth after a second-quarter decline of 0.6 percent; the forecast is for a lower growth reading, not necessarily a contraction. [2](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20a.m.)

## What would change the view

The strongest alternative is higher growth if real imports fell more than BEA estimated. Before the November 30, 2022 release, I would compare full September trade volumes and revisions to July and August with BEA’s advance assumptions. I would switch to higher if the extra lift from lower imports outweighed any export markdown by enough to raise rounded GDP growth, absent offsets elsewhere. A narrower nominal trade deficit alone would not establish that real volumes changed. [1](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=2&search=The%20increase%20in%20exports%20reflected%20increases) [5](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=3&search=Source%20Data%20for%20the%20Advance%20Estimate)

## Sources

1. [BEA GDP advance estimate, Q3 2022, PDF p2 §1](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=2&search=The%20increase%20in%20exports%20reflected%20increases), available by 2022-10-27.
2. [BEA GDP advance estimate, Q3 2022, PDF p1 §1](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20a.m.), available by 2022-10-27.
3. [BEA GDP advance estimate, Q3 2022, PDF p9 §6](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=9&search=Note.%20Users%20are%20cautioned%20that%20particularly), available by 2022-10-27.
4. [BEA GDP advance estimate, Q3 2022, PDF p5 §1](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=5&search=Statistical%20conventions%20%7C%20Updates%20to%20GDP), available by 2022-10-27.
5. [BEA GDP advance estimate, Q3 2022, PDF p3 §1](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=3&search=Source%20Data%20for%20the%20Advance%20Estimate), available by 2022-10-27.
