# Investment research memo

As of 2015-12-17T12:00:00Z

Forecast direction: within

**Research question**
What did the Federal Reserve decide on 2015-12-16, what in the statement qualifies its policy stance, and where do you expect the upper endpoint of the federal funds target range at the 2016-01-27 scheduled decision relative to its 2015-12-16 level? Distinguish the rate decision from the stance after it. Within means unchanged. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

On December 16, 2015, the FOMC raised the federal funds target range to 1/4–1/2 percent, effective December 17, 2015. The hike was a tightening step, but the Committee explicitly said policy remained accommodative after it. The supplied statement confirms the increase and the new range but does not restate the previous range, so it does not independently verify the size of the increase. [1](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=1&search=The%20Committee%20judges%20that%20there%20has) [2](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=3&search=December%2016%2C%202015%20Decisions%20Regarding%20Monetary) [3](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=2&search=-%202%20-%20range%20for%20the)

## Evidence

The distinction turns on timing. Labor-market improvement and confidence that inflation would return to target over the medium term justified raising the rate before inflation reached its goal. But inflation was still below target, and the Committee intended the post-hike stance to support further job gains and a return to 2 percent inflation. The case for lifting the rate in December was therefore not, by itself, a case for lifting it again in January. [1](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=1&search=The%20Committee%20judges%20that%20there%20has) [4](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=1&search=For%20immediate%20release%20%7C%20December%2016%2C) [3](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=2&search=-%202%20-%20range%20for%20the)

## Outlook

As of 2015-12-17T12:00:00Z, my base case for 2016-01-27 is **within** (inclusive threshold: unchanged). The announced upper endpoint was 1/2 percent, or 0.50 percent. I forecast that same endpoint in January: subtracting the announced endpoint from the forecast endpoint gives a zero percentage-point move. Gradualism is the main driver. With inflation still short of target and further increases expected to be gradual and dependent on incoming data, waiting for clearer evidence of progress on inflation is more consistent with the guidance than hiking again at the next meeting. The statement does not commit the FOMC to a January hold. [2](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=3&search=December%2016%2C%202015%20Decisions%20Regarding%20Monetary) [3](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=2&search=-%202%20-%20range%20for%20the)

## What would change the view

The strongest alternative is **higher**. I would switch to that call if pre-meeting payroll gains materially exceeded expectations and core inflation readings showed clear firming. The combination matters more than a strong jobs report alone: it would strengthen the employment case for another hike while addressing the inflation shortfall that favors waiting. This is a test for the forecast, not a trigger specified by the FOMC. [3](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=2&search=-%202%20-%20range%20for%20the)

## Sources

1. [Federal Reserve FOMC statement of 2015-12-16, PDF p1 §2](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=1&search=The%20Committee%20judges%20that%20there%20has), available by 2015-12-16.
2. [Federal Reserve FOMC statement of 2015-12-16, PDF p3 §1](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=3&search=December%2016%2C%202015%20Decisions%20Regarding%20Monetary), available by 2015-12-16.
3. [Federal Reserve FOMC statement of 2015-12-16, PDF p2 §1](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=2&search=-%202%20-%20range%20for%20the), available by 2015-12-16.
4. [Federal Reserve FOMC statement of 2015-12-16, PDF p1 §1](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=1&search=For%20immediate%20release%20%7C%20December%2016%2C), available by 2015-12-16.
