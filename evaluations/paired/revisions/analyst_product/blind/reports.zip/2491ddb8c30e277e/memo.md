# Investment research memo

As of 2020-07-31T12:00:00Z

**Research question**
Using the nine months in Apple’s Q3 FY2020 statements, did cash from operations after capital spending cover dividends and share repurchases? Quantify the gap. Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

No. In the nine months ended June 27, 2020, Apple’s dividends and common-stock repurchases exceeded its operating cash flow after capital spending. Net coverage was -11,168 (USD millions). Apple therefore needed existing cash or other cash inflows to fund the gap; the calculation does not identify which source funded the payouts. [1](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF) [2](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Payments%20for%20dividends%20and%20dividend%20equivalents)

## Evidence

Apple generated 60,098 from operations and paid (5,525) for property, plant and equipment, leaving 54,573 after capital spending (USD millions; parentheses denote outflows). Payments for dividends and dividend equivalents of (10,570) and common-stock repurchases of (55,171) totaled -65,741 on the same signed basis. Adding that payout outflow to cash after capital spending gives net coverage of -11,168, a shortfall. [1](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF) [2](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Payments%20for%20dividends%20and%20dividend%20equivalents)

## Outlook

The shortfall does not establish that Apple could not sustain its dividend: cash flow after capital spending covered dividends alone, but not the buybacks as well. If those cash flows and payouts recur, the combined funding gap will recur. A plausible alternative is that buybacks slow enough to restore coverage without a dividend cut. The test is whether, in a comparable subsequent period, repurchases fall within the cash left after capital spending and dividends. [1](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF) [2](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Payments%20for%20dividends%20and%20dividend%20equivalents)

## Checked calculations

- C1. Apple, nine months ended June 27, 2020: operating cash flow after PP&E payments = $54,573m (PDF p. 3) (USD millions) — 60,098 + (5,525) = 54,573 [1](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF)
- C2. Same nine months: dividends and dividend equivalents plus common-stock repurchases = −$65,741m (PDF p. 3) (USD millions) — (10,570) + (55,171) = -65,741 [2](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Payments%20for%20dividends%20and%20dividend%20equivalents)
- C3. No: the $11,168m shortfall required other cash sources; it does not establish future payout capacity (PDF p. 3). (USD millions) — C1 + C2 = -11,168 [2](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Payments%20for%20dividends%20and%20dividend%20equivalents) [1](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF)

## Sources

1. [Apple FY2020 third-quarter consolidated financial statements, PDF p3 §1](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF), available by 2020-07-30.
2. [Apple FY2020 third-quarter consolidated financial statements, PDF p3 §2](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Payments%20for%20dividends%20and%20dividend%20equivalents), available by 2020-07-30.
