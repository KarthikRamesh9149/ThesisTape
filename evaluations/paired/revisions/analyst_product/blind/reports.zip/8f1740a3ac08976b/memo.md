# Investment research memo

As of 2017-09-29T12:00:00Z

Forecast direction: within

**Research question**
Prepare an auction preview for the U.S. Treasury 13-week bill sale scheduled for 2017-10-02. Identify the offering and maturity, report the prior comparable auction’s bid-to-cover and clearing rate, and forecast the new high discount rate relative to that auction (within means ±5 basis points, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

As of 2017-09-29T12:00:00Z, the call is within: the U.S. Treasury’s October 02, 2017 auction of $42,000,000,000 in 13-Week Bills, maturing January 04, 2018, should clear near the prior high discount rate. Treasury is asking buyers to absorb almost exactly the amount awarded at the previous sale. [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2017/A_20170928_1.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A) [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2017/R_20170925_1.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Evidence

The comparable September 25, 2017 sale was also a 91-Day Bill. Its high discount rate was 1.050%, not the 1.067% investment rate. Total tenders of $121,370,119,500 divided by total awards of $42,000,519,500 gave Treasury’s reported bid-to-cover of 2.89. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2017/R_20170925_1.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Outlook

Within is the base case. The forecast band is an inclusive ±0.05 percentage points band around the reference: the prior 1.050% high discount rate plus or minus five basis points, with both endpoints included under the question’s classification rule. The main driver is stable sale size. If buyers bid much as they did last week, Treasury has little reason to pay a higher rate simply to place more bills. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2017/R_20170925_1.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C) [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2017/A_20170928_1.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A)

## What would change the view

The strongest alternative is higher: even at unchanged sale size, buyers demanding more yield could push the marginal accepted bid above the band. Prior coverage measures bid volume, not the rate buyers will require on Monday. I would switch to higher if the bill trades consistently above the band on a discount-rate basis in the when-issued market shortly before the 11:30 a.m. ET competitive close. Neither release supplies such a quote. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2017/R_20170925_1.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C) [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2017/A_20170928_1.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A)

## Sources

1. [U.S. Treasury offering announcement of 2017-09-28, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2017/A_20170928_1.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A), available by 2017-09-28.
2. [U.S. Treasury competitive auction results of 2017-09-25, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2017/R_20170925_1.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C), available by 2017-09-25.
