# Investment research memo

As of 2021-02-03T12:00:00Z

**Research question**
For viagogo’s completed purchase of StubHub, identify the UK market harm, the required disposal and the buyer approval condition. Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

As of 2021-02-03T12:00:00Z, the CMA had found that viagogo’s completed purchase of StubHub had resulted, or could be expected to result, in a substantial lessening of competition in uncapped secondary ticketing platform services for resale of tickets to UK events. The finding concerns rivalry between resale platforms, not all ticket sales. The remedy reaches beyond the UK: viagogo must sell StubHub International, the whole StubHub business outside North America, but need not sell the North American business. [1](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=1&search=Completed%20acquisition%20by%20PUG%20LLC%20%28viagogo%29) [2](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=14&search=suitable%20purchaser%20could%20be%20found.%20We)

A willing buyer is not enough. The CMA judged the partial divestiture effective in principle only if a suitable purchaser could be found. It selected the sale of StubHub International as the least intrusive effective remedy and required approval of both the purchaser’s identity and the transaction terms. The cited passages establish that condition but do not spell out detailed criteria for assessing purchaser suitability. [3](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=13&search=relation%20to%20the%20SLC%20and%20its) [2](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=14&search=suitable%20purchaser%20could%20be%20found.%20We)

## Outlook

Base case: once an approved sale closes, separate ownership should restore pressure to compete for UK-event listings and buyers through fees and service, relative to continued common ownership. The parties’ buyer survey suggested broader choice, but a primary seller is little use once an event sells out, and the survey excluded StubHub buyers. The CMA’s finding of close rivalry on both sides of the platforms is more relevant to the outlook than the number of channels a buyer might consider. [4](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=7&search=Coronavirus%20%28COVID-19%29%20pandemic%29%2C%20buyers%20using%20the) [5](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=7&search=Parties%E2%80%99%20gross%20transaction%20value%20%28GTV%29.%20Indeed%2C) [6](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=10&search=52.%20%7C%20Other%20secondary%20ticketing%20platforms)

## What would change the view

The main limitation is execution: the report establishes a sale requirement, not buyer approval, closing or a measured fee reduction. The strongest near-term alternative is delay rather than restored rivalry. The CMA planned to seek undertakings and to issue an order if suitable undertakings were not obtained in time. The observable signals are CMA approval of a named purchaser and the terms, followed by closing; until then, do not treat independent competition as restored. No figures were derived. [2](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=14&search=suitable%20purchaser%20could%20be%20found.%20We)

## Sources

1. [CMA final report summary on viagogo and StubHub, PDF p1 §1](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=1&search=Completed%20acquisition%20by%20PUG%20LLC%20%28viagogo%29), available by 2021-02-02.
2. [CMA final report summary on viagogo and StubHub, PDF p14 §1](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=14&search=suitable%20purchaser%20could%20be%20found.%20We), available by 2021-02-02.
3. [CMA final report summary on viagogo and StubHub, PDF p13 §2](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=13&search=relation%20to%20the%20SLC%20and%20its), available by 2021-02-02.
4. [CMA final report summary on viagogo and StubHub, PDF p7 §2](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=7&search=Coronavirus%20%28COVID-19%29%20pandemic%29%2C%20buyers%20using%20the), available by 2021-02-02.
5. [CMA final report summary on viagogo and StubHub, PDF p7 §1](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=7&search=Parties%E2%80%99%20gross%20transaction%20value%20%28GTV%29.%20Indeed%2C), available by 2021-02-02.
6. [CMA final report summary on viagogo and StubHub, PDF p10 §1](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=10&search=52.%20%7C%20Other%20secondary%20ticketing%20platforms), available by 2021-02-02.
