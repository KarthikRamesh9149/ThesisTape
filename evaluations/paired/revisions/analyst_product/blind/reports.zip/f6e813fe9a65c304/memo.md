# Investment research memo

As of 2018-05-18T12:00:00Z

Forecast direction: within

**Research question**
Prepare an auction preview for the U.S. Treasury 52-week bill sale scheduled for 2018-05-22. Identify the offering and maturity, report the prior comparable auction’s bid-to-cover and clearing rate, and forecast the new bid-to-cover ratio relative to that auction (within means ±0.05 ratio points, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

Treasury’s May 17, 2018 announcement scheduled a $26,000,000,000 sale of 52-Week Bills for May 22, 2018, with issue on May 24, 2018 and maturity on May 23, 2019. The offering is nearly the same size as the amount accepted at the prior comparable sale, so the change in bid-to-cover should depend mainly on how much bidders tender. [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2018/A_20180517_3.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A) [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2018/R_20180424_2.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Evidence

The last comparable auction in the available record was Treasury’s April 24, 2018 sale of the 364-Day Bill. It cleared at a high discount rate of 2.200%. Treasury reported bid-to-cover of 3.39: $88,259,071,900 tendered divided by $26,000,439,900 accepted, rounded as published. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2018/R_20180424_2.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Outlook

Base case as of 2018-05-18T12:00:00Z: within. My point forecast is 3.39, with an inclusive decision band of an inclusive ±0.05 ratio points band around the reference around the published prior ratio. The anchor is stable sale size: if Treasury accepts bids near the announced amount and total tenders hold near the prior level, cover should stay near its prior reading. This is a carry-forward forecast, not evidence that demand is unchanged; the announcement contains terms, not current bids. The band is a classification rule, not a confidence interval. [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2018/A_20180517_3.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A) [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2018/R_20180424_2.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## What would change the view

The strongest alternative is lower: primary dealers tendered $67,196,000,000 at the prior sale, so a pullback in their bids could outweigh steady bidding elsewhere. I would switch to lower if pre-auction dealer bid indications, with other tenders held at their prior level, put projected total tenders below the lower edge of the decision band multiplied by the $26,000,000,000 offering. That test assumes acceptances near the offering size; neither document supplies such indications by the cutoff. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2018/R_20180424_2.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C) [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2018/A_20180517_3.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A)

## Sources

1. [U.S. Treasury offering announcement of 2018-05-17, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2018/A_20180517_3.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A), available by 2018-05-17.
2. [U.S. Treasury competitive auction results of 2018-04-24, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2018/R_20180424_2.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C), available by 2018-04-24.
