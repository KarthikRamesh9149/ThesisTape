# Investment research memo

As of 2021-07-30T12:00:00Z

Forecast direction: within

**Research question**
How did the first BEA estimate for Q2 2021 distinguish real GDP growth from the domestic purchases price index? Explain how federal government spending affected the growth reading. In the second estimate, will gross domestic purchases price index growth be revised lower, remain within, or go higher? Within means unchanged at the published one-decimal precision. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Answer

BEA’s advance estimate for Q2 2021 put annualized real GDP growth at 6.5 percent and gross domestic purchases price growth at 5.7 percent. The first rate measures growth in inflation-adjusted U.S. production; the second measures how fast prices rose for final goods and services bought by U.S. residents. Federal spending reduced the output growth reading, but that does not imply a downward revision to purchases prices. [1](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [2](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=2&search=declined%20%7C%20.%20Current%20%7C%20-dollar) [3](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=5&search=Additional%20Information%20Resources%20%7C%20The%20%7C) [4](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=5&search=Gross%20%7C%20output%20%7C%20is%20the)

## Evidence

The federal contribution to real GDP growth was negative. BEA traced the decline mainly to nondefense purchases of intermediate goods and services: banks did less work processing and administering Paycheck Protection Program loan applications on the government’s behalf. It was the decline in services purchased, not the face value of the loans, that mattered here. The available excerpts verify the sign but do not give the federal contribution in percentage points. [1](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [5](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Second-Quarter%202021)

## Outlook

Within remains the base case (inclusive tolerance: unchanged). One plausible alternative is higher. Compare revised June consumer-services price inputs with those BEA used in the advance estimate. I would switch to higher only if the revisions, after accounting for expenditure weights and offsets in other purchases, pushed published annualized purchases price growth above 5.7 percent. A rise in one component alone would not change the call. The excerpts provide neither the revised inputs nor the unrounded advance rate, so they do not show how close the estimate is to rounding higher. [2](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=2&search=declined%20%7C%20.%20Current%20%7C%20-dollar) [6](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=6&search=adjusted%20values%20are%20calculated%20from%20the) [1](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.)

## Sources

1. [BEA GDP advance estimate, Q2 2021, PDF p1 §1](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.), available by 2021-07-29.
2. [BEA GDP advance estimate, Q2 2021, PDF p2 §2](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=2&search=declined%20%7C%20.%20Current%20%7C%20-dollar), available by 2021-07-29.
3. [BEA GDP advance estimate, Q2 2021, PDF p5 §1](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=5&search=Additional%20Information%20Resources%20%7C%20The%20%7C), available by 2021-07-29.
4. [BEA GDP advance estimate, Q2 2021, PDF p5 §3](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=5&search=Gross%20%7C%20output%20%7C%20is%20the), available by 2021-07-29.
5. [BEA GDP advance estimate, Q2 2021, PDF p2 §1](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Second-Quarter%202021), available by 2021-07-29.
6. [BEA GDP advance estimate, Q2 2021, PDF p6 §2](https://www.bea.gov/sites/default/files/2021-07/gdp2q21_adv.pdf#page=6&search=adjusted%20values%20are%20calculated%20from%20the), available by 2021-07-29.
