# Investment research memo

As of 2020-08-21T12:00:00Z

Forecast direction: lower

**Research question**
Prepare an auction preview for the U.S. Treasury 7-year nominal note sale scheduled for 2020-08-27. Identify the offering and maturity, report the prior comparable auction’s bid-to-cover and clearing rate, and forecast the new bid-to-cover ratio relative to that auction (within means ±0.05 ratio points, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

As of 2020-08-21T12:00:00Z, I forecast a lower bid-to-cover ratio of 2.293 for the U.S. Treasury’s August 27, 2020 auction of a new 7-Year Note (CUSIP 91282CAH4), to be issued August 31, 2020 and due August 31, 2027. The $47,000,000,000 offering is larger than July’s public award, so Treasury needs more bid dollars just to maintain July’s cover. [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2020/A_20200820_3.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A) [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2020/R_20200728_3.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Evidence

The prior comparable was Treasury’s July 28, 2020 auction of the 7-Year Note, CUSIP 91282CAD3. It cleared at a high yield of 0.446%. Treasury reported cover of 2.45: public tenders of $107,769,283,300 divided by public awards of $44,000,013,300, excluding SOMA from both sides. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2020/R_20200728_3.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Outlook

Lower is the base case. Holding public tenders at July’s $107,769,283,300 and using the announced $47,000,000,000 as the expected public award gives cover of 2.293. Subtracting July’s reported 2.45 gives -0.157 ratio points, below the inclusive an inclusive ±0.05 ratio points band around the reference band. The driver is greater supply, not a predicted fall in bid dollars: July’s result establishes a demand benchmark, but neither it nor the August announcement establishes how much investors will tender. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2020/R_20200728_3.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C) [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2020/A_20200820_3.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A)

## What would change the view

The strongest alternative is that bids grow in proportion to supply. Matching July’s reported cover would require $47,000,000,000 × 2.45 = 115,150,000,000 in public tenders. I would switch to within if pre-sale dealer estimates of total public tenders, divided by the offering amount, put expected cover inside the inclusive an inclusive ±0.05 ratio points band around the reference band around July’s result. [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2020/A_20200820_3.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A) [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2020/R_20200728_3.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Checked calculations

- C2. Aug 27: new $47bn 7-year nominal note, 91282CAH4, due Aug 31, 2027 (P2, PDF p1). Flat tenders imply 2.293. (forecast bid-to-cover ratio) — 107,769,283,300 ÷ 47,000,000,000 ≈ 2.292963 [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2020/R_20200728_3.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C) [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2020/A_20200820_3.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A)
- C3. Aug forecast less July reported cover = −0.157: LOWER. Larger supply dilutes cover if tender dollars stay flat. (ratio points) — C2 − 2.45 ≈ -0.157037 [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2020/R_20200728_3.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C) [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2020/A_20200820_3.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A)
- C4. Alternative: demand scales with supply. Switch to WITHIN if pre-sale dealer tender estimates imply cover near 2.45. (USD tenders at unchanged August cover) — 47,000,000,000 × 2.45 = 115,150,000,000.00 [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2020/R_20200728_3.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C) [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2020/A_20200820_3.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A)

## Sources

1. [U.S. Treasury offering announcement of 2020-08-20, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2020/A_20200820_3.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A), available by 2020-08-20.
2. [U.S. Treasury competitive auction results of 2020-07-28, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2020/R_20200728_3.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C), available by 2020-07-28.
