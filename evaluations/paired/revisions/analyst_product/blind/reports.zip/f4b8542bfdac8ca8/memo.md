# Investment research memo

As of 2018-04-27T12:00:00Z

Forecast direction: higher

**Research question**
At Nintendo’s FY2018 results, what operating profit did it guide for the year ending March 2019? Compare it with the just-reported year, discuss the scale of Switch hardware sales in the just-reported year, and forecast the full-year actual relative to guidance (within means ±2% of the guide, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

Nintendo guided to 225.0 billion yen in consolidated operating profit for the year ending March 31, 2019, up 26.7% from the just-reported year. My base case is higher than guidance beyond the tolerance band. Switch sold 15.05 million consoles in the just-reported year; those buyers can keep buying games even if new console sales do no better than Nintendo expects. [1](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=4&search=Through%20these%20initiatives%2C%20for%20the%20fiscal) [2](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=2&search=Consolidated%20Financial%20Forecast%20for%20the%20Fiscal) [3](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=3&search=Description%20of%20Operating%20Results%201.%20Operating)

## Evidence

The comparison inputs are the consolidated guide of 225,000 million yen and Nintendo’s reported growth rate of 26.7%. Dividing the guide by one plus that rate gives an approximate prior-year profit, not an exact actual, because the published rate is rounded. The separate 128,104 million yen figure is parent-only and is not the denominator. For the forecast test, the endpoints are the original consolidated guide minus and plus the question’s tolerance times that same guide: an inclusive ±2% band around the reference, inclusive. [2](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=2&search=Consolidated%20Financial%20Forecast%20for%20the%20Fiscal) [4](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=2&search=million%20yen%20%7C%20%25%20%7C%20million)

## Outlook

Higher. I expect continued purchases of established Nintendo games by the expanding Switch audience to lift software profit above plan. Mario Kart alone sold 9.22 million units in the just-reported year. Nintendo already counts on catalog sales, so their mere continuation is not the upside case: it takes stronger sales than budgeted. The strongest alternative is lower profit if stand-alone game purchases disappoint. The software target is 10,000 ten-thousand units excluding bundles, against 6,351 ten-thousand actual units including bundles; the apparent increase therefore understates the task on a comparable basis. Title-level margins are not disclosed here, so unit sales cannot establish the size of a profit beat. [3](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=3&search=Description%20of%20Operating%20Results%201.%20Operating) [5](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=4&search=2.%20Outlook%20for%20the%20Fiscal%20Year) [6](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=15&search=%284%29%20Consolidated%20sales%20units%2C%20number%20of)

## What would change the view

I would switch to lower if, after the holiday selling season, Nintendo cut its full-year Switch software unit forecast below its original target while retaining its advertising plan of 85,000 million yen. That combination would remove the expected contribution from extra games without a corresponding saving in promotion. [6](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=15&search=%284%29%20Consolidated%20sales%20units%2C%20number%20of) [7](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=14&search=%2A2%20Includes%20amiibo%2C%20Virtual%20Console%20and)

## Sources

1. [Nintendo consolidated financial statements for year ended March 2018, PDF p4 §2](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=4&search=Through%20these%20initiatives%2C%20for%20the%20fiscal), available by 2018-04-26.
2. [Nintendo consolidated financial statements for year ended March 2018, PDF p2 §1](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=2&search=Consolidated%20Financial%20Forecast%20for%20the%20Fiscal), available by 2018-04-26.
3. [Nintendo consolidated financial statements for year ended March 2018, PDF p3 §1](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=3&search=Description%20of%20Operating%20Results%201.%20Operating), available by 2018-04-26.
4. [Nintendo consolidated financial statements for year ended March 2018, PDF p2 §2](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=2&search=million%20yen%20%7C%20%25%20%7C%20million), available by 2018-04-26.
5. [Nintendo consolidated financial statements for year ended March 2018, PDF p4 §1](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=4&search=2.%20Outlook%20for%20the%20Fiscal%20Year), available by 2018-04-26.
6. [Nintendo consolidated financial statements for year ended March 2018, PDF p15 §1](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=15&search=%284%29%20Consolidated%20sales%20units%2C%20number%20of), available by 2018-04-26.
7. [Nintendo consolidated financial statements for year ended March 2018, PDF p14 §2](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=14&search=%2A2%20Includes%20amiibo%2C%20Virtual%20Console%20and), available by 2018-04-26.
