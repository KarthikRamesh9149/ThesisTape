# Investment research memo

As of 2023-04-28T12:00:00Z

Forecast direction: within

**Research question**
How did the first BEA estimate for Q1 2023 distinguish real GDP growth from the domestic purchases price index? Explain how consumption and inventory investment affected the growth reading. In the second estimate, will gross domestic purchases price index growth be revised lower, remain within, or go higher? Within means unchanged at the published one-decimal precision. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

As of 2023-04-28T12:00:00Z, my call is **within**: I expect BEA’s May 25, 2023 second estimate to leave first-quarter gross domestic purchases price growth at 3.8 percent annualized at the published precision. BEA’s advance estimate put real GDP growth at 1.1 percent annualized. The distinction matters: slower growth in inflation-adjusted output does not imply a downward revision to prices paid by U.S. residents. [1](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=3&search=Source%20Data%20for%20the%20Advance%20Estimate) [2](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=2&search=The%20decrease%20in%20private%20inventory%20investment) [3](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20a.m.) [4](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=4&search=produced%20%7C%20by%20%7C%20the%20%7C)

## Evidence

Real output rose, but more slowly: first-quarter growth of 1.1 percent minus fourth-quarter growth of 2.6 percent gives -1.5 annualized percentage points. Consumer spending added to growth, and its acceleration cushioned the slowdown. Private inventory investment did the opposite: its downturn, led by wholesale trade and manufacturing, was a primary reason GDP growth slowed. That is a drag from the change in inventory investment, not necessarily a fall in the stock of inventories. [3](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20a.m.) [2](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=2&search=The%20decrease%20in%20private%20inventory%20investment)

Prices accelerated even as real output growth slowed. The purchases index covers final goods and services bought by U.S. residents. Its first-quarter rate of 3.8 percent minus the fourth-quarter rate of 3.6 percent gives 0.2 annualized percentage points. The separate PCE price index also accelerated, to 4.2 percent from 3.7 percent. Both comparisons describe changes between quarters, not revisions to the same quarter; neither shows that BEA understated first-quarter prices. [4](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=4&search=produced%20%7C%20by%20%7C%20the%20%7C) [2](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=2&search=The%20decrease%20in%20private%20inventory%20investment)

## Outlook

Base case: **within** (unchanged), meaning unchanged at the published tenth, not necessarily unchanged before rounding. The reason is the absence of an identified price-source update that would move the aggregate across a rounding boundary. Confidence is low: BEA says its advance inputs are incomplete or revisable. Its historical advance-to-second revision statistic concerns real GDP and disregards sign; it cannot establish the size or direction of a purchases-price revision. [1](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=3&search=Source%20Data%20for%20the%20Advance%20Estimate) [5](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=5&search=Statistical%20conventions%20%7C%20detailed%20and%20more)

## What would change the view

The main alternative is **higher**. I would switch if revised first-quarter consumer-services price data came in above the inputs used in the advance estimate and, after weighting them alongside the other purchases components, the implied annualized rate rounded above 3.8 percent. The benchmark for that test is BEA’s advance source-data and assumptions file, not the strength of real services spending. No such price surprise is established by the advance release. [1](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=3&search=Source%20Data%20for%20the%20Advance%20Estimate) [6](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=5&search=most%20recent%20calendar%20years%20%28and%20their) [2](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=2&search=The%20decrease%20in%20private%20inventory%20investment)

## Checked calculations

- C1. Q1 2023 minus Q4 2022: change in real GDP growth (advance PDF p. 1) (annualized percentage points) — 1.1 − 2.6 = -1.5 [3](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20a.m.)
- C2. Q1 2023 minus Q4 2022: change in domestic purchases price growth (advance PDF p. 2) (annualized percentage points) — 3.8 − 3.6 = 0.2 [2](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=2&search=The%20decrease%20in%20private%20inventory%20investment)

## Sources

1. [BEA GDP advance estimate, Q1 2023, PDF p3 §1](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=3&search=Source%20Data%20for%20the%20Advance%20Estimate), available by 2023-04-27.
2. [BEA GDP advance estimate, Q1 2023, PDF p2 §1](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=2&search=The%20decrease%20in%20private%20inventory%20investment), available by 2023-04-27.
3. [BEA GDP advance estimate, Q1 2023, PDF p1 §1](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20a.m.), available by 2023-04-27.
4. [BEA GDP advance estimate, Q1 2023, PDF p4 §3](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=4&search=produced%20%7C%20by%20%7C%20the%20%7C), available by 2023-04-27.
5. [BEA GDP advance estimate, Q1 2023, PDF p5 §1](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=5&search=Statistical%20conventions%20%7C%20detailed%20and%20more), available by 2023-04-27.
6. [BEA GDP advance estimate, Q1 2023, PDF p5 §2](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=5&search=most%20recent%20calendar%20years%20%28and%20their), available by 2023-04-27.
