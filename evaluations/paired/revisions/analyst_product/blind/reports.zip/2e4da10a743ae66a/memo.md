# Investment research memo

As of 2021-02-03T12:00:00Z

**Research question**
For viagogo’s completed purchase of StubHub, identify the UK market harm, the required disposal and the buyer approval condition. Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

As of 2021-02-03T12:00:00Z, yes. The CMA found that viagogo’s completed purchase of StubHub had resulted, or could be expected to result, in a substantial lessening of competition in uncapped secondary ticketing platform services for the resale of tickets to UK events. It required viagogo to sell StubHub International: the entire StubHub business outside North America, not just its UK operations. The CMA judged this the least intrusive effective remedy, provided a suitable purchaser could be found. Both the buyer’s identity and the transaction terms required CMA approval. [1](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=13&search=Countervailing%20buyer%20power%2073.%20%7C%20After) [2](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=13&search=relation%20to%20the%20SLC%20and%20its) [3](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=14&search=suitable%20purchaser%20could%20be%20found.%20We)

## Evidence

The investment implication concerns platform fees and service terms, not a prediction about ticket prices. Without the merger, the CMA expected viagogo and StubHub to keep competing closely for both buyers and resellers. The parties argued that combining listings and buyers could lower resale prices. The CMA was not persuaded; even if primary ticket sales influenced what resellers charged, that would not necessarily stop the merged platform from raising its own fees or worsening its terms. [4](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=7&search=Coronavirus%20%28COVID-19%29%20pandemic%29%2C%20buyers%20using%20the) [5](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=4&search=%28d%29%20awareness%20of%20the%20brand.%2016.) [6](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=11&search=affect%20the%20degree%20of%20competition%20in)

## What would change the view

The base case is conditional: a completed disposal to a suitable buyer should restore an independent rival for UK-event listings and buyers. The strongest alternative is that no suitable buyer secures approval on acceptable terms, leaving that rivalry unrestored. The merger was complete, but the report set out how the CMA proposed to implement the disposal; it did not establish that the sale had closed or that competition had recovered. The signals to watch are CMA approval of the buyer and terms, then closing and evidence that the divested platform continues to attract both resellers and buyers. [3](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=14&search=suitable%20purchaser%20could%20be%20found.%20We) [5](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=4&search=%28d%29%20awareness%20of%20the%20brand.%2016.)

## Sources

1. [CMA final report summary on viagogo and StubHub, PDF p13 §1](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=13&search=Countervailing%20buyer%20power%2073.%20%7C%20After), available by 2021-02-02.
2. [CMA final report summary on viagogo and StubHub, PDF p13 §2](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=13&search=relation%20to%20the%20SLC%20and%20its), available by 2021-02-02.
3. [CMA final report summary on viagogo and StubHub, PDF p14 §1](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=14&search=suitable%20purchaser%20could%20be%20found.%20We), available by 2021-02-02.
4. [CMA final report summary on viagogo and StubHub, PDF p7 §2](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=7&search=Coronavirus%20%28COVID-19%29%20pandemic%29%2C%20buyers%20using%20the), available by 2021-02-02.
5. [CMA final report summary on viagogo and StubHub, PDF p4 §1](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=4&search=%28d%29%20awareness%20of%20the%20brand.%2016.), available by 2021-02-02.
6. [CMA final report summary on viagogo and StubHub, PDF p11 §1](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=11&search=affect%20the%20degree%20of%20competition%20in), available by 2021-02-02.
