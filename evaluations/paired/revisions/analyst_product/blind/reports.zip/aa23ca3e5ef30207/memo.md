# Investment research memo

As of 2018-11-02T12:00:00Z

**Research question**
What explains the gap between iPhone unit and revenue growth in Apple’s fiscal Q4 2018, and how much of quarterly net sales came from iPhone? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

Apple’s fiscal Q4 2018 iPhone revenue grew 29% year over year because revenue per reported phone rose, not because Apple sold materially more phones. The distinction matters: iPhone accounted for 59.1176% of Apple’s quarterly net sales, calculated as $37,185 million in iPhone revenue divided by 62,900 million dollars in companywide net sales. The category’s revenue growth was therefore not evidence of a comparable increase in unit demand. [1](https://www.apple.com/newsroom/pdfs/Q4-18-Data-Summary.pdf#page=1&search=Apple%20Inc.%20Q4%202018%20Unaudited%20Summary) [2](https://www.apple.com/newsroom/pdfs/Q4-FY18-Consolidated-Financial-Statements.pdf#page=1&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF)

## Evidence

Higher revenue per phone does not establish that Apple raised prices on comparable models. Buyers choosing more expensive models could produce the same result even at unchanged model prices, and recognized iPhone revenue includes deferrals and amortization. Independent evidence on transaction prices by model and each model’s share of units would distinguish pricing from mix; the supplied financial statements provide neither. [1](https://www.apple.com/newsroom/pdfs/Q4-18-Data-Summary.pdf#page=1&search=Apple%20Inc.%20Q4%202018%20Unaudited%20Summary)

Apple’s unaudited summary data show that from fiscal Q4 2017 to Q4 2018, iPhone revenue rose from $28,846 million to $37,185 million, up 28.9087%, while reported units rose from 46,677 thousand to 46,889 thousand, up 0.4542%. Apple’s reported 0% unit growth was rounded. Dividing $37,185 million by 46,889 thousand gives implied revenue of 0.793 thousand dollars per phone, well above the prior-year result of dividing $28,846 million by 46,677 thousand. [1](https://www.apple.com/newsroom/pdfs/Q4-18-Data-Summary.pdf#page=1&search=Apple%20Inc.%20Q4%202018%20Unaudited%20Summary)

## Outlook

The holiday base case to test, not a forecast established as of 2018-11-02T12:00:00Z, is continued reliance on elevated revenue per phone. If that figure falls year over year while units stay flat, iPhone will weigh on Apple’s sales growth. The strongest alternative is a volume-led holiday: rising sell-through alongside flat or lower revenue per phone would support it. The supplied statements cover the completed quarter, not the holiday outlook; companywide sales guidance alone would not distinguish those cases. [1](https://www.apple.com/newsroom/pdfs/Q4-18-Data-Summary.pdf#page=1&search=Apple%20Inc.%20Q4%202018%20Unaudited%20Summary) [2](https://www.apple.com/newsroom/pdfs/Q4-FY18-Consolidated-Financial-Statements.pdf#page=1&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF)

## Checked calculations

- C1. iPhone revenue growth, fiscal Q4 2018 vs. Q4 2017 (reported 29%); Apple summary PDF p. 1 (%) — (37,185 − 28,846) ÷ |28,846| × 100 ≈ 28.908688 [1](https://www.apple.com/newsroom/pdfs/Q4-18-Data-Summary.pdf#page=1&search=Apple%20Inc.%20Q4%202018%20Unaudited%20Summary)
- C2. iPhone unit growth, fiscal Q4 2018 vs. Q4 2017 (reported 0% rounded); Apple summary PDF p. 1 (%) — (46,889 − 46,677) ÷ |46,677| × 100 ≈ 0.454185 [1](https://www.apple.com/newsroom/pdfs/Q4-18-Data-Summary.pdf#page=1&search=Apple%20Inc.%20Q4%202018%20Unaudited%20Summary)
- C3. Fiscal Q4 2018 implied iPhone revenue per unit (~$793 vs. ~$618 prior year); Apple summary PDF p. 1 (thousand USD per iPhone) — 37,185 ÷ 46,889 ≈ 0.793043 [1](https://www.apple.com/newsroom/pdfs/Q4-18-Data-Summary.pdf#page=1&search=Apple%20Inc.%20Q4%202018%20Unaudited%20Summary)
- C4. Fiscal Q4 2018 iPhone share of Apple net sales (~59%); summary and consolidated statements PDFs p. 1 (%) — 37,185 ÷ 62,900 × 100 ≈ 59.117647 [1](https://www.apple.com/newsroom/pdfs/Q4-18-Data-Summary.pdf#page=1&search=Apple%20Inc.%20Q4%202018%20Unaudited%20Summary) [2](https://www.apple.com/newsroom/pdfs/Q4-FY18-Consolidated-Financial-Statements.pdf#page=1&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF)

## Sources

1. [Apple FY2018 fourth-quarter unaudited summary data, PDF p1 §1](https://www.apple.com/newsroom/pdfs/Q4-18-Data-Summary.pdf#page=1&search=Apple%20Inc.%20Q4%202018%20Unaudited%20Summary), available by 2018-11-01.
2. [Apple FY2018 fourth-quarter consolidated financial statements, PDF p1 §1](https://www.apple.com/newsroom/pdfs/Q4-FY18-Consolidated-Financial-Statements.pdf#page=1&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF), available by 2018-11-01.
