# Investment research memo

As of 2023-04-28T12:00:00Z

Forecast direction: within

**Research question**
How did the first BEA estimate for Q1 2023 distinguish real GDP growth from the domestic purchases price index? Explain how consumption and inventory investment affected the growth reading. In the second estimate, will gross domestic purchases price index growth be revised lower, remain within, or go higher? Within means unchanged at the published one-decimal precision. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

BEA estimated that U.S. real GDP grew at a 1.1 percent annual rate in the first quarter of 2023, while the gross domestic purchases price index rose at a 3.8 percent annual rate. The former measures inflation-adjusted domestic production; the latter measures prices paid by U.S. residents for final goods and services, including imports. Slower output growth therefore does not imply a downward revision to purchase-price inflation. [1](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20a.m.) [2](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=2&search=The%20decrease%20in%20private%20inventory%20investment) [3](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=4&search=produced%20%7C%20by%20%7C%20the%20%7C)

## Evidence

Consumers cushioned the real GDP slowdown from the fourth quarter’s 2.6 percent pace. Spending accelerated, with gains in both goods and services led by motor vehicles and parts on the goods side and by health care and food services and accommodations on the services side. The main brakes were a downturn in inventory investment, concentrated in wholesale trade and manufacturing, and slower nonresidential fixed investment. It was the drop in the pace of stockbuilding, not a drop in household purchases, that made inventories a drag on growth. [1](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20a.m.) [2](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=2&search=The%20decrease%20in%20private%20inventory%20investment)

## Outlook

Base case as of 2023-04-28T12:00:00Z: within (unchanged). I expect the second estimate to retain 3.8 percent at published precision. The main revision driver I would watch is updated consumer-price data feeding the personal consumption expenditures (PCE) component. The advance estimate already incorporates PCE inflation of 4.2 percent; its acceleration is not fresh evidence for an upward revision. BEA flags incomplete inputs but identifies no signed price error, so unchanged is a judgment, not a measured revision probability. [2](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=2&search=The%20decrease%20in%20private%20inventory%20investment) [4](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=3&search=Source%20Data%20for%20the%20Advance%20Estimate)

## What would change the view

Higher is the strongest alternative if consumer-price growth was understated. I would compare the updated monthly PCE price indexes for the quarter with the path implicit in the advance estimate. I would switch to higher if they imply faster quarterly PCE inflation and, after allowing for investment and government purchase prices and their weights, lift the purchases estimate enough to round above 3.8 percent. A stronger reading for consumer spending volumes alone would not meet that test. [2](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=2&search=The%20decrease%20in%20private%20inventory%20investment) [5](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=5&search=most%20recent%20calendar%20years%20%28and%20their) [4](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=3&search=Source%20Data%20for%20the%20Advance%20Estimate)

## Sources

1. [BEA GDP advance estimate, Q1 2023, PDF p1 §1](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20a.m.), available by 2023-04-27.
2. [BEA GDP advance estimate, Q1 2023, PDF p2 §1](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=2&search=The%20decrease%20in%20private%20inventory%20investment), available by 2023-04-27.
3. [BEA GDP advance estimate, Q1 2023, PDF p4 §3](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=4&search=produced%20%7C%20by%20%7C%20the%20%7C), available by 2023-04-27.
4. [BEA GDP advance estimate, Q1 2023, PDF p3 §1](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=3&search=Source%20Data%20for%20the%20Advance%20Estimate), available by 2023-04-27.
5. [BEA GDP advance estimate, Q1 2023, PDF p5 §2](https://www.bea.gov/sites/default/files/2023-04/gdp1q23_adv.pdf#page=5&search=most%20recent%20calendar%20years%20%28and%20their), available by 2023-04-27.
