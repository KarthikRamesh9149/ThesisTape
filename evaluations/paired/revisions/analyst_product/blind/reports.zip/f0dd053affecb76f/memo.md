# Investment research memo

As of 2016-07-27T12:00:00Z

Forecast direction: within

**Research question**
Using Canon’s first half FY2016 release, what consolidated operating profit remained to be earned to meet its December year-end projection? Give your call on the reported annual result relative to the projection (within means ±2% of guidance, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

Canon needed 156,317 million yen of consolidated operating profit in the second half to meet its December 2016 projection: 265,000 million yen of full-year guidance minus 108,683 million yen earned through June. Meeting guidance therefore required a more profitable second half than first half. [1](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=1&search=CONSOLIDATED%20RESULTS%20FOR%20THE%20SECOND%20QUARTER) [2](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=4&search=semiconductor%20lithography%20equipment%2C%20FPD%20lithography%20equipment)

## Outlook

Within an inclusive ±2% band around the reference is my base case as of 2016-07-27T12:00:00Z. The main driver is the yen: currency movements had already reduced first-half operating profit by ¥43.5 billion year on year, but Canon’s revised guidance already allowed for a stronger yen. If second-half rates average close to the budgeted 105.00 yen per dollar and 115.00 yen per euro, that year-on-year headwind is not itself a reason to forecast a miss. Demand for display manufacturing equipment supports the call, though the release does not quantify how much profit those orders will contribute by December. [3](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=2&search=The%20average%20value%20of%20the%20yen) [2](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=4&search=semiconductor%20lithography%20equipment%2C%20FPD%20lithography%20equipment) [4](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=19&search=Canon%20Inc.%206.%20PROFITABILITY%202016%20%7C) [5](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=2&search=I.%20Operating%20Results%20and%20Financial%20Conditions)

## What would change the view

Lower is the strongest alternative: further yen appreciation would add pressure while laser-printer demand is already weak. I would switch to lower if the running second-half average suggests a sustained dollar shortfall against budget large enough to breach the band. The test is the gap between 105.00 and the observed average yen per dollar, multiplied by Canon’s estimated 2.6 billion yen of operating profit per yen. If that estimated loss exceeds the distance from guidance to the lower edge of an inclusive ±2% band around the reference, with the euro near budget and no offset from operations, even meeting the rest of the plan would not suffice. [4](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=19&search=Canon%20Inc.%206.%20PROFITABILITY%202016%20%7C) [3](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=2&search=The%20average%20value%20of%20the%20yen)

## Checked calculations

- C1. FY2016 guidance (PDF pp. 1, 4) less reported H1 profit (p. 1): H2 operating profit needed = 156,317 (JPY million) — 265,000 − 108,683 = 156,317 [1](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=1&search=CONSOLIDATED%20RESULTS%20FOR%20THE%20SECOND%20QUARTER)

## Sources

1. [Canon consolidated results for the second quarter and first half ended June 30, 2016, PDF p1 §1](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=1&search=CONSOLIDATED%20RESULTS%20FOR%20THE%20SECOND%20QUARTER), available by 2016-07-26.
2. [Canon consolidated results for the second quarter and first half ended June 30, 2016, PDF p4 §2](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=4&search=semiconductor%20lithography%20equipment%2C%20FPD%20lithography%20equipment), available by 2016-07-26.
3. [Canon consolidated results for the second quarter and first half ended June 30, 2016, PDF p2 §2](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=2&search=The%20average%20value%20of%20the%20yen), available by 2016-07-26.
4. [Canon consolidated results for the second quarter and first half ended June 30, 2016, PDF p19 §1](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=19&search=Canon%20Inc.%206.%20PROFITABILITY%202016%20%7C), available by 2016-07-26.
5. [Canon consolidated results for the second quarter and first half ended June 30, 2016, PDF p2 §1](https://global.canon/en/ir/results/2016/rslt2016q2e.pdf#page=2&search=I.%20Operating%20Results%20and%20Financial%20Conditions), available by 2016-07-26.
