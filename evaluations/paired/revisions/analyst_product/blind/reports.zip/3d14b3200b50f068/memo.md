# Investment research memo

As of 2015-12-17T12:00:00Z

Forecast direction: within

**Research question**
What did the Federal Reserve decide on 2015-12-16, what in the statement qualifies its policy stance, and where do you expect the upper endpoint of the federal funds target range at the 2016-01-27 scheduled decision relative to its 2015-12-16 level? Distinguish the rate decision from the stance after it. Within means unchanged. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

At its December meeting, the Federal Open Market Committee raised the federal funds target range to 1/4 to 1/2 percent. The increase was a tightening action, but the Committee described the resulting stance as accommodative: it expected policy at the new range to support further labor market improvement and a return to its inflation objective. It anticipated gradual increases, with their timing dependent on incoming data rather than a fixed schedule. The statement gives the new range but not the previous upper endpoint, so it establishes the direction of the move without independently establishing its size. [1](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=1&search=The%20Committee%20judges%20that%20there%20has) [2](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=3&search=December%2016%2C%202015%20Decisions%20Regarding%20Monetary) [3](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=2&search=-%202%20-%20range%20for%20the)

## Evidence

The December decision rested on an improving labor market and confidence that inflation would rise over the medium term, not on inflation already being at target. That distinction matters for January: continued job gains would fit the Committee’s existing outlook, while inflation still below 2 percent was the main reason to wait for more evidence before raising rates again. [4](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=1&search=For%20immediate%20release%20%7C%20December%2016%2C) [1](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=1&search=The%20Committee%20judges%20that%20there%20has) [3](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=2&search=-%202%20-%20range%20for%20the)

## Outlook

Base case for 2016-01-27: within (unchanged). I expect the upper endpoint to stay exactly at 1/2 percent. A pause would give the Committee time to assess inflation and would be consistent with its guidance for gradual increases. That guidance did not commit it to a pause or specify the date of the next move. [2](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=3&search=December%2016%2C%202015%20Decisions%20Regarding%20Monetary) [3](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=2&search=-%202%20-%20range%20for%20the)

## What would change the view

The strongest alternative is higher. A materially stronger-than-expected core inflation reading before the meeting, alongside continued job gains, would change my call to another increase. It would provide evidence that price pressures were firming beyond energy, addressing the main reason to wait. This is a forecast signal, not a trigger announced by the Committee. [4](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=1&search=For%20immediate%20release%20%7C%20December%2016%2C) [3](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=2&search=-%202%20-%20range%20for%20the)

## Sources

1. [Federal Reserve FOMC statement of 2015-12-16, PDF p1 §2](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=1&search=The%20Committee%20judges%20that%20there%20has), available by 2015-12-16.
2. [Federal Reserve FOMC statement of 2015-12-16, PDF p3 §1](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=3&search=December%2016%2C%202015%20Decisions%20Regarding%20Monetary), available by 2015-12-16.
3. [Federal Reserve FOMC statement of 2015-12-16, PDF p2 §1](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=2&search=-%202%20-%20range%20for%20the), available by 2015-12-16.
4. [Federal Reserve FOMC statement of 2015-12-16, PDF p1 §1](https://www.federalreserve.gov/monetarypolicy/files/monetary20151216a1.pdf#page=1&search=For%20immediate%20release%20%7C%20December%2016%2C), available by 2015-12-16.
