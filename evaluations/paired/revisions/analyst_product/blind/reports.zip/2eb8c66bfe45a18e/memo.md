# Investment research memo

As of 2018-05-18T12:00:00Z

Forecast direction: within

**Research question**
Prepare an auction preview for the U.S. Treasury 52-week bill sale scheduled for 2018-05-22. Identify the offering and maturity, report the prior comparable auction’s bid-to-cover and clearing rate, and forecast the new bid-to-cover ratio relative to that auction (within means ±0.05 ratio points, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

As of 2018-05-18T12:00:00Z, my bid-to-cover forecast for the U.S. Treasury’s May 22, 2018 sale is 3.39, within the prior auction’s band. Treasury’s May 17, 2018 announcement confirms a $26,000,000,000 offering of the 52-Week Bill, to be issued May 24, 2018 and mature May 23, 2019. The offering is nearly identical in size to the prior award, so the call turns chiefly on whether bidders return at similar volume. [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2018/A_20180517_3.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A) [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2018/R_20180424_2.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Evidence

The comparable 364-Day Bill auction on April 24, 2018 cleared at a high discount rate of 2.200%, not the coupon-equivalent investment rate of 2.268%. Total tenders of $88,259,071,900 divided by total acceptances of $26,000,439,900 give 3.3945, reported by Treasury as R = 3.39. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2018/R_20180424_2.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Outlook

Base case: within (an inclusive ±0.05 ratio points band around the reference). I use April’s total tenders as the estimate for May and the announced offering as the estimate of May acceptances. Primary dealers submitted $67,196,000,000 of April’s $87,601,942,000 in competitive tenders. Similar dealer participation is therefore the key demand assumption; the unchanged scale of supply alone does not guarantee similar cover. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2018/R_20180424_2.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C) [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2018/A_20180517_3.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A)

## What would change the view

The strongest alternative is lower cover if dealers scale back bids and customers do not offset the decline. I would switch to lower if a credible pre-sale survey put aggregate intended tenders below the lower edge of the stated band multiplied by the announced offering. The $151,996,000,000 of publicly held bills due on the issue date is not such a signal in either direction: it measures maturities, not reinvestment orders for this bill. Neither the announcement nor April’s results establish May bidding intentions. [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2018/R_20180424_2.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C) [1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2018/A_20180517_3.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A)

## Checked calculations

- C1. April 24, 2018 364-day bill bid-to-cover: total tendered divided by total accepted (reported as 3.39) (ratio) — 88,259,071,900 ÷ 26,000,439,900 ≈ 3.394522 [2](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2018/R_20180424_2.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C)

## Sources

1. [U.S. Treasury offering announcement of 2018-05-17, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2018/A_20180517_3.pdf#page=1&search=Embargoed%20Until%2011%3A00%20A.M.%20%7C%20CONTACT%3A), available by 2018-05-17.
2. [U.S. Treasury competitive auction results of 2018-04-24, PDF p1 §1](https://www.treasurydirect.gov/instit/annceresult/press/preanre/2018/R_20180424_2.pdf#page=1&search=For%20Immediate%20Release%20%7C%20CONTACT%3A%20%7C), available by 2018-04-24.
