# Investment research memo

As of 2015-05-08T12:00:00Z

Forecast direction: within

**Research question**
At Nintendo’s FY2015 results, what net sales did it guide for the year ending March 2016? Compare it with the just-reported year, discuss the change in demand for older 3DS hardware around the new-model launch, and forecast the full-year actual relative to guidance (within means ±2% of the guide, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

Nintendo guided to consolidated net sales of JPY 570,000 million for the year ending March 31, 2016. My base case is within guidance: sales of the new handhelds need not fully replace lost older-model volume, because Nintendo’s plan already assumes a decline in total handheld units. [1](https://www.nintendo.co.jp/ir/pdf/2015/150507e.pdf#page=2&search=Consolidated%20Financial%20Forecast%20for%20the%20Fiscal) [2](https://www.nintendo.co.jp/ir/pdf/2015/150507e.pdf#page=3&search=party%20publishers%20are%20scheduled%20for%20release.) [3](https://www.nintendo.co.jp/ir/pdf/2015/150507e.pdf#page=16&search=%285%29%20Consolidated%20sales%20units%2C%20number%20of)

## Evidence

The just-reported consolidated actual was 549.7 billion yen, or approximately 549.7 thousand JPY million; the available consolidated excerpt does not establish the actual to the nearest million. Using like units, guide ÷ actual − one = 570.0 ÷ 549.7 − one ≈ 3.7%, matching Nintendo’s reported growth rate. Applying the question’s unverified tolerance premise to the guide, rather than to the prior actual, gives the inclusive band an inclusive ±2% band around the reference. [4](https://www.nintendo.co.jp/ir/pdf/2015/150507e.pdf#page=3&search=enjoyed%20robust%20sales%20of%205.11%20million) [2](https://www.nintendo.co.jp/ir/pdf/2015/150507e.pdf#page=3&search=party%20publishers%20are%20scheduled%20for%20release.) [1](https://www.nintendo.co.jp/ir/pdf/2015/150507e.pdf#page=2&search=Consolidated%20Financial%20Forecast%20for%20the%20Fiscal)

## Outlook

Within. Older 3DS hardware underperformed expectations before the refresh; that is not evidence that the launch itself caused buyers to switch. The New models started well and continued selling. I give that sustained demand more weight than the older models’ weakness because the family hardware plan calls for only 760 ten-thousand units versus 873 ten-thousand units just reported. An expanded amiibo lineup offers a separate route to sales growth. The strongest lower case is that New models mostly displace older purchases and amiibo adds too little revenue to offset the decline; Nintendo does not quantify that incremental revenue here. [5](https://www.nintendo.co.jp/ir/pdf/2015/150507e.pdf#page=3&search=Operating%20Results%201.%20Analysis%20of%20Operations) [3](https://www.nintendo.co.jp/ir/pdf/2015/150507e.pdf#page=16&search=%285%29%20Consolidated%20sales%20units%2C%20number%20of) [2](https://www.nintendo.co.jp/ir/pdf/2015/150507e.pdf#page=3&search=party%20publishers%20are%20scheduled%20for%20release.)

## What would change the view

I would switch to lower if holiday retail sell-through showed New-model gains persistently outweighed by older-model losses, with unsold family inventory building and retailers cutting reorders. That combination would point to Nintendo missing even its reduced family hardware plan; a shift in retail mix alone would not. [3](https://www.nintendo.co.jp/ir/pdf/2015/150507e.pdf#page=16&search=%285%29%20Consolidated%20sales%20units%2C%20number%20of) [5](https://www.nintendo.co.jp/ir/pdf/2015/150507e.pdf#page=3&search=Operating%20Results%201.%20Analysis%20of%20Operations)

## Sources

1. [Nintendo consolidated financial statements for year ended March 2015, PDF p2 §1](https://www.nintendo.co.jp/ir/pdf/2015/150507e.pdf#page=2&search=Consolidated%20Financial%20Forecast%20for%20the%20Fiscal), available by 2015-05-07.
2. [Nintendo consolidated financial statements for year ended March 2015, PDF p3 §3](https://www.nintendo.co.jp/ir/pdf/2015/150507e.pdf#page=3&search=party%20publishers%20are%20scheduled%20for%20release.), available by 2015-05-07.
3. [Nintendo consolidated financial statements for year ended March 2015, PDF p16 §1](https://www.nintendo.co.jp/ir/pdf/2015/150507e.pdf#page=16&search=%285%29%20Consolidated%20sales%20units%2C%20number%20of), available by 2015-05-07.
4. [Nintendo consolidated financial statements for year ended March 2015, PDF p3 §2](https://www.nintendo.co.jp/ir/pdf/2015/150507e.pdf#page=3&search=enjoyed%20robust%20sales%20of%205.11%20million), available by 2015-05-07.
5. [Nintendo consolidated financial statements for year ended March 2015, PDF p3 §1](https://www.nintendo.co.jp/ir/pdf/2015/150507e.pdf#page=3&search=Operating%20Results%201.%20Analysis%20of%20Operations), available by 2015-05-07.
