# Investment research memo

As of 2019-04-26T12:00:00Z

**Research question**
What did the CMA decide about Sainsbury’s proposed merger with Asda, and how did the national and local supermarket findings differ in geographic scope and store coverage? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

On 25 April 2019, the CMA prohibited Sainsbury’s proposed merger with Asda in its entirety. It expected the loss of rivalry to threaten prices, quality, range or service across both supermarket chains, not just in places where the chains competed head to head. The national supermarket finding covered all 1,239 local areas where either chain was present. [1](https://assets.publishing.service.gov.uk/media/5cc1434ee5274a467a8dd482/Executive_summary.pdf#page=1&search=Anticipated%20merger%20between%20J%20Sainsbury%20PLC)

## Evidence

The final local finding covered 537 areas where both chains were present, accounting for approximately 40% of Sainsbury’s supermarkets and 50% of Asda’s supermarkets. Those are shares of each chain’s own stores, as reported by the CMA; the headline count is of areas, not stores. Updated data and methods reduced the provisional local count from 629 areas without materially changing the national finding. [1](https://assets.publishing.service.gov.uk/media/5cc1434ee5274a467a8dd482/Executive_summary.pdf#page=1&search=Anticipated%20merger%20between%20J%20Sainsbury%20PLC) [2](https://assets.publishing.service.gov.uk/media/5cc1434ee5274a467a8dd482/Executive_summary.pdf#page=2&search=5.%20%7C%20Since%20we%20published%20our)

## Outlook

For investors, the base case is continued independent competition, not a combined chain with a few local disposals. The alternative was a merger cleared with store sales. Its credibility depended on an observable test: could a buyer acquire enough assets to restore rivalry nationally as well as locally? The parties proposed selling around 125-150 supermarkets as part of a package designed for a narrower set of concerns. The CMA rejected it as inadequate. [3](https://assets.publishing.service.gov.uk/media/5cc1434ee5274a467a8dd482/Executive_summary.pdf#page=25&search=%28a%29%20prohibition%20of%20the%20Merger%3B%20and)

## What would change the view

Geographic reach is not financial magnitude. The national finding concerned incentives under a merger that did not proceed; it does not establish that every store would have raised prices by the same amount, or quantify the earnings impact. An estimate would need evidence of how prices, service and customer switching would have differed from the no-merger case. Neither the national area count nor the local store shares supply that comparison. [4](https://assets.publishing.service.gov.uk/media/5cc1434ee5274a467a8dd482/Executive_summary.pdf#page=24&search=109.%20%7C%20This%20scale%20of%20efficiencies) [1](https://assets.publishing.service.gov.uk/media/5cc1434ee5274a467a8dd482/Executive_summary.pdf#page=1&search=Anticipated%20merger%20between%20J%20Sainsbury%20PLC)

## Sources

1. [CMA final report executive summary on Sainsbury’s and Asda, PDF p1 §1](https://assets.publishing.service.gov.uk/media/5cc1434ee5274a467a8dd482/Executive_summary.pdf#page=1&search=Anticipated%20merger%20between%20J%20Sainsbury%20PLC), available by 2019-04-25.
2. [CMA final report executive summary on Sainsbury’s and Asda, PDF p2 §2](https://assets.publishing.service.gov.uk/media/5cc1434ee5274a467a8dd482/Executive_summary.pdf#page=2&search=5.%20%7C%20Since%20we%20published%20our), available by 2019-04-25.
3. [CMA final report executive summary on Sainsbury’s and Asda, PDF p25 §1](https://assets.publishing.service.gov.uk/media/5cc1434ee5274a467a8dd482/Executive_summary.pdf#page=25&search=%28a%29%20prohibition%20of%20the%20Merger%3B%20and), available by 2019-04-25.
4. [CMA final report executive summary on Sainsbury’s and Asda, PDF p24 §1](https://assets.publishing.service.gov.uk/media/5cc1434ee5274a467a8dd482/Executive_summary.pdf#page=24&search=109.%20%7C%20This%20scale%20of%20efficiencies), available by 2019-04-25.
