# Investment research memo

As of 2022-10-28T12:00:00Z

Forecast direction: within

**Research question**
How did the first BEA estimate for Q3 2022 distinguish real GDP growth from the domestic purchases price index? Explain how exports and residential fixed investment affected the growth reading. In the second estimate, will real GDP growth be revised lower, remain within, or go higher? Within means unchanged at the published one-decimal precision. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

BEA’s advance estimate put third-quarter 2022 U.S. real GDP growth at 2.6 percent annually, a rebound from a 0.6 percent annualized decline in the preceding quarter. The separate 4.6 percent increase in the gross domestic purchases price index measured prices paid by domestic purchasers, not growth in U.S. output. The revision call is therefore against 2.6 percent, not the inflation reading. [1](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20a.m.) [2](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=2&search=acceleration%20in%20nonresidential%20fixed%20investment%2C%20and)

## Evidence

Exports lifted BEA’s third-quarter growth estimate, while residential fixed investment partly offset that gain. Real exports grew at a 14.4 percent annual rate, adding 1.63 percentage points to real GDP growth. Real residential fixed investment grew at a -26.4 percent annual rate, with new single-family construction and brokers’ commissions leading the decline. The residential figure measures the contraction in investment itself, not the percentage points it subtracted from GDP growth. [3](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=7&search=9%20%7C%20Nonresidential%20%7C%203.6%20%7C) [4](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=8&search=43%20%7C%20Net%20exports%20of%20goods) [5](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=2&search=The%20increase%20in%20exports%20reflected%20increases)

## Outlook

Base case: within (unchanged). I forecast that the second estimate will still round to 2.6 percent, with low confidence. My main assumption is that fuller September trade data will leave real net exports close to the advance estimate and that other updates will not move the rounded headline. No newer source reading in the supplied record shows a surprise relative to BEA’s assumptions. The large initial trade contribution explains growth, not the sign of its revision. Unchanged is a no-news forecast, not a claim that revisions are usually negligible: BEA’s historical average advance-to-second revision was 0.5 percentage points without regard to sign. [1](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20a.m.) [6](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=3&search=Source%20Data%20for%20the%20Advance%20Estimate) [7](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=5&search=Statistical%20conventions%20%7C%20Updates%20to%20GDP) [8](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=5&search=adjusted%20values%20are%20calculated%20from%20the)

## What would change the view

The strongest alternative is lower if the advance estimate understated imports. Compare the fuller September export and import readings, after price adjustment, with the corresponding advance assumptions. If higher real imports are not matched by higher real exports, switch to lower once the resulting reduction in net exports, after other known updates, takes projected GDP growth below 2.6 percent at published precision. A wider nominal trade deficit alone would not establish that signal. [1](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20a.m.) [6](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=3&search=Source%20Data%20for%20the%20Advance%20Estimate) [8](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=5&search=adjusted%20values%20are%20calculated%20from%20the)

## Sources

1. [BEA GDP advance estimate, Q3 2022, PDF p1 §1](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20a.m.), available by 2022-10-27.
2. [BEA GDP advance estimate, Q3 2022, PDF p2 §2](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=2&search=acceleration%20in%20nonresidential%20fixed%20investment%2C%20and), available by 2022-10-27.
3. [BEA GDP advance estimate, Q3 2022, PDF p7 §2](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=7&search=9%20%7C%20Nonresidential%20%7C%203.6%20%7C), available by 2022-10-27.
4. [BEA GDP advance estimate, Q3 2022, PDF p8 §6](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=8&search=43%20%7C%20Net%20exports%20of%20goods), available by 2022-10-27.
5. [BEA GDP advance estimate, Q3 2022, PDF p2 §1](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=2&search=The%20increase%20in%20exports%20reflected%20increases), available by 2022-10-27.
6. [BEA GDP advance estimate, Q3 2022, PDF p3 §1](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=3&search=Source%20Data%20for%20the%20Advance%20Estimate), available by 2022-10-27.
7. [BEA GDP advance estimate, Q3 2022, PDF p5 §1](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=5&search=Statistical%20conventions%20%7C%20Updates%20to%20GDP), available by 2022-10-27.
8. [BEA GDP advance estimate, Q3 2022, PDF p5 §2](https://www.bea.gov/sites/default/files/2022-10/gdp3q22_adv.pdf#page=5&search=adjusted%20values%20are%20calculated%20from%20the), available by 2022-10-27.
