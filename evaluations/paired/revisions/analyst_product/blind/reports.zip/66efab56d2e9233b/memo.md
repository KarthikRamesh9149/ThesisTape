# Investment research memo

As of 2018-11-02T12:00:00Z

**Research question**
What explains the gap between iPhone unit and revenue growth in Apple’s fiscal Q4 2018, and how much of quarterly net sales came from iPhone? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

Apple’s iPhone revenue grew 29% year over year in fiscal Q4 2018, while unit growth rounded to 0%. Higher reported revenue per iPhone, not materially higher volume, explains the gap. iPhone accounted for 59.1176 of Apple’s quarterly net sales ($37,185 million in iPhone revenue divided by 62,900 million dollars in net sales). That makes iPhone central to the sales forecast, but its quarterly growth rate is not a sound rate to apply to Apple as a whole. [1](https://www.apple.com/newsroom/pdfs/Q4-18-Data-Summary.pdf#page=1&search=Apple%20Inc.%20Q4%202018%20Unaudited%20Summary) [2](https://www.apple.com/newsroom/pdfs/Q4-FY18-Consolidated-Financial-Statements.pdf#page=1&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF)

## Evidence

In Q4 2017, $28,846 million divided by 46,677 thousand iPhones yielded about 0.618 per unit. In Q4 2018, $37,185 million divided by 46,889 thousand iPhones yielded about 0.793 per unit. Comparing the unrounded quotients gives a 28.3259 increase in revenue per unit, accounting for nearly all the revenue growth; unit sales rose only slightly. [1](https://www.apple.com/newsroom/pdfs/Q4-18-Data-Summary.pdf#page=1&search=Apple%20Inc.%20Q4%202018%20Unaudited%20Summary)

## Outlook

For the base case, forecast iPhone units and revenue per unit separately, then add sales from Apple’s other businesses. If units remain nearly flat and revenue per unit merely holds its higher level in a comparable quarter, iPhone revenue will also be nearly flat. The strongest alternative is a continuing shift toward higher-priced models: a rising premium-model share accompanied by further gains in revenue per unit despite flat volume would support that case. The aggregate iPhone line cannot distinguish a mix shift from higher prices on the same models, and it includes deferrals and amortization, so the quotient is not a handset transaction price. [1](https://www.apple.com/newsroom/pdfs/Q4-18-Data-Summary.pdf#page=1&search=Apple%20Inc.%20Q4%202018%20Unaudited%20Summary)

## Checked calculations

- C1. FY Q4 2017 iPhone revenue per unit: about $618 (summary PDF p. 1) (USD millions per thousand iPhones) — 28,846 ÷ 46,677 ≈ 0.617992 [1](https://www.apple.com/newsroom/pdfs/Q4-18-Data-Summary.pdf#page=1&search=Apple%20Inc.%20Q4%202018%20Unaudited%20Summary)
- C2. FY Q4 2018 iPhone revenue per unit: about $793; includes related deferrals and amortization (summary PDF p. 1, note 1) (USD millions per thousand iPhones) — 37,185 ÷ 46,889 ≈ 0.793043 [1](https://www.apple.com/newsroom/pdfs/Q4-18-Data-Summary.pdf#page=1&search=Apple%20Inc.%20Q4%202018%20Unaudited%20Summary)
- C3. FY Q4 2018 YoY: revenue per iPhone rose 28.3%, explaining 29% revenue growth on nearly flat units (summary PDF p. 1) (percent) — (C2 − C1) ÷ |C1| × 100 ≈ 28.325851 [1](https://www.apple.com/newsroom/pdfs/Q4-18-Data-Summary.pdf#page=1&search=Apple%20Inc.%20Q4%202018%20Unaudited%20Summary)
- C4. FY Q4 2018: iPhone supplied 59.1% of net sales; forecast units and revenue per unit, not a repeat of 29% (P1/P5, p. 1) (percent of quarterly net sales) — 37,185 ÷ 62,900 × 100 ≈ 59.117647 [1](https://www.apple.com/newsroom/pdfs/Q4-18-Data-Summary.pdf#page=1&search=Apple%20Inc.%20Q4%202018%20Unaudited%20Summary) [2](https://www.apple.com/newsroom/pdfs/Q4-FY18-Consolidated-Financial-Statements.pdf#page=1&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF)

## Sources

1. [Apple FY2018 fourth-quarter unaudited summary data, PDF p1 §1](https://www.apple.com/newsroom/pdfs/Q4-18-Data-Summary.pdf#page=1&search=Apple%20Inc.%20Q4%202018%20Unaudited%20Summary), available by 2018-11-01.
2. [Apple FY2018 fourth-quarter consolidated financial statements, PDF p1 §1](https://www.apple.com/newsroom/pdfs/Q4-FY18-Consolidated-Financial-Statements.pdf#page=1&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF), available by 2018-11-01.
