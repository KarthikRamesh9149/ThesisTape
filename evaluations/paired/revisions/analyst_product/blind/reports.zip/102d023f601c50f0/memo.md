# Investment research memo

As of 2017-07-13T12:00:00Z

Forecast direction: within

**Research question**
What did the Bank of Canada decide on 2017-07-12, what in the statement qualifies its policy stance, and where do you expect the overnight rate target at the 2017-09-06 scheduled decision relative to its 2017-07-12 level? Compare to May and explain the Bank’s view of inflation softness. Within means unchanged. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

On July 12, 2017, the Bank of Canada began withdrawing some monetary stimulus, raising its overnight rate target to 3/4 per cent after holding it at 1/2 per cent on 24 May 2017. The hike was 3/4 per cent − 1/2 per cent = 0.25 percentage points. [1](https://www.bankofcanada.ca/wp-content/uploads/2017/07/fad-press-release-2017-07-12.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [2](https://www.bankofcanada.ca/wp-content/uploads/2017/05/fad-press-release-2017-05-24.pdf#page=1&search=housing%20markets.%20Meanwhile%2C%20e%20%7C%20xport) [3](https://www.bankofcanada.ca/wp-content/uploads/2017/05/fad-press-release-2017-05-24.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [4](https://www.bankofcanada.ca/wp-content/uploads/2017/07/fad-press-release-2017-07-12.pdf#page=1&search=adjustment%20to%20lower%20oil%20prices%20is)

## Evidence

What changed between May and July was the Bank’s confidence that growth would absorb spare capacity, not a rebound in observed inflation. In May, subdued wage growth and low core inflation supported its judgment that existing stimulus was appropriate. By July, stronger evidence of above-potential growth and the lag between a rate change and its effect on inflation justified acting before inflation firmed. [3](https://www.bankofcanada.ca/wp-content/uploads/2017/05/fad-press-release-2017-05-24.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [2](https://www.bankofcanada.ca/wp-content/uploads/2017/05/fad-press-release-2017-05-24.pdf#page=1&search=housing%20markets.%20Meanwhile%2C%20e%20%7C%20xport) [1](https://www.bankofcanada.ca/wp-content/uploads/2017/07/fad-press-release-2017-07-12.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media)

The Bank judged inflation softness mostly temporary, citing food-price competition, Ontario electricity rebates and changes in automobile pricing. It expected inflation to return close to 2 per cent by the middle of 2018 as those price effects faded and excess capacity was absorbed. That was a projection, not a finding that underlying price pressure had already recovered. [4](https://www.bankofcanada.ca/wp-content/uploads/2017/07/fad-press-release-2017-07-12.pdf#page=1&search=adjustment%20to%20lower%20oil%20prices%20is)

## Outlook

As of 2017-07-13T12:00:00Z, my base case for September 6, 2017 is within: unchanged at 3/4 per cent (unchanged). The main driver is whether shrinking slack starts to lift core inflation. The Bank projected the output gap would close around the end of 2017, but its core measures were all still below 2 per cent. On balance, that favors waiting for evidence of firmer underlying inflation rather than repeating July’s hike immediately. [5](https://www.bankofcanada.ca/wp-content/uploads/2017/07/fad-press-release-2017-07-12.pdf#page=2&search=Information%20note%3A%20The%20next%20scheduled%20date) [1](https://www.bankofcanada.ca/wp-content/uploads/2017/07/fad-press-release-2017-07-12.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [4](https://www.bankofcanada.ca/wp-content/uploads/2017/07/fad-press-release-2017-07-12.pdf#page=1&search=adjustment%20to%20lower%20oil%20prices%20is)

The base case remains within—unchanged—for September 6, 2017 (unchanged). The July hike was not a commitment to hike again: the Bank said future moves would depend on what incoming data implied for the inflation outlook, while also taking continued uncertainty and financial system vulnerabilities into account. [4](https://www.bankofcanada.ca/wp-content/uploads/2017/07/fad-press-release-2017-07-12.pdf#page=1&search=adjustment%20to%20lower%20oil%20prices%20is) [5](https://www.bankofcanada.ca/wp-content/uploads/2017/07/fad-press-release-2017-07-12.pdf#page=2&search=Information%20note%3A%20The%20next%20scheduled%20date)

## What would change the view

The strongest alternative is higher: another hike of the same size as July’s. I would switch to that call if CPI releases available before the meeting showed all of the Bank’s core inflation measures moving higher, rather than just a rebound in headline inflation. That would be evidence that shrinking slack was lifting underlying inflation. The July statement establishes the starting point, not that the rebound will occur or that it would automatically trigger a hike. [4](https://www.bankofcanada.ca/wp-content/uploads/2017/07/fad-press-release-2017-07-12.pdf#page=1&search=adjustment%20to%20lower%20oil%20prices%20is)

## Checked calculations

- C1. July 12, 2017 overnight target minus May 24, 2017 target (25 basis points); both announcements PDF p. 1 (percentage points) — 3/4 − 1/2 = 0.25 [3](https://www.bankofcanada.ca/wp-content/uploads/2017/05/fad-press-release-2017-05-24.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [1](https://www.bankofcanada.ca/wp-content/uploads/2017/07/fad-press-release-2017-07-12.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media)

## Sources

1. [Bank of Canada policy rate announcement of 2017-07-12, PDF p1 §1](https://www.bankofcanada.ca/wp-content/uploads/2017/07/fad-press-release-2017-07-12.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media), available by 2017-07-12.
2. [Bank of Canada policy rate announcement of 2017-05-24, PDF p1 §2](https://www.bankofcanada.ca/wp-content/uploads/2017/05/fad-press-release-2017-05-24.pdf#page=1&search=housing%20markets.%20Meanwhile%2C%20e%20%7C%20xport), available by 2017-05-24.
3. [Bank of Canada policy rate announcement of 2017-05-24, PDF p1 §1](https://www.bankofcanada.ca/wp-content/uploads/2017/05/fad-press-release-2017-05-24.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media), available by 2017-05-24.
4. [Bank of Canada policy rate announcement of 2017-07-12, PDF p1 §2](https://www.bankofcanada.ca/wp-content/uploads/2017/07/fad-press-release-2017-07-12.pdf#page=1&search=adjustment%20to%20lower%20oil%20prices%20is), available by 2017-07-12.
5. [Bank of Canada policy rate announcement of 2017-07-12, PDF p2 §1](https://www.bankofcanada.ca/wp-content/uploads/2017/07/fad-press-release-2017-07-12.pdf#page=2&search=Information%20note%3A%20The%20next%20scheduled%20date), available by 2017-07-12.
