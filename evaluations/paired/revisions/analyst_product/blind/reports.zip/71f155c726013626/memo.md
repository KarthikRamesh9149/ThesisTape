# Investment research memo

As of 2020-07-31T12:00:00Z

**Research question**
Using the nine months in Apple’s Q3 FY2020 statements, did cash from operations after capital spending cover dividends and share repurchases? Quantify the gap. Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

No. In the nine months ended June 27, 2020, Apple’s operating cash flow after capital spending fell short of its dividends and share repurchases. The signed gap was 54,573 + (-65,741) = -11,168 million dollars. Apple could fund the dividends from post-capex operating cash, but not the full buyback as well. [1](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF) [2](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Payments%20for%20dividends%20and%20dividend%20equivalents)

## Evidence

In millions of dollars, with parentheses denoting outflows: operating cash of 60,098 plus cash spending on property, plant and equipment of (5,525) left 54,573. Dividends and dividend equivalents of (10,570) plus common-stock repurchases of (55,171) produced a combined outflow of -65,741 on the same signed basis. [1](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF) [2](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Payments%20for%20dividends%20and%20dividend%20equivalents)

The gap measures payout coverage, not borrowing needs. Apple both issued and repaid term debt, and its cash balance declined. The statement reports those flows but does not trace particular dollars to the buyback; the shortfall alone is not evidence that Apple borrowed to repurchase shares. [2](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Payments%20for%20dividends%20and%20dividend%20equivalents)

## Outlook

At 2020-07-31T12:00:00Z, the base case is conditional: if post-capex operating cash and payouts repeat at these levels, the gap persists. A plausible alternative is full coverage without better earnings: the (10,787) million dollar accounts-payable outflow may not recur, and Apple could repurchase fewer shares. The test is whether a later comparable cash-flow statement shows operating cash after cash capital spending matching or exceeding dividends and repurchases; this period establishes neither the timing of supplier payments nor the future pace of buybacks. [1](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF) [2](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Payments%20for%20dividends%20and%20dividend%20equivalents)

## Checked calculations

- C1. C1: Operating cash flow less cash PP&E spending = 54,573 (nine months ended June 27, 2020; PDF p. 3) (USD millions) — 60,098 + (5,525) = 54,573 [1](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF)
- C2. C2: Dividends and dividend equivalents plus repurchases = −65,741 (nine months ended June 27, 2020; PDF p. 3) (USD millions) — (10,570) + (55,171) = -65,741 [2](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Payments%20for%20dividends%20and%20dividend%20equivalents)
- C3. No: −11,168 shortfall; post-capex cash did not fully fund payouts (nine months ended June 27, 2020; PDF p. 3) (USD millions) — C1 + C2 = -11,168 [1](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF) [2](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Payments%20for%20dividends%20and%20dividend%20equivalents)

## Sources

1. [Apple FY2020 third-quarter consolidated financial statements, PDF p3 §1](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF), available by 2020-07-30.
2. [Apple FY2020 third-quarter consolidated financial statements, PDF p3 §2](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Payments%20for%20dividends%20and%20dividend%20equivalents), available by 2020-07-30.
