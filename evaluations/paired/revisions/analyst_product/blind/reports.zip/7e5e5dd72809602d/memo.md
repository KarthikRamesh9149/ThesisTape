# Investment research memo

As of 2019-05-01T12:00:00Z

**Research question**
How much of the year-over-year fall in Apple product sales did services growth offset in fiscal Q2 2019, and how did consolidated revenue reconcile? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Answer

Apple’s Services growth offset just over a third of its year-over-year Products sales decline in fiscal Q2 2019. The premise holds on a like-for-like basis: Apple’s statement compares the three months ended March 30, 2019 with the three months ended March 31, 2018. Services softened the decline but did not prevent consolidated net sales from falling. [1](https://www.apple.com/newsroom/pdfs/Q2%20FY19%20Consolidated%20Financial%20Statements.pdf#page=1&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF)

## Evidence

In millions of dollars, the signed Products change was (46,565 − 51,287), and the Services change was +(11,450 − 9,850). The exact offset ratio is (11,450 − 9,850) / (51,287 − 46,565): the denominator is the magnitude of the Products loss, not beginning Products sales. The consolidated bridge is 61,137 − (51,287 − 46,565) + (11,450 − 9,850) = 58,015, leaving no unexplained change. [1](https://www.apple.com/newsroom/pdfs/Q2%20FY19%20Consolidated%20Financial%20Statements.pdf#page=1&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF)

## Outlook

If Services sales keep rising by less than Products sales fall, Services will cushion—but not prevent—a decline in consolidated revenue. The fiscal first-half Services gain, from 18,979 million dollars to 22,325 million dollars, exceeded the March-quarter gain, so growth was not confined to the March quarter. But aggregate sales do not distinguish repeat spending from one-time purchases, so they do not establish that similar dollar gains will persist. [1](https://www.apple.com/newsroom/pdfs/Q2%20FY19%20Consolidated%20Financial%20Statements.pdf#page=1&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF)

## What would change the view

The downside is that Services keeps growing but offsets a smaller share of a widening Products decline. The iPhone sales drop alone was larger than the net Products loss, with gains in iPad and Wearables, Home and Accessories softening the blow. In later comparable quarters, a falling ratio of the Services dollar gain to the Products dollar loss—especially if those hardware gains fade—would weaken the case for a durable cushion. [2](https://www.apple.com/newsroom/pdfs/Q2%20FY19%20Consolidated%20Financial%20Statements.pdf#page=1&search=Rest%20of%20Asia%20Pacific%20%7C%203%2C615) [1](https://www.apple.com/newsroom/pdfs/Q2%20FY19%20Consolidated%20Financial%20Statements.pdf#page=1&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF)

## Sources

1. [Apple FY2019 second-quarter consolidated financial statements, PDF p1 §1](https://www.apple.com/newsroom/pdfs/Q2%20FY19%20Consolidated%20Financial%20Statements.pdf#page=1&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF), available by 2019-04-30.
2. [Apple FY2019 second-quarter consolidated financial statements, PDF p1 §2](https://www.apple.com/newsroom/pdfs/Q2%20FY19%20Consolidated%20Financial%20Statements.pdf#page=1&search=Rest%20of%20Asia%20Pacific%20%7C%203%2C615), available by 2019-04-30.
