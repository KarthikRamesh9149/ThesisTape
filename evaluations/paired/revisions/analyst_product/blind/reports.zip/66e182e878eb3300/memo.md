# Investment research memo

As of 2020-03-05T12:00:00Z

Forecast direction: lower

**Research question**
What did the Bank of Canada decide on 2020-03-04, what in the statement qualifies its policy stance, and where do you expect the overnight rate target at the 2020-04-15 scheduled decision relative to its 2020-03-04 level? Explain how the outbreak changed the outlook, compare to January and use the scheduled April meeting as the horizon. Within means unchanged. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

On March 4, 2020, the Bank of Canada cut its overnight rate target from January’s 1 ¾ percent to 1 ¼ percent. The March target minus the January target was -0.5 percentage points. The Bank eased because the outbreak threatened future activity, even though the economy had been operating close to potential with inflation on target. [1](https://www.bankofcanada.ca/wp-content/uploads/2020/01/fad-press-release-2020-01-22.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [2](https://www.bankofcanada.ca/wp-content/uploads/2020/03/fad-press-release-2020-03-04.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media)

## Evidence

January’s outlook already allowed for near-term weakness, but the Bank expected stronger global demand to support a modest contribution from Canadian investment and exports. By March, business activity had fallen sharply in some regions, supply chains were disrupted and commodity prices had declined. The Bank expected weaker confidence to depress spending and saw no sign of the anticipated investment recovery. The change was not simply that growth was weak; the demand recovery January’s projection relied on had become less likely. [3](https://www.bankofcanada.ca/wp-content/uploads/2020/01/fad-press-release-2020-01-22.pdf#page=1&search=Moreover%2C%20during%20the%20past%20year%20Canadians) [2](https://www.bankofcanada.ca/wp-content/uploads/2020/03/fad-press-release-2020-03-04.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [4](https://www.bankofcanada.ca/wp-content/uploads/2020/03/fad-press-release-2020-03-04.pdf#page=1&search=weakened.%20It%20is%20becoming%20clear%20that)

The key qualification was “if required.” Governing Council was prepared to adjust policy to support growth and keep inflation on target. That signalled a willingness to act, not a commitment to another cut: the statement specified neither the size nor the timing of any further move. [4](https://www.bankofcanada.ca/wp-content/uploads/2020/03/fad-press-release-2020-03-04.pdf#page=1&search=weakened.%20It%20is%20becoming%20clear%20that)

## Outlook

As of 2020-03-05T12:00:00Z, my base case for the scheduled 2020-04-15 decision is lower than the March target of 1 ¼ percent. The main driver is weaker demand: if firms face fewer orders as confidence falls, they have less reason to invest. I expect that risk to warrant further easing by the April meeting; that is my forecast, not the Bank’s guidance. [2](https://www.bankofcanada.ca/wp-content/uploads/2020/03/fad-press-release-2020-03-04.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [4](https://www.bankofcanada.ca/wp-content/uploads/2020/03/fad-press-release-2020-03-04.pdf#page=1&search=weakened.%20It%20is%20becoming%20clear%20that)

## What would change the view

The strongest alternative is a hold: within unchanged, meaning exactly unchanged. With core inflation still around 2 percent, the Bank could wait to assess the March cut. Stabilization in Canadian new orders despite the outbreak would shift my call toward a hold: it would be observable evidence that demand was holding up better than my base case assumes. The statement does not establish that orders had stabilized. [4](https://www.bankofcanada.ca/wp-content/uploads/2020/03/fad-press-release-2020-03-04.pdf#page=1&search=weakened.%20It%20is%20becoming%20clear%20that)

## Checked calculations

- C1. Reported change in the overnight rate target on March 4, 2020: March 4 target minus January 22 target (percentage points) — 1 ¼ − 1 ¾ = -0.50 [2](https://www.bankofcanada.ca/wp-content/uploads/2020/03/fad-press-release-2020-03-04.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media) [1](https://www.bankofcanada.ca/wp-content/uploads/2020/01/fad-press-release-2020-01-22.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media)

## Sources

1. [Bank of Canada policy rate announcement of 2020-01-22, PDF p1 §1](https://www.bankofcanada.ca/wp-content/uploads/2020/01/fad-press-release-2020-01-22.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media), available by 2020-01-22.
2. [Bank of Canada policy rate announcement of 2020-03-04, PDF p1 §1](https://www.bankofcanada.ca/wp-content/uploads/2020/03/fad-press-release-2020-03-04.pdf#page=1&search=FOR%20IMMEDIATE%20RELEASE%20%7C%20CONTACT%3A%20Media), available by 2020-03-04.
3. [Bank of Canada policy rate announcement of 2020-01-22, PDF p1 §2](https://www.bankofcanada.ca/wp-content/uploads/2020/01/fad-press-release-2020-01-22.pdf#page=1&search=Moreover%2C%20during%20the%20past%20year%20Canadians), available by 2020-01-22.
4. [Bank of Canada policy rate announcement of 2020-03-04, PDF p1 §2](https://www.bankofcanada.ca/wp-content/uploads/2020/03/fad-press-release-2020-03-04.pdf#page=1&search=weakened.%20It%20is%20becoming%20clear%20that), available by 2020-03-04.
