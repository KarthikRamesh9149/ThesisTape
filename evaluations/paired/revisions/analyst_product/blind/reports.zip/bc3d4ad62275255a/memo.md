# Investment research memo

As of 2015-08-11T12:00:00Z

**Research question**
What was Berkshire offering Precision Castparts shareholders, how was the headline deal value defined, and what stood between signing and closing? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Answer

As of 2015-08-11T12:00:00Z, value Precision Castparts (PCC) shares as a pending merger, not a certain cash payment. Both boards unanimously approved a definitive agreement under which Berkshire Hathaway would pay $235 per share in cash at closing. The approximately $ 37.2 billion headline includes PCC’s outstanding net debt; it measures the transaction as a whole, not cash distributable to shareholders. Aggregate shareholder proceeds would be the offer price multiplied by the number of shares purchased. The release does not give that share count. [1](https://www.berkshirehathaway.com/news/aug1015.pdf#page=1&search=Berkshire%20Hathaway%20Inc.%20to%20Acquire%20Precision)

## Evidence

The release supplies no contemporaneous PCC market quote, so it cannot establish an observed merger spread. Given a quote, subtract the market price per share from $235 to get the gross gain per share if the deal closes on its terms. A price below the offer could reflect the wait for cash even if investors expect closing; it could also reflect the risk that the deal fails. The price alone cannot distinguish those explanations or establish a closing probability without assumptions about timing, the required return and PCC’s value if the deal breaks. [1](https://www.berkshirehathaway.com/news/aug1015.pdf#page=1&search=Berkshire%20Hathaway%20Inc.%20to%20Acquire%20Precision) [2](https://www.berkshirehathaway.com/news/aug1015.pdf#page=1&search=The%20transaction%20requires%20approval%20by%20a) [3](https://www.berkshirehathaway.com/news/aug1015.pdf#page=3&search=Statements%20in%20this%20press%20release%20regarding)

## Outlook

Berkshire and PCC expected the acquisition to close in the first quarter of calendar 2016, but that was a forecast, not a payment deadline. The boards’ approval did not replace the required approval by holders of a majority of PCC’s outstanding shares. PCC’s plan to file and mail a merger proxy was a step toward that vote, not evidence that it had passed. Closing also depended on clearance under the Hart–Scott–Rodino Act, competition clearance in certain foreign jurisdictions and satisfaction of other customary closing conditions. [2](https://www.berkshirehathaway.com/news/aug1015.pdf#page=1&search=The%20transaction%20requires%20approval%20by%20a) [4](https://www.berkshirehathaway.com/news/aug1015.pdf#page=2&search=This%20communication%20may%20be%20deemed%20to)

## What would change the view

The strongest alternative to a routine close is that an approval obstacle delays payment or defeats the deal. A favorable vote and confirmed regulatory clearances would support the base case. A regulator demanding conditions would warrant revisiting the timetable and odds of closing; a failed shareholder vote would make PCC’s standalone value, rather than the promised cash price, the relevant benchmark. [3](https://www.berkshirehathaway.com/news/aug1015.pdf#page=3&search=Statements%20in%20this%20press%20release%20regarding) [2](https://www.berkshirehathaway.com/news/aug1015.pdf#page=1&search=The%20transaction%20requires%20approval%20by%20a)

## Sources

1. [Berkshire Hathaway to acquire Precision Castparts, PDF p1 §1](https://www.berkshirehathaway.com/news/aug1015.pdf#page=1&search=Berkshire%20Hathaway%20Inc.%20to%20Acquire%20Precision), available by 2015-08-10.
2. [Berkshire Hathaway to acquire Precision Castparts, PDF p1 §2](https://www.berkshirehathaway.com/news/aug1015.pdf#page=1&search=The%20transaction%20requires%20approval%20by%20a), available by 2015-08-10.
3. [Berkshire Hathaway to acquire Precision Castparts, PDF p3 §2](https://www.berkshirehathaway.com/news/aug1015.pdf#page=3&search=Statements%20in%20this%20press%20release%20regarding), available by 2015-08-10.
4. [Berkshire Hathaway to acquire Precision Castparts, PDF p2 §2](https://www.berkshirehathaway.com/news/aug1015.pdf#page=2&search=This%20communication%20may%20be%20deemed%20to), available by 2015-08-10.
