# Investment research memo

As of 2018-04-27T12:00:00Z

Forecast direction: lower

**Research question**
At Nintendo’s FY2018 results, what operating profit did it guide for the year ending March 2019? Compare it with the just-reported year, discuss the scale of Switch hardware sales in the just-reported year, and forecast the full-year actual relative to guidance (within means ±2% of the guide, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Evidence

The year-over-year comparison must use consolidated profit. The 128,104 million yen actual is from Nintendo’s non-consolidated table; it is not the denominator for the group forecast. The implied prior-year group profit is 225,000 million yen divided by one plus 26.7%. That reverses a rounded growth rate: the excerpts verify the published increase but not the exact consolidated actual. [1](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=2&search=Consolidated%20Financial%20Forecast%20for%20the%20Fiscal) [2](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=2&search=million%20yen%20%7C%20%25%20%7C%20million)

The inclusive within-guidance band is an inclusive ±2% band around the reference. Its endpoints are the original 225,000 million yen guide multiplied by one minus and one plus the question’s tolerance, respectively. The tolerance is an unverified question premise for classification, not a range Nintendo issued. Only a result strictly below the lower endpoint counts as lower. [1](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=2&search=Consolidated%20Financial%20Forecast%20for%20the%20Fiscal)

The comparable prior-year consolidated operating profit is implied by dividing 225.0 billion yen by one plus the published growth rate of 26.7 percent. That reverses a rounded rate; the excerpts verify the published increase, not the exact consolidated actual. The 128,104 million yen figure is non-consolidated and is not the denominator for the group comparison. [3](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=4&search=Through%20these%20initiatives%2C%20for%20the%20fiscal) [1](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=2&search=Consolidated%20Financial%20Forecast%20for%20the%20Fiscal) [2](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=2&search=million%20yen%20%7C%20%25%20%7C%20million)

The inclusive within-guidance band is an inclusive ±2% band around the reference. Its endpoints are the original 225.0 billion yen guide multiplied by one minus and one plus the question’s tolerance, respectively. That tolerance is an unverified question premise, not a range Nintendo issued. Only a result strictly below the lower endpoint counts as lower. [3](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=4&search=Through%20these%20initiatives%2C%20for%20the%20fiscal)

Nintendo reported selling 15.05 million Switch consoles in the just-reported year. Its consolidated unit table gives planned hardware growth as 2,000 divided by 1,505, minus one, and planned software growth as 10,000 divided by 6,351, minus one, with all inputs in ten-thousands of units. That puts planned hardware growth at roughly a third and planned software growth at more than half. The excerpts report company unit sales, not consumer sell-through. [4](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=3&search=Description%20of%20Operating%20Results%201.%20Operating) [5](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=15&search=%284%29%20Consolidated%20sales%20units%2C%20number%20of)

## Outlook

Lower is my base case because the software target asks more of Switch demand than the hardware target. In units of ten thousand, planned hardware growth is 2,000 divided by 1,505 minus one; planned software growth is 10,000 divided by 6,351 minus one. The latter understates the required growth in non-bundled games: actuals include bundled copies, but the forecast excludes them. I expect a software shortfall large enough to push profit below the band even if hardware sell-in meets plan. The unit data do not establish a per-game profit or quantify the miss. [5](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=15&search=%284%29%20Consolidated%20sales%20units%2C%20number%20of)

Lower is my base case because the software plan asks more of Switch demand than the hardware plan. The headline software comparison understates the growth needed in non-bundled games: actuals include bundled copies, but the forecast excludes them. I expect a software shortfall large enough to put operating profit below the band even if hardware sales meet plan. The unit data do not establish profit per game or quantify the likely miss. [5](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=15&search=%284%29%20Consolidated%20sales%20units%2C%20number%20of)

## What would change the view

Within guidance is plausible if the planned Super Smash Bros. release and continuing sales of existing games draw enough purchases from the growing installed base. I would switch to within if, by the end of December, cumulative Switch software sell-in excluding bundles reached at least four-fifths of the annual 10,000 ten-thousand-unit target and Nintendo retained its hardware forecast. That is my checkpoint, not company guidance: it would leave at most one-fifth of the software plan for the final quarter. [6](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=4&search=2.%20Outlook%20for%20the%20Fiscal%20Year) [5](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=15&search=%284%29%20Consolidated%20sales%20units%2C%20number%20of)

## Sources

1. [Nintendo consolidated financial statements for year ended March 2018, PDF p2 §1](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=2&search=Consolidated%20Financial%20Forecast%20for%20the%20Fiscal), available by 2018-04-26.
2. [Nintendo consolidated financial statements for year ended March 2018, PDF p2 §2](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=2&search=million%20yen%20%7C%20%25%20%7C%20million), available by 2018-04-26.
3. [Nintendo consolidated financial statements for year ended March 2018, PDF p4 §2](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=4&search=Through%20these%20initiatives%2C%20for%20the%20fiscal), available by 2018-04-26.
4. [Nintendo consolidated financial statements for year ended March 2018, PDF p3 §1](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=3&search=Description%20of%20Operating%20Results%201.%20Operating), available by 2018-04-26.
5. [Nintendo consolidated financial statements for year ended March 2018, PDF p15 §1](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=15&search=%284%29%20Consolidated%20sales%20units%2C%20number%20of), available by 2018-04-26.
6. [Nintendo consolidated financial statements for year ended March 2018, PDF p4 §1](https://www.nintendo.co.jp/ir/pdf/2018/180426e.pdf#page=4&search=2.%20Outlook%20for%20the%20Fiscal%20Year), available by 2018-04-26.
