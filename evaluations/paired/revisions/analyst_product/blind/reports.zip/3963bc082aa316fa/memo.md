# Investment research memo

As of 2019-05-01T12:00:00Z

**Research question**
How much of the year-over-year fall in Apple product sales did services growth offset in fiscal Q2 2019, and how did consolidated revenue reconcile? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Evidence

In USD millions, the Products decline was 51,287 − 46,565 = 4,722, while the Services gain was 11,450 − 9,850 = 1,600. Dividing the Services gain by the Products loss (1,600 ÷ 4,722) gives the offset. Subtracting the loss from the gain gives the consolidated revenue change: 1,600 − 4,722 = -3,122, exactly matching current-quarter net sales of 58,015 less year-earlier net sales of 61,137. [1](https://www.apple.com/newsroom/pdfs/Q2%20FY19%20Consolidated%20Financial%20Statements.pdf#page=1&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF)

## Outlook

The strongest case for a durable buffer is that Services also grew while Products fell over the fiscal first half. But that period includes the quarter under review, and the quarterly Products decline was itself a net figure: iPad and Wearables, Home and Accessories gains softened the iPhone loss. The base case is therefore a variable cushion, not a fixed offset. Repeated quarters in which Services dollar gains cover a comparable share of Products losses despite changes in product mix would strengthen the durability case. [1](https://www.apple.com/newsroom/pdfs/Q2%20FY19%20Consolidated%20Financial%20Statements.pdf#page=1&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF) [2](https://www.apple.com/newsroom/pdfs/Q2%20FY19%20Consolidated%20Financial%20Statements.pdf#page=1&search=Rest%20of%20Asia%20Pacific%20%7C%203%2C615)

## Checked calculations

- C1. FY Q2 Products sales decline, FY2018 less FY2019: $4,722m (PDF p1) (USD millions) — 51,287 − 46,565 = 4,722 [1](https://www.apple.com/newsroom/pdfs/Q2%20FY19%20Consolidated%20Financial%20Statements.pdf#page=1&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF)
- C2. FY Q2 Services sales growth, FY2019 less FY2018: $1,600m (PDF p1) (USD millions) — 11,450 − 9,850 = 1,600 [1](https://www.apple.com/newsroom/pdfs/Q2%20FY19%20Consolidated%20Financial%20Statements.pdf#page=1&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF)
- C4. FY Q2 net sales change: −$3,122m, matching reported revenue of $58,015m versus $61,137m a year earlier (PDF p1) (USD millions) — C2 − C1 = -3,122 [1](https://www.apple.com/newsroom/pdfs/Q2%20FY19%20Consolidated%20Financial%20Statements.pdf#page=1&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF)

## Sources

1. [Apple FY2019 second-quarter consolidated financial statements, PDF p1 §1](https://www.apple.com/newsroom/pdfs/Q2%20FY19%20Consolidated%20Financial%20Statements.pdf#page=1&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF), available by 2019-04-30.
2. [Apple FY2019 second-quarter consolidated financial statements, PDF p1 §2](https://www.apple.com/newsroom/pdfs/Q2%20FY19%20Consolidated%20Financial%20Statements.pdf#page=1&search=Rest%20of%20Asia%20Pacific%20%7C%203%2C615), available by 2019-04-30.
