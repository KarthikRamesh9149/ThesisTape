# Investment research memo

As of 2022-04-27T12:00:00Z

Forecast direction: within

**Research question**
Using Canon’s first quarter FY2022 release, what consolidated net income attributable to Canon Inc. remained to be earned to meet its December year-end projection? Give your call on the reported annual result relative to the projection (within means ±2% of guidance, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Answer

Canon needed to earn JPY (252,000 − 45,975) million over the remaining three quarters to meet its December year-end projection. The first input is full-year guidance; the second is net income attributable to Canon Inc. for the quarter ended March 31, 2022. That quarterly figure already excludes income attributable to noncontrolling interests. [1, PDF p1 §1](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=1&search=CONSOLIDATED%20RESULTS%20FOR%20THE%20FIRST%20QUARTER) [2, PDF p7 §1](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=7&search=CANON%20INC.%20AND%20SUBSIDIARIES%20CONSOLIDATED%202.)

## Outlook

Base case as of 2022-04-27T12:00:00Z: within. Apply the question’s ±2% tolerance to full-year guidance of JPY 252,000 million, not to the amount remaining: subtract the tolerance amount from guidance for the lower bound and add it for the upper bound, including both endpoints. The main driver is Canon’s ability to turn firm demand into shipments. Substitute parts and new suppliers were already supporting production in the first quarter. Canon incorporated further supply gains and exchange rates of ¥120 per US dollar and ¥130 per euro into its raised forecast. Those assumptions support meeting guidance, not exceeding it. [1, PDF p1 §1](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=1&search=CONSOLIDATED%20RESULTS%20FOR%20THE%20FIRST%20QUARTER) [3, PDF p2 §2](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=2&search=production%20delays%20%7C%20due%20to%20the) [4, PDF p4 §3](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=4&search=devices%20including%20laptops%20and%20tablets.%20With)

## What would change the view

The strongest alternative is lower. First-quarter attributable income grew 3.4% year over year against 17.4% projected for the year, so meeting guidance required faster growth after March. Rising parts and freight costs had already cut gross margin by 0.7 percentage points to 44.9%. I would switch to lower if Canon’s next earnings update said chip and logistics constraints would persist through the second half without the expected easing: firm orders would not protect earnings if Canon could not ship the products. The release establishes that management expected relief, not that relief occurred or that the eventual annual result fell within the band. [1, PDF p1 §1](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=1&search=CONSOLIDATED%20RESULTS%20FOR%20THE%20FIRST%20QUARTER) [3, PDF p2 §2](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=2&search=production%20delays%20%7C%20due%20to%20the) [5, PDF p4 §2](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=4&search=and%20region.%20In%20the%20markets%20in)

## Sources

1. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p1 §1](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=1&search=CONSOLIDATED%20RESULTS%20FOR%20THE%20FIRST%20QUARTER), available by 2022-04-26.
2. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p7 §1](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=7&search=CANON%20INC.%20AND%20SUBSIDIARIES%20CONSOLIDATED%202.), available by 2022-04-26.
3. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p2 §2](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=2&search=production%20delays%20%7C%20due%20to%20the), available by 2022-04-26.
4. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p4 §3](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=4&search=devices%20including%20laptops%20and%20tablets.%20With), available by 2022-04-26.
5. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p4 §2](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=4&search=and%20region.%20In%20the%20markets%20in), available by 2022-04-26.
