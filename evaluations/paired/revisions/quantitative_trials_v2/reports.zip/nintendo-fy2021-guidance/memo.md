# Investment research memo

As of 2020-05-08T12:00:00Z

Forecast direction: higher

**Research question**
At Nintendo’s FY2020 results, what profit attributable to owners of parent did it guide for the year ending March 2021? Compare it with the just-reported year, discuss the risk to the supply of components, and forecast the full-year actual relative to guidance (within means ±2% of the guide, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Evidence

Nintendo’s Switch software plan leaves room for upside, but the headline unit comparison exaggerates the planned decline. In units of ten thousand, Nintendo forecast 14,000 against 16,872 sold in the reported year. Actual sales included games bundled with hardware; forecast sales excluded them. Without the bundled volume or the incremental profit per game, these figures cannot establish how much additional software demand would take parent-attributable profit above the band. [1, PDF p14 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=14&search=%284%29%20Consolidated%20sales%20units%2C%20number%20of)

## Outlook

Base case at 2020-05-08T12:00:00Z: higher, with low confidence. Multiplying JPY 200,000 million by unity minus and unity plus the question’s percentage tolerance (±2%) gives an inclusive band of JPY 196,000 to 204,000 million. I expect profit above the upper bound chiefly because existing Switch owners can keep buying games without buying another console. Animal Crossing: New Horizons sold 11.77 million units in its March launch month, and older titles were still selling well. The launch sales belong to the reported year; the forecast depends on demand persisting into the new year. [2, PDF p2 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=2&search=Consolidated%20Financial%20Forecast%20for%20the%20Fiscal) [3, PDF p3 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=3&search=Description%20of%20Operating%20Results%201.%20Operating)

## What would change the view

The strongest alternative is below the band if component shortages prevent Nintendo from making up lost Switch shipments by fiscal year-end. Production and shipping delays were easing, and guidance already assumed supply would meet full-year demand, so temporary stockouts alone would not change the call. I would switch to lower if Nintendo cut its full-year Switch hardware plan because it could not procure parts in time: fewer consoles built and shipped would cost hardware sales and leave fewer new owners buying software. [4, PDF p3 §4](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=3&search=Net%20cash%20provided%20by%20%28used%20in%29) [5, PDF p4 §3](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=4&search=forecasting%20are%20105%20yen%20per%20US) [1, PDF p14 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=14&search=%284%29%20Consolidated%20sales%20units%2C%20number%20of)

## Checked calculations

- C3. Inclusive lower guidance bound (JPY million) — 200,000 − |200,000| × 2% (question tolerance) = 196,000.00 [2, PDF p2 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=2&search=Consolidated%20Financial%20Forecast%20for%20the%20Fiscal)
- C4. Inclusive upper guidance bound (JPY million) — 200,000 + |200,000| × 2% (question tolerance) = 204,000.00 [2, PDF p2 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=2&search=Consolidated%20Financial%20Forecast%20for%20the%20Fiscal)

## Sources

1. [Nintendo consolidated financial statements for year ended March 2020, PDF p14 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=14&search=%284%29%20Consolidated%20sales%20units%2C%20number%20of), available by 2020-05-07.
2. [Nintendo consolidated financial statements for year ended March 2020, PDF p2 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=2&search=Consolidated%20Financial%20Forecast%20for%20the%20Fiscal), available by 2020-05-07.
3. [Nintendo consolidated financial statements for year ended March 2020, PDF p3 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=3&search=Description%20of%20Operating%20Results%201.%20Operating), available by 2020-05-07.
4. [Nintendo consolidated financial statements for year ended March 2020, PDF p3 §4](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=3&search=Net%20cash%20provided%20by%20%28used%20in%29), available by 2020-05-07.
5. [Nintendo consolidated financial statements for year ended March 2020, PDF p4 §3](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=4&search=forecasting%20are%20105%20yen%20per%20US), available by 2020-05-07.
