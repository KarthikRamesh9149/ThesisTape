# Financial research memo

As of 2021-11-05T12:00:00Z

After the tribunal remittal in JD Sports’ Footasylum acquisition, which markets and constraints did the CMA reconsider, and did its disposal requirement change? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Findings

The Tribunal left the CMA’s overall analytical approach intact but required it to revisit two pandemic-sensitive judgments: how Footasylum would have fared without the merger, and how strongly Nike’s and adidas’s own direct-to-consumer (DTC) channels would constrain the merged retailer (PDF p1). [CMA remittal final report summary on JD Sports and Footasylum, PDF p1 §1](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=1&search=Summary%20Overview%20of%20our%20findings%201.)

The CMA again found a substantial lessening of competition in two UK retail markets: sports-inspired casual footwear and sports-inspired casual apparel. Each included both in-store and online sales. The disposal requirement did not change: JD Sports still had to sell all of Footasylum to a CMA-approved buyer (PDF p11). [CMA remittal final report summary on JD Sports and Footasylum, PDF p11 §1](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=11&search=Entry%20or%20expansion%2052.%20%7C%20For)

## Interpretation

What changed was whose shoppers were most at risk. Footasylum had become a weaker rival to JD Sports, but JD Sports remained an important alternative for Footasylum shoppers. Under common ownership, a sale lost by Footasylum to JD Sports would stay within the group. That reduced the incentive to improve Footasylum’s price, quality, range or service; the finding did not require equally large effects on JD Sports shoppers (PDF pp2, 11). [CMA remittal final report summary on JD Sports and Footasylum, PDF p11 §1](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=11&search=Entry%20or%20expansion%2052.%20%7C%20For) [CMA remittal final report summary on JD Sports and Footasylum, PDF p2 §1](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=2&search=5.%20%7C%20In%20December%202020%20the)

## Alternative and revision signal

A possible alternative was that Nike’s DTC growth could replace some of the lost rivalry. The limitation is that growth alone does not show whom Nike constrains: in online footwear, Nike was a stronger constraint on JD Sports than Footasylum was, yet Footasylum shoppers ranked Nike behind JD Sports. A repeat survey showing those shoppers choosing Nike over JD Sports as their best alternative would weaken the footwear rationale; it would not by itself settle the apparel question (PDF p8). [CMA remittal final report summary on JD Sports and Footasylum, PDF p8 §1](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=8&search=Parties%2C%20the%20sales%20performance%20of%20the)
