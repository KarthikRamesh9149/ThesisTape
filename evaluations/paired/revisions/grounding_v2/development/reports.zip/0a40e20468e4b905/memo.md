# Financial research memo

As of 2021-01-29T12:00:00Z

How did the first BEA estimate for Q4 2020 distinguish real GDP growth from the domestic purchases price index? Explain how goods exports affected the growth reading. In the second estimate, will real GDP growth be revised lower, remain within, or go higher? Within means unchanged at the published one-decimal precision. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Forecast direction: within

## Findings

In its Q4 2020 advance estimate, BEA reported that real GDP rose: the U.S. economy produced more after adjusting for price changes. The 1.7 percent increase in the domestic purchases price index measured a different change: prices paid for goods and services purchased in the United States. The supplied excerpt does not state the annualized real GDP growth rate. Its 6.0 percent annual rate is for current-dollar GDP, not real GDP. (PDF pp. 2, 7) [BEA GDP advance estimate, Q4 2020, PDF p2 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020) [BEA GDP advance estimate, Q4 2020, PDF p7 §2](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=7&search=adjusted%20values%20are%20calculated%20from%20the)

Goods accounted for most of the export increase, led by industrial supplies and materials. Stronger foreign purchases of U.S. output supported real GDP growth, all else equal. Those exports were not domestic purchases, so the export gain was not part of the 1.7 percent price reading. (PDF p. 2) [BEA GDP advance estimate, Q4 2020, PDF p2 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020)

## Base case

Base case for the February 25 second estimate: within, meaning Q4 real GDP growth remains unchanged at the published one-decimal annualized rate. The key assumption is that updated goods-export data broadly confirm the advance estimate. The export gain was already counted; it is not, by itself, evidence for an upward revision. This is a low-confidence call because the supplied passages give no newer goods-export reading. (PDF pp. 2, 5) [BEA GDP advance estimate, Q4 2020, PDF p2 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020) [BEA GDP advance estimate, Q4 2020, PDF p5 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=5&search=Release%20Dates%20in%202021%202020%20Q4)

## Alternative and revision signal

Alternative: lower. I would change the call if updated Q4 trade data showed a smaller increase in real industrial-supplies exports than BEA initially incorporated, large enough, without offsets elsewhere, to lower annualized real GDP growth at one-decimal precision. The signal is weaker export volume, not merely lower export prices. (PDF pp. 2, 7) [BEA GDP advance estimate, Q4 2020, PDF p2 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020) [BEA GDP advance estimate, Q4 2020, PDF p7 §2](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=7&search=adjusted%20values%20are%20calculated%20from%20the)
