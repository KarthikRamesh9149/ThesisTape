# Financial research memo

As of 2021-01-29T12:00:00Z

How did the first BEA estimate for Q4 2020 distinguish real GDP growth from the domestic purchases price index? Explain how goods exports affected the growth reading. In the second estimate, will real GDP growth be revised lower, remain within, or go higher? Within means unchanged at the published one-decimal precision. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Forecast direction: within

## Findings

In its January 28 advance estimate, BEA reported that real GDP grew at a 4.0 percent annual rate from Q3 to Q4 2020 (PDF p. 1). Separately, the gross domestic purchases price index rose 1.7 percent in Q4 (PDF p. 2). The first measures growth in the volume of U.S. production; the second measures price changes for what U.S. residents buy, including imports. The 4.0 percent figure is already adjusted for price changes. [BEA GDP advance estimate, Q4 2020, PDF p1 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [BEA GDP advance estimate, Q4 2020, PDF p2 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020)

Goods drove the increase in exports, led by industrial supplies and materials (PDF p. 2). That export increase supported real GDP because exports count as U.S. production. Imports also increased and are subtracted in the GDP calculation, so the export boost alone does not establish the net contribution of trade (PDF p. 1). [BEA GDP advance estimate, Q4 2020, PDF p2 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020) [BEA GDP advance estimate, Q4 2020, PDF p1 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.)

## Base case

Base case as of January 29: within. I expect the February 25 second estimate to still print 4.0 percent annualized at one-decimal precision. The main assumption is that updated goods trade data will not change the net trade contribution enough to move the headline. The advance release identifies goods exports as a source of growth, but it gives no clear signal that their contribution was over- or understated. Confidence is low because the advance estimate relies on incomplete or revisable data (PDF pp. 1–2). [BEA GDP advance estimate, Q4 2020, PDF p1 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [BEA GDP advance estimate, Q4 2020, PDF p2 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020)

## Alternative and revision signal

Alternative: lower. I would switch if updated Q4 goods trade data showed weaker real exports of industrial supplies and materials than BEA assumed, and the shortfall was large enough to pull the published rate below 4.0 percent without an offset from lower imports or stronger spending. The observable check is the updated trade data against BEA’s advance-estimate source assumptions (PDF pp. 1, 2, 4). [BEA GDP advance estimate, Q4 2020, PDF p4 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=4&search=Source%20Data%20for%20the%20Advance%20Estimate) [BEA GDP advance estimate, Q4 2020, PDF p2 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020) [BEA GDP advance estimate, Q4 2020, PDF p1 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.)
