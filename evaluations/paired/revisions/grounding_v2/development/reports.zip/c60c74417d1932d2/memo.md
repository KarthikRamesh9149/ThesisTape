# Financial research memo

As of 2021-01-29T12:00:00Z

How did the first BEA estimate for Q4 2020 distinguish real GDP growth from the domestic purchases price index? Explain how goods exports affected the growth reading. In the second estimate, will real GDP growth be revised lower, remain within, or go higher? Within means unchanged at the published one-decimal precision. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Forecast direction: within

## Findings

BEA’s advance estimate showed that inflation-adjusted U.S. output grew at a 4.0 percent annual rate in Q4 2020, down from 33.4 percent in Q3 (PDF p. 1). The gross domestic purchases price index measures changes in prices paid for domestic purchases, not growth in U.S. output. It rose 1.7 percent in Q4, compared with 3.3 percent in Q3 (PDF p. 2). [BEA GDP advance estimate, Q4 2020, PDF p1 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [BEA GDP advance estimate, Q4 2020, PDF p2 §2](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=The%20price%20index%20for%20gross%20domestic)

Rising exports lifted the advance real GDP reading. Goods accounted for most of the export increase, led by industrial supplies and materials. Imports also rose, offsetting some of the export boost because imports are subtracted in calculating GDP (PDF pp. 1–2). [BEA GDP advance estimate, Q4 2020, PDF p1 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [BEA GDP advance estimate, Q4 2020, PDF p2 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020)

## Base case

Base case as of January 29, 2021: within. I expect BEA’s February 25 second estimate to leave Q4 2020 real GDP growth at 4.0 percent annualized to one decimal place. The main revision driver I would watch is real net exports: more complete source data can change the estimated contributions of both exports and imports. Goods exports lifted the advance estimate, but that does not show whether BEA initially estimated them too high or too low (PDF pp. 1–2). [BEA GDP advance estimate, Q4 2020, PDF p1 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [BEA GDP advance estimate, Q4 2020, PDF p2 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020)

## Alternative and revision signal

Alternative: higher. If updated December goods-trade data and the price data needed to adjust them become available before February 25, compare real goods exports and imports with BEA’s advance-estimate source assumptions. I would switch to higher if stronger real goods exports raised the net export contribution enough for growth to round above 4.0 percent annualized after accounting for import revisions and any other known offsets. The advance release points to BEA’s source assumptions but does not establish when the updated inputs will be available (PDF pp. 1–2). [BEA GDP advance estimate, Q4 2020, PDF p2 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=2&search=COVID-19%20Impact%20on%20the%20Fourth-Quarter%202020) [BEA GDP advance estimate, Q4 2020, PDF p1 §1](https://www.bea.gov/sites/default/files/2021-01/gdp4q20_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.)
