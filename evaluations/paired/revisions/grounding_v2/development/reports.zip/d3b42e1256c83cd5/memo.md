# Financial research memo

As of 2022-03-22T12:00:00Z

How should a holder read Berkshire’s cash offer for Alleghany, its premiums to the prior month and 52-week high and the possibility of another bid? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Findings

Berkshire agreed to pay $848.02 per Alleghany share in cash, valuing Alleghany’s equity at approximately $11.6 billion (PDF p. 1). [Berkshire Hathaway to acquire Alleghany, PDF p1 §1](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=Berkshire%20Hathaway%20to%20Acquire%20Alleghany%20Corporation)

The release reports that the $848.02 cash price is 29% above Alleghany’s average stock price over the last 30 days and 16% above its 52-week high closing price. These are reported premiums, not new calculations: the release identifies both benchmarks but does not give their dollar values in the cited passage (PDF p. 1). [Berkshire Hathaway to acquire Alleghany, PDF p1 §1](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=Berkshire%20Hathaway%20to%20Acquire%20Alleghany%20Corporation)

## Interpretation

A holder should read the offer as a fixed cash payout if the deal closes, not as a guaranteed return. The 16% premium shows that the offer clears even the highest closing price of the prior 52 weeks, rather than merely looking attractive against the recent average. But both comparisons are backward-looking: neither establishes what Alleghany is worth on its own, and the cash payout still depends on required stockholder and regulatory approvals and other closing conditions (PDF pp. 1–2). [Berkshire Hathaway to acquire Alleghany, PDF p1 §1](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=Berkshire%20Hathaway%20to%20Acquire%20Alleghany%20Corporation) [Berkshire Hathaway to acquire Alleghany, PDF p2 §2](https://www.berkshirehathaway.com/news/mar2122.pdf#page=2&search=forward-looking%20statements%20to%20differ%20include%3A%20%28i%29)

## Alternative and revision signal

A rival could offer more cash per share during the 25-day go-shop. Alleghany can terminate the Berkshire agreement to accept a superior proposal during that period, subject to the merger agreement’s terms and conditions. A public announcement that the board has determined a rival offer is superior would be a reason to revise the analysis. Silence alone is not evidence that no rival has come forward: Alleghany says it does not intend to report developments unless the board makes a determination requiring disclosure (PDF pp. 1–2). [Berkshire Hathaway to acquire Alleghany, PDF p1 §3](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=alternative%20acquisition%20proposals%20during%20a%2025-day) [Berkshire Hathaway to acquire Alleghany, PDF p2 §1](https://www.berkshirehathaway.com/news/mar2122.pdf#page=2&search=the%20process%20unless%20and%20until%20Alleghany%E2%80%99s)
