# Financial research memo

As of 2022-03-22T12:00:00Z

How should a holder read Berkshire’s cash offer for Alleghany, its premiums to the prior month and 52-week high and the possibility of another bid? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Findings

On March 21, 2022, Berkshire Hathaway and Alleghany announced a definitive agreement for Berkshire to buy all outstanding Alleghany shares for $848.02 per share in cash, representing approximately $11.6 billion in equity value (PDF p. 1). [Berkshire Hathaway to acquire Alleghany, PDF p1 §1](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=Berkshire%20Hathaway%20to%20Acquire%20Alleghany%20Corporation)

The release reports a 29% premium to Alleghany’s average stock price over the prior 30 days and a 16% premium to its 52-week high closing price. The offer was above even the highest close in that longer window, but the two percentages measure the same offer against different historical benchmarks (PDF p. 1). [Berkshire Hathaway to acquire Alleghany, PDF p1 §1](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=Berkshire%20Hathaway%20to%20Acquire%20Alleghany%20Corporation)

## Interpretation

For a holder, cash fixes the payout at $848.02 per share if the deal closes on the agreed terms; a move in Berkshire’s stock price does not change that amount. But a fixed payout is not a guaranteed payout: required stockholder and regulatory approvals and other closing conditions remain. The historical premiums show how much Berkshire offered over past prices, not what a holder is certain to receive (PDF pp. 1–2). [Berkshire Hathaway to acquire Alleghany, PDF p1 §1](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=Berkshire%20Hathaway%20to%20Acquire%20Alleghany%20Corporation) [Berkshire Hathaway to acquire Alleghany, PDF p2 §2](https://www.berkshirehathaway.com/news/mar2122.pdf#page=2&search=forward-looking%20statements%20to%20differ%20include%3A%20%28i%29)

## Alternative and revision signal

A competing buyer could offer better terms. During the 25-day go-shop period, Alleghany can terminate the Berkshire merger agreement to accept a superior proposal, subject to the agreement’s terms. The go-shop gives holders a chance at a better deal, but there is no assurance it will produce a superior proposal. A public announcement of a superior proposal would be a reason to reassess the expected payout (PDF p. 1, §3). [Berkshire Hathaway to acquire Alleghany, PDF p1 §3](https://www.berkshirehathaway.com/news/mar2122.pdf#page=1&search=alternative%20acquisition%20proposals%20during%20a%2025-day)
