# Financial research memo

As of 2020-05-03T12:00:00Z

Bridge Berkshire’s first-quarter 2020 operating earnings to its shareholder net loss. What makes it risky to read the net loss as a cash outflow? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Findings

Berkshire’s first-quarter 2020 bridge was, after tax and in USD millions: 5,871 in operating earnings, plus (54,517) in investment losses and (1,100) in derivative losses. The two losses totaled (55,617); adding them to operating earnings produced a (49,746) net loss attributable to Berkshire shareholders (PDF p. 1). [Berkshire Hathaway first-quarter 2020 earnings, PDF p1 §1](https://www.berkshirehathaway.com/news/may0220.pdf#page=1&search=BERKSHIRE%20HATHAWAY%20INC.%20NEWS%20RELEASE%20FOR)

## Interpretation

The net loss is not a measure of cash outflow. GAAP required Berkshire to recognize changes in unrealized gains and losses on its equity holdings in earnings. That revaluation accounted for approximately $55.5 billion of first-quarter 2020 investment losses: it reduced reported earnings without itself requiring a sale or a cash payment (PDF p. 1). The implication is that the headline loss mainly reflects a decline in the value of the equity holdings, not a comparable cash drain from running the businesses. [Berkshire Hathaway first-quarter 2020 earnings, PDF p1 §2](https://www.berkshirehathaway.com/news/may0220.pdf#page=1&search=Net%20earnings%20%28loss%29%20per%20average%20equivalent)

## Alternative and revision signal

A better starting point for assessing the businesses is Berkshire’s non-GAAP operating earnings, which exclude investment and derivative gains and losses (PDF p. 2). But operating earnings are not cash flow either. The release notes realized gains on investment sales without showing how much cash those sales generated (PDF p. 1). The check is the first-quarter 10-Q cash-flow statement: cash used in operating activities would indicate a separate operating cash drain, even though the unrealized equity loss itself did not consume cash. [Berkshire Hathaway first-quarter 2020 earnings, PDF p2 §1](https://www.berkshirehathaway.com/news/may0220.pdf#page=2&search=An%20analysis%20of%20Berkshire%E2%80%99s%20operating%20earnings) [Berkshire Hathaway first-quarter 2020 earnings, PDF p1 §2](https://www.berkshirehathaway.com/news/may0220.pdf#page=1&search=Net%20earnings%20%28loss%29%20per%20average%20equivalent) [Berkshire Hathaway first-quarter 2020 earnings, PDF p1 §1](https://www.berkshirehathaway.com/news/may0220.pdf#page=1&search=BERKSHIRE%20HATHAWAY%20INC.%20NEWS%20RELEASE%20FOR)

## Checked calculations

- C1. Q1 2020 combined after-tax investment and derivative loss (USD millions) — (54,517) + (1,100) = -55,617 [P1, PDF p1 §1](https://www.berkshirehathaway.com/news/may0220.pdf#page=1&search=BERKSHIRE%20HATHAWAY%20INC.%20NEWS%20RELEASE%20FOR)
- C2. Q1 2020 after-tax net loss attributable to Berkshire shareholders (USD millions) — 5,871 + C1 = -49,746 [P1, PDF p1 §1](https://www.berkshirehathaway.com/news/may0220.pdf#page=1&search=BERKSHIRE%20HATHAWAY%20INC.%20NEWS%20RELEASE%20FOR)
