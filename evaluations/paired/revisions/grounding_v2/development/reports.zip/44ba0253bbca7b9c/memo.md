# Financial research memo

As of 2021-11-05T12:00:00Z

After the tribunal remittal in JD Sports’ Footasylum acquisition, which markets and constraints did the CMA reconsider, and did its disposal requirement change? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

Partial coverage.

## Findings

On remittal, the CMA again found that JD Sports’ acquisition of Footasylum had resulted, or could be expected to result, in a substantial lessening of competition. It reconsidered two UK retail markets: sports-inspired casual footwear and sports-inspired casual apparel, each covering in-store and online sales (PDF pp. 1–2). [CMA remittal final report summary on JD Sports and Footasylum, PDF p1 §1](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=1&search=Summary%20Overview%20of%20our%20findings%201.) [CMA remittal final report summary on JD Sports and Footasylum, PDF p2 §1](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=2&search=5.%20%7C%20In%20December%202020%20the)

The CMA reassessed how COVID-19 affected Footasylum’s ability to compete had the merger not happened and how strongly Nike’s and adidas’s own direct-to-consumer retail offers would constrain the merged business (PDF pp. 1–2). [CMA remittal final report summary on JD Sports and Footasylum, PDF p1 §1](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=1&search=Summary%20Overview%20of%20our%20findings%201.) [CMA remittal final report summary on JD Sports and Footasylum, PDF p2 §1](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=2&search=5.%20%7C%20In%20December%202020%20the)

The excerpts establish that the competition finding was renewed, but not whether the disposal requirement changed. PDF p. 1 states the original and remittal competition findings, not the operative remedy terms. Comparing the disposal requirements would require the remedy provisions from both decisions. [CMA remittal final report summary on JD Sports and Footasylum, PDF p1 §1](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=1&search=Summary%20Overview%20of%20our%20findings%201.)

## Interpretation

The May 2021 online survey showed an asymmetric competitive constraint. If they could no longer shop at Footasylum, over 40% of its footwear customers and half of its apparel customers said they would go to JD Sports. In the reverse direction, the figures were 9% for footwear and 8% for apparel. That suggests JD Sports constrained Footasylum more strongly online than Footasylum constrained JD Sports: under common ownership, sales that Footasylum loses to JD Sports stay within the group, which can weaken the incentive to maintain Footasylum’s offer (PDF pp. 2, 6). [CMA remittal final report summary on JD Sports and Footasylum, PDF p6 §1](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=6&search=found%20some%20differences.%20For%20example%2C%20Footasylum) [CMA remittal final report summary on JD Sports and Footasylum, PDF p2 §1](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=2&search=5.%20%7C%20In%20December%202020%20the)

## Alternative and revision signal

The survey measured stated choices, not observed switching, and its results need not carry over to stores. The CMA said in-store diversion could be higher. Footasylum could therefore be a stronger constraint on JD Sports in stores than the online responses suggest. An observable signal would be a larger share of displaced JD Sports shoppers actually buying at Footasylum after a JD Sports store closure than the reverse-direction online responses suggest (PDF p. 6). [CMA remittal final report summary on JD Sports and Footasylum, PDF p6 §1](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=6&search=found%20some%20differences.%20For%20example%2C%20Footasylum)
