# Financial research memo

As of 2021-11-05T12:00:00Z

After the tribunal remittal in JD Sports’ Footasylum acquisition, which markets and constraints did the CMA reconsider, and did its disposal requirement change? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Findings

The CMA reconsidered two UK retail markets: sports-inspired casual footwear and sports-inspired casual apparel, each covering in-store and online sales. Its 4 November 2021 remittal report again found a substantial lessening of competition in both markets (PDF pp. 1–2). [CMA remittal final report summary on JD Sports and Footasylum, PDF p2 §1](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=2&search=5.%20%7C%20In%20December%202020%20the) [CMA remittal final report summary on JD Sports and Footasylum, PDF p1 §1](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=1&search=Summary%20Overview%20of%20our%20findings%201.)

The remittal focused on two COVID-19 questions: how competitive Footasylum would have been without the merger, and how strongly Nike’s and adidas’s own direct-to-consumer retail offers would constrain the merged firm. The CMA separately examined whether the brands might reduce or stop supplying Footasylum, which bears on its ability to compete independently (PDF pp. 1, 4). [CMA remittal final report summary on JD Sports and Footasylum, PDF p1 §1](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=1&search=Summary%20Overview%20of%20our%20findings%201.) [CMA remittal final report summary on JD Sports and Footasylum, PDF p4 §1](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=4&search=14.%20%7C%20We%20have%20found%20that)

After the remittal, the CMA found a substantial lessening of competition in two UK retail markets: sports-inspired casual footwear and sports-inspired casual apparel, both sold in stores and online (PDF p. 1, §1). The finding therefore covered both sales channels, not just physical stores. The cited passage does not identify the specific competitive constraints the CMA reconsidered or say whether the disposal requirement changed; an unchanged competition finding does not establish that the remedy was unchanged. [CMA remittal final report summary on JD Sports and Footasylum, PDF p1 §1](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=1&search=Summary%20Overview%20of%20our%20findings%201.)

## Interpretation

The implication is that the merger could weaken JD Sports’ incentive to maintain its range or service: if shoppers who would otherwise switch to Footasylum stay within the merged group, JD Sports loses fewer sales when its offer worsens (PDF p. 2). [CMA remittal final report summary on JD Sports and Footasylum, PDF p2 §1](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=2&search=5.%20%7C%20In%20December%202020%20the)

## Alternative and revision signal

A limitation is that most of the supplier evidence was confidential. If Nike or adidas would have materially cut Footasylum’s access to key products even without the merger, the merger may have removed less competitive pressure than an analyst assuming stable supply would infer. Dated allocation notices showing sustained cuts to product range or volume that were planned independently of the merger would be a reason to revise that interpretation (PDF p. 4). [CMA remittal final report summary on JD Sports and Footasylum, PDF p4 §1](https://assets.publishing.service.gov.uk/media/6182ac988fa8f52978e14cc8/JD_Sports_Footasylum_Summary.pdf#page=4&search=14.%20%7C%20We%20have%20found%20that)
