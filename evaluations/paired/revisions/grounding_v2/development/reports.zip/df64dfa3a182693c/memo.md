# Financial research memo

As of 2019-04-27T12:00:00Z

How did the first BEA estimate for Q1 2019 distinguish real GDP growth from the domestic purchases price index? Explain how personal consumption expenditures affected the growth reading. In the second estimate, will gross domestic purchases price index growth be revised lower, remain within, or go higher? Within means unchanged at the published one-decimal precision. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Partial coverage.

Forecast direction: within

## Findings

In its April 26 advance estimate, BEA reported that real GDP—U.S. output adjusted for price changes—grew 3.2% annualized in Q1 2019, up from 2.2% in Q4 2018 (3.2 − 2.2 = +1.0 annualized percentage point). The gross domestic purchases price index instead measures prices paid for domestic purchases. It rose 0.8% annualized, down from 1.7% (0.8 − 1.7 = −0.9 annualized percentage point). Output growth accelerated while purchase-price inflation slowed; these are quarter-to-quarter comparisons, not revisions (PDF pp. 1–2). [BEA GDP advance estimate, Q1 2019, PDF p1 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [BEA GDP advance estimate, Q1 2019, PDF p2 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=2&search=The%20acceleration%20in%20real%20GDP%20growth)

Real personal consumption expenditures (PCE) contributed positively to Q1 GDP growth, but grew more slowly than in Q4, tempering the acceleration. Separately, PCE price growth slowed to 0.6% annualized from 1.5% (PDF pp. 1–2). [BEA GDP advance estimate, Q1 2019, PDF p1 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [BEA GDP advance estimate, Q1 2019, PDF p2 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=2&search=The%20acceleration%20in%20real%20GDP%20growth)

## Base case

Base case for BEA’s May 30 second estimate: within, meaning Q1 gross domestic purchases price growth still rounds to 0.8% annualized. Confidence is low. The advance estimate already reflects slower consumer-price growth. More complete source data could revise the consumer-price component and move the broader index, but the available evidence gives no directional signal and no reason to expect a change at one-decimal precision (PDF pp. 1–2). [BEA GDP advance estimate, Q1 2019, PDF p1 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [BEA GDP advance estimate, Q1 2019, PDF p2 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=2&search=The%20acceleration%20in%20real%20GDP%20growth)

## Alternative and revision signal

Alternative: lower. Before May 30, watch for updated March consumer-price inputs that imply Q1 PCE price growth below the advance estimate’s 0.6% annualized. Switch to lower only if the implied downward revision, after accounting for other purchase prices, is large enough for the broader index to round below 0.8% (PDF pp. 1–2). [BEA GDP advance estimate, Q1 2019, PDF p1 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [BEA GDP advance estimate, Q1 2019, PDF p2 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=2&search=The%20acceleration%20in%20real%20GDP%20growth)

## Checked calculations

- C1. Real GDP growth acceleration, Q1 2019 versus Q4 2018 (annualized percentage points) — 3.2 − 2.2 = 1.0 [P1, PDF p1 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.)
- C2. Gross domestic purchases price index growth change, Q1 2019 versus Q4 2018 (annualized percentage points) — 0.8 − 1.7 = -0.9 [P2, PDF p2 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=2&search=The%20acceleration%20in%20real%20GDP%20growth)
