# Financial research memo

As of 2019-04-27T12:00:00Z

How did the first BEA estimate for Q1 2019 distinguish real GDP growth from the domestic purchases price index? Explain how personal consumption expenditures affected the growth reading. In the second estimate, will gross domestic purchases price index growth be revised lower, remain within, or go higher? Within means unchanged at the published one-decimal precision. State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Forecast direction: within

## Findings

BEA’s advance estimate showed that real GDP—the volume of U.S. production—grew at a 3.2% annual rate in Q1 2019, up from 2.2% in Q4 2018 (3.2 − 2.2 = 1.0 annualized percentage point). The gross domestic purchases price index, which measures prices paid by U.S. residents rather than output, rose at a 0.8% annual rate, down from 1.7% (0.8 − 1.7 = −0.9 annualized percentage points). Output growth accelerated while purchases-price inflation slowed (PDF pp. 1–2). [BEA GDP advance estimate, Q1 2019, PDF p1 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [BEA GDP advance estimate, Q1 2019, PDF p2 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=2&search=The%20acceleration%20in%20real%20GDP%20growth)

Real personal consumption expenditures (PCE) added to Q1 GDP growth, but grew more slowly than in Q4, partly offsetting the acceleration in GDP. Separately, headline PCE price growth slowed from 1.5% in Q4 to 0.6% in Q1, and core PCE price growth slowed from 1.8% to 1.3%, both at annual rates (PDF pp. 1–2, 5). [BEA GDP advance estimate, Q1 2019, PDF p1 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [BEA GDP advance estimate, Q1 2019, PDF p2 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=2&search=The%20acceleration%20in%20real%20GDP%20growth) [BEA GDP advance estimate, Q1 2019, PDF p5 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=5&search=to%20further%20revision%20by%20the%20source)

## Base case

Base case: within. I expect the May 30, 2019 second estimate to leave Q1 gross domestic purchases price growth at 0.8% annualized at published one-decimal precision. Slower consumer-price growth helps explain the low advance reading because consumer purchases are part of domestic purchases. But that slowdown is a comparison with Q4, not evidence of a downward revision to Q1. The main driver of the call is the absence of a directional signal from the source data: more complete inputs can change the unrounded estimate without changing the published rate (PDF pp. 1–2, 5). [BEA GDP advance estimate, Q1 2019, PDF p1 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [BEA GDP advance estimate, Q1 2019, PDF p2 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=2&search=The%20acceleration%20in%20real%20GDP%20growth) [BEA GDP advance estimate, Q1 2019, PDF p5 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=5&search=to%20further%20revision%20by%20the%20source)

## Alternative and revision signal

Alternative: higher. Before May 30, watch for published upward revisions to the March source price series used to estimate PCE prices. I would switch to higher if those revisions, after accounting for their weight in domestic purchases and any offsets from other purchases prices, implied a Q1 annualized rate that rounds above 0.8% (PDF pp. 1–2, 5). [BEA GDP advance estimate, Q1 2019, PDF p1 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.) [BEA GDP advance estimate, Q1 2019, PDF p2 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=2&search=The%20acceleration%20in%20real%20GDP%20growth) [BEA GDP advance estimate, Q1 2019, PDF p5 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=5&search=to%20further%20revision%20by%20the%20source)

## Checked calculations

- C1. Real GDP growth acceleration, Q1 2019 versus Q4 2018 (annualized percentage points) — 3.2 − 2.2 = 1.0 [P1, PDF p1 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=1&search=EMBARGOED%20UNTIL%20RELEASE%20AT%208%3A30%20A.M.)
- C2. Gross domestic purchases price index growth change, Q1 2019 versus Q4 2018 (annualized percentage points) — 0.8 − 1.7 = -0.9 [P2, PDF p2 §1](https://www.bea.gov/sites/default/files/2019-04/gdp1q19_adv.pdf#page=2&search=The%20acceleration%20in%20real%20GDP%20growth)
