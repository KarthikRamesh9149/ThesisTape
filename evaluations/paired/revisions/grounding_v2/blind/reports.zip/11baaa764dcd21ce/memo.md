# Financial research memo

As of 2021-02-03T12:00:00Z

For viagogo’s completed purchase of StubHub, identify the UK market harm, the required disposal and the buyer approval condition. Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Findings

The CMA found that viagogo’s completed purchase of StubHub resulted, or may be expected to result, in a substantial lessening of competition in uncapped secondary ticketing platform services for resale of tickets to UK events (PDF p. 13). [CMA final report summary on viagogo and StubHub, PDF p13 §1](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=13&search=Countervailing%20buyer%20power%2073.%20%7C%20After)

The CMA required the merged entity to sell StubHub International—the StubHub business outside North America. The CMA must approve both the purchaser’s identity and the transaction terms (PDF p. 14). [CMA final report summary on viagogo and StubHub, PDF p14 §1](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=14&search=suitable%20purchaser%20could%20be%20found.%20We)

## Interpretation

The merger removed a close rival for both buyers and resellers. With too few alternatives to switch to, users would have less leverage to resist higher fees or worse terms. The disposal is intended to restore that competitive pressure; the decision does not establish that fees actually rose (PDF pp. 7, 13–14). [CMA final report summary on viagogo and StubHub, PDF p7 §2](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=7&search=Coronavirus%20%28COVID-19%29%20pandemic%29%2C%20buyers%20using%20the) [CMA final report summary on viagogo and StubHub, PDF p13 §1](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=13&search=Countervailing%20buyer%20power%2073.%20%7C%20After) [CMA final report summary on viagogo and StubHub, PDF p14 §1](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=14&search=suitable%20purchaser%20could%20be%20found.%20We)

## Alternative and revision signal

The disposal requirement is not evidence that an independent rival was already back in the market. If the CMA cannot obtain suitable undertakings in time, it says it will issue an order instead. An order would signal that the undertakings route did not deliver in time; confirmation that the sale closed with a CMA-approved buyer on approved terms would be the signal to treat the disposal as implemented (PDF p. 14). [CMA final report summary on viagogo and StubHub, PDF p14 §1](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=14&search=suitable%20purchaser%20could%20be%20found.%20We)
