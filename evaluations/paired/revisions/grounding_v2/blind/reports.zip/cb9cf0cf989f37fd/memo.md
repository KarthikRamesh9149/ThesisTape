# Financial research memo

As of 2021-02-03T12:00:00Z

For viagogo’s completed purchase of StubHub, identify the UK market harm, the required disposal and the buyer approval condition. Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Findings

The CMA found that viagogo’s completed purchase of StubHub had resulted, or could be expected to result, in a substantial lessening of competition in uncapped secondary ticketing platform services for the resale of tickets to UK events (final report summary, PDF p. 1). Capped resale platforms, non-specialist channels and social media were not close alternatives for users of uncapped platforms, so their presence did not imply strong competitive pressure on those platforms (PDF p. 3). The finding should not be read as covering all ticket sales. The cited passages do not establish the required disposal or the buyer approval condition. [CMA final report summary on viagogo and StubHub, PDF p1 §1](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=1&search=Completed%20acquisition%20by%20PUG%20LLC%20%28viagogo%29) [CMA final report summary on viagogo and StubHub, PDF p3 §1](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=3&search=%28d%29%20offline%20channels%20%E2%80%93%20such%20as)

The CMA required the merged entity to sell StubHub International—the StubHub business outside North America—and reserved approval of both the purchaser’s identity and the transaction terms. It selected this partial divestiture as the least intrusive effective remedy, not a sale of all of StubHub (PDF p. 14). [CMA final report summary on viagogo and StubHub, PDF p14 §1](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=14&search=suitable%20purchaser%20could%20be%20found.%20We)

## Interpretation

The loss of a close switching option could weaken pressure on the merged platform to keep reseller fees competitive or offer attractive payment terms. A sale to an independent operator could restore that pressure by giving resellers another route to buyers (PDF pp. 3, 13 and 14). [CMA final report summary on viagogo and StubHub, PDF p13 §1](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=13&search=Countervailing%20buyer%20power%2073.%20%7C%20After) [CMA final report summary on viagogo and StubHub, PDF p3 §1](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=3&search=%28d%29%20offline%20channels%20%E2%80%93%20such%20as) [CMA final report summary on viagogo and StubHub, PDF p14 §1](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=14&search=suitable%20purchaser%20could%20be%20found.%20We)

## Alternative and revision signal

The requirement is not evidence that a sale closed or that rivalry had already returned. The CMA proposed implementing the sale through undertakings, with a formal Order as the alternative if suitable undertakings were not obtained in time. CMA approval of a named purchaser and the transaction terms, followed by confirmed completion, would justify treating the disposal as implemented rather than pending (PDF p. 14). [CMA final report summary on viagogo and StubHub, PDF p14 §1](https://assets.publishing.service.gov.uk/media/6018393e8fa8f53fbdc27dab/Summary_V-SH.pdf#page=14&search=suitable%20purchaser%20could%20be%20found.%20We)
