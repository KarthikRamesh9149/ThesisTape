# Financial research memo

As of 2017-10-04T12:00:00Z

How did Berkshire’s announced Pilot Flying J investment divide ownership and control initially, and what change was planned for 2023? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Findings

Initially, under the October 3, 2017 announcement, Berkshire took a 38.6 percent minority equity stake in Pilot Flying J. The Haslam family retained majority ownership at 50.1 percent, and FJ Management, owned by the Maggelet family, retained 11.3 percent until 2023. Jimmy Haslam remained CEO and the management team stayed in place (PDF p. 1). [Berkshire Hathaway invests in Pilot Flying J, PDF p1 §1](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=NEWS%20RELEASE%20CONTACT%3A%20Kim%20Metcalfe%20Zeno)

For 2023, Berkshire planned to buy an additional 41.4 percent equity stake and become the majority owner. Its initial 38.6 percent stake plus the additional 41.4 percentage points would bring it to 80.0 percent ownership. The Haslam family would retain 20 percent and remain involved (PDF p. 1). [Berkshire Hathaway invests in Pilot Flying J, PDF p1 §1](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=NEWS%20RELEASE%20CONTACT%3A%20Kim%20Metcalfe%20Zeno) [Berkshire Hathaway invests in Pilot Flying J, PDF p1 §2](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=Maggelet%20family%2C%20will%20retain%2011.3%20percent)

## Interpretation

The deal separated immediate economic exposure from majority ownership. Berkshire gained a share of Pilot Flying J’s growth without taking the majority or replacing management at the outset. If the second purchase closed as announced, majority ownership could give Berkshire more influence over decisions such as how much cash to reinvest in expansion (PDF p. 1). [Berkshire Hathaway invests in Pilot Flying J, PDF p1 §1](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=NEWS%20RELEASE%20CONTACT%3A%20Kim%20Metcalfe%20Zeno) [Berkshire Hathaway invests in Pilot Flying J, PDF p1 §2](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=Maggelet%20family%2C%20will%20retain%2011.3%20percent)

## Alternative and revision signal

The 2023 transfer was a plan, not a completed change in control. If the second purchase were delayed and ownership otherwise stayed unchanged, Berkshire would remain a minority investor past the planned date. A later company filing confirming the closing date and resulting ownership would be the signal to update that assessment (PDF pp. 1–2). [Berkshire Hathaway invests in Pilot Flying J, PDF p1 §2](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=Maggelet%20family%2C%20will%20retain%2011.3%20percent) [Berkshire Hathaway invests in Pilot Flying J, PDF p2 §2](https://www.berkshirehathaway.com/news/oct0317.pdf#page=2&search=Securities%20Litigation%20Reform%20Act%20of%201995.)

## Checked calculations

- C1. Berkshire ownership after the planned 2023 acquisition (percent) — 38.6 + 41.4 = 80.0 [P1, PDF p1 §1](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=NEWS%20RELEASE%20CONTACT%3A%20Kim%20Metcalfe%20Zeno) [P2, PDF p1 §2](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=Maggelet%20family%2C%20will%20retain%2011.3%20percent)
