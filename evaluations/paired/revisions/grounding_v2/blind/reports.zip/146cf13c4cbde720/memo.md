# Financial research memo

As of 2020-07-31T12:00:00Z

Using the nine months in Apple’s Q3 FY2020 statements, did cash from operations after capital spending cover dividends and share repurchases? Quantify the gap. Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Findings

No. In the nine months ended June 27, 2020, Apple generated 54,573 USD million after capital spending (60,098 − 5,525). Dividends and dividend equivalents plus share repurchases used 65,741 USD million (10,570 + 55,171), leaving an 11,168 USD million shortfall (54,573 − 65,741 = −11,168). All inputs are from PDF p. 3. [Apple FY2020 third-quarter consolidated financial statements, PDF p3 §1](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF) [Apple FY2020 third-quarter consolidated financial statements, PDF p3 §2](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Payments%20for%20dividends%20and%20dividend%20equivalents)

## Interpretation

Apple could not fund both payouts at that pace from operating cash after capital spending alone. If the gap persisted, maintaining that pace would require drawing on existing liquidity or obtaining financing. The comparison does not show how Apple funded the gap: the same cash-flow statement reports both debt issuance and debt repayments (PDF p. 3). [Apple FY2020 third-quarter consolidated financial statements, PDF p3 §1](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF) [Apple FY2020 third-quarter consolidated financial statements, PDF p3 §2](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Payments%20for%20dividends%20and%20dividend%20equivalents)

## Alternative and revision signal

One nine-month period does not establish a recurring funding gap. Buybacks may have been concentrated in this period rather than running at a sustained pace. In the next comparable nine-month filing, check whether lower repurchases bring total payouts within operating cash after capital spending; that would weaken the case for a recurring gap (line items on PDF p. 3). [Apple FY2020 third-quarter consolidated financial statements, PDF p3 §1](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF) [Apple FY2020 third-quarter consolidated financial statements, PDF p3 §2](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Payments%20for%20dividends%20and%20dividend%20equivalents)

## Checked calculations

- C1. Operating cash flow after capital spending, nine months ended June 27, 2020 (USD millions) — 60,098 + (5,525) = 54,573 [P1, PDF p3 §1](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF)
- C2. Combined cash outflow for dividends and share repurchases, nine months ended June 27, 2020 (USD millions) — (10,570) + (55,171) = -65,741 [P2, PDF p3 §2](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Payments%20for%20dividends%20and%20dividend%20equivalents)
- C3. Cash surplus or shortfall after capital spending, dividends and buybacks, nine months ended June 27, 2020 (USD millions) — C1 + C2 = -11,168 [P1, PDF p3 §1](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Apple%20Inc.%20CONDENSED%20CONSOLIDATED%20STATEMENTS%20OF) [P2, PDF p3 §2](https://www.apple.com/newsroom/pdfs/FY20-Q3_Consolidated_Financial_Statements.pdf#page=3&search=Payments%20for%20dividends%20and%20dividend%20equivalents)
