# Financial research memo

As of 2015-08-11T12:00:00Z

What was Berkshire offering Precision Castparts shareholders, how was the headline deal value defined, and what stood between signing and closing? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Findings

On August 10, 2015, Berkshire Hathaway and Precision Castparts (PCC) announced a definitive agreement, unanimously approved by both boards, under which Berkshire would pay $235 per share in cash for all outstanding PCC shares (PDF p. 1). [Berkshire Hathaway to acquire Precision Castparts, PDF p1 §1](https://www.berkshirehathaway.com/news/aug1015.pdf#page=1&search=Berkshire%20Hathaway%20Inc.%20to%20Acquire%20Precision)

The headline transaction value was approximately $37.2 billion, including outstanding PCC net debt. It was not the amount payable to shareholders (PDF p. 1). [Berkshire Hathaway to acquire Precision Castparts, PDF p1 §1](https://www.berkshirehathaway.com/news/aug1015.pdf#page=1&search=Berkshire%20Hathaway%20Inc.%20to%20Acquire%20Precision)

Closing required approval by holders of a majority of PCC’s outstanding shares and satisfaction of customary closing conditions, including Hart–Scott–Rodino clearance and competition clearance in certain foreign jurisdictions. The companies expected closing in the first quarter of calendar 2016 (PDF p. 1). [Berkshire Hathaway to acquire Precision Castparts, PDF p1 §2](https://www.berkshirehathaway.com/news/aug1015.pdf#page=1&search=The%20transaction%20requires%20approval%20by%20a)

## Interpretation

Use the $235 cash offer, not the debt-inclusive headline, to assess what shareholders would receive. The equity payout would be $235 per share multiplied by the number of outstanding PCC shares. The cited announcement excerpts give the price but not the share count or a separate net-debt figure, so they do not support a numerical equity payout or a reconciliation to the headline value (PDF p. 1). [Berkshire Hathaway to acquire Precision Castparts, PDF p1 §1](https://www.berkshirehathaway.com/news/aug1015.pdf#page=1&search=Berkshire%20Hathaway%20Inc.%20to%20Acquire%20Precision)

## Alternative and revision signal

Treat the first-quarter 2016 close as an expectation, not a certainty. A plausible alternative is a later close if a competition authority imposes conditions that take time to resolve. An announced remedy requirement would be a concrete signal to revisit the expected date: a delay would push back receipt of the cash and reduce its present value at a positive discount rate (PDF pp. 1, 3). [Berkshire Hathaway to acquire Precision Castparts, PDF p1 §2](https://www.berkshirehathaway.com/news/aug1015.pdf#page=1&search=The%20transaction%20requires%20approval%20by%20a) [Berkshire Hathaway to acquire Precision Castparts, PDF p3 §2](https://www.berkshirehathaway.com/news/aug1015.pdf#page=3&search=Statements%20in%20this%20press%20release%20regarding) [Berkshire Hathaway to acquire Precision Castparts, PDF p1 §1](https://www.berkshirehathaway.com/news/aug1015.pdf#page=1&search=Berkshire%20Hathaway%20Inc.%20to%20Acquire%20Precision)
