# Financial research memo

As of 2015-08-11T12:00:00Z

What was Berkshire offering Precision Castparts shareholders, how was the headline deal value defined, and what stood between signing and closing? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Findings

On August 10, 2015, Berkshire and Precision Castparts (PCC) announced that both boards had unanimously approved a definitive agreement under which Berkshire would pay $235 per share in cash for all outstanding PCC shares (PDF p. 1). [Berkshire Hathaway to acquire Precision Castparts, PDF p1 §1](https://www.berkshirehathaway.com/news/aug1015.pdf#page=1&search=Berkshire%20Hathaway%20Inc.%20to%20Acquire%20Precision)

The headline value was approximately $ 37.2 billion, including PCC’s outstanding net debt. It was not the aggregate cash payment to shareholders (PDF p. 1). [Berkshire Hathaway to acquire Precision Castparts, PDF p1 §1](https://www.berkshirehathaway.com/news/aug1015.pdf#page=1&search=Berkshire%20Hathaway%20Inc.%20to%20Acquire%20Precision)

Board approval did not clear the way to close on its own. The deal required approval by holders of a majority of PCC’s outstanding shares. The release also flagged obtaining requisite regulatory approval without conditions and satisfying other closing conditions as risks to completion (PDF pp. 1, 3). [Berkshire Hathaway to acquire Precision Castparts, PDF p1 §1](https://www.berkshirehathaway.com/news/aug1015.pdf#page=1&search=Berkshire%20Hathaway%20Inc.%20to%20Acquire%20Precision) [Berkshire Hathaway to acquire Precision Castparts, PDF p3 §2](https://www.berkshirehathaway.com/news/aug1015.pdf#page=3&search=Statements%20in%20this%20press%20release%20regarding)

## Interpretation

If the deal closed on the announced terms, PCC holders would receive a fixed cash amount rather than Berkshire shares, so movements in Berkshire’s share price would not change the $235 per-share payout. For valuation, the headline figure cannot be used as equity proceeds: the supplied excerpts do not quantify PCC’s net debt or give the outstanding share count needed to calculate those proceeds (PDF p. 1). [Berkshire Hathaway to acquire Precision Castparts, PDF p1 §1](https://www.berkshirehathaway.com/news/aug1015.pdf#page=1&search=Berkshire%20Hathaway%20Inc.%20to%20Acquire%20Precision)

## Alternative and revision signal

An alternative to closing on the announced terms is that a regulator attaches conditions, delaying or jeopardizing completion. An announced regulatory decision imposing conditions would be a concrete signal to reassess the likelihood and timing of closing (PDF p. 3). [Berkshire Hathaway to acquire Precision Castparts, PDF p3 §2](https://www.berkshirehathaway.com/news/aug1015.pdf#page=3&search=Statements%20in%20this%20press%20release%20regarding)
