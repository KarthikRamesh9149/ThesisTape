# Financial research memo

As of 2017-10-04T12:00:00Z

How did Berkshire’s announced Pilot Flying J investment divide ownership and control initially, and what change was planned for 2023? Explain one implication and one limitation that could change an analyst’s interpretation. Cite PDF pages for material claims and show the inputs to derived figures.

## Findings

Initially, Berkshire took a 38.6 percent equity stake in Pilot Flying J. The Haslam family retained majority ownership at 50.1 percent, and FJ Management retained 11.3 percent until 2023 (PDF p. 1). [Berkshire Hathaway invests in Pilot Flying J, PDF p1 §1](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=NEWS%20RELEASE%20CONTACT%3A%20Kim%20Metcalfe%20Zeno)

Day-to-day leadership stayed in place: Jimmy Haslam remained CEO, and President Ken Parent and the management team stayed on (PDF p. 1). [Berkshire Hathaway invests in Pilot Flying J, PDF p1 §1](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=NEWS%20RELEASE%20CONTACT%3A%20Kim%20Metcalfe%20Zeno)

For 2023, Berkshire was set to become the majority shareholder by acquiring an additional 41.4 percent equity stake. If completed as announced, Berkshire would own 80.0 percent (38.6 percent initial stake + 41.4 percent additional stake). The Haslam family would retain 20 percent and remain involved (PDF p. 1). [Berkshire Hathaway invests in Pilot Flying J, PDF p1 §1](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=NEWS%20RELEASE%20CONTACT%3A%20Kim%20Metcalfe%20Zeno) [Berkshire Hathaway invests in Pilot Flying J, PDF p1 §2](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=Maggelet%20family%2C%20will%20retain%2011.3%20percent)

## Interpretation

The staged deal gave Berkshire a share of the economic upside immediately without displacing the Haslam family as majority owner or changing operating leadership. The planned second purchase would shift the majority equity position to Berkshire, but that alone would not establish who would run the business day to day (PDF p. 1). [Berkshire Hathaway invests in Pilot Flying J, PDF p1 §1](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=NEWS%20RELEASE%20CONTACT%3A%20Kim%20Metcalfe%20Zeno) [Berkshire Hathaway invests in Pilot Flying J, PDF p1 §2](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=Maggelet%20family%2C%20will%20retain%2011.3%20percent)

## Alternative and revision signal

The release says Berkshire planned to acquire an additional 41.4 percent equity stake in 2023 and thereby become the majority shareholder (PDF p1 §2). This implies Berkshire initially held a minority stake, but the cited passage does not specify the initial ownership split or who controlled day-to-day operations. The release cautions that actual results could differ materially from forecasts (PDF p2 §2), so the announced purchase is not evidence that it closed. If the purchase were delayed and ownership otherwise stayed unchanged, Berkshire would remain a minority shareholder. A closing announcement confirming the additional stake and resulting majority ownership would establish that the planned ownership change occurred. [Berkshire Hathaway invests in Pilot Flying J, PDF p1 §2](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=Maggelet%20family%2C%20will%20retain%2011.3%20percent) [Berkshire Hathaway invests in Pilot Flying J, PDF p2 §2](https://www.berkshirehathaway.com/news/oct0317.pdf#page=2&search=Securities%20Litigation%20Reform%20Act%20of%201995.)

## Checked calculations

- C1. Berkshire’s planned 2023 equity ownership (percent) — 38.6 + 41.4 = 80.0 [P2, PDF p1 §1](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=NEWS%20RELEASE%20CONTACT%3A%20Kim%20Metcalfe%20Zeno) [P3, PDF p1 §2](https://www.berkshirehathaway.com/news/oct0317.pdf#page=1&search=Maggelet%20family%2C%20will%20retain%2011.3%20percent)
