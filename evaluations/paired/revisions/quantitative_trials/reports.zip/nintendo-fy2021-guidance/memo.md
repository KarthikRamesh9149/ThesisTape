# Investment research memo

As of 2020-05-08T12:00:00Z

Forecast direction: higher

**Research question**
At Nintendo’s FY2020 results, what profit attributable to owners of parent did it guide for the year ending March 2021? Compare it with the just-reported year, discuss the risk to the supply of components, and forecast the full-year actual relative to guidance (within means ±2% of the guide, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Answer

The inclusive an inclusive ±2% band around the reference tolerance is an unverified question premise, not a range issued by Nintendo. Applying it to the JPY 200,000 million point guide gives a lower bound of JPY 196,000 million and an upper bound of JPY 204,000 million. Profit must exceed the upper bound, not merely the point guide, for the beat call to hold. [1, PDF p2 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=2&search=Consolidated%20Financial%20Forecast%20for%20the%20Fiscal)

## Evidence

Nintendo observed regional production and shipment delays in February and March, but reported limited impact on the year just ended and said delays appeared to be easing. The full-year supply loss was a risk, not an observed fact: if COVID-19 kept suppliers from delivering necessary parts, Nintendo could not finish enough consoles to meet demand. Sales delayed beyond year-end would also leave fewer new owners buying games during the year. No independent contemporary report is in the available record to corroborate the component mechanism or establish how long shortages would last. [2, PDF p3 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=3&search=Description%20of%20Operating%20Results%201.%20Operating) [3, PDF p3 §4](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=3&search=Net%20cash%20provided%20by%20%28used%20in%29)

## Outlook

Base case: higher. Nintendo planned for fewer Switch hardware and software units than it had just sold, though the software comparison overstates the decline because only actuals include bundles. Animal Crossing sold 11.77 million units after its March launch, and older titles were still growing. That launch volume belongs to the prior year; the case for a beat is that continued game purchases by existing owners can lift full-year software sales and profit above plan without requiring a surge in console production. The launch alone cannot establish that demand will persist. [4, PDF p14 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=14&search=%284%29%20Consolidated%20sales%20units%2C%20number%20of) [2, PDF p3 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=3&search=Description%20of%20Operating%20Results%201.%20Operating)

## What would change the view

The strongest alternative is lower. Nintendo already assumed it could meet full-year demand and release software as planned, so normalizing shipments alone would not be upside. I would switch to lower if Nintendo cut its full-year Switch hardware and software unit forecasts and attributed the cuts to persistent component shortages. That would indicate the disruption was costing sales within the fiscal year rather than shifting them between quarters. [5, PDF p4 §3](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=4&search=forecasting%20are%20105%20yen%20per%20US) [3, PDF p3 §4](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=3&search=Net%20cash%20provided%20by%20%28used%20in%29)

## Checked calculations

- C3. Inclusive lower guidance bound (JPY million) — 200,000 − |200,000| × 2% (question tolerance) = 196,000.00 [1, PDF p2 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=2&search=Consolidated%20Financial%20Forecast%20for%20the%20Fiscal)
- C4. Inclusive upper guidance bound (JPY million) — 200,000 + |200,000| × 2% (question tolerance) = 204,000.00 [1, PDF p2 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=2&search=Consolidated%20Financial%20Forecast%20for%20the%20Fiscal)

## Sources

1. [Nintendo consolidated financial statements for year ended March 2020, PDF p2 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=2&search=Consolidated%20Financial%20Forecast%20for%20the%20Fiscal), available by 2020-05-07.
2. [Nintendo consolidated financial statements for year ended March 2020, PDF p3 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=3&search=Description%20of%20Operating%20Results%201.%20Operating), available by 2020-05-07.
3. [Nintendo consolidated financial statements for year ended March 2020, PDF p3 §4](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=3&search=Net%20cash%20provided%20by%20%28used%20in%29), available by 2020-05-07.
4. [Nintendo consolidated financial statements for year ended March 2020, PDF p14 §1](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=14&search=%284%29%20Consolidated%20sales%20units%2C%20number%20of), available by 2020-05-07.
5. [Nintendo consolidated financial statements for year ended March 2020, PDF p4 §3](https://www.nintendo.co.jp/ir/pdf/2020/200507e.pdf#page=4&search=forecasting%20are%20105%20yen%20per%20US), available by 2020-05-07.
