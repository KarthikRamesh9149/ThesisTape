# Investment research memo

As of 2022-04-27T12:00:00Z

Forecast direction: undetermined

**Research question**
Using Canon’s first quarter FY2022 release, what consolidated net income attributable to Canon Inc. remained to be earned to meet its December year-end projection? Give your call on the reported annual result relative to the projection (within means ±2% of guidance, inclusive). State one base-case direction (lower, within, or higher), the main driver, an alternative and an observable signal that would change the call. Cite PDF pages for material claims and show the inputs to derived figures.

Some parts of the question could not be established from eligible evidence.

## Answer

Canon needed to earn JPY 206,025 million over the remaining three quarters to meet its year-end projection: JPY 252,000 million projected for the year ending December 31, 2022, less JPY 45,975 million earned in the three months ended March 31, 2022. Both figures measure consolidated net income attributable to Canon Inc., after deducting noncontrolling interests—not operating profit or total consolidated net income. [1, PDF p1 §1](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=1&search=CONSOLIDATED%20RESULTS%20FOR%20THE%20FIRST%20QUARTER) [2, PDF p7 §1](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=7&search=CANON%20INC.%20AND%20SUBSIDIARIES%20CONSOLIDATED%202.)

## Evidence

The chip shortage hurt shipments, but its earnings effect was not uniform. Office multifunction-device unit sales fell despite recovering demand, yet Printing pretax income rose 0.7% year on year as services and consumables recovered. Across the group, parts and logistics costs cut gross margin by 0.7 percentage points, but a weaker yen helped gross profit rise 2.6%. The cutoff record contains no dated independent source corroborating Canon’s account; the quarter shows that these offsets mattered, not that they would last. [3, PDF p3 §1](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=3&search=Results%20by%20Segment%20Looking%20at%20Canon%E2%80%99s) [4, PDF p2 §2](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=2&search=production%20delays%20%7C%20due%20to%20the) [5, PDF p2 §3](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=2&search=However%2C%20first-quarter%20gross%20profit%20increased%20by)

## Outlook

Component availability is the main driver. Canon had already used substitute parts and new suppliers to sustain production. I expect those measures to turn more of the recovering printer demand into shipments over the rest of the year. That supports meeting rather than beating the projection: Canon already assumed greater product supply, alongside exchange rates of ¥120 to the dollar and ¥130 to the euro, when it raised guidance. [4, PDF p2 §2](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=2&search=production%20delays%20%7C%20due%20to%20the) [6, PDF p4 §3](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=4&search=devices%20including%20laptops%20and%20tablets.%20With)

## What would change the view

The strongest alternative is lower: even if Canon ships more units, higher component and freight costs could leave too little profit on each sale. I would switch to lower if the next quarterly release showed consolidated gross margin below the first quarter’s 44.9% and attributed the decline to parts and logistics costs outpacing price increases. That would identify cost pressure worsening beyond what Canon could already see when it raised guidance. [4, PDF p2 §2](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=2&search=production%20delays%20%7C%20due%20to%20the) [6, PDF p4 §3](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=4&search=devices%20including%20laptops%20and%20tablets.%20With)

## Checked calculations

- C1. Remaining net income attributable to Canon Inc. (JPY million) — 252,000 − 45,975 = 206,025 [1, PDF p1 §1](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=1&search=CONSOLIDATED%20RESULTS%20FOR%20THE%20FIRST%20QUARTER)

## Sources

1. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p1 §1](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=1&search=CONSOLIDATED%20RESULTS%20FOR%20THE%20FIRST%20QUARTER), available by 2022-04-26.
2. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p7 §1](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=7&search=CANON%20INC.%20AND%20SUBSIDIARIES%20CONSOLIDATED%202.), available by 2022-04-26.
3. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p3 §1](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=3&search=Results%20by%20Segment%20Looking%20at%20Canon%E2%80%99s), available by 2022-04-26.
4. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p2 §2](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=2&search=production%20delays%20%7C%20due%20to%20the), available by 2022-04-26.
5. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p2 §3](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=2&search=However%2C%20first-quarter%20gross%20profit%20increased%20by), available by 2022-04-26.
6. [Canon consolidated results for the first quarter ended March 31, 2022, PDF p4 §3](https://global.canon/en/ir/results/2022/rslt2022q1e.pdf#page=4&search=devices%20including%20laptops%20and%20tablets.%20With), available by 2022-04-26.
